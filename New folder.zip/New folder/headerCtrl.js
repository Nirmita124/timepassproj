(function() {
	'use strict';

	/**
	 * *
	 * 
	 * @ngdoc controller
	 * @name endosos.headerController
	 * @description # headerCtrl This controller manages the header division of
	 *              the all the web pages.
	 * 
	 * 
	 * 
	 */
	angular.module('endososUiApp').controller(
			'headerCtrl',
			[
					'$scope',
					'labelService',
					'$rootScope',
					'$cookies',
					'$window',
					'$location','$http','$timeout',
					function($scope, $labelService, $rootScope, $cookies,
							$window, $location,$http,$timeout) {

						var count3 = $cookies.get('ser');
						var count2 = $cookies.get('soli');
						var count1 = $cookies.get('nue');
						if (isNaN(count3)) {

							$cookies.put('ser', 1);

						}
						if (isNaN(count2)) {

							$cookies.put('soli', 1);

						}
						if (isNaN(count1)) {

							$cookies.put('nue', 1);
						}

						$scope.order1 = [ count1, count2, count3 ];
						var temp = $scope.order1.slice(0);
						$scope.order1.sort(function(a, b) {
							return a - b
						}).reverse();

						for (var i = 0; i < 3; i++) {
							temp[i] = $scope.order1.indexOf(temp[i]) + 1;
						}

						$rootScope.nuevact = temp[0];
						$rootScope.solicitudct = temp[1];
						$rootScope.servicect = temp[2];

						$scope.labels_headerIndex = {};

						$scope.labels_headerIndex = $labelService
								.getHeaderIndexLabels();

						$scope.$watch(function(scope) {
							return $location.url();
						}, function() {
							// console.log($location)
							if ($location.url() == "/"
									|| ($location.url() == "")) {
								$scope.navigationToggle = true;
							} else {
								$scope.navigationToggle = false;
							}
						});

						$scope.notification = function() {
							$rootScope.volver = true;
						}

						$scope.showvolver = function() {
							$rootScope.volver = false;
							window.history.back();

						}
						$scope.func = function() {
							$rootScope.volver = false;

						}

						$rootScope.nueva = function() {

							var value = $cookies.get('nue');
							value++;
							$cookies.put('nue', value);

						}

						$rootScope.service = function() {

							var value = $cookies.get('ser');
							value++;
							$cookies.put('ser', value);

						}
						$rootScope.solicitud = function() {

							var value = $cookies.get('soli');
							value++;
							$cookies.put('soli', value);

						}

						
					
						$scope.invalidate = function() {
				        	var urlType = $location.$$host.substring(0,$location.$$host.indexOf("."));
				        	console.log($location.$$host)
				        	if((urlType !== 'localhost' ) ) {
				        	//if(($location.$$host == 'localhost' ) ) {
				        		$http({
									method : 'GET',
									url : 'http://'+window.location.hostname+':'+window.location.port+window.location.pathname+'v1/endososAPI/closeSession',
									
								}).then(function (result) {
					        		console.log(result.data);
					                $timeout(function() {
					                	console.log("Exit");
					                    $window.location.href = $window.location.origin + '/mxportalendososui/';
					                	$window.location.reload();
					                }, 1000);
					        	});
				        	}
				        };
						
					} ]);

})();