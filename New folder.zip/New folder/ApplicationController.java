package mx.com.metlife.endosos.web.controller;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import mx.com.metlife.endosos.web.utils.GenericResponse;
import mx.com.metlife.endosos.web.utils.LogTrace;
import mx.com.metlife.endosos.web.utils.RetriveIOfToken;
import mx.com.metlife.endosos.web.utils.UploadDetails;
import mx.com.metlife.endosos.web.utils.UploadRequestForJson;
import mx.com.metlife.endosos.web.utils.UploadRequestForXLSX;

@RestController
@RequestMapping(path = "/v1/endososAPI")
@PropertySource("classpath:${geb_env:dev}-geb.properties")
@CrossOrigin
public class ApplicationController {

	private static final Logger logger = LogManager.getLogger(ApplicationController.class);

	@Autowired
	Environment env;

	@Autowired
	private HttpServletRequest request;

	@Autowired
	RetriveIOfToken retriveOfToken;

	@Value("${url.uploadfile.massive}")
	private String uploadFileMassive;

	@Value("${url.uploadfile.json}")
	private String kkk;

	@SuppressWarnings({ "rawtypes" })
	@PostMapping(path = "/uploadClientFile/multi")
	public ResponseEntity uploadFileMulti(@RequestParam("file") MultipartFile file) throws Exception {
		logger.info("File Upload Start");
		ResponseEntity<Object> response = null;
		try {
			if (file != null) {
				MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
				File xlsFile = convert(file);
				body.add("files", new FileSystemResource(xlsFile));
				body.add("files", new FileSystemResource(getJson()));
				response = retriveOfToken.postFormData(body);
				xlsFile.delete();
			}
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		logger.info("File Upload End");
		return response;

	}

	public File getJson() throws JsonGenerationException, JsonMappingException, IOException {
		UploadRequestForXLSX uploadRequest = new UploadRequestForXLSX();
		uploadRequest.setAgentCode("");
		uploadRequest.setAgentName("");
		uploadRequest.setIs_Masive(true);
		uploadRequest.setPromotion("MLU");
		uploadRequest.setChannel("W");
		uploadRequest.setBusinessLine("R");
		uploadRequest.setEmail("juan.hernandez@capgemini.com");
		uploadRequest.setOperationType("1");

		ObjectMapper mapper = new ObjectMapper();
		File jsonFile = new File("uploadXls.json");
		mapper.writeValue(jsonFile, uploadRequest);
		return jsonFile;
	}

	public static File convert(MultipartFile multipart) throws IOException {
		File convFile = new File(generateRandomDigits().toString().concat("_").concat(multipart.getOriginalFilename()));
		try {
			convFile.createNewFile();
			FileOutputStream fos = new FileOutputStream(convFile);
			fos.write(multipart.getBytes());
			fos.close();
		} catch (IOException e) {
			throw e;
		}
		return convFile;
	}

	public static Integer generateRandomDigits() {
		int m = (int) Math.pow(10, 7 - 1);
		return m + new Random().nextInt(9 * m);
	}

	@PostMapping("/logtrace")
	public LogTrace getLogTrace(@RequestBody LogTrace logtrace) {

		System.out.println("Screen Name " + logtrace.getScreenName());

		return new LogTrace();
	}

	@SuppressWarnings({ "rawtypes" })
	@PostMapping(path = "/uploadClientFile/multidata")
	public ResponseEntity uploadFileMultiJson(@RequestBody List<UploadDetails> jsonDTOs) throws Exception {
		ResponseEntity<Object> response = null;
		UploadRequestForJson uploadRequest = getHeaderJsonObject();
		uploadRequest.setEndorsements(jsonDTOs);
		System.out.println(uploadRequest);
		response = retriveOfToken.postFormData(uploadRequest);

		return response;

	}

	public UploadRequestForJson getHeaderJsonObject()
			throws JsonGenerationException, JsonMappingException, IOException {
		UploadRequestForJson uploadRequest = new UploadRequestForJson();
		uploadRequest.setAgentCode("");
		uploadRequest.setAgentName("");
		uploadRequest.setIs_Masive(false);
		uploadRequest.setPromotion("MLU");
		uploadRequest.setChannel("W");
		uploadRequest.setBusinessLine("E");
		uploadRequest.setEmail("juan.hernandez@capgemini.com");
		uploadRequest.setOperationType("1");
		return uploadRequest;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@RequestMapping(value = "/getUserHeaders", method = RequestMethod.GET, produces = "application/json; charset=utf-8")
	public Map<String, String> getHeadersSession() {
		return getHeadersInfo();
	}

	// get user agent
	private String getUserAgent() {
		return request.getHeader("user-agent");
	}

	// get request header
	private Map<String, String> getHeadersInfo() {

		Map<String, String> map = new HashMap<String, String>();

		Enumeration headerNames = request.getHeaderNames();
		while (headerNames.hasMoreElements()) {
			String key = (String) headerNames.nextElement();
			String value = request.getHeader(key);
			map.put(key, value);
		}

		return map;
	}
	
	@GetMapping("/closeSession")
	@CrossOrigin
	public ResponseEntity<Object> closeSession(HttpServletRequest request, HttpServletResponse response) {
		HttpSession session = request.getSession();
		session.invalidate();
		invalidateCookie(response);
		return new ResponseEntity(new GenericResponse("SUCCESSFULLY CLOSED SESSION", true, null), HttpStatus.OK);
	} 
	
	public static void invalidateCookie(HttpServletResponse response) {
		logger.info("invalidating SM cookie");
		Cookie cookie = new Cookie("SMSESSION", "LOGGEDOFF");
		cookie.setPath("/");
		cookie.setMaxAge(60);
		cookie.setDomain("metlife.com");
		cookie.setSecure(true);
		cookie.setHttpOnly(true);
		response.addCookie(cookie);
	}

}
