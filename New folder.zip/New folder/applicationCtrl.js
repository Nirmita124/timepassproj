(function() {
	'use strict';

/**
 * @ngdoc controller
 * @name moiiApp.headerCtrl
 * @description
 * # headerCtrl
 * This controller manages the header division of the all the web pages. 
 * @requires $scope
 * @requires $location
 * @requires labelService
 * 
 * @property {object} UserName : UserName handles the current logged in user.
 * @property {object} SignOff : SignOff handles the log out functionality for the logged in user.
 * @property {object} labels_headerIndex : labels_headerIndex handles the labels for the header division.
 * @property {boolean} navigationToggle : navigationToggle handles the tile navigation menu.
 */
angular
		.module('endososUiApp')
.controller(
		'applicationCtrl',
	[
			'$scope',
			'$rootScope',
			'$http',
			'$window',
			'utilityService',
			'getFileService','controllerService','logtraceService','$timeout',
			function($scope, $rootScope, $http, $window,
					utilityService, getFileService,controllerService,logtraceService,$timeout) {
				//$scope.display= 'M';
				$scope.onloadFun = function() {
					var screenName = "Solicitud de Endoso";
					logtraceService.logtrace(screenName);

				}
				$scope.MyData = [];
				$scope.tableValidation = false;
				$rootScope.volver = false;
				$scope.showw = false;
				$scope.select = 'No';
				$scope.isFormShow = false;
				$scope.folios = [

				{
					date : '22/05/2019 | 18:58:00',
					detail : 'Endoso procesado con exito',
					folio : 'A00312',
					status : 'Movimiento del asegurado',
					kind : 'Procesado'
				}, {
					date : '22/05/2019 | 11:10:50',
					detail : 'Error en la carga',
					folio : '',
					status : 'Servicio poliza',
					kind : 'Error'
				}, {
					date : '22/05/2019 | 09:10:23',
					detail : 'CDFI Listo',
					folio : 'C06362',
					status : 'Movimiento del asegurado',
					kind : 'Procesado'
				}

				];

				$('.input').keyup(function () {
                    var reg = /^[^`~!@#$%\^&*()_+={}|[\]\\:';"<>?,./-]*$/;
                    var regOne= /[^A-Za-z0-9_.]/;
                    
                    if (!this.value.match(/[0-9]/)) {
                     this.value = this.value.replace(/[^0-9]/g, '');
                    }
                    else{
                           if(this.value.length>8 ){
                                  if (this.value.match(regOne)) {
                                        this.value = this.value.replace(regOne, '');
                                  }
                                  if(this.value.match(reg)) {
                                        this.valueOne = this.value;
                                        this.value = this.value.replace(reg, '');
                                        this.value +=this.valueOne.substring(0, 8);
                                         console.log(this.value);
                                  }
                           }
                           }
             });

								$scope.downloadFile = function() {
									$window.open(utilityService.requestExcel());
								}
								var filterdata = $scope.dataJson = {
									"isMassive" : true,
									"promotion" : "some text",
									"agentId" : "some text",
									"agentCode" : "some text",
									"dcn" : "1111676511",
									"idBroker" : "some text",
									"fileName" : "file.xlsx"
								}
								$scope.getFileName = function() {
									$("#loading").modal('show');
									var dcn = "A0000000000000000131";
									controllerService
											.requestFileServicesEndPoint(dcn)
											.then(function success(response)  {
												console.log(response);
												if(response.data == "" && response.xhrStatus == "complete" ){
													$("#closeModal").trigger('click');
													$scope.errorDetails = "Carga completada";
													$("#fileUplaodExit").modal();//
												}else{
												if($.type(response.data) === "string"){
													response.data = JSON.parse(response.data)
												}

												if(response){
													var responseObject = response.data;
													if (angular.isDefined(responseObject.dcn)) {
														$scope.dcnNumber = responseObject.dcn;
														$("#fileUplaod1").modal();
													} else if (angular.isDefined(responseObject.error)) {
														console.log(responseObject);
														//$scope.errorDetails = "Error in File Uploaded";
														$scope.errorDetails = responseObject.error.message;
														$("#fileUplaod1Error").modal();
													} else {
														console.log(response.data);
														//$scope.errorDetails = "Error in File Uploaded";
														$scope.errorDetails = responseObject.error.message;
														$("#fileUplaod1Error").modal();
													}
													
													$timeout(function() {
								     					$("#closeModal").trigger('click');
								    				}, 200);
												 
										/*		 $scope.dcnNumber1 =  response.data.errorsf.message;
												 $("#fileUplaod1").modal();*/
												}
												}
												return response.data;
											}, function error(response)  {
												$("#closeModal").trigger('click');
												console.log(response.data);
												$scope.errorDetails = "Error in File Uploaded";
												$("#fileUplaodError").modal();
												
											});
									/*$timeout(function() { 
										$("#timeoutMessgae").modal();
										$("#closeModal").trigger('click');
									},60050)*/
									
									
				}
				
							
								$scope.validate = function() {
									
								for(var i=0;i<$scope.table.length;i++){
									/*if($scope.table[i].agentKey = '' || $scope.table[i].agentKey == undefined){
										$("#loading").modal('hide');
									}
									else
										{*/
										
									if ($scope.table[i].agentKey == ''
											|| $scope.table[i].agentKey == undefined) {

										$scope.table[i].isValidate1 = false;
									} else {

										$scope.table[i].isValidate1 = true;
									}

									/*if ($scope.table[i].movement == ''
											|| $scope.table[i].movement == undefined) {

										$scope.table[i].isValidate2 = false;

									} else {

										$scope.table[i].isValidate2 = true;
									}*/

									if ($scope.table[i].brachSubBranch == ''
											|| $scope.table[i].brachSubBranch == undefined) {

										$scope.table[i].isValidate3 = false;

									} else {

										$scope.table[i].isValidate3 = true;

									}

									if ($scope.table[i].policyNumber == ''
											|| $scope.table[i].policyNumber == undefined) {

										$scope.table[i].isValidate4 = false;

									} else {

										$scope.table[i].isValidate4 = true;
									}

									if ($scope.table[i].subGroupNumber == ''
											|| $scope.table[i].subGroupNumber == undefined) {

										$scope.table[i].isValidate5 = false;

									} else {

										$scope.table[i].isValidate5 = true;
											
									}

									/*if($scope.table[i].subGrpName=='' || $scope.table[i].subGrpName==undefined){

									             $scope.validationResult[6] = true;

									             $scope.hidecontent6 = true;

									      }else {

									             $scope.validationResult[6] = false;

									             $scope.hidecontent6 = false;

									      }*/

									if ($scope.table[i].categoryNumber == ''
											|| $scope.table[i].categoryNumber == undefined) {

										$scope.table[i].isValidate7 = false;
										
									} else {

										$scope.table[i].isValidate7 = true;

									}

									if ((($scope.table[i].insuredNumber == '' || $scope.table[i].insuredNumber == undefined)
											&& $scope.MyData[i] == 'Dependiente')

											|| (($scope.table[i].insuredNumber == '' || $scope.table[i].insuredNumber == undefined)
													&& $scope.MyData[i] == 'bajaTitular')

											|| (($scope.table[i].insuredNumber == '' || $scope.table[i].insuredNumber == undefined)
													&& $scope.MyData[i] == 'bajaDependiente')

											|| (($scope.table[i].insuredNumber == '' || $scope.table[i].insuredNumber == undefined)
													&& $scope.MyData[i] == 'correction')

											|| (($scope.table[i].insuredNumber == '' || $scope.table[i].insuredNumber == undefined)
													&& $scope.MyData[i] == 'corrSubgrp')

											|| (($scope.table[i].insuredNumber == '' || $scope.table[i].insuredNumber == undefined)
													&& $scope.MyData[i] == 'corrCateg')) {

										$scope.table[i].isValidate8 = false;

									} else {
										$scope.table[i].isValidate8 = true;

									}

									if ((($scope.table[i].birthdate == '' || $scope.table[i].birthdate == undefined)
											&& $scope.MyData[i] == 'Dependiente')

											|| (($scope.table[i].birthdate == '' || $scope.table[i].birthdate == undefined)
													&& $scope.MyData[i] == 'Titular')

											|| (($scope.table[i].birthdate== '' || $scope.table[i].birthdate == undefined)
													&& $scope.MyData[i] == 'corrGenr')

											|| (($scope.table[i].birthdate == '' || $scope.table[i].birthdate == undefined)
													&& $scope.MyData[i] == 'corrNacim')) {

										$scope.table[i].isValidate9 = false;

									} else {

										$scope.table[i].isValidate9 = true;

									}

									if ($scope.table[i].insuredName == ''
											|| $scope.table[i].insuredName == undefined) {//mandate

										$scope.table[i].isValidate10 = false;

									} else {

										$scope.table[i].isValidate10 = true;
									}

									/*if($scope.table[i].workOrder == '' || $scope.table[i].workOrder == undefined){

										$scope.table[i].isValidate11 = false;

									      }else {

									    		$scope.table[i].isValidate11 = true;


									      }*/

									if (($scope.table[i].depNmbr == ''
											|| $scope.table[i].depNmbr == undefined)
											&& $scope.MyData[i] == 'bajaDependiente') {
										
										$scope.table[i].isValidate12 = false;

									} else {

										$scope.table[i].isValidate12 = true;

									}

									if (($scope.table[i].treatment == ''
											|| $scope.table[i].treatment == undefined)
											&& $scope.MyData[i] == 'Titular') {

										$scope.table[i].isValidate13 = false;

									} else {

										$scope.table[i].isValidate13 = true;

									}

									/*if ($scope.table[i].username == ''
											|| $scope.table[i].username == undefined) {//mandate

										$scope.table[i].isValidate14 = false;

									} else {

										$scope.table[i].isValidate14 = true;

									}*/

									if ($scope.table[i].lastName == ''
											|| $scope.table[i].lastName == undefined) {//mandate

										$scope.table[i].isValidate15 = false;

									} else {

										$scope.table[i].isValidate15 = true;

									}

									if ($scope.table[i].middleName == ''
											|| $scope.table[i].middleName == undefined) {//mandate

										$scope.table[i].isValidate16 = false;

									} else {

										$scope.table[i].isValidate16 = true;

									}

									/*if($scope.table[i].ascription=='' || $scope.table[i].ascription==undefined){

										$scope.table[i].isValidate17 = false;

									} else {

										$scope.table[i].isValidate17 = true;

									}*/

									if ((($scope.table[i].gender == '' || $scope.table[i].gender == undefined)
											&& $scope.MyData[i] == 'Dependiente')

											|| (($scope.table[i].gender == '' || $scope.table[i].gender == undefined)
													&& $scope.MyData[i] == 'Titular')

											|| (($scope.table[i].gender == '' || $scope.table[i].gender == undefined)
													&& $scope.MyData[i] == 'corrGenr')) {
										$scope.table[i].isValidate18 = false;

									} else {

										$scope.table[i].isValidate18 = true;

									}

									if ((($scope.table[i].relationship == '' || $scope.table[i].relationship == undefined)
											&& $scope.MyData[i] == 'Dependiente')

											|| (($scope.table[i].relationship == '' || $scope.table[i].relationship == undefined)
													&& $scope.MyData[i] == 'Titular')

											|| (($scope.table[i].relationship == '' || $scope.table[i].relationship == undefined)
													&& $scope.MyData[i] == 'correction')

											|| (($scope.table[i].relationship == '' || $scope.table[i].relationship == undefined)
													&& $scope.MyData[i] == 'bajaTitular')

											|| (($scope.table[i].relationship == '' || $scope.table[i].relationship == undefined)
													&& $scope.MyData[i] == 'bajaDependiente')) {

										$scope.table[i].isValidate19 = false;

									} else {

										$scope.table[i].isValidate19 = true;

									}

									if ((($scope.table[i].civilStatus == '' || $scope.table[i].civilStatus == undefined)
											&& $scope.MyData[i] == 'Dependiente')

											|| (($scope.table[i].civilStatus == '' || $scope.table[i].civilStatus == undefined)
													&& $scope.MyData[i] == 'Titular')) {

										$scope.table[i].isValidate20 = false;

									} else {

										$scope.table[i].isValidate20 = true;

									}
									if ((($scope.table[i].salary == '' || $scope.table[i].salary == undefined)
											&& $scope.MyData[i] == 'Titular')

											|| (($scope.table[i].salary == '' || $scope.table[i].salary == undefined)
													&& $scope.MyData[i] == 'corrSueldo')) {

										$scope.table[i].isValidate21 = false;

									} else {

										$scope.table[i].isValidate21 = true;

									}

									if ((($scope.table[i].startDate == '' || $scope.table[i].startDate == undefined)
											&& $scope.MyData[i] == 'Titular')

											|| (($scope.table[i].startDate == '' || $scope.table[i].startDate == undefined)
													&& $scope.MyData[i] == 'Dependiente')) {

										$scope.table[i].isValidate22 = false;

									} else {

										$scope.table[i].isValidate22 = true;

									}

									if ((($scope.table[i].endDate == '' || $scope.table[i].endDate == undefined)
											&& $scope.MyData[i] == 'bajaTitular')

											|| (($scope.table[i].endDate == '' || $scope.table[i].endDate == undefined)
													&& $scope.MyData[i] == 'bajaDependiente')) {

										$scope.table[i].isValidate23 = false;

									} else {

										$scope.table[i].isValidate23 = true;

									}

									/*if ($scope.table[i].incomeDateEmployee == ''
											|| $scope.table[i].incomeDateEmployee == undefined) {


										$scope.table[i].isValidate24 = false;

									} else {

										$scope.table[i].isValidate24 = true;

									}*/

									if (($scope.table[i].antiqueDate == ''
											|| $scope.table[i].antiqueDate == undefined)
											&& $scope.MyData[i] == 'corrAntig') {
										
										$scope.table[i].isValidate25 = false;

									} else {

										$scope.table[i].isValidate25 = true;

									}


									if (($scope.table[i].rfc == ''
											|| $scope.table[i].rfc == undefined)
											&& $scope.MyData[i] == 'corrRfc') {

										$scope.table[i].isValidate26 = false;

									} else {

										$scope.table[i].isValidate26 = true;

									}

									/*if($scope.curp=='' || $scope.curp==undefined){

										$scope.table[i].isValidate27 = false;

									} else {

										$scope.table[i].isValidate27 = true;

									}*/
									//creating json data****
									/*if($scope.table[i].isValidate1==false || $scope.table[i].isValidate2==false || $scope.table[i].isValidate3==false || $scope.table[i].isValidate4==false 
											|| $scope.table[i].isValidate5==false || $scope.table[i].isValidate7==false || $scope.table[i].isValidate8==false 
											|| $scope.table[i].isValidate10==false || $scope.table[i].isValidate11==false 
											|| $scope.table[i].isValidate14==false || $scope.table[i].isValidate15==false || $scope.table[i].isValidate16==false )
									{
										$scope.tableValidation = false;
									}*/
									if($scope.table[i].isValidate1==false || $scope.table[i].isValidate2==false || $scope.table[i].isValidate3==false || $scope.table[i].isValidate4==false 
											|| $scope.table[i].isValidate5==false || $scope.table[i].isValidate6==false || $scope.table[i].isValidate7==false || $scope.table[i].isValidate8==false 
											|| $scope.table[i].isValidate9==false || $scope.table[i].isValidate10==false || $scope.table[i].isValidate11==false || $scope.table[i].isValidate12==false 
											|| $scope.table[i].isValidate13==false || $scope.table[i].isValidate14==false || $scope.table[i].isValidate15==false || $scope.table[i].isValidate16==false 
											|| $scope.table[i].isValidate18==false || $scope.table[i].isValidate19==false || $scope.table[i].isValidate20==false || $scope.table[i].isValidate21==false 
											|| $scope.table[i].isValidate22==false || $scope.table[i].isValidate23==false || $scope.table[i].isValidate24==false || $scope.table[i].isValidate25==false 
											|| $scope.table[i].isValidate26==false || $scope.table[i].isValidate27==false )
									{
										$scope.tableValidation = false;
									}
									/*else if($scope.table[i].isValidate1==false || $scope.table[i].isValidate3==false || $scope.table[i].isValidate4==false 
											|| $scope.table[i].isValidate5==false || $scope.table[i].isValidate7==false || $scope.table[i].isValidate6==false 
											|| $scope.table[i].isValidate10==false || $scope.table[i].isValidate11==false 
											|| $scope.table[i].isValidate25==false || $scope.table[i].isValidate15==false || $scope.table[i].isValidate16==false )//antiguedad
									{
										$scope.tableValidation = false;
									}*/
									else
										{
											$("#loading").modal('show');
											$scope.tableValidation = true;
										}

										var dropDownValue = $scope.MyData[i];
										$scope.moveTypeABC = "";
										if (dropDownValue == 'Titular'
												|| dropDownValue == 'Dependiente') {
											$scope.table[i].moveType = 1;
										} else if (dropDownValue == 'bajaTitular'
												|| dropDownValue == 'bajaDependiente') {
											$scope.table[i].moveType = 2;
										} else if (dropDownValue == 'correction'
												|| dropDownValue == 'corrSubgrp'
												|| dropDownValue == 'corrCateg'
												|| dropDownValue == 'corrSueldo'
												|| dropDownValue == 'corrNacim'
												|| dropDownValue == 'corrGenr'
												|| dropDownValue == 'corrRfc'
												|| dropDownValue == 'corrAntig') {
											$scope.table[i].moveType = 3;
										}

									
									}
									
									
									if($scope.table && $scope.table.length > 0 && $scope.tableValidation){
										
										var jsonData = $scope.table;
										console.log("data: ",jsonData)
										
										//$timeout($("#timeoutMessgae").modal(),60050)
										
										$http({
													method : 'POST',
													url : 'http://'+window.location.hostname+':'+window.location.port+window.location.pathname+'v1/endososAPI/uploadClientFile/multidata',
													data : jsonData,
													timeout : 60000
													
												}).then( function success(response) {
													 console.log(response);
													
													 var responseObject = angular.fromJson(response.data);
													 if (angular.isDefined(responseObject.dcn)) {
															$scope.dcnNumber = responseObject.dcn;
															$("#fileUplaod1").modal();
														} else if (angular.isDefined(responseObject.error)) {
															console.log(response.data);
															$scope.dcnNumber1 = "Error: " + response.data.message;
															$("#fileUplaod1Error").modal();
														} else {
															console.log(response.data);
															$scope.dcnNumber1 = "Error: " + response.data.message;
															$("#fileUplaod1Error").modal();
														}
													 $timeout(function() {
									     					$("#closeModal").trigger('click');
									    				}, 200);
													 
													 $scope.dcnNumber1 =  response.data.errors.message;
													 $("#fileUplaod1").modal();
													 
												},function  error(response) { 
													$("#closeModal").trigger('click');
													console.log(response);
													//	response.data.error.message*
													$scope.dcnNumber1 = "Error: " + response.data.message;
													$("#fileUplaod1Error").modal();
												
												  });
										setTimeout(function() { 
											$("#timeoutMessgae").modal();
											$("#closepopup").trigger('click');
											$scope.closePopup = function(){
												window.location.reload()
											}
										},60050)
									}
							}
				//adding records on click of button****
				
				const test = {"agentKey":"",
						"isValidate1":true,
						"movement":"",
						"isValidate2":true,
						"brachSubBranch":"",
						"isValidate3":true,
						"policyNumber":"",
						"isValidate4":true,
						"subGroupNumber":"",
						"isValidate5":true,
						"subGroupName":"",
						"isValidate6":true,
						"categoryNumber":"",
						"isValidate7":true,
						"insuredNumber":"",
						"isValidate8":true,
						"birthdate":"",
						"isValidate9":true,
						"insuredName":"",
						"isValidate10":true,
						"workOrder":"",
						"isValidate11":true,
						"depNmbr":"",
						"isValidate12":true,
						"treatment":"",
						"isValidate13":true,
						"username":"",
						"isValidate14":true,
						"lastName":"",
						"isValidate15":true,
						"middleName":"",
						"isValidate16":true,
						"ascription":"",
						"isValidate17":true,
						"gender":"",
						"isValidate18":true,
						"relationship":"",
						"isValidate19":true,
						"civilStatus":"",
						"isValidate20":true,
						"salary":"",
						"isValidate21":true,
						"startDate":"",
						"isValidate22":true,
						"endDate":"",
						"isValidate23":true,
						"incomeDateEmployee":"",
						"isValidate24":true,
						"antiqueDate":"",
						"isValidate25":true,
						"rfc":"",
						"isValidate26":true,
						"curp":"",
						"isValidate27":true,
						"moveType" : ""
						};
				
				$scope.counter = 2;
				$scope.checkIndex =0;
				$scope.table = [];
				$scope.formData = {};
				let check  = JSON.parse(JSON.stringify(test));
				var a = 0;
				check['isShowHide']= false;
				$scope.table.push(check);
				
				//console.log(JSON.stringify($scope.table));
				
				//$scope.table.push(check);
				$scope.addRecord = function() {
					if ($scope.counter <= 10) {
						let check  = JSON.parse(JSON.stringify(test));
						$scope.checkIndex++;
						check['isShowHide']= false;
//						let _object = {...test};
			//			let check = JSON.parse(JSON.stringify(test))
						$scope.table.push(check);
						$scope.counter++;
					}
				}

				$scope.checkCollapse = function(index){

					if($scope.table[index].isShowHide){
						$scope.table[index].isShowHide = false;
					}else{
						$scope.table[index].isShowHide = true;
					}
					
					for(var i=0;i<$scope.table.length;i++){
						if(i != index){
							$scope.table[i].isShowHide = false
						}
					}
				};
				
				//claering model data on change of dropdown****
				$scope.resetData = function(value, index) {
					
					if(value != null){
						$scope.table[index].isShowHide = true;
						
						for(var i=0;i<$scope.table.length;i++){
							if(i != index){
								$scope.table[i].isShowHide = false
							}
						}
						$scope.resetBreak1(index);
					}
					
				}
				
				$scope.$watch(function() {
					return $('#startDate').text();
				}, function(a,b){
					console.log(a,b)
				});
				$scope.resetBreak1 = function(i) {
							
						$scope.table[i].agentKey = '';
						$scope.table[i].isValidate1 = true;

						$scope.table[i].movement = '';
						$scope.table[i].isValidate2 = true;

						$scope.table[i].brachSubBranch = '';
						$scope.table[i].isValidate3 = true;

						$scope.table[i].policyNumber = '';
						$scope.table[i].isValidate4 = true;

						$scope.table[i].subGroupNumber = '';
						$scope.table[i].isValidate5 = true;

						$scope.table[i].subGroupName = '';
						$scope.table[i].isValidate6 = true;

						$scope.table[i].categoryNumber = '';
						$scope.table[i].isValidate7 = true;

						$scope.table[i].insuredNumber = '';
						$scope.table[i].isValidate8 = true;

						$scope.table[i].birthdate = '';
						$scope.table[i].isValidate9 = true;

						$scope.table[i].insuredName = '';
						$scope.table[i].isValidate10 = true;

						$scope.table[i].workOrder = '';
						$scope.table[i].isValidate11 = true;

						$scope.table[i].depNmbr = '';
						$scope.table[i].isValidate12 = true;

						$scope.table[i].treatment = '';
						$scope.table[i].isValidate13 = true;

						$scope.table[i].username = '';
						$scope.table[i].isValidate14 = true;
						
						$scope.table[i].lastName = '';
						$scope.table[i].isValidate15 = true;

						$scope.table[i].middleName = '';
						$scope.table[i].isValidate16 = true;

						$scope.table[i].ascription = '';
						$scope.table[i].isValidate17 = true;

						$scope.table[i].gender = '';
						$scope.table[i].isValidate18 = true;

						$scope.table[i].relationship = '';
						$scope.table[i].isValidate19 = true;

						$scope.table[i].civilStatus = '';
						$scope.table[i].isValidate20 = true;

						$scope.table[i].salary = '';
						$scope.table[i].isValidate21 = true;

						$scope.table[i].startDate = '';
						$scope.table[i].isValidate22 = true;

						$scope.table[i].endDate = '';
						$scope.table[i].isValidate23 = true;

						$scope.table[i].incomeDateEmployee = '';
						$scope.table[i].isValidate24 = true;

						$scope.table[i].antiqueDate = '';
						$scope.table[i].isValidate25 = true;

						$scope.table[i].rfc = '';
						$scope.table[i].isvalidate26 = true;

						$scope.table[i].curp = '';
						$scope.table[i].isValidate27 = true;

				}

			} ]);

})();/**

 *

 */
