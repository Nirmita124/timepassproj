package stepDefinition;

import static org.junit.Assert.assertEquals;

import java.io.File;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.apache.commons.io.FileUtils;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class History {
	WebDriver driver;
	@Given("^Open the Chrome and launch the application$")
	public void open_the_Chrome_and_launch_the_application() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		System.setProperty("webdriver.chrome.driver",
				"C:/Users/sarsriva/Desktop/GEBUIAutomation/Automation/chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("localhost:8090");
		Thread.sleep(1000);
	    
	}

	@When("^Title of the page is Endosos$")
	public void title_of_the_page_is_Endosos() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String title = driver.getTitle();
		assertEquals("Endosos", title);
	}

	@Then("^Click on Servicios$")
	public void click_on_Servicios() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		driver.findElement(By.id("Ingresar")).click();
		Thread.sleep(1000);
	}

	@When("^On Servicios$")
	public void on_Servicios() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    String url=driver.getCurrentUrl();
	    assertEquals("http://localhost:8090/#/services",url);
	}

	@Then("^Click on Documentos de antiguedad$")
	public void click_on_Documentos_de_antig_edad() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    driver.findElement(By.id("historyIngresar")).click();
	    Thread.sleep(1000);
	}

	@When("^On History$")
	public void on_History() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		 String url=driver.getCurrentUrl();
		 assertEquals("http://localhost:8090/#/services/history",url);
	}

	@Then("^Select either Constancia de antiguedad or Carta de antiguedad$")
	public void select_either_Constancia_de_antig_edad_or_Carta_de_antig_edad() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		driver.findElement(By.id("Constancy")).click();
		Thread.sleep(1000);
	    driver.findElement(By.name("clave")).sendKeys("123456");
	    driver.findElement(By.name("ramo")).sendKeys("12345");
	    driver.findElement(By.name("de1")).sendKeys("abcd");
	    driver.findElement(By.name("de")).sendKeys("123");
	    driver.findElement(By.name("asegurado")).sendKeys("asegurado");
	    driver.findElement(By.name("apellido")).sendKeys("apellido");
	    driver.findElement(By.name("materno")).sendKeys("materno");
	    driver.findElement(By.name("certificado")).sendKeys("certificado");
	    Thread.sleep(1000);
	    driver.findElement(By.id("ENVIAR SOLICITUD")).click();
	    Thread.sleep(1000);
	    TakesScreenshot scrShot =((TakesScreenshot)driver);
	    File SrcFile=scrShot.getScreenshotAs(OutputType.FILE);
	    File DestFile=new File("C:/Users/sarsriva/Pictures/Screenshots/screenshot.png");
	    FileUtils.copyFile(SrcFile, DestFile);
	    driver.findElement(By.id("Close2")).click();
	    Thread.sleep(1000);
	    driver.findElement(By.id("Carta")).click();
	    Thread.sleep(1000);
	    driver.findElement(By.name("clave")).sendKeys("123456");
	    driver.findElement(By.name("ramo")).sendKeys("12345");
	    driver.findElement(By.name("de1")).sendKeys("abcd");
	    driver.findElement(By.name("de")).sendKeys("123");
	    driver.findElement(By.name("asegurado")).sendKeys("abcdefg");
	    driver.findElement(By.name("apellido")).sendKeys("jhkknh");
	    driver.findElement(By.id("calendar")).click();
	    driver.findElement(By.xpath("//li[33]")).click();
	    driver.findElement(By.name("materno")).sendKeys("materno");
	    driver.findElement(By.name("certificado")).sendKeys("certificado");
	    driver.findElement(By.id("ENVIAR SOLICITUD")).click();
	    Thread.sleep(1000);
	    driver.findElement(By.id("Close2")).click();
	    Thread.sleep(1000);
	    
	    
	    
	}

	

}
