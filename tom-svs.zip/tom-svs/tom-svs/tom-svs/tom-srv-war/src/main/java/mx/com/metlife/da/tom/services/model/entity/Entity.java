package mx.com.metlife.da.tom.services.model.entity;

import lombok.Data;

@Data
public class Entity {

	private String date;
}
