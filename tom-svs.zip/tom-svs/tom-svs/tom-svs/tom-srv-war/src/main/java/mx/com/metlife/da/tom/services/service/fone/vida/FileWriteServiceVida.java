package mx.com.metlife.da.tom.services.service.fone.vida;

import static org.slf4j.LoggerFactory.getLogger;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.springframework.stereotype.Service;

@Service
public class FileWriteServiceVida {

	private static final Logger logger = getLogger(FileWriteServiceVida.class);
	
	public Object writeToTextFileVida(HashMap<Integer, HashMap<LayoutFoneVida, String>> hashMapOfAllRows,
			String fileName, String parentFileName) {
		

		File op = new File(fileName.concat(ConstantVida.OUTPUTFILE));
		logger.info(op.getAbsolutePath());

		List<String> collect = hashMapOfAllRows.entrySet().stream().map(row -> {
			StringBuilder sb = new StringBuilder();
			for (LayoutFoneVida key : LayoutFoneVida.values()) {
				String value = row.getValue().get(key) == null ? "" : row.getValue().get(key);
				sb.append(value);
			}
			return sb.toString();
		}).collect(Collectors.toList());

		hashMapOfAllRows = null;

		try (FileWriter fw = new FileWriter(parentFileName.concat(ConstantVida.OUTPUTFILE), true);
				BufferedWriter bw = new BufferedWriter(fw);
				PrintWriter out = new PrintWriter(bw)) {
			collect.forEach(out::println);
		} catch (IOException e) {
			logger.info("Error Writing file:" , fileName );
			logger.info(" Error: {}" , e.getMessage());
		}

		collect = null;
		
		return null;
	}

	public void processAndWriteErrorCSVVida(HashMap<Integer, ArrayList<String>> errorLibyLNandEval, String fileName)
			throws IOException {

		File csvOutputFile = new File("Error.csv");

		try (FileWriter fileWriter = new FileWriter(csvOutputFile, true);
				BufferedReader fileReader = new BufferedReader(new FileReader(csvOutputFile));
				PrintWriter printWriter = new PrintWriter(fileWriter, true)) {

			if (fileReader.readLine() == null) {
				String header = Arrays.asList("Registro", "Nombre del Archivo", "Detalle Error").stream()
						.collect(Collectors.joining(","));
				printWriter.println(header);
			}
			String fileNameForErrorColumn = fileName.substring(fileName.lastIndexOf("/") + 1, fileName.length());
			errorLibyLNandEval.entrySet().stream().map(row -> {
				
				return String.join(",", Arrays.asList(String.valueOf(row.getKey()), fileNameForErrorColumn,
						row.getValue().get(0).concat(" - ").concat(row.getValue().get(1))));
			}).forEach(printWriter::println);
		}

	}

}
