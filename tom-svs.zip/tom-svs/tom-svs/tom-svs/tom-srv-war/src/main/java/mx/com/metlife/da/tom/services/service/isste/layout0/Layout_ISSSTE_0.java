/**
 * 
 */
package mx.com.metlife.da.tom.services.service.isste.layout0;

/**
 * @author Capgemini
 * @since 09-07-2019
 */

public enum Layout_ISSSTE_0 {
	
	CONCEPTO("CONCEPTO", 3),
	LOCALIDAD("LOCALIDAD", 10),
	NUM_PENSION("NUM_PENSION", 10),
	RFC("RFC", 13),
	NOMBRE("NOMBRE", 34),
	SEXO("SEXO", 1),
	IMP_PENSION("IMP_PENSION", 30),
	IMP_DESCUENTO("IMP_DESCUENTO", 30),
	RAMO("RAMO", 6),
	FECHA_INICIO("FECHA_INICIO", 6),
	ARCHIVO_ORIGINARIO("ARCHIVO_ORIGINARIO", 30),
	OFICIO("OFICIO", 30),
	MES_PAGO("MES_PAGO", 10),
	MES_REPORTADO("MES_REPORTADO", 10),
	ID("ID", 10),
	POLIZA("POLIZA", 15),
	NOMBRE_CLIENTE("NOMBRE_CLIENTE", 50),
	SUBGRUPO("SUBGRUPO", 15),
	FOLIO("FOLIO", 10),
	MOVIMIENTO("MOVIMIENTO", 10);
	
	private final String columnName;
    private final Integer outputConstraint;

    Layout_ISSSTE_0(String key, Integer value) {
        this.columnName = key;
        this.outputConstraint = value;
    }

	public String getColumnName() {
		return columnName;
	}

	public Integer getOutputConstraint() {
		return outputConstraint;
	}
    
}
