package mx.com.metlife.da.tom.services.service.dto;

import lombok.Data;

@Data
public class UploadFileRequest {
	
	
	
}
