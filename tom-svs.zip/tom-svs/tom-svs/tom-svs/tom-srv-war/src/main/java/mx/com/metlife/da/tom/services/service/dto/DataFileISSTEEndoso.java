package mx.com.metlife.da.tom.services.service.dto;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.gizbel.excel.annotations.ExcelBean;
import com.gizbel.excel.annotations.ExcelColumnIndex;

import lombok.Data;

@Data
@ExcelBean
public class DataFileISSTEEndoso {

	@ExcelColumnIndex(columnIndex = "0", dataType = "int")
	@NotEmpty
	@Size(min = 1, max = 5, message = "CPTO length cannot exceed more than 5.")
	@Pattern(regexp="\\d+", message="CPTO must be numeric with no spaces")
	public String cpto;
	
	@ExcelColumnIndex(columnIndex = "1", dataType = "string")
	@NotEmpty
	@Size(min = 1, max = 7, message = "Localidad length cannot exceed more than 7.")
	@Pattern(regexp="^[a-zA-Z0-9-]*$", message="Localidad must be alphanumeric with no spaces")
	public int localidad;

	@ExcelColumnIndex(columnIndex = "2", dataType = "int")
	@NotEmpty
	@Size(min = 1, max = 7, message = "num_Pen length cannot exceed more than 7.")
	@Pattern(regexp="\\d+", message="num_Pen must be numeric with no spaces")
	public String numPen;

	@ExcelColumnIndex(columnIndex = "3", dataType = "string")
	@NotEmpty
	@Size(min = 10, max = 14, message = "RFC length cannot exceed more than 7.")
	@Pattern(regexp="^[a-zA-Z0-9]*$", message="RFC must be alphanumeric with no spaces")
	public String rfc;
	
	@ExcelColumnIndex(columnIndex = "4", dataType = "string")
	@NotEmpty
	@Size(min = 1, max = 34, message = "Nombre length cannot exceed more than 7.")
	@Pattern(regexp="^[a-zA-Z ]*$", message="Nombre must be alphabetic")
	public String nombre;
	
	@ExcelColumnIndex(columnIndex = "5", dataType = "string")
	@Size(min = 1, max = 1, message = "Genero length cannot exceed more than 1.")
	@Pattern(regexp="M|F|m|f| ", message="Genero must be alphabetic")
	public String generoAb;
	
	@ExcelColumnIndex(columnIndex = "6", dataType = "double")
	@NotEmpty
	@Size(min = 1, max = 9, message = "imp_pen length cannot exceed more than 9.")
	@Pattern(regexp="[0-9]{1,8}(\\.[0-9]*)?", message="imp_pen must be a decimal value")
	public double impPen;
	
	@ExcelColumnIndex(columnIndex = "7", dataType = "string")
	@NotEmpty
	@Size(min = 1, max = 9, message = "impCPTO length cannot exceed more than 9.")
	@Pattern(regexp="[0-9]{1,8}(\\.[0-9]*)?", message="impCPTO must be a decimal value")
	public String impCPTO;
	
	@ExcelColumnIndex(columnIndex = "8", dataType = "int")
	@NotEmpty
	@Size(min = 1, max = 5, message = "RAMO length cannot exceed more than 5.")
	@Pattern(regexp="\\d+", message="RAMO must be numeric with no spaces")
	public int ramo;


	@ExcelColumnIndex(columnIndex = "9", dataType = "int")
	@NotEmpty
	@Size(min = 1, max = 6, message = "fetchaIni length cannot exceed more than 6.")
	@Pattern(regexp="\\d+", message="fetchaIni must be numeric with no spaces")
	public String fetchaIni;
	
	@ExcelColumnIndex(columnIndex = "10", dataType = "int")
	@Size(min = 1, max = 3, message = "tip_pen_act length cannot exceed more than 6.")
	@Pattern(regexp="\\d+ ", message="tip_pen_act must be numeric with no spaces")
	public String tipPenAct;
	
}
