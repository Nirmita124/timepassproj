package mx.com.metlife.da.tom.services.service;

import java.io.FileWriter;
import java.io.Writer;
import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Service;

import com.opencsv.CSVWriter;
import com.opencsv.bean.ColumnPositionMappingStrategy;
import com.opencsv.bean.HeaderColumnNameMappingStrategy;
import com.opencsv.bean.StatefulBeanToCsv;
import com.opencsv.bean.StatefulBeanToCsvBuilder;
import com.opencsv.bean.comparator.LiteralComparator;

import mx.com.metlife.da.tom.services.service.dto.FileDataFilter2;
import mx.com.metlife.da.tom.services.utility.CSVUtils;

@Service
public class GenerateOutputService {

	public static void generateOutPutFile(List<FileDataFilter2> listOfDataItems) throws Exception {
		String csvFile = "C:\\Users\\prasjain\\Desktop\\PSJ\\Javatest\\output.csv";
		try (FileWriter writer = new FileWriter(csvFile)) {

			CSVUtils.writeLine(writer, listOfDataItems);// PT1.561S
			writer.flush();
		} catch (Exception e) {
			throw e;
		}
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static void generateOutPutFileWithCSVUtil(List<FileDataFilter2> listOfDataItems) throws Exception {
		String csvFile = "C:\\Users\\prasjain\\Desktop\\PSJ\\Javatest\\outputWithCSVUtil.csv";
		try (FileWriter writer = new FileWriter(csvFile)) {
			ColumnPositionMappingStrategy mappingStrategy = new ColumnPositionMappingStrategy();
			mappingStrategy.setType(FileDataFilter2.class);
			StringBuilder sb = new StringBuilder();
			List<Field> fields = Arrays.asList(FileDataFilter2.class.getDeclaredFields());
			fields.forEach(field -> {
				sb.append(field.getName()).append(",");
			});

			// Arrange column name as provided in below array.
			String[] columns = sb.toString().split(",");
			mappingStrategy.setColumnMapping(columns);

			// Creating StatefulBeanToCsv object
			StatefulBeanToCsvBuilder<FileDataFilter2> builder = new StatefulBeanToCsvBuilder(writer);
			StatefulBeanToCsv beanWriter = builder.withMappingStrategy(mappingStrategy).build();

			// Write list to StatefulBeanToCsv object
			beanWriter.write(listOfDataItems);

		} catch (Exception e) {
			throw e;
		}
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static void generateOutPutFileWithCSVUtil2(List<FileDataFilter2> listOfDataItems) throws Exception {

		/*
		 * try (Writer writer = new FileWriter(
		 * "C:\\Users\\prasjain\\Desktop\\PSJ\\Javatest\\outputWithCSVUtil2.csv")) {
		 * StatefulBeanToCsv beanToCsv = new StatefulBeanToCsvBuilder(writer).build();
		 * beanToCsv.write(listOfDataItems); writer.close(); }
		 */
		try (Writer writer = new FileWriter("C:\\Users\\prasjain\\Desktop\\PSJ\\Javatest\\outputWithCSVUtil2.csv")) {

			StatefulBeanToCsv sbc = new StatefulBeanToCsvBuilder(writer).withSeparator(CSVWriter.DEFAULT_SEPARATOR)
					.build();

			sbc.write(listOfDataItems);
			writer.close();
		}
	}

}
