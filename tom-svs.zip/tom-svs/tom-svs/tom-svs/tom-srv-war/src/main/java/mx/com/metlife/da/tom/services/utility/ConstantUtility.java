package mx.com.metlife.da.tom.services.utility;

/**
 * Class to keep constants.
 * 
 * @author Capgemini
 * @since 26/03/2019
 */
public class ConstantUtility {

	private ConstantUtility() {
		throw new IllegalStateException("ConstantUtility class");
	}

	public static final String DATE_FORMAT = "MM/dd/yyyy";
	public static final String DATE_FORMAT_DD_MM_YYYY = "dd/MM/yyyy";
	public static final String TOM_APP_NAME = "[App Name = TOM] ";

	public static final String LOG_MSG_EXECUTING = "Execution STARTED of service - ";
	public static final String LOG_MSG_EXECUTED = " Execution ENDED of service - ";
	public static final String LOG_MSG_ERROR_EXECUTING = " ERROR executing service - ";
	public static final String LOG_MSG_EXECUTING_CLASS = "Executing class: ";
	public static final String LOG_MSG_EXECUTING_METHOD = "Started executing method: ";
	public static final String LOG_MSG_EXECUTED_METHOD = "Executed method: ";
	public static final String LOG_MSG_SERVICE_START_TIME = "Start time of execution: ";
	public static final String LOG_MSG_SERVICE_EXECUTION_TIME = "Execution time in Seconds: ";

	public static final String SEARCH_TOM_METHOD = "searchTOM ";

	public static final String NO_DATA_FOUND = "No data found";
	public static final String UN_AUTHORIZED_USER = "Unauthorized User";
	public static final String RESULT_SET_EMPTY = "Result set is empty.";
	public static final String INTERNAL_ERROR = "Error in Search";
	public static final String SEARCH_CRITERIA_NOT_ENOUGH = "Not enough inforamation to Perform Search";

	// Error Code Constant
	public static final String ERROR_CODE_500 = "500";
	public static final String ERROR_MESSAGE_500 = "Internal error";
	public static final String ERROR_CODE_401 = "401";
	public static final String ERROR_CODE_400 = "400";
	public static final String ERROR_CODE_202 = "202";
	public static final String SUCCESS_CODE_200 = "200";

	public static final String OPENING_BRACET = " [ ";
	public static final String CLOSING_BRACKET = " ] ";
	public static final String EQUAL_SIGN = " = ";
	
	public static final String LOGGER_DOUBLE_BRACET = "{} {}";
	
	public static final String LOGGER_TRIPLE_BRACET = "{} {} {}";

	public static final String SPACE = " ";
}

