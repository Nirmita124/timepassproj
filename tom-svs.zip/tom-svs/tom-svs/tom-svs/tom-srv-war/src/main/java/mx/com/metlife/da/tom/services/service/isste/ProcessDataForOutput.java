package mx.com.metlife.da.tom.services.service.isste;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Locale;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Service;

import mx.com.metlife.da.tom.services.utility.writeUtils.WriteUtils;

/**
 * @author Capgemini
 * @since 08-07-2019
 */
@Service
@PropertySource({"classpath:application.properties","classpath:issteReadWrite.properties"})
public class ProcessDataForOutput {
	
	@Value("#{${outputLengthConstraint}}")
	private HashMap<String, String> outputLengthConstraint;
	
	@Autowired
	private FileWriteService fileWriteService;
	
	public Object processTextOutPut (ArrayList<ArrayList<String>> arrayListOfRows, String fileName) {
		
		Calendar c = Calendar.getInstance();
		String displayName = c.getDisplayName(Calendar.MONTH, Calendar.LONG, new Locale("es", "ES"));
		String monthName = StringUtils.leftPad(displayName.toUpperCase(), 10);
		
		String trimmedfileName = StringUtils.leftPad(fileName, 30);
		
		arrayListOfRows.forEach( row -> {
			
			if(row.get(0).length() < 3 ) {
				row.set(0, StringUtils.leftPad(row.get(0), 3)) ;
			}
			
			if(row.get(1).length() < 10 ) {
				row.set(1, StringUtils.leftPad(row.get(1), 10)) ;
			}
			
			if(row.get(2).length() < 10 ) {
				row.set(2, StringUtils.leftPad(row.get(2), 10));
			}
			
			row.set(3, StringUtils.remove(row.get(3), '-'));
			if(row.get(3).length() < 13 ) {
				row.set(3, StringUtils.leftPad(row.get(3), 13));
			}
			
			String truncated = StringUtils.truncate(row.get(4), 30);
			row.set(4, StringUtils.leftPad(truncated, 30));
			truncated = null;
			
			row.set(5, WriteUtils.stringifyWithDecimals(row.get(5)));
			
			if(row.get(5).length() < 30 ) {
				row.set(5, StringUtils.leftPad(row.get(5), 30));
			}
			
			row.set(6, WriteUtils.stringifyWithDecimals(row.get(6)));
			
			if(row.get(6).length() < 30 ) {
				row.set(6, StringUtils.leftPad(row.get(6), 30));
			}
			
			if(row.get(7).length() < 6 ) {
				row.set(7, StringUtils.leftPad(row.get(7), 6));
			}
			
			if(row.get(8).length() < 6 ) {
				row.set(8, StringUtils.leftPad(row.get(8), 6));
			}
			
			//Add Gender Column
			row.add(5, "M");
			
			//Add ARCHIVO_ORIGINARIO
			row.add(trimmedfileName);
			
			//Add MES_REPORTADO
			row.add(monthName);
			
			//Add Id
			String id = StringUtils.joinWith("-", row.get(0).intern(), row.get(8).trim().intern());
			row.add(StringUtils.leftPad(id, 10));
			
		});
		
		c = null;
		
		fileWriteService.writeToTextFile(arrayListOfRows);
		
		return arrayListOfRows;
	}

}
