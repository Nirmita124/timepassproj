package mx.com.metlife.da.tom.services.service.isste03;

import static mx.com.metlife.da.tom.services.service.isste03.EnumISSTE3.PERIODO;
import static mx.com.metlife.da.tom.services.service.isste03.EnumISSTE3.DESCRIPCION;
import static mx.com.metlife.da.tom.services.service.isste03.EnumISSTE3.DEPENDENCIA;
import static mx.com.metlife.da.tom.services.service.isste03.EnumISSTE3.HOMO;
import static mx.com.metlife.da.tom.services.service.isste03.EnumISSTE3.CURP;
import static mx.com.metlife.da.tom.services.service.isste03.EnumISSTE3.NIV_TAB;
import static mx.com.metlife.da.tom.services.service.isste03.EnumISSTE3.PERCEPCION;
import static mx.com.metlife.da.tom.services.service.isste03.EnumISSTE3.PRIMA_BASICA;
import static mx.com.metlife.da.tom.services.service.isste03.EnumISSTE3.PRIMA;
import static mx.com.metlife.da.tom.services.service.isste03.EnumISSTE3.APELLIDO_PATERNO;
import static mx.com.metlife.da.tom.services.service.isste03.EnumISSTE3.APELLIDO_MATERNO;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;

public class RemoveColumnISSSTE03 {

	@Autowired
	private FileWriteServiceISSSTE03 fileWriteServiceISSSTE03;

	@SuppressWarnings("unlikely-arg-type")
	public Object removeColumnDataISSSTE3(HashMap<Integer, HashMap<EnumISSTE3, String>> arrayListOfSTringsBR,
			String parentFileName, String fileName) {

		arrayListOfSTringsBR.forEach((lineNumber, row) -> {

			row.remove(PERIODO);
			row.remove(DESCRIPCION);
			row.remove(DEPENDENCIA);
			row.remove(HOMO);
			row.remove(CURP);
			row.remove(NIV_TAB);
			row.remove(PERCEPCION);
			row.remove(PRIMA_BASICA);
			row.remove(PRIMA);
			row.remove(APELLIDO_PATERNO);
			row.remove(APELLIDO_MATERNO);

		});

		fileWriteServiceISSSTE03 = new FileWriteServiceISSSTE03();
		return fileWriteServiceISSSTE03.writeToTextFile(arrayListOfSTringsBR, parentFileName, fileName);

	}

}
