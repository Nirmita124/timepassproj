package mx.com.metlife.da.tom.services.service.fone.vida;

public class ConstantVida {

	public static final String CVE_UR_ERROR = "CVE_UR is not alphaNumeric value";
	public static final String CICLO_ERROR = "CICLO is not numeric value";
	public static final String CVE_MES_ERROR = "CVE_MES is not numeric value";
	public static final String PERIODO_ERROR = "PERIODO is not in date format";
	public static final String TIPO_NOMINA_ERROR = "TIPO_NOMINA is not in alphabetical value";
	public static final String NO_NOMINA_ERROR = "NO_NOMINA is not in numeric value";
	public static final String CURP_ERROR = "CURP is not in alphaNumeric value";
	public static final String RFC_ERROR = "RFC is not in alphaNumeric value";
	public static final String TIPO_PERIODO_ERROR = "TIPO_PERIODO is not in alphabetical value";
	public static final String NUM_PERIODO_ERROR = "NUM_PERIODO is not in alphaNumeric value";
	public static final String NUM_COMPROBANTE_ERROR = "NUM_COMPROBANTE is not in numeric value";
	public static final String CVE_CONCEPTO_ERROR = "CVE_CONCEPTO is not in numeric value";
	public static final String IMPORTE_ERROR = "IMPORTE is not in decimal value";
	public static final String TIPO_CONCEPTO_ERROR = "TIPO_CONCEPTO is not in Uppercase";
	public static final String CVE_PLAZA_ERROR = "CVE_PLAZA is not in alphaNumeric value";
	public static final String NOMBRE_ERROR = "NOMBRE is not in alphabetic value";
	public static final String APELLIDO_PATERNO_ERROR = "APELLIDO_PATERNO is not an alphabetical value";
	public static final String APELLIDO_MATERNO_ERROR = "APELLIDO_MATERNO is not an alphabetical value";
	public static final String ZONA_ECONOMICA_ERROR = "ZONA_ECONOMICA is not an alphabetical value";
	public static final String NIVEL_ERROR = "NIVEL is not in alphaNumeric value";
	public static final String CÓDIGO_ERROR = "CÓDIGO is not in alphaNumeric value";
	public static final String IS_ISR_ERROR = "IS_ISR is not in numeric value";
	public static final String MODELO_ERROR = "MODELO is not in numeric value";
	public static final String PORCENTAJE_ERROR = "PORCENTAJE is not in decimal value";
	public static final String APORTACION_ERROR = "APORTACION is not in decimal value";

	public static final String OUTPUTFILE = "-Output.txt";
	
}
