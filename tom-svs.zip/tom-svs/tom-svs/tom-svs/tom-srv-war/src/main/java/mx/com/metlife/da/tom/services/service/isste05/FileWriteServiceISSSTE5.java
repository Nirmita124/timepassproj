package mx.com.metlife.da.tom.services.service.isste05;

import static org.slf4j.LoggerFactory.getLogger;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.springframework.stereotype.Service;

@Service
public class FileWriteServiceISSSTE5 {

	private static final Logger logger = getLogger(FileWriteServiceISSSTE5.class);
	
	public Object writeToTextFileISSSTE5(HashMap<Integer, HashMap<LayoutInputISSSTE5, String>> arrayListOfSTringsBR,
			String parentFileName, String fileName) {
		

		File op = new File(fileName.concat(ConstantISSSTE5.OUTPUTFILE));
		logger.info(op.getAbsolutePath());

		List<String> collect = arrayListOfSTringsBR.entrySet().stream().map(row -> {
			StringBuilder sb = new StringBuilder();
			for (LayoutInputISSSTE5 key : LayoutInputISSSTE5.values()) {
				String value = row.getValue().get(key) == null ? "" : row.getValue().get(key);
				sb.append(value);
			}
			return sb.toString();
		}).collect(Collectors.toList());

		arrayListOfSTringsBR = null;

		try (FileWriter fw = new FileWriter(parentFileName.concat(ConstantISSSTE5.OUTPUTFILE), true);
				BufferedWriter bw = new BufferedWriter(fw);
				PrintWriter out = new PrintWriter(bw)) {
			collect.forEach(out::println);
		} catch (IOException e) {
			logger.info("Error Writing file:" , fileName );
			logger.info(" Error: {}" , e.getMessage());
		}

		collect = null;
		
		return null;
	}

	public void processAndWriteErrorCSVISSSTE5(HashMap<Integer, ArrayList<String>> errorLibyLNandEval, String fileName)
			throws IOException {

		File csvOutputFile = new File("Error.csv");

		try (FileWriter fileWriter = new FileWriter(csvOutputFile, true);
				BufferedReader fileReader = new BufferedReader(new FileReader(csvOutputFile));
				PrintWriter printWriter = new PrintWriter(fileWriter, true)) {

			if (fileReader.readLine() == null) {
				String header = Arrays.asList("Registro", "Nombre del Archivo", "Detalle Error").stream()
						.collect(Collectors.joining(","));
				printWriter.println(header);
			}
			String fileNameForErrorColumn = fileName.substring(fileName.lastIndexOf("/") + 1, fileName.length());
			errorLibyLNandEval.entrySet().stream().map(row -> {
			return String.join(",", Arrays.asList(String.valueOf(row.getKey()), fileNameForErrorColumn,
						row.getValue().get(0).concat("-").concat(row.getValue().get(1))));
			}).forEach(printWriter::println);
		}

	}

}
