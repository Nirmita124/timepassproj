package mx.com.metlife.da.tom.services.service.isste05;

import static org.slf4j.LoggerFactory.getLogger;

import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import mx.com.metlife.da.tom.services.utility.readUtils.StringUtilsOverRide;

@Service
public class ValidateDataTextISSSTE5 {

	private static final Logger logger = getLogger(ValidateDataTextISSSTE5.class);

	
	 @Autowired
	 private ProcessDataForOutputISSSTE5 processOutputISSSTE5;
	 
	 @Autowired 
	 private FileWriteServiceISSSTE5 fileWriteServiceISSSTE5;
	

	public ArrayList<String> validateDataTextISSSTE5(
			HashMap<Integer, HashMap<LayoutInputISSSTE5, String>> arrayListOfSTringsBR, String parentFileName,
			String fileName) throws Exception {

		Instant validationStart = Instant.now();

		ExecutorService executor = Executors.newFixedThreadPool(6);

		List<Callable<Map<Integer, HashMap<LayoutInputISSSTE5, String>>>> callables = Arrays.asList(() -> {
			// SEGURO

			Stream<Entry<Integer, HashMap<LayoutInputISSSTE5, String>>> stream = arrayListOfSTringsBR.entrySet()
					.stream();
	
				
			Map<Integer, HashMap<LayoutInputISSSTE5, String>> collect2 = stream.filter(row -> {
				return !StringUtils.isNumeric(row.getValue().get(LayoutInputISSSTE5.CONCEPTO));
			}).collect(Collectors.toMap(entry -> entry.getKey(), entry -> entry.getValue()));

			return collect2;
		}, () -> {
			// LOCALIDAD

			Stream<Entry<Integer, HashMap<LayoutInputISSSTE5, String>>> stream = arrayListOfSTringsBR.entrySet()
					.stream();

			Map<Integer, HashMap<LayoutInputISSSTE5, String>> collect2 = stream.filter(row -> {
				return !StringUtils.isAlphanumeric(row.getValue().get(LayoutInputISSSTE5.LOCALIDAD));
			}).collect(Collectors.toMap(entry -> entry.getKey(), entry -> entry.getValue()));

			return collect2;
		}, () -> {
			// NUM_PENSION

			Stream<Entry<Integer, HashMap<LayoutInputISSSTE5, String>>> stream = arrayListOfSTringsBR.entrySet()
					.stream();

			Map<Integer, HashMap<LayoutInputISSSTE5, String>> collect2 = stream.filter(row -> {
				return !StringUtils.isNumeric(row.getValue().get(LayoutInputISSSTE5.NUM_PENSION));
			}).collect(Collectors.toMap(entry -> entry.getKey(), entry -> entry.getValue()));

			return collect2;
		}, () -> {
			// RFC

			Stream<Entry<Integer, HashMap<LayoutInputISSSTE5, String>>> stream = arrayListOfSTringsBR.entrySet()
					.stream();

			Map<Integer, HashMap<LayoutInputISSSTE5, String>> collect2 = stream.filter(row -> {
				return !StringUtilsOverRide.isAlphanumericSpace(row.getValue().get(LayoutInputISSSTE5.RFC));
			}).collect(Collectors.toMap(entry -> entry.getKey(), entry -> entry.getValue()));

			return collect2;
		}, () -> {
			// NOMBRE

			Stream<Entry<Integer, HashMap<LayoutInputISSSTE5, String>>> stream = arrayListOfSTringsBR.entrySet()
					.stream();

			Map<Integer, HashMap<LayoutInputISSSTE5, String>> collect2 = stream.filter(row -> {
				return !StringUtilsOverRide.isAlphaSpaceDotApostrophe(row.getValue().get(LayoutInputISSSTE5.NOMBRE));
			}).collect(Collectors.toMap(entry -> entry.getKey(), entry -> entry.getValue()));

			return collect2;
		}, () -> {
			// RAMO

			Stream<Entry<Integer, HashMap<LayoutInputISSSTE5, String>>> stream = arrayListOfSTringsBR.entrySet()
					.stream();

			Map<Integer, HashMap<LayoutInputISSSTE5, String>> collect2 = stream.filter(row -> {
				return !StringUtils.isNumeric(row.getValue().get(LayoutInputISSSTE5.RAMO));
			}).collect(Collectors.toMap(entry -> entry.getKey(), entry -> entry.getValue()));

			return collect2;
		});

		List<Future<Map<Integer, HashMap<LayoutInputISSSTE5, String>>>> futures = null;
		try {
			futures = executor.invokeAll(callables);
		} catch (InterruptedException e1) {
			e1.printStackTrace();
			throw new Exception("Error executing Executer service");
		}

		ArrayList<String> listOfAllError = new ArrayList<>();
		HashMap<Integer, ArrayList<String>> errorLinebyLineandval = new HashMap<>();

		for (int i = 0; i < futures.size(); i++) {
			switch (i) {
			case 0:
				try {
					Map<Integer, HashMap<LayoutInputISSSTE5, String>> list = futures.get(i).get();
					list.forEach((lineNumber, row) -> {
						ArrayList<String> errorLineandVal = new ArrayList<>();
						errorLineandVal.addAll(
								Arrays.asList(ConstantISSSTE5.CONCEPTO_ERROR, row.get(LayoutInputISSSTE5.CONCEPTO)));
						errorLinebyLineandval.put(lineNumber, errorLineandVal);
					});
				} catch (InterruptedException | ExecutionException e) {
					throw new Exception(e);
				}
				break;
			case 1:
				try {
					Map<Integer, HashMap<LayoutInputISSSTE5, String>> list = futures.get(i).get();
					list.forEach((lineNumber, row) -> {
						ArrayList<String> errorLineandVal = new ArrayList<>();
						errorLineandVal.addAll(
								Arrays.asList(ConstantISSSTE5.LOCALIDAD_ERROR, row.get(LayoutInputISSSTE5.LOCALIDAD)));
						errorLinebyLineandval.put(lineNumber, errorLineandVal);
					});
				} catch (InterruptedException | ExecutionException e) {
					throw new Exception(e);
				}
				break;
			case 2:
				try {
					Map<Integer, HashMap<LayoutInputISSSTE5, String>> list = futures.get(i).get();
					list.forEach((lineNumber, row) -> {
						ArrayList<String> errorLineandVal = new ArrayList<>();
						errorLineandVal.addAll(Arrays.asList(ConstantISSSTE5.NUM_PENSION_ERROR,
								row.get(LayoutInputISSSTE5.NUM_PENSION)));
						errorLinebyLineandval.put(lineNumber, errorLineandVal);
					});
				} catch (InterruptedException | ExecutionException e) {
					throw new Exception(e);
				}
				break;
			case 3:
				try {
					Map<Integer, HashMap<LayoutInputISSSTE5, String>> list = futures.get(i).get();
					list.forEach((lineNumber, row) -> {
						ArrayList<String> errorLineandVal = new ArrayList<>();
						errorLineandVal
								.addAll(Arrays.asList(ConstantISSSTE5.RFC_ERROR, row.get(LayoutInputISSSTE5.RFC)));
						errorLinebyLineandval.put(lineNumber, errorLineandVal);
					});
				} catch (InterruptedException | ExecutionException e) {
					throw new Exception(e);
				}
				break;
			case 4:
				try {
					Map<Integer, HashMap<LayoutInputISSSTE5, String>> list = futures.get(i).get();
					list.forEach((lineNumber, row) -> {
						ArrayList<String> errorLineandVal = new ArrayList<>();
						errorLineandVal.addAll(
								Arrays.asList(ConstantISSSTE5.NOMBRE_ERROR, row.get(LayoutInputISSSTE5.NOMBRE)));
						errorLinebyLineandval.put(lineNumber, errorLineandVal);
					});
				} catch (InterruptedException | ExecutionException e) {
					throw new Exception(e);
				}
				break;
			case 5:
				try {
					Map<Integer, HashMap<LayoutInputISSSTE5, String>> list = futures.get(i).get();
					list.forEach((lineNumber, row) -> {
						ArrayList<String> errorLineandVal = new ArrayList<>();
						errorLineandVal
								.addAll(Arrays.asList(ConstantISSSTE5.RAMO_ERROR, row.get(LayoutInputISSSTE5.RAMO)));
						errorLinebyLineandval.put(lineNumber, errorLineandVal);
					});
				} catch (InterruptedException | ExecutionException e) {
					throw new Exception(e);
				}
				break;

			}
		}

		try {
			executor.shutdown();
			executor.awaitTermination(20, TimeUnit.MILLISECONDS);
		} catch (InterruptedException e) {
			e.printStackTrace();
		} finally {
			if (!executor.isTerminated()) {
				logger.info("Not terminated");
			}
			executor.shutdownNow();
		}

		logger.info("Validation time : ");
		logger.info(String.valueOf(Duration.between(validationStart, Instant.now()).toMillis()));

		
		 processOutputISSSTE5 = new ProcessDataForOutputISSSTE5();
		 processOutputISSSTE5.processTextOutPutISSSTE5(arrayListOfSTringsBR, parentFileName,fileName);
	
		 fileWriteServiceISSSTE5 = new FileWriteServiceISSSTE5();
		 fileWriteServiceISSSTE5.processAndWriteErrorCSVISSSTE5(errorLinebyLineandval,fileName);
		 
		listOfAllError.add("Error File Generated");
		return listOfAllError;
	}

}