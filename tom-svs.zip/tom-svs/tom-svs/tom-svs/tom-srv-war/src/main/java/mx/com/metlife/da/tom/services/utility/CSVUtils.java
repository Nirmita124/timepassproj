package mx.com.metlife.da.tom.services.utility;

import java.io.IOException;
import java.io.Writer;
import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.List;

import mx.com.metlife.da.tom.services.service.dto.FileDataFilter2;

public class CSVUtils {

	private static final char DEFAULT_SEPARATOR = ',';

	public static void writeLine(Writer w, List<FileDataFilter2> listOfDataItems) throws IOException {
		writeLine(w, listOfDataItems, DEFAULT_SEPARATOR);
	}

	@SuppressWarnings({ "rawtypes", "unused" })
	public static void writeLine(Writer w, List<FileDataFilter2> listOfDataItems, char separators) throws IOException {
		
		boolean first= true;
		StringBuilder sb = new StringBuilder();
		
		for (FileDataFilter2 rowObject : listOfDataItems) {
			Class clazz = rowObject.getClass();
			List<Field> fields = Arrays.asList(clazz.getDeclaredFields());
			if (first) {
				fields.forEach(field -> {
					sb.append(field.getName()).append(Character.toString(separators));
				});
				sb.append("\n");
			}
			first = false;
			
			fields.forEach(field -> {
				String fieldValue = "";
				try {
					fieldValue = field.get(rowObject).toString();
					sb.append(fieldValue).append(Character.toString(separators));
				} catch (IllegalArgumentException e) {
					e.printStackTrace();
				} catch (IllegalAccessException e) {
					e.printStackTrace();
				}

			});
			sb.append("\n");
		}
		w.append(sb.toString());
	}

}