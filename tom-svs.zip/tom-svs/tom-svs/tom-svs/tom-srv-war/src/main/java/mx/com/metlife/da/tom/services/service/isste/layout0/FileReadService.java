package mx.com.metlife.da.tom.services.service.isste.layout0;

import static org.slf4j.LoggerFactory.getLogger;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.concurrent.atomic.AtomicInteger;

import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @author Capgemini
 * @since 08-07-2019
 */

@Service
public class FileReadService {

	private static Integer[] intSplitTextFileISSTE = {1,5,6,12,13,19,20,33,34,67,68,76,77,85,86,90,91,96};
	
	private static final Logger logger = getLogger(FileReadService.class);
	
	/*@Value("${splitTextFileISSTE}")
	private String[] splitTextFileISSTE;
	
	private int[] intArraySplitTextFileISSTE;
	
	@PostConstruct
	private void setTheSplitArray() {
		intArraySplitTextFileISSTE = Arrays.asList(splitTextFileISSTE).stream().mapToInt(Integer::parseInt).toArray();
		System.out.println(intArraySplitTextFileISSTE);
	}*/

	@Autowired
	private ValidateISSSTETextData validateDataText;

	/**
	 * @param file
	 * @param issste1 
	 * @param parentFileName 
	 * @param fileName 
	 * @return
	 * @throws Exception
	 */
	public ArrayList<String> readFileThroughIS(InputStream fileInputStream, Layout_ISSSTE_0[] issste1, String parentFileName, String fileName) throws Exception {

		logger.info("Starting reading data for file {}.", fileName);
		HashMap<Integer, HashMap<Layout_ISSSTE_0, String>> arrayListOfSTringsBR = new HashMap<>();
		
		BufferedReader br = new BufferedReader(new InputStreamReader(fileInputStream));
		
		AtomicInteger lineNumber = new AtomicInteger();
		
		br.lines().forEach(rowString -> {

			HashMap<Layout_ISSSTE_0, String> singleLine = new HashMap<>();
			for (int i = 0, forIsste= 0; i < intSplitTextFileISSTE.length; i++, forIsste++) {
				try {
					
					singleLine.put(issste1[forIsste],
							rowString.substring(intSplitTextFileISSTE[i++] - 1, intSplitTextFileISSTE[i]).trim());
				} catch (Exception e) {
					System.out.println(
							rowString + " - ::::" + e.getMessage() + " i value -" + (intSplitTextFileISSTE[i]));
				}
				
			}
			arrayListOfSTringsBR.put(lineNumber.incrementAndGet(), singleLine);

		});
		
		br.close();
		logger.info("Reading completed for file {}.", fileName);
		// return validateDataText.validateWithoutEx(arrayListOfSTringsBR);
		return validateDataText.validateDataText(arrayListOfSTringsBR, parentFileName, fileName);
	}
}
