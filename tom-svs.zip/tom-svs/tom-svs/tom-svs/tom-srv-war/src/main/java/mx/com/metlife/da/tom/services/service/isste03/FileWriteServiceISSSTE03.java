/**
 * 
 */
package mx.com.metlife.da.tom.services.service.isste03;

import static org.slf4j.LoggerFactory.getLogger;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.springframework.stereotype.Service;




/**
 * @author Capgemini
 * @since 07-08-2019
 */
@Service
public class FileWriteServiceISSSTE03 {
	
private static final Logger logger = getLogger(FileWriteServiceISSSTE03.class);
	
	public Object writeToTextFile(HashMap<Integer, HashMap<EnumISSTE3, String>> hashMapOfAllRows, String parentFileName,  String fileName) {

		logger.info("Starting Output file creation for : {}", fileName);
		File op = new File(fileName.concat(ConstantsISSSTE03.OUTPUT));
		logger.info("path: " , op.getAbsolutePath());

		List<String> collect = hashMapOfAllRows.entrySet().stream().map(row -> {
			StringBuilder sb = new StringBuilder();
			for (EnumISSTE3 key : EnumISSTE3.values()) {
				String value = row.getValue().get(key) == null ? "" : row.getValue().get(key);
				sb.append(value);
			}
			return sb.toString();
		}).collect(Collectors.toList());

		hashMapOfAllRows = null;

	try (FileWriter fw = new FileWriter(fileName.concat(ConstantsISSSTE03.OUTPUT), true);
				BufferedWriter bw = new BufferedWriter(fw);
				PrintWriter out = new PrintWriter(bw)) {
			collect.forEach(out::println);
		} catch (IOException e) {
			logger.error("Error Writing file: {} , Error: {}", fileName, e.getMessage());
		}

		collect = null;
		logger.info("Output File ready for: {}. Available at location {}", fileName, op.getAbsolutePath());
		return null;
	}
	
	public void processAndWriteErrorCSV(HashMap<Integer, ArrayList<String>> errorLibyLNandEval, String fileName) {
		
		 File csvOutputFile = new File(ConstantsISSSTE03.ERROR);
		    try (PrintWriter pw = new PrintWriter(csvOutputFile)) {
		    	
		    	String header = Arrays.asList("Registro","Nombre del Archivo","Detalle Error").stream().collect(Collectors.joining(","));
		    	pw.println(header);
		    	
		    	errorLibyLNandEval.entrySet().stream()
		          .map(row -> {
		        	 return String.join(",", Arrays.asList(
		        			 String.valueOf(row.getKey()),
		        			 fileName,
		        			 row.getValue().get(0).concat(" - ").concat(row.getValue().get(1))));
		          })
		          .forEach(pw::println);
		    } catch (FileNotFoundException e) {
				e.printStackTrace();
			}
		    logger.info(csvOutputFile.getAbsolutePath());
	}


}
