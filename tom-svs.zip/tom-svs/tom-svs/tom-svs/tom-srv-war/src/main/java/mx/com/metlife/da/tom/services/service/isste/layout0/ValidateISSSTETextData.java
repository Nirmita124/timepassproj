/**
 * 
 */
package mx.com.metlife.da.tom.services.service.isste.layout0;

import static mx.com.metlife.da.tom.services.service.isste.layout0.Layout_ISSSTE_0.CONCEPTO;
import static mx.com.metlife.da.tom.services.service.isste.layout0.Layout_ISSSTE_0.FECHA_INICIO;
import static mx.com.metlife.da.tom.services.service.isste.layout0.Layout_ISSSTE_0.IMP_DESCUENTO;
import static mx.com.metlife.da.tom.services.service.isste.layout0.Layout_ISSSTE_0.IMP_PENSION;
import static mx.com.metlife.da.tom.services.service.isste.layout0.Layout_ISSSTE_0.LOCALIDAD;
import static mx.com.metlife.da.tom.services.service.isste.layout0.Layout_ISSSTE_0.NOMBRE;
import static mx.com.metlife.da.tom.services.service.isste.layout0.Layout_ISSSTE_0.NUM_PENSION;
import static mx.com.metlife.da.tom.services.service.isste.layout0.Layout_ISSSTE_0.RAMO;
import static mx.com.metlife.da.tom.services.service.isste.layout0.Layout_ISSSTE_0.RFC;
import static org.slf4j.LoggerFactory.getLogger;

import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import mx.com.metlife.da.tom.services.utility.readUtils.ReadUtils;

/**
 * @author Capgemini
 * @since 08-07-2019
 */

@Service
public class ValidateISSSTETextData {
	
	private static final Logger logger = getLogger(ValidateISSSTETextData.class);
	
	@Autowired
	private ProcessDataForOutput processOutput;
	
	@Autowired
	private FileWriteService fileWrite;
	/*ArrayList<ArrayList<String>> arrayListOfSTringsBR,*/
	public ArrayList<String> validateDataText(
			HashMap<Integer, HashMap<Layout_ISSSTE_0, String>> hashMapOfAllRows,String parentFileName, String fileName) throws Exception {

		logger.info("Starting validating file {}.", fileName);
		Instant validationStart = Instant.now();

		ExecutorService executor = Executors.newFixedThreadPool(9);
		
		
		List<Callable<Map<Integer, HashMap<Layout_ISSSTE_0, String>>>> callables = Arrays.asList(
				() -> {
					//Concepto

					/*List<HashMap<Isste1, String>> collect = arrayListOfSTringsBR2.stream()
							.filter(singleLine -> !StringUtils.isNumericSpace(singleLine.get(Isste1.CONCEPTO)))
							.collect(Collectors.toList());*/
					
					Stream<Entry<Integer, HashMap<Layout_ISSSTE_0, String>>> stream = hashMapOfAllRows.entrySet().stream();
					
					Map<Integer, HashMap<Layout_ISSSTE_0, String>> collect2 = stream.filter(row -> {
						return !StringUtils.isNumericSpace(row.getValue().get(CONCEPTO));
					}).collect(Collectors.toMap(entry -> entry.getKey(), entry -> entry.getValue() ) );
					
					return collect2;
				//return collect2;
					},
				() -> {
					// Localidad

					/*List<HashMap<Isste1, String>> collect = arrayListOfSTringsBR2.stream().filter(singleLine -> {
						String Localidad = StringUtils.remove(singleLine.get(Isste1.LOCALIDAD), '-');
						return !StringUtils.isAlphanumericSpace(Localidad);
					}).collect(Collectors.toList());*/

					Stream<Entry<Integer, HashMap<Layout_ISSSTE_0, String>>> stream = hashMapOfAllRows.entrySet().stream();

					Map<Integer, HashMap<Layout_ISSSTE_0, String>> collect2 = stream.filter(row -> {
						String Localidad = StringUtils.remove(row.getValue().get(LOCALIDAD), '-');
						return !StringUtils.isAlphanumericSpace(Localidad);
					}).collect(Collectors.toMap(entry -> entry.getKey(), entry -> entry.getValue()));

					return collect2;
				}, 
				() -> {
					// Número de Pensión

					/*List<HashMap<Isste1, String>> collect = arrayListOfSTringsBR2.stream()
							.filter(singleLine -> !StringUtils.isNumericSpace(singleLine.get(Isste1.NUM_PENSION)))
							.collect(Collectors.toList());*/

					Stream<Entry<Integer, HashMap<Layout_ISSSTE_0, String>>> stream = hashMapOfAllRows.entrySet().stream();

					Map<Integer, HashMap<Layout_ISSSTE_0, String>> collect2 = stream.filter(row -> {
						return !StringUtils.isNumericSpace(row.getValue().get(NUM_PENSION));
					}).collect(Collectors.toMap(entry -> entry.getKey(), entry -> entry.getValue()));

					return collect2;
				}, 
				() -> {
					//RFC

					/*List<HashMap<Isste1, String>> collect = arrayListOfSTringsBR2.stream().filter(singleLine -> {
						String rfc = StringUtils.remove(singleLine.get(Isste1.RFC), '-');
						return !StringUtils.isAlphanumericSpace(rfc);
					}).collect(Collectors.toList());*/
					
					Stream<Entry<Integer, HashMap<Layout_ISSSTE_0, String>>> stream = hashMapOfAllRows.entrySet().stream();

					Map<Integer, HashMap<Layout_ISSSTE_0, String>> collect2 = stream.filter(row -> {
						String rfc = StringUtils.remove(row.getValue().get(RFC), '-');
						return !StringUtils.isAlphanumericSpace(rfc);
					}).collect(Collectors.toMap(entry -> entry.getKey(), entry -> entry.getValue()));
					
					return collect2;
				}, 
				() -> {
					//Nombre

					// Overrided the StringUtils,isAlphaSpace to support the dot character in names
					
					/*List<HashMap<Isste1, String>> collect = arrayListOfSTringsBR2.stream()
							.filter(singleLine -> !StringUtilsOverRide
									.isAlphaSpaceDotApostrophe(singleLine.get(Isste1.NOMBRE)))
							.collect(Collectors.toList());*/
					
					Stream<Entry<Integer, HashMap<Layout_ISSSTE_0, String>>> stream = hashMapOfAllRows.entrySet().stream();

					Map<Integer, HashMap<Layout_ISSSTE_0, String>> collect2 = stream.filter(row -> {
						return !ReadUtils
								.isAlphaSpaceDotApostrophe(row.getValue().get(NOMBRE));
					}).collect(Collectors.toMap(entry -> entry.getKey(), entry -> entry.getValue()));
					
					return collect2;
				}, 
				() -> {
					//Importe de la Pensión

					/*List<HashMap<Isste1, String>> collect = arrayListOfSTringsBR2.stream()
							.filter(singleLine -> !StringUtils.isNumericSpace(singleLine.get(Isste1.IMP_PENSION)))
							.collect(Collectors.toList());*/
					
					Stream<Entry<Integer, HashMap<Layout_ISSSTE_0, String>>> stream = hashMapOfAllRows.entrySet().stream();

					Map<Integer, HashMap<Layout_ISSSTE_0, String>> collect2 = stream.filter(row -> {
						return !StringUtils.isNumericSpace(row.getValue().get(IMP_PENSION));
					}).collect(Collectors.toMap(entry -> entry.getKey(), entry -> entry.getValue()));
					
					return collect2;
				}, 
				() -> {
					//Importe de Descuento

					/*List<HashMap<Isste1, String>> collect = arrayListOfSTringsBR2.stream()
							.filter(singleLine -> !StringUtils.isNumericSpace(singleLine.get(Isste1.IMP_DESCUENTO)))
							.collect(Collectors.toList());*/
					
					Stream<Entry<Integer, HashMap<Layout_ISSSTE_0, String>>> stream = hashMapOfAllRows.entrySet().stream();

					Map<Integer, HashMap<Layout_ISSSTE_0, String>> collect2 = stream.filter(row -> {
						return !StringUtils.isNumericSpace(row.getValue().get(IMP_DESCUENTO));
					}).collect(Collectors.toMap(entry -> entry.getKey(), entry -> entry.getValue()));
					
					return collect2;
				}, 
				() -> {
					//Ramo

					/*List<HashMap<Isste1, String>> collect = arrayListOfSTringsBR2.stream()
							.filter(singleLine -> !StringUtils.isNumericSpace(singleLine.get(Isste1.RAMO)))
							.collect(Collectors.toList());*/
					
					Stream<Entry<Integer, HashMap<Layout_ISSSTE_0, String>>> stream = hashMapOfAllRows.entrySet().stream();

					Map<Integer, HashMap<Layout_ISSSTE_0, String>> collect2 = stream.filter(row -> {
						return !StringUtils.isNumericSpace(row.getValue().get(RAMO));
					}).collect(Collectors.toMap(entry -> entry.getKey(), entry -> entry.getValue()));
					
					return collect2;
				}, 
				() -> {
					//Fecha de Inicio de la Pensión

					/*List<HashMap<Isste1, String>> collect = arrayListOfSTringsBR2.stream()
							.filter(singleLine -> !StringUtils.isNumericSpace(singleLine.get(Isste1.FECHA_INICIO)))
							.collect(Collectors.toList());*/
					
					Stream<Entry<Integer, HashMap<Layout_ISSSTE_0, String>>> stream = hashMapOfAllRows.entrySet().stream();

					Map<Integer, HashMap<Layout_ISSSTE_0, String>> collect2 = stream.filter(row -> {
						return !StringUtils.isNumericSpace(row.getValue().get(FECHA_INICIO));
					}).collect(Collectors.toMap(entry -> entry.getKey(), entry -> entry.getValue()));
					
					return collect2;
				});

		List<Future<Map<Integer, HashMap<Layout_ISSSTE_0, String>>>> futures = null;
		try {
			futures = executor.invokeAll(callables);
		} catch (InterruptedException e1) {
			e1.printStackTrace();
			throw new Exception("Error executing Executer service");
		}

		/*HashMap<Isste1, List<String>> listOfAllError = new HashMap<>();*/
		ArrayList<String> listOfAllError = new ArrayList<>();
		HashMap<Integer, ArrayList<String>> errorLibyLNandEval = new HashMap<>();

		for (int i = 0; i < futures.size(); i++) {
			switch (i) {
			case 0:
				try {
					Map<Integer, HashMap<Layout_ISSSTE_0, String>> list = futures.get(i).get();
					list.forEach((lineNumber, row) -> {
						ArrayList<String> errorLineandVal = new ArrayList<>();
						errorLineandVal.addAll(Arrays.asList("Concepto is not numeric value", row.get(CONCEPTO)));
						errorLibyLNandEval.put(lineNumber, errorLineandVal);
					});
					/*List<String> collect = list.entrySet().stream().map(n -> {
						return getErrorLine(n);
					}).collect(Collectors.toList());

					if (!collect.isEmpty()) {
						listOfAllError.put(Isste1.CONCEPTO, collect);
					}*/
				} catch (InterruptedException | ExecutionException e) {
					throw new Exception(e);
				}
				break;
			case 1:
				try {
					Map<Integer, HashMap<Layout_ISSSTE_0, String>> list = futures.get(i).get();
					
					list.forEach((lineNumber, row) -> {
						ArrayList<String> errorLineandVal = new ArrayList<>();
						errorLineandVal.addAll(Arrays.asList("Localidad is not alphaNumeric value", row.get(LOCALIDAD)));
						errorLibyLNandEval.put(lineNumber, errorLineandVal);
					});
					/*List<String> collect = list.entrySet().stream().map(n -> {
						return getErrorLine(n);
					}).collect(Collectors.toList());
					
					if(!collect.isEmpty()) {
						listOfAllError.put(Isste1.LOCALIDAD, collect);
					}*/
				} catch (InterruptedException | ExecutionException e) {
					throw new Exception(e);
				}
				break;
			case 2:
				try {
					Map<Integer, HashMap<Layout_ISSSTE_0, String>> list = futures.get(i).get();
					list.forEach((lineNumber, row) -> {
						ArrayList<String> errorLineandVal = new ArrayList<>();
						errorLineandVal.addAll(Arrays.asList("Num Pension is not numeric value", row.get(NUM_PENSION)));
						errorLibyLNandEval.put(lineNumber, errorLineandVal);
					});
					/*List<String> collect = list.entrySet().stream().map(n -> {
						return getErrorLine(n);
					}).collect(Collectors.toList());
					
					if(!collect.isEmpty()) {
						listOfAllError.put(Isste1.NUM_PENSION, collect);
					}*/
				} catch (InterruptedException | ExecutionException e) {
					throw new Exception(e);
				}
				break;
			case 3:
				try {
					Map<Integer, HashMap<Layout_ISSSTE_0, String>> list = futures.get(i).get();
					list.forEach((lineNumber, row) -> {
						ArrayList<String> errorLineandVal = new ArrayList<>();
						errorLineandVal.addAll(Arrays.asList("RFC is not alphaNumeric value", row.get(RFC)));
						errorLibyLNandEval.put(lineNumber, errorLineandVal);
					});
					/*List<String> collect = list.entrySet().stream().map(n -> {
						return getErrorLine(n);
					}).collect(Collectors.toList());
					
					if(!collect.isEmpty()) {
						listOfAllError.put(Isste1.RFC, collect);
					}*/
				} catch (InterruptedException | ExecutionException e) {
					throw new Exception(e);
				}
				break;
			case 4:
				try {
					Map<Integer, HashMap<Layout_ISSSTE_0, String>> list = futures.get(i).get();
					list.forEach((lineNumber, row) -> {
						ArrayList<String> errorLineandVal = new ArrayList<>();
						errorLineandVal.addAll(Arrays.asList("Nombre is not alphabetical value", row.get(NOMBRE)));
						errorLibyLNandEval.put(lineNumber, errorLineandVal);
					});
					/*List<String> collect = list.entrySet().stream().map(n -> {
						return getErrorLine(n);
					}).collect(Collectors.toList());
					
					if(!collect.isEmpty()) {
						listOfAllError.put(Isste1.NOMBRE, collect);
					}*/
				} catch (InterruptedException | ExecutionException e) {
					throw new Exception(e);
				}
				break;
			case 5:
				try {
					Map<Integer, HashMap<Layout_ISSSTE_0, String>> list = futures.get(i).get();
					list.forEach((lineNumber, row) -> {
						ArrayList<String> errorLineandVal = new ArrayList<>();
						errorLineandVal.addAll(Arrays.asList("Imp Pension is not numeric value", row.get(IMP_PENSION)));
						errorLibyLNandEval.put(lineNumber, errorLineandVal);
					});
					/*List<String> collect = list.entrySet().stream().map(n -> {
						return getErrorLine(n);
					}).collect(Collectors.toList());
					
					if(!collect.isEmpty()) {
						listOfAllError.put(Isste1.IMP_PENSION, collect);
					}*/
				} catch (InterruptedException | ExecutionException e) {
					throw new Exception(e);
				}
				break;
			case 6:
				try {
					Map<Integer, HashMap<Layout_ISSSTE_0, String>> list = futures.get(i).get();
					list.forEach((lineNumber, row) -> {
						ArrayList<String> errorLineandVal = new ArrayList<>();
						errorLineandVal.addAll(Arrays.asList("Imp Descuento is not numeric value", row.get(IMP_DESCUENTO)));
						errorLibyLNandEval.put(lineNumber, errorLineandVal);
					});
					/*List<String> collect = list.entrySet().stream().map(n -> {
						return getErrorLine(n);
						 
					}).collect(Collectors.toList());
					
					if(!collect.isEmpty()) {
						listOfAllError.put(Isste1.IMP_DESCUENTO, collect);
					}*/
				} catch (InterruptedException | ExecutionException e) {
					throw new Exception(e);
				}
				break;
			case 7:
				try {
					Map<Integer, HashMap<Layout_ISSSTE_0, String>> list = futures.get(i).get();
					list.forEach((lineNumber, row) -> {
						ArrayList<String> errorLineandVal = new ArrayList<>();
						errorLineandVal.addAll(Arrays.asList("RAMO is not numeric value", row.get(RAMO)));
						errorLibyLNandEval.put(lineNumber, errorLineandVal);
					});
					/*List<String> collect = list.entrySet().stream().map(n -> {
						return getErrorLine(n);
					}).collect(Collectors.toList());
					
					if(!collect.isEmpty()) {
						listOfAllError.put(Isste1.RAMO, collect);
					}*/
				} catch (InterruptedException | ExecutionException e) {
					throw new Exception(e);
				}
				break;
			case 8:
				try {
					Map<Integer, HashMap<Layout_ISSSTE_0, String>> list = futures.get(i).get();
					list.forEach((lineNumber, row) -> {
						ArrayList<String> errorLineandVal = new ArrayList<>();
						errorLineandVal.addAll(Arrays.asList("FECHA_INICIO is not numeric value",row.get(FECHA_INICIO)));
						errorLibyLNandEval.put(lineNumber, errorLineandVal);
					});
					list = null;
					/*List<String> collect = list.entrySet().stream().map(n -> {
						return getErrorLine(n);
					}).collect(Collectors.toList());
					
					if(!collect.isEmpty()) {
						listOfAllError.put(Isste1.FECHA_INICIO, collect);
					}*/
				} catch (InterruptedException | ExecutionException e) {
					throw new Exception(e);
				}
				break;
			}
		}

		try {
			executor.shutdown();
			executor.awaitTermination(20, TimeUnit.MILLISECONDS);
		} catch (InterruptedException e) {
			e.printStackTrace();
		} finally {
			if (!executor.isTerminated()) {
				System.out.println("NOt terminated");
			}
			executor.shutdownNow();
		}

		System.out.println(
				"Validation time : " + String.valueOf(Duration.between(validationStart, Instant.now()).toMillis()));
		
		if (errorLibyLNandEval.isEmpty()) {
			logger.info("Validation complete for file: {}", fileName);
			processOutput.processTextOutPut(hashMapOfAllRows, parentFileName, fileName);
		} else {
			logger.error("Error in file {}", fileName);
			fileWrite.processAndWriteErrorCSV(errorLibyLNandEval, fileName);
			listOfAllError.add("Error File Generated");
		}
		return listOfAllError;
	}

	/**
	 * @param n
	 * @return
	 */
	private String getErrorLine(Entry<Integer, HashMap<Layout_ISSSTE_0, String>> n) {
		StringBuilder sb = new StringBuilder();
		 for(Layout_ISSSTE_0 key :Layout_ISSSTE_0.values()) {
			 sb.append(n.getValue().get(key));
		 }
		 return sb.toString();
	}

	public HashMap<String, List<String>> validateWithoutEx(ArrayList<ArrayList<String>> al) {

		Instant validationStart = Instant.now();
		HashMap<String, List<String>> listOfAllError = new HashMap<>();

		listOfAllError.put("CONCEPTO", al.stream().filter(singleLine -> !StringUtils.isNumericSpace(singleLine.get(0)))
				.map(List::toString).collect(Collectors.toList()));

		listOfAllError.put("LOCALIDAD", al.stream()
				.filter(singleLine -> !StringUtils.isAlphanumericSpace(StringUtils.remove(singleLine.get(1), '-')))
				.map(List::toString).collect(Collectors.toList()));

		listOfAllError.put("NUM_PENSION",
				al.stream().filter(singleLine -> !StringUtils.isNumericSpace(singleLine.get(2))).map(List::toString)
						.collect(Collectors.toList()));

		listOfAllError.put("RFC", al.stream()
				.filter(singleLine -> !StringUtils.isAlphanumericSpace(StringUtils.remove(singleLine.get(3), '-')))
				.map(List::toString).collect(Collectors.toList()));

		listOfAllError.put("NOMBRE", al.stream().filter(singleLine -> !StringUtils.isAlphaSpace(singleLine.get(4)))
				.map(List::toString).collect(Collectors.toList()));

		listOfAllError.put("IMP_PENSION",
				al.stream().filter(singleLine -> !StringUtils.isNumericSpace(singleLine.get(5))).map(List::toString)
						.collect(Collectors.toList()));

		listOfAllError.put("IMP_DESCUENTO",
				al.stream().filter(singleLine -> !StringUtils.isNumericSpace(singleLine.get(6))).map(List::toString)
						.collect(Collectors.toList()));

		listOfAllError.put("RAMO", al.stream().filter(singleLine -> !StringUtils.isNumericSpace(singleLine.get(7)))
				.map(List::toString).collect(Collectors.toList()));

		listOfAllError.put("FECHA_INICIO",
				al.stream().filter(singleLine -> !StringUtils.isNumericSpace(singleLine.get(8))).map(List::toString)
						.collect(Collectors.toList()));

		System.out.println("Validation time Without executor: "
				+ String.valueOf(Duration.between(validationStart, Instant.now()).toMillis()));

		return listOfAllError;
	}
	
}
