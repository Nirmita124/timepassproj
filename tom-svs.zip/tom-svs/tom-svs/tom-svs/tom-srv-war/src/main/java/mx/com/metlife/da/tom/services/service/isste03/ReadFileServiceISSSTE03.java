package mx.com.metlife.da.tom.services.service.isste03;

import static org.slf4j.LoggerFactory.getLogger;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.concurrent.atomic.AtomicInteger;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import mx.com.metlife.da.tom.services.service.isste05.LayoutInputISSSTE5;

@Service
public class ReadFileServiceISSSTE03 {

	@Autowired
	private ValidateDataTextISSSTE03 validateDataText;
	private static final Logger logger = getLogger(ReadFileServiceISSSTE03.class);

	public File convertToFile(CommonsMultipartFile file) throws Exception {
		File convFile = new File(file.getOriginalFilename());
		logger.info("Started Executing readExcelFile Method");
		try {
			convFile.createNewFile();
			FileOutputStream fos = new FileOutputStream(convFile);
			BufferedOutputStream bout = new BufferedOutputStream(fos);
			bout.write(file.getBytes());
			bout.flush();
			bout.close();
			file = null;
		} catch (Exception e) {
			throw e;
		}

		return convFile;
	}

	@SuppressWarnings("resource")
	public ArrayList<String> readExcelFileData(File file, String fileName) throws Exception {

		logger.info("Started Executing readExcelFile Method");
		HashMap<Integer, HashMap<EnumISSTE3, String>> hashMapOfAllRows = new HashMap();
		String parentFileName = "";
		AtomicInteger lineNumber = new AtomicInteger();
		try (Workbook workbook = new HSSFWorkbook(new FileInputStream(file))) {

			/* Execution */
			Instant fileProcessStart = Instant.now();
			DataFormatter dataFormatter = new DataFormatter();

			for (Sheet sheetIterate : workbook) {
				int count = 0;
				for (Row row : sheetIterate) {
					count++;
					if (count != 1) {
						HashMap<EnumISSTE3, String> rowObject = new HashMap();
						short length = row.getLastCellNum();
						for (int i = 0; i < length; i++) 
						{
							
							if(EnumISSTE3.values()[i].equals(EnumISSTE3.HOMO) )
							{
								continue;
							}
							else
							{	
								System.out.println(row.getCell(i));
							
								if (row.getCell(i) == null)
								{
									row.removeCell(row.getCell(i));
									break;
								}
								else
								{
									rowObject.put(EnumISSTE3.values()[i], dataFormatter.formatCellValue(row.getCell(i)));
								}
							
							}
						}
						System.out.println(rowObject);
						hashMapOfAllRows.put(lineNumber.incrementAndGet(), rowObject);
						rowObject = null;
					}
				}
			}
			logger.info("read processing time Bufferedreader: ");
			logger.info(String.valueOf(Duration.between(fileProcessStart, Instant.now()).toMillis()));

		} catch (Exception e) {
			e.printStackTrace();
		}
		
		  validateDataText = new ValidateDataTextISSSTE03(); 
		  return validateDataText.validateDataTexts(hashMapOfAllRows,parentFileName, fileName);
	}

	public static void main(String[] args) throws Exception {
		ReadFileServiceISSSTE03 readFileService = new ReadFileServiceISSSTE03();
		File file = new File(
				"C:\\Users\\djain5\\Downloads\\arch_cpto_Dispersion27_032019_01.xls");
		logger.info(file.getName());
		ArrayList<String> returnMap = readFileService.readExcelFileData(file, file.getName());
	}
}