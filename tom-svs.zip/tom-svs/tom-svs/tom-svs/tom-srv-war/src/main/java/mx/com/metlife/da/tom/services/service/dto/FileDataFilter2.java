package mx.com.metlife.da.tom.services.service.dto;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

import com.gizbel.excel.annotations.ExcelBean;
import com.gizbel.excel.annotations.ExcelColumnIndex;

import lombok.Data;

@Data
@ExcelBean
public class FileDataFilter2 {

	@ExcelColumnIndex(columnIndex = "0", dataType = "string")
	public String entidad;
	
	@ExcelColumnIndex(columnIndex = "1", dataType = "int")
	public int idEntidad;

	@ExcelColumnIndex(columnIndex = "2", dataType = "string")
	public String noArchivo;

	@ExcelColumnIndex(columnIndex = "3", dataType = "string")
	public String procesoDeNomina;
	
	@ExcelColumnIndex(columnIndex = "4", dataType = "string")
	public String nombre;
	
	@ExcelColumnIndex(columnIndex = "5", dataType = "string")
	public String primerPaterno;
	
	@ExcelColumnIndex(columnIndex = "6", dataType = "string")
	@NotEmpty
	@Size(min = 1, max = 20, message = "segundoMaterino Materno length cannot exceed more than 20.")
	public String segundoMaterino;
	
	@ExcelColumnIndex(columnIndex = "7", dataType = "string")
	public String curp;
	
	@ExcelColumnIndex(columnIndex = "8", dataType = "string")
	//@Pattern(regexp="^[a-zA-Z0-9]+$", message="User name must be alphanumeric with no spaces")
	public String rfc;
	
	@ExcelColumnIndex(columnIndex = "9", dataType = "int")
	public int clc;

	@ExcelColumnIndex(columnIndex = "10", dataType = "string")
	public String cveConCepto;
	
	@ExcelColumnIndex(columnIndex = "11", dataType = "string")
	public String description;
	
	@ExcelColumnIndex(columnIndex = "12", dataType = "double")
	public double sumaDeImporte;
}
