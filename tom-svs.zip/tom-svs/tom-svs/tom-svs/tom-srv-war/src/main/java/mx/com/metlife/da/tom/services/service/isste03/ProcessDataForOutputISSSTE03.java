package mx.com.metlife.da.tom.services.service.isste03;


import static mx.com.metlife.da.tom.services.service.isste03.EnumISSTE3.PERIODO;
import static mx.com.metlife.da.tom.services.service.isste03.EnumISSTE3.NUMPEN;
import static mx.com.metlife.da.tom.services.service.isste03.EnumISSTE3.DESCRIPCION;
import static mx.com.metlife.da.tom.services.service.isste03.EnumISSTE3.RAMO;
import static mx.com.metlife.da.tom.services.service.isste03.EnumISSTE3.NOMBRE;
import static mx.com.metlife.da.tom.services.service.isste03.EnumISSTE3.CPTO;
import static mx.com.metlife.da.tom.services.service.isste03.EnumISSTE3.APELLIDO_PATERNO;
import static mx.com.metlife.da.tom.services.service.isste03.EnumISSTE3.RFC;
import static mx.com.metlife.da.tom.services.service.isste03.EnumISSTE3.DEPENDENCIA;
import static mx.com.metlife.da.tom.services.service.isste03.EnumISSTE3.APELLIDO_MATERNO;
import static mx.com.metlife.da.tom.services.service.isste03.EnumISSTE3.HOMO;
import static mx.com.metlife.da.tom.services.service.isste03.EnumISSTE3.SEXO;
import static mx.com.metlife.da.tom.services.service.isste03.EnumISSTE3.NIV_TAB;
import static mx.com.metlife.da.tom.services.service.isste03.EnumISSTE3.PERCEPCION;
import static mx.com.metlife.da.tom.services.service.isste03.EnumISSTE3.PRIMA_BASICA;
import static mx.com.metlife.da.tom.services.service.isste03.EnumISSTE3.PRIMA;
import static mx.com.metlife.da.tom.services.service.isste03.EnumISSTE3.CURP;
import static mx.com.metlife.da.tom.services.service.isste03.EnumISSTE3.ID;
import static mx.com.metlife.da.tom.services.service.isste03.EnumISSTE3.CONCEPTO;
import static mx.com.metlife.da.tom.services.service.isste03.EnumISSTE3.LOCALIDAD;
import static mx.com.metlife.da.tom.services.service.isste03.EnumISSTE3.NUM_PENSION;
import static mx.com.metlife.da.tom.services.service.isste03.EnumISSTE3.IMP_PENSION;
import static mx.com.metlife.da.tom.services.service.isste03.EnumISSTE3.IMP_DESCUENTO;
import static mx.com.metlife.da.tom.services.service.isste03.EnumISSTE3.FECHA_INICIO;
import static mx.com.metlife.da.tom.services.service.isste03.EnumISSTE3.ARCHIVO_ORIGINARIO;
import static mx.com.metlife.da.tom.services.service.isste03.EnumISSTE3.OFICIO;
import static mx.com.metlife.da.tom.services.service.isste03.EnumISSTE3.MES_PAGO;
import static mx.com.metlife.da.tom.services.service.isste03.EnumISSTE3.MES_REPORTADO;
import static mx.com.metlife.da.tom.services.service.isste03.EnumISSTE3.ID;
import static mx.com.metlife.da.tom.services.service.isste03.EnumISSTE3.POLIZA;
import static mx.com.metlife.da.tom.services.service.isste03.EnumISSTE3.NOMBRE_CLIENTE;
import static mx.com.metlife.da.tom.services.service.isste03.EnumISSTE3.SUBGRUPO;
import static mx.com.metlife.da.tom.services.service.isste03.EnumISSTE3.FOLIO;
import static mx.com.metlife.da.tom.services.service.isste03.EnumISSTE3.MOVIMIENTO;









import java.util.HashMap;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


/**
 * @author Capgemini
 * @since 08-07-2019
 */
@Service

public class ProcessDataForOutputISSSTE03 {

	@Autowired
	private RemoveColumnISSSTE03 removeColumnISSSTE03;

	public Object processTextOutPut(HashMap<Integer, HashMap<EnumISSTE3, String>> hashMapOfRows, String parentFileName, String fileName) {

//		HashMap<Integer, HashMap<EnumISSTE3, String>> newHashMap = new HashMap<>();

		hashMapOfRows.forEach((lineNumber,row) -> {

			row.replace(CONCEPTO, StringUtils.leftPad(row.get(CPTO), 10)) ;
			row.replace(LOCALIDAD, StringUtils.leftPad(row.get(LOCALIDAD), 10)) ;
			row.replace(NUM_PENSION, StringUtils.leftPad(row.get(NUMPEN), 6)) ;
		
			
			
			row.put(RFC, StringUtils.leftPad(StringUtils.remove(row.get(RFC), '-'), 13)) ;
			String nombre = new StringBuilder(row.get(APELLIDO_MATERNO)).append(" ").append(row.get(APELLIDO_PATERNO)).append(" ").append(row.get(NOMBRE).trim()).toString();
			row.put(NOMBRE, StringUtils.leftPad(nombre, 20)) ;
			row.put(SEXO, StringUtils.leftPad(row.get(SEXO), 1)) ;
			row.put(IMP_PENSION, StringUtils.leftPad(row.get(IMP_PENSION), 30)) ;
			row.put(IMP_DESCUENTO, StringUtils.leftPad(row.get(IMP_DESCUENTO), 30)) ;
			row.put(RAMO, StringUtils.leftPad(row.get(RAMO), 6 )) ;
			row.put(FECHA_INICIO, StringUtils.leftPad(row.get(FECHA_INICIO), 6 )) ;
			row.put(OFICIO, StringUtils.leftPad(row.get(OFICIO), 20 )) ;
			row.put(MES_PAGO, StringUtils.leftPad(row.get(MES_PAGO), 10 )) ;
			row.put(MES_REPORTADO, StringUtils.leftPad(row.get(MES_REPORTADO), 10 )) ;
			row.put(ARCHIVO_ORIGINARIO, StringUtils.leftPad(row.get(ARCHIVO_ORIGINARIO), 30 )) ;
			String id = new StringBuilder(row.get(CPTO)).append("-").append(row.get(RAMO).trim()).toString();
			row.put(ID, StringUtils.leftPad(id, 10)) ;
			row.put(POLIZA, StringUtils.leftPad(row.get(POLIZA),15));
			row.put(NOMBRE_CLIENTE, StringUtils.leftPad(row.get(NOMBRE_CLIENTE),50));
			
			row.put(SUBGRUPO, StringUtils.leftPad(row.get(SUBGRUPO), 15)) ;
			
			row.put(FOLIO, StringUtils.leftPad(row.get(FOLIO), 6)) ;
			row.put(MOVIMIENTO, StringUtils.leftPad(row.get(MOVIMIENTO), 4)) ;
			
			/*row.remove(PERIODO);
			row.remove(DESCRIPCION);
			row.remove(DEPENDENCIA);
			row.remove(HOMO);
			row.remove(CURP);
			row.remove(NIV_TAB);
			row.remove(PERCEPCION);
			row.remove(PRIMA_BASICA);
			row.remove(PRIMA);*/
			
			
			
			/*row.put(APELLIDO_MATERNO, StringUtils.leftPad(row.get(APELLIDO_MATERNO), 18)) ;
			row.put(DESCRIPCION, StringUtils.leftPad(row.get(DESCRIPCION), 80)) ;
			row.put(NIV_TAB, StringUtils.leftPad(row.get(NIV_TAB), 10)) ;
			row.put(PERCEPCION, StringUtils.leftPad(row.get(PERCEPCION), 10)) ;
			row.put(PRIMA_BASICA, StringUtils.leftPad(row.get(PRIMA_BASICA), 10)) ;
			row.put(PRIMA, StringUtils.leftPad(row.get(PRIMA), 10)) ;
			row.put(PRIMA, StringUtils.leftPad(row.get(DEPENDENCIA), 10)) ;
			row.put(CURP, StringUtils.leftPad(row.get(CURP), 18)) ;
			row.put(APELLIDO_PATERNO, StringUtils.leftPad(row.get(APELLIDO_PATERNO), 20)) ;*/
			
		});
		//newHashMap.putAll(hashMapOfRows);
		removeColumnISSSTE03 = new RemoveColumnISSSTE03();
		
		return removeColumnISSSTE03.removeColumnDataISSSTE3(hashMapOfRows,parentFileName,fileName);
	}
}