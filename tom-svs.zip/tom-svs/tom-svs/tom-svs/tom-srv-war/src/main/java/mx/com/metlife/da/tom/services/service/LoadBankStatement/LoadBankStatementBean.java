package mx.com.metlife.da.tom.services.service.LoadBankStatement;
import javax.persistence.*;


@Entity
@Table(name="Estado_Cuenta")
public class LoadBankStatementBean {
	
	@Id
	@Column(name = "banco_Id")
	private int banco_Id;
	
	@Id
	@Column(name = "folio_Carga")
	private long folio_Carga;
	
	@Id
	@Column(name = "numero_Movimiento")
	private long numero_Movimiento;
	
	@Column(name = "referencia_Bancaria")
	   private String referencia_Bancaria;
	
	@Column(name = "concepto")
	   private String concepto;
	
	@Column(name = "fecha_Pago")
	   private java.util.Date fecha_Pago;
	
	@Column(name = "importe_Pago")
	   private double importe_Pago;
	
	@Column(name = "fecha_Carga")
	   private java.util.Date fecha_Carga;
	
	@Column(name = "importe_Restante")
	   private double importe_Restante;

	public LoadBankStatementBean() {
	}

	public LoadBankStatementBean(int banco_Id, long folio_Carga, long numero_Movimiento, String referencia_Bancaria,
			String concepto, java.util.Date fecha_Pago, double importe_Pago, java.util.Date fecha_Carga,
			double importe_Restante) {
		super();
		this.banco_Id = banco_Id;
		this.folio_Carga = folio_Carga;
		this.numero_Movimiento = numero_Movimiento;
		this.referencia_Bancaria = referencia_Bancaria;
		this.concepto = concepto;
		this.fecha_Pago = fecha_Pago;
		this.importe_Pago = importe_Pago;
		this.fecha_Carga = fecha_Carga;
		this.importe_Restante = importe_Restante;
	}

	public int getBanco_Id() {
		return banco_Id;
	}

	public void setBanco_Id(int banco_Id) {
		this.banco_Id = banco_Id;
	}

	public long getFolio_Carga() {
		return folio_Carga;
	}

	public void setFolio_Carga(long folio_Carga) {
		this.folio_Carga = folio_Carga;
	}

	public long getNumero_Movimiento() {
		return numero_Movimiento;
	}

	public void setNumero_Movimiento(long numero_Movimiento) {
		this.numero_Movimiento = numero_Movimiento;
	}

	public String getReferencia_Bancaria() {
		return referencia_Bancaria;
	}

	public void setReferencia_Bancaria(String referencia_Bancaria) {
		this.referencia_Bancaria = referencia_Bancaria;
	}

	public String getConcepto() {
		return concepto;
	}

	public void setConcepto(String concepto) {
		this.concepto = concepto;
	}

	public java.util.Date getFecha_Pago() {
		return fecha_Pago;
	}

	public void setFecha_Pago(java.util.Date fecha_Pago) {
		this.fecha_Pago = fecha_Pago;
	}

	public double getImporte_Pago() {
		return importe_Pago;
	}

	public void setImporte_Pago(double importe_Pago) {
		this.importe_Pago = importe_Pago;
	}

	public java.util.Date getFecha_Carga() {
		return fecha_Carga;
	}

	public void setFecha_Carga(java.util.Date fecha_Carga) {
		this.fecha_Carga = fecha_Carga;
	}

	public double getImporte_Restante() {
		return importe_Restante;
	}

	public void setImporte_Restante(double importe_Restante) {
		this.importe_Restante = importe_Restante;
	}

		
	
	
}
