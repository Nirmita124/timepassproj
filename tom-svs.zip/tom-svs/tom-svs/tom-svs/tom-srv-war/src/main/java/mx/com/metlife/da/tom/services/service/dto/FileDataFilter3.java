package mx.com.metlife.da.tom.services.service.dto;

import com.gizbel.excel.annotations.ExcelBean;
import com.gizbel.excel.annotations.ExcelColumnHeader;

import lombok.Data;

@Data
@ExcelBean
public class FileDataFilter3 {

	@ExcelColumnHeader(columnHeader = "ENTIDAD", dataType = "string")
	private String entidad;
	
	@ExcelColumnHeader(columnHeader ="IDENTIDAD", dataType = "int")
	private int idEntidad;

	@ExcelColumnHeader(columnHeader = "No ARCHIVO", dataType = "string")
	private String noArchivo;

	@ExcelColumnHeader(columnHeader ="PROCESO_DE_NOMINA", dataType = "string")
	private String procesoDeNomina;
	
	@ExcelColumnHeader(columnHeader ="NOMBRE", dataType = "string")
	private String nombre;
	
	@ExcelColumnHeader(columnHeader ="PRIMER_APELLIDO", dataType = "string")
	private String primerPaterno;
	
	@ExcelColumnHeader(columnHeader ="SEGUNDO_APELLIDO", dataType = "string")
	private String segundoMaterino;
	
	@ExcelColumnHeader(columnHeader ="CRUP", dataType = "string")
	private String curp;
	
	@ExcelColumnHeader(columnHeader ="RFC", dataType = "string")
	private String rfc;
	
	@ExcelColumnHeader(columnHeader ="CLC", dataType = "int")
	private int clc;

	@ExcelColumnHeader(columnHeader ="CVE_CONCEPTO", dataType = "string")
	private String cveConCepto;
	
	@ExcelColumnHeader(columnHeader ="DESCRIPCION", dataType = "string")
	private String description;
	
	@ExcelColumnHeader(columnHeader ="SumaDeIMPORTE", dataType = "double")
	private double sumaDeImporte;
}
