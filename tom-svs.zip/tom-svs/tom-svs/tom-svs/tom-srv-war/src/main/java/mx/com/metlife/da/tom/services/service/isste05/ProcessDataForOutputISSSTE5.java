package mx.com.metlife.da.tom.services.service.isste05;

import static mx.com.metlife.da.tom.services.service.isste05.LayoutInputISSSTE5.APELLIDO_MATERNO;
import static mx.com.metlife.da.tom.services.service.isste05.LayoutInputISSSTE5.APELLIDO_PATERNO;
import static mx.com.metlife.da.tom.services.service.isste05.LayoutInputISSSTE5.ARCHIVO_ORIGINARIO;
import static mx.com.metlife.da.tom.services.service.isste05.LayoutInputISSSTE5.CONCEPTO;
import static mx.com.metlife.da.tom.services.service.isste05.LayoutInputISSSTE5.FECHA_INICIO;
import static mx.com.metlife.da.tom.services.service.isste05.LayoutInputISSSTE5.FOLIO;
import static mx.com.metlife.da.tom.services.service.isste05.LayoutInputISSSTE5.ID;
import static mx.com.metlife.da.tom.services.service.isste05.LayoutInputISSSTE5.IMP_DESCUENTO;
import static mx.com.metlife.da.tom.services.service.isste05.LayoutInputISSSTE5.IMP_PENSION;
import static mx.com.metlife.da.tom.services.service.isste05.LayoutInputISSSTE5.LOCALIDAD;
import static mx.com.metlife.da.tom.services.service.isste05.LayoutInputISSSTE5.MES_PAGO;
import static mx.com.metlife.da.tom.services.service.isste05.LayoutInputISSSTE5.MES_REPORTADO;
import static mx.com.metlife.da.tom.services.service.isste05.LayoutInputISSSTE5.MOVIMIENTO;
import static mx.com.metlife.da.tom.services.service.isste05.LayoutInputISSSTE5.NOMBRE;
import static mx.com.metlife.da.tom.services.service.isste05.LayoutInputISSSTE5.NOMBRE_CLIENTE;
import static mx.com.metlife.da.tom.services.service.isste05.LayoutInputISSSTE5.NUM_PENSION;
import static mx.com.metlife.da.tom.services.service.isste05.LayoutInputISSSTE5.OFICIO;
import static mx.com.metlife.da.tom.services.service.isste05.LayoutInputISSSTE5.POLIZA;
import static mx.com.metlife.da.tom.services.service.isste05.LayoutInputISSSTE5.RAMO;
import static mx.com.metlife.da.tom.services.service.isste05.LayoutInputISSSTE5.RFC;
import static mx.com.metlife.da.tom.services.service.isste05.LayoutInputISSSTE5.SEXO;
import static mx.com.metlife.da.tom.services.service.isste05.LayoutInputISSSTE5.SUBGRUPO;

import java.util.HashMap;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Service;

@Service
@PropertySource({ "classpath:application.properties", "classpath:vidaReadWrite.properties" })
public class ProcessDataForOutputISSSTE5 {

	@Autowired
	private RemoveColumnISSSTE5 removeColumnISSSTE5;

	@SuppressWarnings("unlikely-arg-type")
	public Object processTextOutPutISSSTE5(HashMap<Integer, HashMap<LayoutInputISSSTE5, String>> arrayListOfSTringsBR,
			String parentFileName, String fileName) {

		arrayListOfSTringsBR.forEach((lineNumber, row) -> {
			row.put(CONCEPTO, StringUtils.leftPad(row.get(CONCEPTO), 2));
			row.put(LOCALIDAD, StringUtils.leftPad(row.get(LOCALIDAD), 10));
			row.put(NUM_PENSION, StringUtils.leftPad(row.get(NUM_PENSION), 10));
			row.put(RFC, StringUtils.leftPad(row.get(RFC), 13));

			String nombre = new StringBuilder(row.get(APELLIDO_PATERNO)).append(row.get(APELLIDO_MATERNO))
					.append(row.get(NOMBRE).trim()).toString();
			row.put(NOMBRE, StringUtils.leftPad(nombre, 30));

		

			/*
			row.put(SEXO, "M");
			row.put(IMP_PENSION, "123");
			row.put(IMP_DESCUENTO, "1231");

			row.put(FECHA_INICIO, "asdf");
			row.put(ARCHIVO_ORIGINARIO, "adfh");
			row.put(OFICIO, "rtw");
			row.put(MES_PAGO, "cb");
			row.put(MES_REPORTADO, "ghfj");
			row.put(ID, "fj");
			row.put(POLIZA, "dhfghf");
			row.put(NOMBRE_CLIENTE, "gasdfg");
			row.put(SUBGRUPO, "rsad");
			row.put(FOLIO, "xcn");
			row.put(MOVIMIENTO, "fghg");		
*/			
			
			row.put(SEXO, StringUtils.leftPad(row.get(SEXO), 1));
			row.put(IMP_PENSION, StringUtils.leftPad(row.get(IMP_PENSION), 30));
			row.put(IMP_DESCUENTO,StringUtils.leftPad(row.get(IMP_DESCUENTO), 30));

			row.put(RAMO, StringUtils.leftPad(row.get(RAMO), 6));
			
			row.put(FECHA_INICIO, StringUtils.leftPad(row.get(FECHA_INICIO), 6));
			row.put(ARCHIVO_ORIGINARIO, StringUtils.leftPad(row.get(ARCHIVO_ORIGINARIO), 30));
			row.put(OFICIO, StringUtils.leftPad(row.get(OFICIO), 20));
			row.put(MES_PAGO, StringUtils.leftPad(row.get(MES_PAGO), 10));
			row.put(MES_REPORTADO,StringUtils.leftPad(row.get(MES_REPORTADO), 10));
			row.put(ID,StringUtils.leftPad(row.get(ID), 10));
			row.put(POLIZA, StringUtils.leftPad(row.get(POLIZA), 15));
			row.put(NOMBRE_CLIENTE, StringUtils.leftPad(row.get(NOMBRE_CLIENTE), 50));
			row.put(SUBGRUPO, StringUtils.leftPad(row.get(SUBGRUPO), 15));
			row.put(FOLIO, StringUtils.leftPad(row.get(FOLIO), 6));
			row.put(MOVIMIENTO, StringUtils.leftPad(row.get(MOVIMIENTO), 4));
			
			

		});

		removeColumnISSSTE5 = new RemoveColumnISSSTE5();
		return removeColumnISSSTE5.removeColumnDataISSSTE5(arrayListOfSTringsBR, parentFileName, fileName);

	}
}
