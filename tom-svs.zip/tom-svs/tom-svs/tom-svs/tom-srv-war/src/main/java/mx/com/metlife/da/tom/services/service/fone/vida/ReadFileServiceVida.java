package mx.com.metlife.da.tom.services.service.fone.vida;

import static org.slf4j.LoggerFactory.getLogger;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.concurrent.atomic.AtomicInteger;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

@Service
public class ReadFileServiceVida {

	private static final Logger logger = getLogger(ReadFileServiceVida.class);

	@Autowired
	private ValidateDataTextVida validateDataTextVida;

	public File convertToFile(CommonsMultipartFile file) throws Exception {
		File convFile = new File(file.getOriginalFilename());
		logger.info("Started Executing readExcelFile Method");
		try {
			convFile.createNewFile();
			FileOutputStream fos = new FileOutputStream(convFile);
			BufferedOutputStream bout = new BufferedOutputStream(fos);
			bout.write(file.getBytes());
			bout.flush();
			bout.close();
			file = null;
		} catch (Exception e) {
			throw e;
		}

		return convFile;
	}

	@SuppressWarnings("resource")
	public ArrayList<String> readFileThroughIS(File file, String fileName) throws Exception {

		logger.info("Started Executing readExcelFile Method");
		HashMap<Integer, HashMap<LayoutFoneVida, String>> arrayListOfSTringsBR = new HashMap<>();
		AtomicInteger lineNumber = new AtomicInteger();
		String parentFileName = "";
		try {

			Workbook workbook = new XSSFWorkbook(file);

			Instant fileProcessStartBR = Instant.now();

			DataFormatter dataFormatter = new DataFormatter();
			for (Sheet sheetIterate : workbook) {

				int count = 0;

				for (Row row : sheetIterate) {
					count++;
					if (count != 1) {

						HashMap<LayoutFoneVida, String> rowObject = new HashMap<>();
						short length = row.getLastCellNum();
						for (int i = 0; i < length; i++) {
							rowObject.put(LayoutFoneVida.values()[i], dataFormatter.formatCellValue(row.getCell(i)));
						}

						arrayListOfSTringsBR.put(lineNumber.incrementAndGet(), rowObject);
						rowObject = null;

					}
				}
			}

			logger.info("Read processing time Bufferedreader: ");
			logger.info(String.valueOf(Duration.between(fileProcessStartBR, Instant.now()).toMillis()));
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println(e);
		}

		validateDataTextVida = new ValidateDataTextVida();
		return validateDataTextVida.validateDataTextVida(arrayListOfSTringsBR, parentFileName, fileName);

	}

	public static void main(String[] args) throws Exception {
		ReadFileServiceVida readFileService = new ReadFileServiceVida();
		File file = new File(
				"C:\\Users\\vitandel\\Desktop\\Project Stuff\\Materials\\Template Input File\\Detalle_SEG_VIDA_R01_03_2019.xlsx");
		ArrayList<String> returnMap = readFileService.readFileThroughIS(file, file.getName());

	}

}
