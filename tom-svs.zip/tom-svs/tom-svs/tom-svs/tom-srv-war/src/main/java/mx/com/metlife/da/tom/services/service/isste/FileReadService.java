package mx.com.metlife.da.tom.services.service.isste;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.commons.CommonsMultipartFile;
import mx.com.metlife.da.tom.services.service.isste.ValidateDataText;
/**
 * @author Capgemini
 * @since 08-07-2019
 */

@Service
public class FileReadService {

	private static Integer[] intSplitTextFileISSTE = {1,5,6,12,13,19,20,33,34,67,68,76,77,85,86,90,91,96};
	
	/*@Value("${splitTextFileISSTE}")
	private String[] splitTextFileISSTE;
	
	private int[] intArraySplitTextFileISSTE;
	
	@PostConstruct
	private void setTheSplitArray() {
		intArraySplitTextFileISSTE = Arrays.asList(splitTextFileISSTE).stream().mapToInt(Integer::parseInt).toArray();
		System.out.println(intArraySplitTextFileISSTE);
	}*/

	@Autowired
	private ValidateDataText validateDataText;

	/**
	 * @param file
	 * @param fileName 
	 * @return
	 * @throws Exception
	 */
	public HashMap<String, List<String>> readFileThroughIS(CommonsMultipartFile file, String fileName) throws Exception {

		ArrayList<ArrayList<String>> arrayListOfSTringsBR = new ArrayList<>();
		
		Instant fileProcessStartBR = Instant.now();
		BufferedReader br = new BufferedReader(new InputStreamReader(file.getInputStream()));

		br.lines().forEach(string -> {
			ArrayList<String> singleLine = new ArrayList<>();
			for (int i = 0; i < intSplitTextFileISSTE.length; i++) {
				try {
					singleLine.add(
							string.substring(intSplitTextFileISSTE[i++] - 1, intSplitTextFileISSTE[i]).trim().intern());
				} catch (Exception e) {
					System.out.println(
							string + " - ::::" + e.getMessage() + " i value -" + (intSplitTextFileISSTE[i]));
				}
			}
			arrayListOfSTringsBR.add(singleLine);

		});
		br.close();

		System.out.println("read processing time Bufferedreader: "
				+ String.valueOf(Duration.between(fileProcessStartBR, Instant.now()).toMillis()));

		System.out.println("Starting Validation");
		// return validateDataText.validateWithoutEx(arrayListOfSTringsBR);
		return validateDataText.validateDataText(arrayListOfSTringsBR, fileName);
	}
}
