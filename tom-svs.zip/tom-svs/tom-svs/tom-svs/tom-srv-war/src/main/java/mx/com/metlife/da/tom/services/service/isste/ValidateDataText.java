/**
 * 
 */
package mx.com.metlife.da.tom.services.service.isste;

import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import mx.com.metlife.da.tom.services.utility.readUtils.StringUtilsOverRide;

/**
 * @author Capgemini
 * @since 08-07-2019
 */

@Service
public class ValidateDataText {
	
	@Autowired
	private ProcessDataForOutput processOutput;

	public HashMap<String, List<String>> validateDataText(ArrayList<ArrayList<String>> arrayListOfSTringsBR, String fileName) throws Exception {

		Instant validationStart = Instant.now();

		ExecutorService executor = Executors.newFixedThreadPool(9);

		List<Callable<List<ArrayList<String>>>> callables = Arrays.asList(
				() -> {
					//Concepto

					List<ArrayList<String>> findAll = arrayListOfSTringsBR.stream()
							.filter(singleLine -> !StringUtils.isNumericSpace(singleLine.get(0)))
							.collect(Collectors.toList());
					
					findAll.forEach(System.out::println);
					return findAll;
					},
				() -> {
					//Localidad
					
					List<ArrayList<String>> findAll = arrayListOfSTringsBR.stream().filter(
							singleLine -> !StringUtils.isAlphanumericSpace(StringUtils.remove(singleLine.get(1), '-')))
							.collect(Collectors.toList());
					findAll.forEach(System.out::println);
					return findAll;
				}, 
				() -> {
					//Número de Pensión

					List<ArrayList<String>> findAll = arrayListOfSTringsBR.stream()
							.filter(singleLine -> !StringUtils.isNumericSpace(singleLine.get(2)))
							.collect(Collectors.toList());
					
					findAll.forEach(System.out::println);
					return findAll;
				}, 
				() -> {
					//RFC

					List<ArrayList<String>> findAll = arrayListOfSTringsBR.stream().filter(
							singleLine -> !StringUtils.isAlphanumericSpace(StringUtils.remove(singleLine.get(3), '-')))
							.collect(Collectors.toList());
					
					findAll.forEach(System.out::println);
					return findAll;
				}, 
				() -> {
					//Nombre

					// Overrided the StringUtils,isAlphaSpace to support the dot character in names
					List<ArrayList<String>> findAll = arrayListOfSTringsBR.stream()
							.filter(singleLine -> !StringUtilsOverRide.isAlphaSpaceDotApostrophe(singleLine.get(4)))
							.collect(Collectors.toList());
					
					findAll.forEach(System.out::println);
					return findAll;
				}, 
				() -> {
					//Importe de la Pensión

					List<ArrayList<String>> findAll = arrayListOfSTringsBR.stream()
							.filter(singleLine -> !StringUtils.isNumericSpace(singleLine.get(5)))
							.collect(Collectors.toList());
					
					findAll.forEach(System.out::println);
					return findAll;
				}, 
				() -> {
					//Importe de Descuento

					List<ArrayList<String>> findAll = arrayListOfSTringsBR.stream()
							.filter(singleLine -> !StringUtils.isNumericSpace(singleLine.get(6)))
							.collect(Collectors.toList());
					
					findAll.forEach(System.out::println);
					return findAll;
				}, 
				() -> {
					//Ramo

					List<ArrayList<String>> findAll = arrayListOfSTringsBR.stream()
							.filter(singleLine -> !StringUtils.isNumericSpace(singleLine.get(7)))
							.collect(Collectors.toList());
					
					findAll.forEach(System.out::println);
					return findAll;
				}, 
				() -> {
					//Fecha de Inicio de la Pensión

					List<ArrayList<String>> findAll = arrayListOfSTringsBR.stream()
							.filter(singleLine -> !StringUtils.isNumericSpace(singleLine.get(8)))
							.collect(Collectors.toList());
					
					findAll.forEach(System.out::println);
					return findAll;
				});

		List<Future<List<ArrayList<String>>>> futures = null;
		try {
			futures = executor.invokeAll(callables);
		} catch (InterruptedException e1) {
			e1.printStackTrace();
			throw new Exception("Error executing Executer service");
		}

		HashMap<String, List<String>> listOfAllError = new HashMap<>();
		

		for (int i = 0; i < futures.size(); i++) {
			switch (i) {
			case 0:
				try {
					List<String> collect = futures.get(i).get().stream().map(List::toString)
							.collect(Collectors.toList());
					
					if(!collect.isEmpty()) {
						listOfAllError.put("CONCEPTO", collect);
					}
				} catch (InterruptedException | ExecutionException e) {
					throw new Exception(e);
				}
				break;
			case 1:
				try {
					List<String> collect = futures.get(i).get().stream().map(List::toString)
							.collect(Collectors.toList());
					
					if(!collect.isEmpty()) {
						listOfAllError.put("LOCALIDAD", collect);
					}
				} catch (InterruptedException | ExecutionException e) {
					throw new Exception(e);
				}
				break;
			case 2:
				try {
					List<String> collect = futures.get(i).get().stream().map(List::toString)
							.collect(Collectors.toList());
					
					if(!collect.isEmpty()) {
						listOfAllError.put("NUM_PENSION", collect);
					}
				} catch (InterruptedException | ExecutionException e) {
					throw new Exception(e);
				}
				break;
			case 3:
				try {
					List<String> collect = futures.get(i).get().stream().map(List::toString)
							.collect(Collectors.toList());
					
					if(!collect.isEmpty()) {
						listOfAllError.put("RFC", collect);
					}
				} catch (InterruptedException | ExecutionException e) {
					throw new Exception(e);
				}
				break;
			case 4:
				try {
					List<String> collect = futures.get(i).get().stream().map(List::toString)
							.collect(Collectors.toList());
					
					if(!collect.isEmpty()) {
						listOfAllError.put("NOMBRE", collect);
					}
				} catch (InterruptedException | ExecutionException e) {
					throw new Exception(e);
				}
				break;
			case 5:
				try {
					List<String> collect = futures.get(i).get().stream().map(List::toString)
							.collect(Collectors.toList());
					
					if(!collect.isEmpty()) {
						listOfAllError.put("IMP_PENSION", collect);
					}
				} catch (InterruptedException | ExecutionException e) {
					throw new Exception(e);
				}
				break;
			case 6:
				try {
					List<String> collect = futures.get(i).get().stream().map(List::toString)
							.collect(Collectors.toList());
					
					if(!collect.isEmpty()) {
						listOfAllError.put("IMP_DESCUENTO", collect);
					}
				} catch (InterruptedException | ExecutionException e) {
					throw new Exception(e);
				}
				break;
			case 7:
				try {
					List<String> collect = futures.get(i).get().stream().map(List::toString)
							.collect(Collectors.toList());
					
					if(!collect.isEmpty()) {
						listOfAllError.put("RAMO", collect);
					}
				} catch (InterruptedException | ExecutionException e) {
					throw new Exception(e);
				}
				break;
			case 8:
				try {
					List<String> collect = futures.get(i).get().stream().map(List::toString)
							.collect(Collectors.toList());
					
					if(!collect.isEmpty()) {
						listOfAllError.put("FECHA_INICIO", collect);
					}
				} catch (InterruptedException | ExecutionException e) {
					throw new Exception(e);
				}
				break;
			}
		}

		try {
			executor.shutdown();
			executor.awaitTermination(20, TimeUnit.MILLISECONDS);
		} catch (InterruptedException e) {
			e.printStackTrace();
		} finally {
			if (!executor.isTerminated()) {
				System.out.println("NOt terminated");
			}
			executor.shutdownNow();
		}

		System.out.println(
				"Validation time : " + String.valueOf(Duration.between(validationStart, Instant.now()).toMillis()));
		
		if ( listOfAllError.isEmpty() ) {
			processOutput.processTextOutPut(arrayListOfSTringsBR, fileName);
		}
		return listOfAllError;
	}

	public HashMap<String, List<String>> validateWithoutEx(ArrayList<ArrayList<String>> al) {

		Instant validationStart = Instant.now();
		HashMap<String, List<String>> listOfAllError = new HashMap<>();

		listOfAllError.put("CONCEPTO", al.stream().filter(singleLine -> !StringUtils.isNumericSpace(singleLine.get(0)))
				.map(List::toString).collect(Collectors.toList()));

		listOfAllError.put("LOCALIDAD", al.stream()
				.filter(singleLine -> !StringUtils.isAlphanumericSpace(StringUtils.remove(singleLine.get(1), '-')))
				.map(List::toString).collect(Collectors.toList()));

		listOfAllError.put("NUM_PENSION",
				al.stream().filter(singleLine -> !StringUtils.isNumericSpace(singleLine.get(2))).map(List::toString)
						.collect(Collectors.toList()));

		listOfAllError.put("RFC", al.stream()
				.filter(singleLine -> !StringUtils.isAlphanumericSpace(StringUtils.remove(singleLine.get(3), '-')))
				.map(List::toString).collect(Collectors.toList()));

		listOfAllError.put("NOMBRE", al.stream().filter(singleLine -> !StringUtils.isAlphaSpace(singleLine.get(4)))
				.map(List::toString).collect(Collectors.toList()));

		listOfAllError.put("IMP_PENSION",
				al.stream().filter(singleLine -> !StringUtils.isNumericSpace(singleLine.get(5))).map(List::toString)
						.collect(Collectors.toList()));

		listOfAllError.put("IMP_DESCUENTO",
				al.stream().filter(singleLine -> !StringUtils.isNumericSpace(singleLine.get(6))).map(List::toString)
						.collect(Collectors.toList()));

		listOfAllError.put("RAMO", al.stream().filter(singleLine -> !StringUtils.isNumericSpace(singleLine.get(7)))
				.map(List::toString).collect(Collectors.toList()));

		listOfAllError.put("FECHA_INICIO",
				al.stream().filter(singleLine -> !StringUtils.isNumericSpace(singleLine.get(8))).map(List::toString)
						.collect(Collectors.toList()));

		System.out.println("Validation time Without executor: "
				+ String.valueOf(Duration.between(validationStart, Instant.now()).toMillis()));

		return listOfAllError;
	}
}
