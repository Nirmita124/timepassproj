package mx.com.metlife.da.tom.services.service;

import static org.slf4j.LoggerFactory.getLogger;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.text.Normalizer;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipInputStream;

import javax.validation.Configuration;
import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.jxls.reader.ReaderBuilder;
import org.jxls.reader.XLSReader;
import org.jxls.reader.XLSSheetReader;
import org.jxls.reader.XLSSheetReaderImpl;
import org.slf4j.Logger;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import com.gizbel.excel.enums.ExcelFactoryType;
import com.gizbel.excel.factory.Parser;

import mx.com.metlife.da.tom.services.service.dto.FileDataFilter;
import mx.com.metlife.da.tom.services.service.dto.FileDataFilter2;

@Service
public class ReadFromFileService {

	private static final Logger logger = getLogger(ReadFromFileService.class);

	static String[] key = { "entidad", "idEntidad", "noArchivo", "procesoDeNomina", "nombre", "primerPaterno",
			"segundoMaterino", "curp", "rfc", "clc", "cveConCepto", "description", "sumaDeImporte" };
	
	public static void main(String[] args) throws Exception {
		LocalDateTime startTime = LocalDateTime.now();

		/*
		 * List<String> fileLocationList =
		 * Arrays.asList("C:\\Users\\prasjain\\Desktop\\PSJ\\Javatest\\Java.csv",
		 * "C:\\Users\\prasjain\\Desktop\\PSJ\\Javatest\\Java.xls",
		 * "C:\\Users\\prasjain\\Desktop\\PSJ\\Javatest\\Java.xlsx",
		 * "C:\\Users\\prasjain\\Desktop\\PSJ\\Javatest\\Java.txt",
		 * "C:\\Users\\prasjain\\Desktop\\PSJ\\Javatest\\Java.zip");
		 * 
		 * fileLocationList.forEach(fileName -> { try { processFile(fileName); } catch
		 * (Exception e) { e.printStackTrace(); } }); double as = 7002;
		 */

		final String sampleText = " ";
		System.out.println(sampleText.matches("M|F|m|f| "));

		Duration duration = Duration.between(startTime, LocalDateTime.now());
		System.out.println("ReadFromFile2: " + duration); // ReadFromFile2: PT0.003S
	}

	public static void processFile(String fileName) throws Exception {
		File file = new File(fileName);
		String fileExtention = getFileExtension(fileName);
		System.out.println("fileName: " + file.getName());
		System.out.println("fileExtention: " + fileExtention);

		if (fileExtention.equalsIgnoreCase("zip")) {
			try (ZipInputStream zipIn = new ZipInputStream(
					new FileInputStream("C:\\Users\\prasjain\\Desktop\\PSJ\\Javatest\\Java.zip"))) {
				readZipFile(zipIn);
			}
		} else {
			try (InputStream fileInputStream = new FileInputStream(file)) {
				readFileData(fileInputStream, fileExtention);
			}
		}

	}

	public static void readFileData(InputStream fileInputStream, String fileExtension) throws Exception {
		switch (fileExtension.toLowerCase()) {
		case "txt":
			System.out.println("for case: txt");
			// readTextFlie(fileInputStream);
			break;
		case "csv":
			System.out.println("for case: csv");
			readCSVFile(fileInputStream, ",");
			break;
		case "xls":
			System.out.println("for case: xls");
			// readExcelFlie(fileInputStream, fileExtension);
			break;
		case "dat":
			System.out.println("for case: dat");
			readDimilitedOrDATFile(fileInputStream, "\\|");
			break;
		case "xlsx":
			System.out.println("for case: xlsx");
			// readExcelFlie(fileInputStream, fileExtension);
			break;
		default:
			break;
		}
	}

	public static HashMap<String, Object> readExcelFlie(File convFile, String fileExtension) throws Exception {

		logger.info("Started Executing readExcelFile Method");
		Workbook workbook = null;

		OPCPackage op = OPCPackage.open(convFile);
		ArrayList<FileDataFilter> fdList = new ArrayList<>();
		Instant conversionToWorkbook = Instant.now();

		if (fileExtension.equalsIgnoreCase("xls")) {
			// workbook = new HSSFWorkbook(new );
		} else if (fileExtension.equalsIgnoreCase("xlsx")) {
			workbook = new XSSFWorkbook(op);
		}

		logger.info("{} milliSecond", Duration.between(conversionToWorkbook, Instant.now()).toMillis());

		try {
			System.out.println("Workbook has " + workbook.getNumberOfSheets() + " Sheets : ");

			workbook.forEach(sheet -> {
				System.out.println("=> " + sheet.getSheetName());
			});

			Sheet sheet = workbook.getSheetAt(0);
			System.out.println(sheet.getPhysicalNumberOfRows());
			DataFormatter dataFormatter = new DataFormatter();
			System.out.println("Iterating over Rows and Columns using Java 8 forEach with lambda\n");

			for (Sheet sheetIterate : workbook) {

				for (Row row : sheetIterate) {

					HashMap<String, Object> rowObject = new HashMap<String, Object>();
					FileDataFilter fd = new FileDataFilter();
					short length = row.getLastCellNum();

					for (int i = 0; i < length; i++) {
						rowObject.put(key[i], i == 12 ? row.getCell(i) : dataFormatter.formatCellValue(row.getCell(i)));
					}

					try {
						BeanUtils.populate(fd, rowObject);
					} catch (IllegalAccessException | InvocationTargetException e) {
						e.printStackTrace();
					}
					fdList.add(fd);

					rowObject = null;
				}
			}

		} catch (Exception exception) {
			throw exception;
		}

		HashMap<String, Object> parseAndValidateExcelData = parseAndValidateExcelData(fdList);

		return parseAndValidateExcelData;
	}

	@SuppressWarnings("unchecked")
	public static HashMap<String, Object> readTextFlie(File convFile) throws Exception {

		ArrayList<String> arl = (ArrayList<String>) FileUtils.readLines(convFile, "UTF-8");
		logger.info("Size Before removing empty elements : {}", arl.size());
		arl.removeIf(x -> String.valueOf(x).trim().equals(""));
		logger.info("Size Before removing empty elements : {}", arl.size());
		ArrayList<FileDataFilter> fdList = new ArrayList<>();
		for (String object : arl) {
			List<String> al = Arrays.asList(object.split(" ++"));
			HashMap<String, Object> hm = new HashMap<>();
			FileDataFilter fd = new FileDataFilter();
			for (int i = 0; i < al.size(); i++) {
				hm.put(key[i], StringUtils.deleteWhitespace(al.get(i)));

			}
			BeanUtils.populate(fd, hm);
			fdList.add(fd);
		}
		HashMap<String, Object> hm = new HashMap<>();
		hm.put("ResultFromTxtFile", fdList);
		return hm;

	}

	public static void readCSVFile(InputStream fileInputStream, String cvsSplitBy) throws Exception {
		try (BufferedReader reader = new BufferedReader(new InputStreamReader(fileInputStream))) {
			String line = "";
			while ((line = reader.readLine()) != null) {
				String[] fileData = line.split(cvsSplitBy);
				System.out.println("fileData " + fileData[0]);
			}
		}
	}

	public static void readDimilitedOrDATFile(InputStream fileInputStream, String delimiter) throws Exception {
		try (BufferedReader reader = new BufferedReader(new InputStreamReader(fileInputStream))) {
			String line = "";
			while ((line = reader.readLine()) != null) {
				String[] fileData = line.split(delimiter);
				System.out.println("fileData " + fileData[0].toString());
			}
		}
	}

	public static void readZipFile(ZipInputStream zipIn) throws Exception {
		ZipEntry entry;
		while ((entry = zipIn.getNextEntry()) != null) {
			String fileName = entry.getName();
			System.out.println(entry.getName());
			InputStream fileInputStream = new FileInputStream(fileName);
			readFileData(fileInputStream, getFileExtension(fileName));
			fileInputStream.close();
			zipIn.closeEntry();
		}
	}

	@SuppressWarnings({ "rawtypes", "resource" })
	public static void readZipStream(String zipFileName) throws Exception {
		ZipFile zip = new ZipFile(new File(zipFileName));

		for (Enumeration e = zip.entries(); e.hasMoreElements();) {
			ZipEntry entry = (ZipEntry) e.nextElement();
			System.out.println("File name: " + entry.getName() + "; size: " + entry.getSize() + "; compressed size: "
					+ entry.getCompressedSize());
			InputStream is = zip.getInputStream(entry);
			InputStreamReader isr = new InputStreamReader(is);

			char[] buffer = new char[1024];
			while (isr.read(buffer, 0, buffer.length) != -1) {
				String s = new String(buffer);
				System.out.println(s.trim());
			}
		}
	}

	public static List<FileDataFilter> parseExcelFile(InputStream inputStream) throws Exception {
		final List<FileDataFilter> dataList = new ArrayList<FileDataFilter>();
		InputStream xmlMapping = new BufferedInputStream(
				ReadFromFileService.class.getClassLoader().getResourceAsStream("paymentData.xml"));
		// ReaderConfig.getInstance().setUseDefaultValuesForPrimitiveTypes(true);
		// ReaderConfig.getInstance().setSkipErrors(true);
		try (InputStream inputXLS = new BufferedInputStream(inputStream)) {
			XLSReader mainReader = ReaderBuilder.buildFromXML(xmlMapping);
			XLSSheetReader sheetReader = new XLSSheetReaderImpl();
			mainReader.addSheetReader(sheetReader);
			// mainReader.
			final Map<String, Object> beans = new HashMap<String, Object>();
			beans.put("dataList", dataList);
			mainReader.read(inputXLS, beans);
			System.out.println("Data extracted successfully, number of rows are: " + dataList.size());
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
			throw new Exception(ex.getMessage());
		}

		return dataList;
	}

	public static List<Object> parseExcelAnnotation(File excelFile) throws Exception {
		Parser parser = new Parser(FileDataFilter2.class, ExcelFactoryType.COLUMN_INDEX_BASED_EXTRACTION);
		parser.setSkipHeader(true); // In case if you want to skip header
		List<Object> listOfDataItems = parser.parse(excelFile); // Whatever excel file you want
		System.out.println("Data extracted successfully, number of rows are: " + listOfDataItems.size()); // 1.288S
		return listOfDataItems;
	}

	public byte[] convert(XSSFSheet sheet) {
		// File convFile = new File(sheet.getSheetName());
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		try {
			sheet.getWorkbook().write(baos);
		} catch (IOException e) {
			// blah
		}
		return baos.toByteArray();
	}

	public static HashMap<String, Object> parseAndValidateExcelData(List<FileDataFilter> listOfDataItems)
			throws Exception {
		final String tabSpace = "   ";
		// List<FileDataFilter> listOfDataItems =
		// parseExcelFile(inputStream);//parseExcelAnnotation(excelFile);
		HashMap<Object, List<String>> hash_Map = new HashMap<>();
		HashMap<String, Object> outputMessage = new HashMap<>();

		Validator validator = createValidator();
		StringBuilder violationMessage = new StringBuilder();

		for (FileDataFilter rowObject : listOfDataItems) {
			violationMessage.setLength(0);
			// FileDataFilter2 rowObject = (FileDataFilter2) obj;
			Set<ConstraintViolation<FileDataFilter>> violations = validator.validate(rowObject);
			if (!violations.isEmpty()) {

				/*
				 * hash_Map.put(rowObject.getNombre(), new ArrayList<>());
				 * violations.stream().forEach(x -> { violationMessage.setLength(0);
				 * hash_Map.get(rowObject.getNombre()).add((violationMessage.append(x.getMessage
				 * ()).append(tabSpace) .append(x.getInvalidValue()).toString())); });
				 */
			}
			// errorReport.append(validateData(rowObject, hash_Set));
		}
		if (hash_Map.isEmpty()) {
			outputMessage.put("result", "Data validated Successfully");
			// List<FileDataFilter2> listOfDataItemsNew =
			// (List<FileDataFilter2>)(Object)listOfDataItems;
			// GenerateOutputService.generateOutPutFileWithCSVUtil2(listOfDataItemsNew);

		} else {
			outputMessage.put("List of Errored Columns are: ", hash_Map);
		}

		return outputMessage;
	}

	public static Validator createValidator() {
		Configuration<?> config = Validation.byDefaultProvider().configure();
		ValidatorFactory factory = config.buildValidatorFactory();
		Validator validator = factory.getValidator();
		factory.close();
		return validator;
	}

	@SuppressWarnings("rawtypes")
	public static String validateData(FileDataFilter2 rowObject, Set<String> hash_Set) {
		StringBuilder returnText = new StringBuilder("");
		Class clazz = rowObject.getClass();
		Field[] fields = clazz.getDeclaredFields();
		// System.out.println("Number of fields = " + fields.length);
		for (Field field : fields) {
			String fieldName = "", fieldValue = "", fieldType = "";
			try {
				fieldName = field.getName();
				fieldType = field.getType().getName();
				fieldValue = field.get(rowObject).toString();
				switch (fieldType) {
				case "java.lang.String":
					if (!flattenToAscii(fieldValue).matches("^[a-zA-Z0-9-./ ]*$")) {
						returnText.append(fieldName + " is not correct with Value " + fieldValue + "\n");
						hash_Set.add(fieldName);
					}
					break;

				case "int":
					if (!fieldValue.matches("\\d+")) {
						returnText.append(fieldName + " is not correct with Value " + fieldValue + "\n");
						hash_Set.add(fieldName);
					}
					break;

				case "double":
					if (!fieldValue.matches("[0-9]{1,13}(\\.[0-9]*)?")) {
						returnText.append(fieldName + " is not correct with Value " + fieldValue + "\n");
						hash_Set.add(fieldName);
					}
					break;

				default:
					returnText.append(fieldName + " does not matches: " + fieldValue + "\n");
					hash_Set.add(fieldName);
					break;
				}
			} catch (Exception e) {
				returnText.append("Error in parsing field: " + fieldName + " " + e + "\n");
				hash_Set.add(fieldName);
			}
		}

		return returnText.toString();
	}

	public static HashMap<String, Object> readData(CommonsMultipartFile file) {
		String fileName = file.getOriginalFilename();
		HashMap<String, Object> resResult = new HashMap<>();
		try {
			System.out.println("uploaded file name is: " + fileName);
			// resResult = parseAndValidateExcelData(file.getInputStream());
		} catch (Exception e) {
			e.printStackTrace();
		}

		return resResult;
	}

	public static String flattenToAscii(String string) {
		char[] out = new char[string.length()];
		string = Normalizer.normalize(string, Normalizer.Form.NFD);
		int j = 0;
		for (int i = 0, n = string.length(); i < n; ++i) {
			char c = string.charAt(i);
			if (c <= '\u007F')
				out[j++] = c;
		}
		return new String(out);
	}

	public static String getFileExtension(String fileName) {
		int lastIndexOf = fileName.lastIndexOf(".");
		if (lastIndexOf == -1) {
			return "";
		}
		return fileName.substring(lastIndexOf + 1);
	}
}