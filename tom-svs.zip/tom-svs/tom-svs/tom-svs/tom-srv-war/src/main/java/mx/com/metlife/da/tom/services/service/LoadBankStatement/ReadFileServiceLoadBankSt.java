package mx.com.metlife.da.tom.services.service.LoadBankStatement;

import static org.slf4j.LoggerFactory.getLogger;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.InvocationTargetException;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.time.temporal.TemporalAccessor;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.concurrent.atomic.AtomicInteger;

import org.apache.commons.beanutils.BeanUtils;
import org.hibernate.validator.constraints.Length;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import mx.com.metlife.da.tom.services.service.dto.FileDataFilter;
import mx.com.metlife.da.tom.services.service.fone.vida.ValidateDataTextVida;

@Service
public class ReadFileServiceLoadBankSt {
	
	private static Integer[] intSplitTextFileLoadBankSt = {1,2,3,12,13,22,23,52,53,82,83,90,91,105,106,119};
	
	private static final Logger logger = getLogger(ReadFileServiceLoadBankSt.class);

	static String[] key = { "banco_Id", "folio_Carga", "numero_Movimiento", "referencia_Bancaria", "concepto", "fecha_Pago",
			"importe_Pago", "fecha_Carga"};
	
	@Autowired
	private ValidateDataTextVida validateDataTextVida;
	
	public File convertToFile(CommonsMultipartFile file) throws Exception {
		File convFile = new File(file.getOriginalFilename());
		logger.info("Started Executing readExcelFile Method");
		
		try {
			convFile.createNewFile();
			FileOutputStream fos = new FileOutputStream(convFile);
			BufferedOutputStream bout = new BufferedOutputStream(fos);
			bout.write(file.getBytes());
			bout.flush();
			bout.close();
			file = null;
		} catch (Exception e) {
			throw e;
		}

		return convFile;
	}

	@SuppressWarnings("resource")
	public ArrayList<String> readFileThroughIS(InputStream fileStream, String fileName) throws Exception {

		logger.info("Started Executing readExcelFile Method");
//		HashMap<Integer, HashMap<Layout_LoadBankStatement, String>> arrayListOfSTringsBR = new HashMap<>();
		String parentFileName = "";
		
		ArrayList<LoadBankStatementBean> loadBankStList = new ArrayList<>();
		
		HashMap<String, Object> singleLine = new HashMap<>();
		LoadBankStatementBean bankStatementBean = new LoadBankStatementBean();
//	System.out.println("Length of the ENUM: " + intSplitTextFileLoadBankSt.length);
		
//		System.out.println("Name of Enum: " + Layout_LoadBankStatement.values()[8]);
		
		
		BufferedReader br = new BufferedReader(new InputStreamReader(fileStream));
		
		AtomicInteger lineNumber = new AtomicInteger();
		
		br.lines().forEach(rowString -> {
			
			for (int i = 0, forenum = 0; i < intSplitTextFileLoadBankSt.length; i++,forenum++) {
				try {
					
					String valofColumn = rowString.substring(intSplitTextFileLoadBankSt[i++] - 1, intSplitTextFileLoadBankSt[i]).trim(); 
					
					if(valofColumn.length() == 8)
					{
				//		TemporalAccessor date  = DateTimeFormatter.ofPattern("yyyy/MM/dd").parse(valofColumn);
					
						//new SimpleDateFormat("yyyy/MM/dd").parse(valofColumn);
						valofColumn = "2013/02/02";
	//					TemporalAccessor date  = DateTimeFormatter.ofPattern("yyyy/MM/dd").parse(valofColumn);
						SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");
						Date date = formatter.parse(valofColumn);
						
						System.out.println("date--" +date);
						singleLine.put(key[forenum],date);
						
					}
					else if(valofColumn.length() == 14)
					{
						valofColumn = "2013/02/02";
						SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");
						Date date = formatter.parse(valofColumn);
						
						System.out.println(date);
						singleLine.put(key[forenum],date);
					}
					
					else
					{
					
						singleLine.put(key[forenum],valofColumn);
					}
					/*singleLine.put(key[forenum],valofColumn);*/
					
					System.out.println("String...................................." + singleLine);
				
				} catch (Exception e) {
					System.out.println(
							rowString + " - ::::" + e.getMessage() + " i value -" + (intSplitTextFileLoadBankSt[i]));
				}
			
				/*BeanUtils.populate(bankStatementBean,singleLine);
				loadBankStList.add(bankStatementBean);*/
			
			
			System.out.println();
		}	
		//	arrayListOfSTringsBR.put(lineNumber.incrementAndGet(), singleLine);
			try {
				BeanUtils.populate(bankStatementBean,singleLine);
				loadBankStList.add(bankStatementBean);
				System.out.println("Value after populating Banco_ID    "+ bankStatementBean.getBanco_Id());
				System.out.println("Value after populating Banco_ID    "+ bankStatementBean.getConcepto());
			} catch (IllegalAccessException | InvocationTargetException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
		});
		
		br.close();
		logger.info("Reading completed for file {}.", fileName);
		return null;

		
//		validateDataTextVida = new ValidateDataTextVida();
//		return validateDataTextVida.validateDataTextVida(arrayListOfSTringsBR, parentFileName, fileName);

	}

	public static void main(String[] args) throws Exception {
		ReadFileServiceLoadBankSt readFileService = new ReadFileServiceLoadBankSt();
		
		File file = new File(
				"C:\\Users\\djain5\\Desktop\\Load BankStatement\\RAP_PAD_INI_420000012345_20190621171034.txt");
		InputStream fileStream = new FileInputStream(file);
		ArrayList<String> returnMap = readFileService.readFileThroughIS(fileStream, file.getName());

	}
	
	
	
}
