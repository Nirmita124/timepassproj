package mx.com.metlife.da.tom.services.service.isste05;

import static mx.com.metlife.da.tom.services.service.isste05.LayoutInputISSSTE5.APELLIDO_MATERNO;
import static mx.com.metlife.da.tom.services.service.isste05.LayoutInputISSSTE5.APELLIDO_PATERNO;
import static mx.com.metlife.da.tom.services.service.isste05.LayoutInputISSSTE5.CUOTA_DIARIA_PENSION;
import static mx.com.metlife.da.tom.services.service.isste05.LayoutInputISSSTE5.FECHA_INI_PEN;
import static mx.com.metlife.da.tom.services.service.isste05.LayoutInputISSSTE5.FECHA_PROCESO;
import static mx.com.metlife.da.tom.services.service.isste05.LayoutInputISSSTE5.SUELDO_BASE;
import static mx.com.metlife.da.tom.services.service.isste05.LayoutInputISSSTE5.TOTAL_CONCEPTO_01;
import static mx.com.metlife.da.tom.services.service.isste05.LayoutInputISSSTE5.TOTAL_PERCEPCIONES;
import static mx.com.metlife.da.tom.services.service.isste05.LayoutInputISSSTE5.TOTAL_SEGURO;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;

public class RemoveColumnISSSTE5 {

	@Autowired
	private FileWriteServiceISSSTE5 fileWriteServiceISSSTE5;

	@SuppressWarnings("unlikely-arg-type")
	public Object removeColumnDataISSSTE5(HashMap<Integer, HashMap<LayoutInputISSSTE5, String>> arrayListOfSTringsBR,
			String parentFileName, String fileName) {

		arrayListOfSTringsBR.forEach((lineNumber, row) -> {

			row.remove(APELLIDO_PATERNO);
			row.remove(APELLIDO_MATERNO);
			row.remove(TOTAL_PERCEPCIONES);
			row.remove(CUOTA_DIARIA_PENSION);
			row.remove(SUELDO_BASE);
			row.remove(TOTAL_CONCEPTO_01);

			row.remove(TOTAL_SEGURO);
			row.remove(FECHA_INI_PEN);
			row.remove(FECHA_PROCESO);
			
		

		});

		fileWriteServiceISSSTE5 = new FileWriteServiceISSSTE5();
		return fileWriteServiceISSSTE5.writeToTextFileISSSTE5(arrayListOfSTringsBR, parentFileName, fileName);

	}

}
