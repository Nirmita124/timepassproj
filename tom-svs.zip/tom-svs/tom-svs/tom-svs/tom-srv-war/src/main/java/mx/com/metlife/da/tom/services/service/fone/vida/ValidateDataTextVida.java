package mx.com.metlife.da.tom.services.service.fone.vida;

import static org.slf4j.LoggerFactory.getLogger;

import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import mx.com.metlife.da.tom.services.utility.readUtils.StringUtilsOverRide;

@Service
public class ValidateDataTextVida {

	private static final Logger logger = getLogger(ValidateDataTextVida.class);

	@Autowired
	private ProcessDataForOutputVida processOutputVida;

	@Autowired
	private FileWriteServiceVida fileWriteServiceVida;

	public ArrayList<String> validateDataTextVida(
			HashMap<Integer, HashMap<LayoutFoneVida, String>> arrayListOfSTringsBR, String parentFileName,
			String fileName) throws Exception {

		Instant validationStart = Instant.now();

		ExecutorService executor = Executors.newFixedThreadPool(25);

		List<Callable<Map<Integer, HashMap<LayoutFoneVida, String>>>> callables = Arrays.asList(() -> {
			// CVE_UR

			Stream<Entry<Integer, HashMap<LayoutFoneVida, String>>> stream = arrayListOfSTringsBR.entrySet().stream();

			Map<Integer, HashMap<LayoutFoneVida, String>> collect2 = stream.filter(row -> {
				return !StringUtils.isAlphanumeric(row.getValue().get(LayoutFoneVida.CVE_UR));
			}).collect(Collectors.toMap(entry -> entry.getKey(), entry -> entry.getValue()));

			return collect2;
		}, () -> {
			// CICLO

			Stream<Entry<Integer, HashMap<LayoutFoneVida, String>>> stream = arrayListOfSTringsBR.entrySet().stream();

			Map<Integer, HashMap<LayoutFoneVida, String>> collect2 = stream.filter(row -> {
				return !StringUtils.isNumeric(row.getValue().get(LayoutFoneVida.CICLO));
			}).collect(Collectors.toMap(entry -> entry.getKey(), entry -> entry.getValue()));

			return collect2;
		}, () -> {
			// CVE_MES

			Stream<Entry<Integer, HashMap<LayoutFoneVida, String>>> stream = arrayListOfSTringsBR.entrySet().stream();

			Map<Integer, HashMap<LayoutFoneVida, String>> collect2 = stream.filter(row -> {
				return !StringUtils.isNumeric(row.getValue().get(LayoutFoneVida.CVE_MES));
			}).collect(Collectors.toMap(entry -> entry.getKey(), entry -> entry.getValue()));

			return collect2;
		}, () -> {
			// PERIODO

			Stream<Entry<Integer, HashMap<LayoutFoneVida, String>>> stream = arrayListOfSTringsBR.entrySet().stream();

			Map<Integer, HashMap<LayoutFoneVida, String>> collect2 = stream.filter(row -> {
				return !StringUtilsOverRide.isDateformat1(row.getValue().get(LayoutFoneVida.PERIODO));
			}).collect(Collectors.toMap(entry -> entry.getKey(), entry -> entry.getValue()));

			return collect2;
		}, () -> {
			// TIPO_NOMINA

			Stream<Entry<Integer, HashMap<LayoutFoneVida, String>>> stream = arrayListOfSTringsBR.entrySet().stream();

			Map<Integer, HashMap<LayoutFoneVida, String>> collect2 = stream.filter(row -> {
				return !StringUtils.isAlpha(row.getValue().get(LayoutFoneVida.TIPO_NOMINA));
			}).collect(Collectors.toMap(entry -> entry.getKey(), entry -> entry.getValue()));

			return collect2;
		}, () -> {
			// NO_NOMINA

			Stream<Entry<Integer, HashMap<LayoutFoneVida, String>>> stream = arrayListOfSTringsBR.entrySet().stream();

			Map<Integer, HashMap<LayoutFoneVida, String>> collect2 = stream.filter(row -> {
				return !StringUtils.isNumeric(row.getValue().get(LayoutFoneVida.NO_NOMINA));
			}).collect(Collectors.toMap(entry -> entry.getKey(), entry -> entry.getValue()));

			return collect2;
		}, () -> {
			// CURP

			Stream<Entry<Integer, HashMap<LayoutFoneVida, String>>> stream = arrayListOfSTringsBR.entrySet().stream();

			Map<Integer, HashMap<LayoutFoneVida, String>> collect2 = stream.filter(row -> {
				return !StringUtils.isAlphanumeric(row.getValue().get(LayoutFoneVida.CURP));
			}).collect(Collectors.toMap(entry -> entry.getKey(), entry -> entry.getValue()));

			return collect2;
		}, () -> {
			// RFC

			Stream<Entry<Integer, HashMap<LayoutFoneVida, String>>> stream = arrayListOfSTringsBR.entrySet().stream();

			Map<Integer, HashMap<LayoutFoneVida, String>> collect2 = stream.filter(row -> {
				return !StringUtils.isAlphanumeric(row.getValue().get(LayoutFoneVida.RFC));
			}).collect(Collectors.toMap(entry -> entry.getKey(), entry -> entry.getValue()));

			return collect2;
		}, () -> {
			// TIPO_PERIODO

			Stream<Entry<Integer, HashMap<LayoutFoneVida, String>>> stream = arrayListOfSTringsBR.entrySet().stream();

			Map<Integer, HashMap<LayoutFoneVida, String>> collect2 = stream.filter(row -> {
				return !StringUtils.isAlpha(row.getValue().get(LayoutFoneVida.TIPO_PERIODO));
			}).collect(Collectors.toMap(entry -> entry.getKey(), entry -> entry.getValue()));

			return collect2;
		}, () -> {
			// NUM_PERIODO

			Stream<Entry<Integer, HashMap<LayoutFoneVida, String>>> stream = arrayListOfSTringsBR.entrySet().stream();

			Map<Integer, HashMap<LayoutFoneVida, String>> collect2 = stream.filter(row -> {
				return !StringUtils.isNumeric(row.getValue().get(LayoutFoneVida.NUM_PERIODO));
			}).collect(Collectors.toMap(entry -> entry.getKey(), entry -> entry.getValue()));

			return collect2;
		}, () -> {
			// NUM_COMPROBANTE

			Stream<Entry<Integer, HashMap<LayoutFoneVida, String>>> stream = arrayListOfSTringsBR.entrySet().stream();

			Map<Integer, HashMap<LayoutFoneVida, String>> collect2 = stream.filter(row -> {
				return !StringUtils.isNumeric(row.getValue().get(LayoutFoneVida.NUM_COMPROBANTE));
			}).collect(Collectors.toMap(entry -> entry.getKey(), entry -> entry.getValue()));

			return collect2;
		}, () -> {
			// CVE_CONCEPTO

			Stream<Entry<Integer, HashMap<LayoutFoneVida, String>>> stream = arrayListOfSTringsBR.entrySet().stream();

			Map<Integer, HashMap<LayoutFoneVida, String>> collect2 = stream.filter(row -> {
				return !StringUtils.isAlphanumeric(row.getValue().get(LayoutFoneVida.CVE_CONCEPTO));
			}).collect(Collectors.toMap(entry -> entry.getKey(), entry -> entry.getValue()));

			return collect2;
		}, () -> {
			// IMPORTE

			Stream<Entry<Integer, HashMap<LayoutFoneVida, String>>> stream = arrayListOfSTringsBR.entrySet().stream();

			Map<Integer, HashMap<LayoutFoneVida, String>> collect2 = stream.filter(row -> {

				return !StringUtils.isAsciiPrintable(row.getValue().get(LayoutFoneVida.IMPORTE));
			}).collect(Collectors.toMap(entry -> entry.getKey(), entry -> entry.getValue()));

			return collect2;
		}, () -> {
			// TIPO_CONCEPTO

			Stream<Entry<Integer, HashMap<LayoutFoneVida, String>>> stream = arrayListOfSTringsBR.entrySet().stream();

			Map<Integer, HashMap<LayoutFoneVida, String>> collect2 = stream.filter(row -> {
				return !StringUtils.isAlpha(row.getValue().get(LayoutFoneVida.TIPO_CONCEPTO));
			}).collect(Collectors.toMap(entry -> entry.getKey(), entry -> entry.getValue()));

			return collect2;
		}, () -> {
			// CVE_PLAZA

			Stream<Entry<Integer, HashMap<LayoutFoneVida, String>>> stream = arrayListOfSTringsBR.entrySet().stream();

			Map<Integer, HashMap<LayoutFoneVida, String>> collect2 = stream.filter(row -> {
				return !StringUtils.isAlphanumeric(row.getValue().get(LayoutFoneVida.CVE_PLAZA));
			}).collect(Collectors.toMap(entry -> entry.getKey(), entry -> entry.getValue()));

			return collect2;
		}, () -> {
			// NOMBRE

			Stream<Entry<Integer, HashMap<LayoutFoneVida, String>>> stream = arrayListOfSTringsBR.entrySet().stream();

			Map<Integer, HashMap<LayoutFoneVida, String>> collect2 = stream.filter(row -> {
				return !StringUtilsOverRide.isAlphaSpaceDotHyphen(row.getValue().get(LayoutFoneVida.NOMBRE));
			}).collect(Collectors.toMap(entry -> entry.getKey(), entry -> entry.getValue()));

			return collect2;
		}, () -> {
			// APELLIDO_PATERNO

			Stream<Entry<Integer, HashMap<LayoutFoneVida, String>>> stream = arrayListOfSTringsBR.entrySet().stream();

			Map<Integer, HashMap<LayoutFoneVida, String>> collect2 = stream.filter(row -> {
				return !StringUtilsOverRide.isAlphaSpaceDotHyphen(row.getValue().get(LayoutFoneVida.APELLIDO_PATERNO));
			}).collect(Collectors.toMap(entry -> entry.getKey(), entry -> entry.getValue()));

			return collect2;
		}, () -> {
			// APELLIDO_MATERNO

			Stream<Entry<Integer, HashMap<LayoutFoneVida, String>>> stream = arrayListOfSTringsBR.entrySet().stream();

			Map<Integer, HashMap<LayoutFoneVida, String>> collect2 = stream.filter(row -> {
				return !StringUtilsOverRide.isAlphaSpaceDotHyphen(row.getValue().get(LayoutFoneVida.APELLIDO_MATERNO));
			}).collect(Collectors.toMap(entry -> entry.getKey(), entry -> entry.getValue()));

			return collect2;
		}, () -> {
			// ZONA_ECONOMICA

			Stream<Entry<Integer, HashMap<LayoutFoneVida, String>>> stream = arrayListOfSTringsBR.entrySet().stream();

			Map<Integer, HashMap<LayoutFoneVida, String>> collect2 = stream.filter(row -> {
				return !StringUtils.isAlphaSpace(row.getValue().get(LayoutFoneVida.ZONA_ECONOMICA));
			}).collect(Collectors.toMap(entry -> entry.getKey(), entry -> entry.getValue()));

			return collect2;
		}, () -> {
			// NIVEL

			Stream<Entry<Integer, HashMap<LayoutFoneVida, String>>> stream = arrayListOfSTringsBR.entrySet().stream();

			Map<Integer, HashMap<LayoutFoneVida, String>> collect2 = stream.filter(row -> {
				return !StringUtils.isAlphanumericSpace(row.getValue().get(LayoutFoneVida.NIVEL));
			}).collect(Collectors.toMap(entry -> entry.getKey(), entry -> entry.getValue()));

			return collect2;
		}, () -> {
			// CÓDIGO

			Stream<Entry<Integer, HashMap<LayoutFoneVida, String>>> stream = arrayListOfSTringsBR.entrySet().stream();

			Map<Integer, HashMap<LayoutFoneVida, String>> collect2 = stream.filter(row -> {
				return !StringUtils.isAlphanumeric(row.getValue().get(LayoutFoneVida.CÓDIGO));
			}).collect(Collectors.toMap(entry -> entry.getKey(), entry -> entry.getValue()));

			return collect2;
		}, () -> {
			// IS_ISR

			Stream<Entry<Integer, HashMap<LayoutFoneVida, String>>> stream = arrayListOfSTringsBR.entrySet().stream();

			Map<Integer, HashMap<LayoutFoneVida, String>> collect2 = stream.filter(row -> {
				return !StringUtils.isNumeric(row.getValue().get(LayoutFoneVida.IS_ISR));
			}).collect(Collectors.toMap(entry -> entry.getKey(), entry -> entry.getValue()));

			return collect2;
		}, () -> {
			// MODELO

			Stream<Entry<Integer, HashMap<LayoutFoneVida, String>>> stream = arrayListOfSTringsBR.entrySet().stream();

			Map<Integer, HashMap<LayoutFoneVida, String>> collect2 = stream.filter(row -> {
				return !StringUtils.isNumeric(row.getValue().get(LayoutFoneVida.MODELO));
			}).collect(Collectors.toMap(entry -> entry.getKey(), entry -> entry.getValue()));

			return collect2;
		}, () -> {
			// PORCENTAJE

			Stream<Entry<Integer, HashMap<LayoutFoneVida, String>>> stream = arrayListOfSTringsBR.entrySet().stream();

			Map<Integer, HashMap<LayoutFoneVida, String>> collect2 = stream.filter(row -> {
				return !StringUtils.isAsciiPrintable(row.getValue().get(LayoutFoneVida.PORCENTAJE));
			}).collect(Collectors.toMap(entry -> entry.getKey(), entry -> entry.getValue()));

			return collect2;
		},

				() -> {
					// APORTACION

					Stream<Entry<Integer, HashMap<LayoutFoneVida, String>>> stream = arrayListOfSTringsBR.entrySet()
							.stream();

					Map<Integer, HashMap<LayoutFoneVida, String>> collect2 = stream.filter(row -> {
						return !StringUtils.isAsciiPrintable(row.getValue().get(LayoutFoneVida.APORTACION));
					}).collect(Collectors.toMap(entry -> entry.getKey(), entry -> entry.getValue()));

					return collect2;
				});

		List<Future<Map<Integer, HashMap<LayoutFoneVida, String>>>> futures = null;
		try {
			futures = executor.invokeAll(callables);
		} catch (InterruptedException e1) {
			e1.printStackTrace();
			throw new Exception("Error executing Executer service");
		}

		ArrayList<String> listOfAllError = new ArrayList<>();
		HashMap<Integer, ArrayList<String>> errorLinebyLineandval = new HashMap<>();

		
		
		for (int i = 0; i < futures.size(); i++) {
			switch (i) {
			case 0:
				try {
					Map<Integer, HashMap<LayoutFoneVida, String>> list = futures.get(i).get();
					list.forEach((lineNumber, row) -> {
						ArrayList<String> errorLineandVal = new ArrayList<>();
						errorLineandVal.addAll(
								Arrays.asList(ConstantVida.CVE_UR_ERROR, row.get(LayoutFoneVida.CVE_UR)));
						errorLinebyLineandval.put(lineNumber, errorLineandVal);
					});
				} catch (InterruptedException | ExecutionException e) {
					throw new Exception(e);
				}
				break;
			case 1:
				try {
					Map<Integer, HashMap<LayoutFoneVida, String>> list = futures.get(i).get();
					list.forEach((lineNumber, row) -> {
						ArrayList<String> errorLineandVal = new ArrayList<>();
						errorLineandVal
								.addAll(Arrays.asList(ConstantVida.CVE_UR_ERROR, row.get(LayoutFoneVida.CICLO)));
						errorLinebyLineandval.put(lineNumber, errorLineandVal);
					});
				} catch (InterruptedException | ExecutionException e) {
					throw new Exception(e);
				}
				break;
			case 2:
				try {
					Map<Integer, HashMap<LayoutFoneVida, String>> list = futures.get(i).get();
					list.forEach((lineNumber, row) -> {
						ArrayList<String> errorLineandVal = new ArrayList<>();
						errorLineandVal
								.addAll(Arrays.asList(ConstantVida.CVE_UR_ERROR, row.get(LayoutFoneVida.CVE_MES)));
						errorLinebyLineandval.put(lineNumber, errorLineandVal);
					});
				} catch (InterruptedException | ExecutionException e) {
					throw new Exception(e);
				}
				break;
			case 3:
				try {
					Map<Integer, HashMap<LayoutFoneVida, String>> list = futures.get(i).get();
					list.forEach((lineNumber, row) -> {
						ArrayList<String> errorLineandVal = new ArrayList<>();
						errorLineandVal.addAll(
								Arrays.asList(ConstantVida.CVE_UR_ERROR, row.get(LayoutFoneVida.PERIODO)));
						errorLinebyLineandval.put(lineNumber, errorLineandVal);
					});
				} catch (InterruptedException | ExecutionException e) {
					throw new Exception(e);
				}
				break;
			case 4:
				try {
					Map<Integer, HashMap<LayoutFoneVida, String>> list = futures.get(i).get();
					list.forEach((lineNumber, row) -> {
						ArrayList<String> errorLineandVal = new ArrayList<>();
						errorLineandVal.addAll(Arrays.asList(ConstantVida.CVE_UR_ERROR,
								row.get(LayoutFoneVida.TIPO_NOMINA)));
						errorLinebyLineandval.put(lineNumber, errorLineandVal);
					});
				} catch (InterruptedException | ExecutionException e) {
					throw new Exception(e);
				}
				break;
			case 5:
				try {
					Map<Integer, HashMap<LayoutFoneVida, String>> list = futures.get(i).get();
					list.forEach((lineNumber, row) -> {
						ArrayList<String> errorLineandVal = new ArrayList<>();
						errorLineandVal.addAll(
								Arrays.asList(ConstantVida.CVE_UR_ERROR, row.get(LayoutFoneVida.NO_NOMINA)));
						errorLinebyLineandval.put(lineNumber, errorLineandVal);
					});
				} catch (InterruptedException | ExecutionException e) {
					throw new Exception(e);
				}
				break;
			case 6:
				try {
					Map<Integer, HashMap<LayoutFoneVida, String>> list = futures.get(i).get();
					list.forEach((lineNumber, row) -> {
						ArrayList<String> errorLineandVal = new ArrayList<>();
						errorLineandVal.addAll(
								Arrays.asList(ConstantVida.CVE_UR_ERROR, row.get(LayoutFoneVida.CURP)));
						errorLinebyLineandval.put(lineNumber, errorLineandVal);
					});
				} catch (InterruptedException | ExecutionException e) {
					throw new Exception(e);
				}
				break;
			case 7:
				try {
					Map<Integer, HashMap<LayoutFoneVida, String>> list = futures.get(i).get();
					list.forEach((lineNumber, row) -> {
						ArrayList<String> errorLineandVal = new ArrayList<>();
						errorLineandVal
								.addAll(Arrays.asList(ConstantVida.CVE_UR_ERROR, row.get(LayoutFoneVida.RFC)));
						errorLinebyLineandval.put(lineNumber, errorLineandVal);
					});
				} catch (InterruptedException | ExecutionException e) {
					throw new Exception(e);
				}
				break;
			case 8:
				try {
					Map<Integer, HashMap<LayoutFoneVida, String>> list = futures.get(i).get();
					list.forEach((lineNumber, row) -> {
						ArrayList<String> errorLineandVal = new ArrayList<>();
						errorLineandVal.addAll(Arrays.asList(ConstantVida.CVE_UR_ERROR,
								row.get(LayoutFoneVida.TIPO_PERIODO)));
						errorLinebyLineandval.put(lineNumber, errorLineandVal);
					});
				} catch (InterruptedException | ExecutionException e) {
					throw new Exception(e);
				}
				break;

			case 9:
				try {
					Map<Integer, HashMap<LayoutFoneVida, String>> list = futures.get(i).get();
					list.forEach((lineNumber, row) -> {
						ArrayList<String> errorLineandVal = new ArrayList<>();
						errorLineandVal.addAll(Arrays.asList(ConstantVida.CVE_UR_ERROR,
								row.get(LayoutFoneVida.NUM_PERIODO)));
						errorLinebyLineandval.put(lineNumber, errorLineandVal);
					});
				} catch (InterruptedException | ExecutionException e) {
					throw new Exception(e);
				}
				break;
			case 10:
				try {
					Map<Integer, HashMap<LayoutFoneVida, String>> list = futures.get(i).get();
					list.forEach((lineNumber, row) -> {
						ArrayList<String> errorLineandVal = new ArrayList<>();
						errorLineandVal.addAll(Arrays.asList(ConstantVida.CVE_UR_ERROR,
								row.get(LayoutFoneVida.NUM_COMPROBANTE)));
						errorLinebyLineandval.put(lineNumber, errorLineandVal);
					});
				} catch (InterruptedException | ExecutionException e) {
					throw new Exception(e);
				}
				break;
			case 11:
				try {
					Map<Integer, HashMap<LayoutFoneVida, String>> list = futures.get(i).get();
					list.forEach((lineNumber, row) -> {
						ArrayList<String> errorLineandVal = new ArrayList<>();
						errorLineandVal.addAll(Arrays.asList(ConstantVida.CVE_UR_ERROR,
								row.get(LayoutFoneVida.CVE_CONCEPTO)));
						errorLinebyLineandval.put(lineNumber, errorLineandVal);
					});
				} catch (InterruptedException | ExecutionException e) {
					throw new Exception(e);
				}
				break;
			case 12:
				try {
					Map<Integer, HashMap<LayoutFoneVida, String>> list = futures.get(i).get();
					list.forEach((lineNumber, row) -> {
						ArrayList<String> errorLineandVal = new ArrayList<>();
						errorLineandVal.addAll(
								Arrays.asList(ConstantVida.CVE_UR_ERROR, row.get(LayoutFoneVida.IMPORTE)));
						errorLinebyLineandval.put(lineNumber, errorLineandVal);
					});
				} catch (InterruptedException | ExecutionException e) {
					throw new Exception(e);
				}
				break;
			case 13:
				try {
					Map<Integer, HashMap<LayoutFoneVida, String>> list = futures.get(i).get();
					list.forEach((lineNumber, row) -> {
						ArrayList<String> errorLineandVal = new ArrayList<>();
						errorLineandVal.addAll(Arrays.asList(ConstantVida.CVE_UR_ERROR,
								row.get(LayoutFoneVida.TIPO_CONCEPTO)));
						errorLinebyLineandval.put(lineNumber, errorLineandVal);
					});
				} catch (InterruptedException | ExecutionException e) {
					throw new Exception(e);
				}
				break;
			case 14:
				try {
					Map<Integer, HashMap<LayoutFoneVida, String>> list = futures.get(i).get();
					list.forEach((lineNumber, row) -> {
						ArrayList<String> errorLineandVal = new ArrayList<>();
						errorLineandVal.addAll(Arrays.asList(ConstantVida.CVE_UR_ERROR,
								row.get(LayoutFoneVida.CVE_PLAZA)));
						errorLinebyLineandval.put(lineNumber, errorLineandVal);
					});
				} catch (InterruptedException | ExecutionException e) {
					throw new Exception(e);
				}
				break;
			case 15:
				try {
					Map<Integer, HashMap<LayoutFoneVida, String>> list = futures.get(i).get();
					list.forEach((lineNumber, row) -> {
						ArrayList<String> errorLineandVal = new ArrayList<>();
						errorLineandVal.addAll(
								Arrays.asList(ConstantVida.CVE_UR_ERROR, row.get(LayoutFoneVida.NOMBRE)));
						errorLinebyLineandval.put(lineNumber, errorLineandVal);
					});
				} catch (InterruptedException | ExecutionException e) {
					throw new Exception(e);
				}
				break;
			case 16:
				try {
					Map<Integer, HashMap<LayoutFoneVida, String>> list = futures.get(i).get();
					list.forEach((lineNumber, row) -> {
						ArrayList<String> errorLineandVal = new ArrayList<>();
						errorLineandVal.addAll(Arrays.asList(ConstantVida.CVE_UR_ERROR,
								row.get(LayoutFoneVida.APELLIDO_PATERNO)));
						errorLinebyLineandval.put(lineNumber, errorLineandVal);
					});
				} catch (InterruptedException | ExecutionException e) {
					throw new Exception(e);
				}
				break;
			case 17:
				try {
					Map<Integer, HashMap<LayoutFoneVida, String>> list = futures.get(i).get();
					list.forEach((lineNumber, row) -> {
						ArrayList<String> errorLineandVal = new ArrayList<>();
						errorLineandVal.addAll(Arrays.asList(ConstantVida.CVE_UR_ERROR,
								row.get(LayoutFoneVida.APELLIDO_MATERNO)));
						errorLinebyLineandval.put(lineNumber, errorLineandVal);
					});
				} catch (InterruptedException | ExecutionException e) {
					throw new Exception(e);
				}
				break;
			case 18:
				try {
					Map<Integer, HashMap<LayoutFoneVida, String>> list = futures.get(i).get();
					list.forEach((lineNumber, row) -> {
						ArrayList<String> errorLineandVal = new ArrayList<>();
						errorLineandVal.addAll(Arrays.asList(ConstantVida.CVE_UR_ERROR,
								row.get(LayoutFoneVida.ZONA_ECONOMICA)));
						errorLinebyLineandval.put(lineNumber, errorLineandVal);
					});
				} catch (InterruptedException | ExecutionException e) {
					throw new Exception(e);
				}
				break;
			case 19:
				try {
					Map<Integer, HashMap<LayoutFoneVida, String>> list = futures.get(i).get();
					list.forEach((lineNumber, row) -> {
						ArrayList<String> errorLineandVal = new ArrayList<>();
						errorLineandVal.addAll(
								Arrays.asList(ConstantVida.CVE_UR_ERROR, row.get(LayoutFoneVida.NIVEL)));
						errorLinebyLineandval.put(lineNumber, errorLineandVal);
					});
				} catch (InterruptedException | ExecutionException e) {
					throw new Exception(e);
				}
				break;
			case 20:
				try {
					Map<Integer, HashMap<LayoutFoneVida, String>> list = futures.get(i).get();
					list.forEach((lineNumber, row) -> {
						ArrayList<String> errorLineandVal = new ArrayList<>();
						errorLineandVal.addAll(
								Arrays.asList(ConstantVida.CVE_UR_ERROR, row.get(LayoutFoneVida.CÓDIGO)));
						errorLinebyLineandval.put(lineNumber, errorLineandVal);
					});
				} catch (InterruptedException | ExecutionException e) {
					throw new Exception(e);
				}
				break;
			case 21:
				try {
					Map<Integer, HashMap<LayoutFoneVida, String>> list = futures.get(i).get();
					list.forEach((lineNumber, row) -> {
						ArrayList<String> errorLineandVal = new ArrayList<>();
						errorLineandVal.addAll(
								Arrays.asList(ConstantVida.CVE_UR_ERROR, row.get(LayoutFoneVida.IS_ISR)));
						errorLinebyLineandval.put(lineNumber, errorLineandVal);
					});
				} catch (InterruptedException | ExecutionException e) {
					throw new Exception(e);
				}
				break;
			case 22:
				try {
					Map<Integer, HashMap<LayoutFoneVida, String>> list = futures.get(i).get();
					list.forEach((lineNumber, row) -> {
						ArrayList<String> errorLineandVal = new ArrayList<>();
						errorLineandVal.addAll(
								Arrays.asList(ConstantVida.CVE_UR_ERROR, row.get(LayoutFoneVida.MODELO)));
						errorLinebyLineandval.put(lineNumber, errorLineandVal);
					});
				} catch (InterruptedException | ExecutionException e) {
					throw new Exception(e);
				}
				break;
			case 23:
				try {
					Map<Integer, HashMap<LayoutFoneVida, String>> list = futures.get(i).get();
					list.forEach((lineNumber, row) -> {
						ArrayList<String> errorLineandVal = new ArrayList<>();
						errorLineandVal.addAll(Arrays.asList(ConstantVida.CVE_UR_ERROR,
								row.get(LayoutFoneVida.PORCENTAJE)));
						errorLinebyLineandval.put(lineNumber, errorLineandVal);
					});
				} catch (InterruptedException | ExecutionException e) {
					throw new Exception(e);
				}
				break;
			case 24:
				try {
					Map<Integer, HashMap<LayoutFoneVida, String>> list = futures.get(i).get();
					list.forEach((lineNumber, row) -> {
						ArrayList<String> errorLineandVal = new ArrayList<>();
						errorLineandVal.addAll(Arrays.asList("APORTACION is not in decimal value",
								row.get(LayoutFoneVida.APORTACION)));
						errorLinebyLineandval.put(lineNumber, errorLineandVal);
					});
				} catch (InterruptedException | ExecutionException e) {
					throw new Exception(e);
				}
				break;
			}
		}

		try {
			executor.shutdown();
			executor.awaitTermination(20, TimeUnit.MILLISECONDS);
		} catch (InterruptedException e) {
			e.printStackTrace();
		} finally {
			if (!executor.isTerminated()) {
				logger.info("Not terminated");
			}
			executor.shutdownNow();
		}

		logger.info("Validation time : ");
		logger.info(String.valueOf(Duration.between(validationStart, Instant.now()).toMillis()));

		processOutputVida = new ProcessDataForOutputVida();
		processOutputVida.processTextOutPutVida(arrayListOfSTringsBR, parentFileName, fileName);
		fileWriteServiceVida = new FileWriteServiceVida();
		fileWriteServiceVida.processAndWriteErrorCSVVida(errorLinebyLineandval, fileName);
		listOfAllError.add("Error File Generated");
		return listOfAllError;
	}

}