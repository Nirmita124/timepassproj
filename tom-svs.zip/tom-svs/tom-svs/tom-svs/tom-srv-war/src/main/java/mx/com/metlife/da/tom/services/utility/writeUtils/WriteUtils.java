package mx.com.metlife.da.tom.services.utility.writeUtils;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.NumberFormat;
import java.util.Locale;

public class WriteUtils {
	
	public static String stringifyWithDecimals(String numericValue) {
        
		BigDecimal number = new BigDecimal(numericValue);
		BigDecimal divide = number.divide(new BigDecimal(100)).setScale(2, RoundingMode.HALF_EVEN);
		
		return NumberFormat.getNumberInstance(Locale.US).format(divide.doubleValue());
    }

}
