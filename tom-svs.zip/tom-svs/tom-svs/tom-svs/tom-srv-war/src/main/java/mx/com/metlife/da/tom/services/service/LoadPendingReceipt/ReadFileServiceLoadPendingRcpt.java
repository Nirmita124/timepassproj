package mx.com.metlife.da.tom.services.service.LoadPendingReceipt;

import static org.slf4j.LoggerFactory.getLogger;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.InvocationTargetException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.concurrent.atomic.AtomicInteger;

import org.apache.commons.beanutils.BeanUtils;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import mx.com.metlife.da.tom.services.service.fone.vida.ValidateDataTextVida;

@Service
public class ReadFileServiceLoadPendingRcpt {
	
	private static Integer[] intSplitTextFileLoadBankSt = {51,60,62,70,71,78,190,190,212,223,1070,1074,1206,1216,1217,1227};
	
	private static final Logger logger = getLogger(ReadFileServiceLoadPendingRcpt.class);

	static String[] key = { "numero_Poliza","fecha_Vig_Recibo","fecha_Fin_Vig_Recibo","estatus_Id","importe","ramo_SubRamo","folio",  
			"folio_Fiscal"};
	
	@Autowired
	private ValidateDataTextVida validateDataTextVida;
	
	public File convertToFile(CommonsMultipartFile file) throws Exception {
		File convFile = new File(file.getOriginalFilename());
		logger.info("Started Executing readExcelFile Method");
		
		try {
			convFile.createNewFile();
			FileOutputStream fos = new FileOutputStream(convFile);
			BufferedOutputStream bout = new BufferedOutputStream(fos);
			bout.write(file.getBytes());
			bout.flush();
			bout.close();
			file = null;
		} catch (Exception e) {
			throw e;
		}

		return convFile;
	}

	@SuppressWarnings("resource")
	public ArrayList<String> readFileThroughIS(InputStream fileStream, String fileName) throws Exception {


		logger.info("Started Executing readExcelFile Method");
//		HashMap<Integer, HashMap<Layout_LoadBankStatement, String>> arrayListOfSTringsBR = new HashMap<>();
		String parentFileName = "";
		
		ArrayList<LoadPendingRcptBean> loadPendingRcptList = new ArrayList<>();
		
		HashMap<String, Object> singleLine = new HashMap<>();
		LoadPendingRcptBean pendingRcptBean = new LoadPendingRcptBean();
//		System.out.println("Length of the ENUM: " + intSplitTextFileLoadBankSt.length);
//		System.out.println("Name of Enum: " + Layout_LoadBankStatement.values()[8]);
		
		BufferedReader br = new BufferedReader(new InputStreamReader(fileStream));
		
		AtomicInteger lineNumber = new AtomicInteger();
		
		br.lines().forEach(rowString -> {
			
			for (int i = 0, forenum = 0; i < intSplitTextFileLoadBankSt.length; i++,forenum++) {
				try {
					
					String valofColumn = rowString.substring(intSplitTextFileLoadBankSt[i++] - 1, intSplitTextFileLoadBankSt[i]).trim(); 
					
					if(valofColumn.length() == 8)
					{
						
				//		TemporalAccessor date  = DateTimeFormatter.ofPattern("yyyy/MM/dd").parse(valofColumn);
					
						//new SimpleDateFormat("yyyy/MM/dd").parse(valofColumn);
						valofColumn = "2013/02/02";
	//					TemporalAccessor date  = DateTimeFormatter.ofPattern("yyyy/MM/dd").parse(valofColumn);
						SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");
						Date date = formatter.parse(valofColumn);
						
						System.out.println(date);
						singleLine.put(key[forenum],date);
						
					}
					else if(valofColumn.length() == 14)
					{
						valofColumn = "2013/02/02";
						SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");
						Date date = formatter.parse(valofColumn);
						
						System.out.println(date);
						singleLine.put(key[forenum],date);
					}
					
					else
					{
					
						singleLine.put(key[forenum],valofColumn);
					}
					/*singleLine.put(key[forenum],valofColumn);*/
					
				
					System.out.println("String...................................." + singleLine);
			
					
					
					
				} catch (Exception e) {
					System.out.println(
							rowString + " - ::::" + e.getMessage() + " i value -" + (intSplitTextFileLoadBankSt[i]));
				}
			
				/*BeanUtils.populate(pendingRcptBean,singleLine);
				loadPendingRcptList.add(pendingRcptBean);*/
			
			try {
				BeanUtils.populate(pendingRcptBean,singleLine);
				loadPendingRcptList.add(pendingRcptBean);
				System.out.println("Value after populating Banco_ID    "+ pendingRcptBean.getNumero_Poliza());
				
			} catch (IllegalAccessException | InvocationTargetException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		}	
		//	arrayListOfSTringsBR.put(lineNumber.incrementAndGet(), singleLine);
	
		});
		
		br.close();
		logger.info("Reading completed for file {}.", fileName);
		return null;

//		validateDataTextVida = new ValidateDataTextVida();
//		return validateDataTextVida.validateDataTextVida(arrayListOfSTringsBR, parentFileName, fileName);

	}

	public static void main(String[] args) throws Exception {
		
		
		ReadFileServiceLoadPendingRcpt readFileService = new ReadFileServiceLoadPendingRcpt();
		
		File file = new File(
				"C:\\Users\\djain5\\Desktop\\Load pending reciept\\GCAPADEXT_DEUDORTOMC_AAAAMMDDHHMMSS.txt");
		InputStream fileStream = new FileInputStream(file);
		ArrayList<String> returnMap = readFileService.readFileThroughIS(fileStream, file.getName());

	}
	
	
	
}
