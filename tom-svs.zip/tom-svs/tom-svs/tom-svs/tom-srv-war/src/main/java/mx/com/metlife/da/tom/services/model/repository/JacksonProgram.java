package mx.com.metlife.da.tom.services.model.repository;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

public class JacksonProgram {

    public static void main(String[] args) throws Exception {
        System.out.println("Start");
    	test();
    	System.out.println("End");
    }

    public static void test() throws FileNotFoundException, IOException, Exception {
    	String csvFile = "C:\\Users\\prasjain\\Desktop\\Projects\\TOM\\Catalog\\TOM UI GEB CSV.csv";
    	try (InputStream in = new FileInputStream(csvFile);) {
    	    CSV csv = new CSV(true, ',', in );
    	    List < String > fieldNames = null;
    	    if (csv.hasNext()) fieldNames = new ArrayList < > (csv.next());
    	    List < Map < ?, ?>> list = new ArrayList < > ();
    	    while (csv.hasNext()) {
    	        List < String > x = csv.next();
    	        Map < String, String > obj = new LinkedHashMap < > ();
    	        for (int i = 0; i < fieldNames.size(); i++) {
    	            if (fieldNames.get(i).contains("FEC")) {
    	            	obj.put(fieldNames.get(i), getDateinYYYYMMDDformat(x.get(i)));
					} else 
						obj.put(fieldNames.get(i), x.get(i));
    	            
    	            
    	        }
    	        list.add(obj);
    	    }
    	    ObjectMapper mapper = new ObjectMapper();
    	    mapper.enable(SerializationFeature.INDENT_OUTPUT);
    	   
    	    // Creating a File object that represents the disk file. 
            PrintStream o = new PrintStream(new File("C:\\Users\\prasjain\\Desktop\\Projects\\TOM\\Catalog\\output.json")); 
            // Assign o to output stream 
            System.setOut(o); 
    	    
    	    mapper.writeValue(System.out, list);
    	}
    }
    
    public static String getDateinYYYYMMDDformat(String date) throws Exception {
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy");
		Date givenDate;
		String formattedDate = "";
		try {
			givenDate = simpleDateFormat.parse(date);
			simpleDateFormat = new SimpleDateFormat("yyyy/MM/dd");
			formattedDate = simpleDateFormat.format(givenDate);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		
		
		return formattedDate;
    }
		
}