package mx.com.metlife.da.tom.services.service.isste.layout0;

import static mx.com.metlife.da.tom.services.service.isste.layout0.Layout_ISSSTE_0.ARCHIVO_ORIGINARIO;
import static mx.com.metlife.da.tom.services.service.isste.layout0.Layout_ISSSTE_0.CONCEPTO;
import static mx.com.metlife.da.tom.services.service.isste.layout0.Layout_ISSSTE_0.FECHA_INICIO;
import static mx.com.metlife.da.tom.services.service.isste.layout0.Layout_ISSSTE_0.ID;
import static mx.com.metlife.da.tom.services.service.isste.layout0.Layout_ISSSTE_0.IMP_DESCUENTO;
import static mx.com.metlife.da.tom.services.service.isste.layout0.Layout_ISSSTE_0.IMP_PENSION;
import static mx.com.metlife.da.tom.services.service.isste.layout0.Layout_ISSSTE_0.LOCALIDAD;
import static mx.com.metlife.da.tom.services.service.isste.layout0.Layout_ISSSTE_0.MES_PAGO;
import static mx.com.metlife.da.tom.services.service.isste.layout0.Layout_ISSSTE_0.NOMBRE;
import static mx.com.metlife.da.tom.services.service.isste.layout0.Layout_ISSSTE_0.NOMBRE_CLIENTE;
import static mx.com.metlife.da.tom.services.service.isste.layout0.Layout_ISSSTE_0.NUM_PENSION;
import static mx.com.metlife.da.tom.services.service.isste.layout0.Layout_ISSSTE_0.POLIZA;
import static mx.com.metlife.da.tom.services.service.isste.layout0.Layout_ISSSTE_0.RAMO;
import static mx.com.metlife.da.tom.services.service.isste.layout0.Layout_ISSSTE_0.RFC;
import static mx.com.metlife.da.tom.services.service.isste.layout0.Layout_ISSSTE_0.SEXO;
import static mx.com.metlife.da.tom.services.service.isste.layout0.Layout_ISSSTE_0.SUBGRUPO;
import static org.slf4j.LoggerFactory.getLogger;

import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.DependsOn;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Service;

import mx.com.metlife.da.tom.services.utility.writeUtils.WriteUtils;

/**
 * @author Capgemini
 * @since 08-07-2019
 */
@Service
@PropertySource({"classpath:application.properties","classpath:issteReadWrite.properties"})
@DependsOn(value = {"ricsiCatalog", "issteCatalog"})
public class ProcessDataForOutput {
	
	private static final String NO_ENCONTRADO = "NO ENCONTRADO";
	private static final String POTENCIACION = "POTENCIACION";
	private static final String removeLeadingZeros = "^0+(?!$)";

	private static final Logger logger = getLogger(ProcessDataForOutput.class);
	
	@Value("#{${outputLengthConstraint}}")
	private HashMap<String, String> outputLengthConstraint;
	
	@Autowired
	private FileWriteService fileWriteService;
	
	@Autowired
	private ApplicationContext applicationContext;
	
	Map<Integer, String> ricsiCatalog;
	Map<String, List<String>> issteCatalog;
	
	@SuppressWarnings("unchecked")
	@PostConstruct
	public void getValidationCatalogBeans() {
		try {
			logger.info("Retrieving catalog beans");
			ricsiCatalog = (Map<Integer, String>) applicationContext.getBean("ricsiCatalog");
			
			issteCatalog = (Map<String, List<String>>) applicationContext.getBean("issteCatalog");
		} catch (BeansException e) {
			e.printStackTrace();
		}
	}
	
	public Object processTextOutPut (HashMap<Integer, HashMap<Layout_ISSSTE_0, String>> hashMapOfAllRows, String parentFileName, String fileName) {
		
		logger.info("Starting Output processing for file : {}", fileName);
		Calendar c = Calendar.getInstance();
		String displayName = c.getDisplayName(Calendar.MONTH, Calendar.LONG, new Locale("es", "ES"));
		String monthName = StringUtils.leftPad(displayName.toUpperCase(), 10);
		
		String trimmedfileName = StringUtils.leftPad(fileName.substring(fileName.lastIndexOf("/") + 1, fileName.length()), 30);
		
		hashMapOfAllRows.forEach((lineNumber,row) -> {

			row.replace(CONCEPTO, StringUtils.leftPad(row.get(CONCEPTO), CONCEPTO.getOutputConstraint() ));

			row.put(LOCALIDAD, StringUtils.leftPad(row.get(LOCALIDAD), LOCALIDAD.getOutputConstraint()));

			row.put(NUM_PENSION, StringUtils.leftPad(row.get(NUM_PENSION), NUM_PENSION.getOutputConstraint()));

			String rfc = StringUtils.remove(row.get(RFC), '-');
			row.put(RFC, StringUtils.leftPad(rfc, RFC.getOutputConstraint()));
			rfc = null;
			
			row.put(NOMBRE, StringUtils.leftPad(row.get(NOMBRE), NOMBRE.getOutputConstraint()));

			String importe_de_la_Pension = WriteUtils.stringifyWithDecimals(row.get(IMP_PENSION));

			row.put(IMP_PENSION, StringUtils.leftPad(importe_de_la_Pension, IMP_PENSION.getOutputConstraint()));

			String importe_de_Descuento = WriteUtils.stringifyWithDecimals(row.get(IMP_DESCUENTO));
			row.put(IMP_DESCUENTO, StringUtils.leftPad(importe_de_Descuento, IMP_DESCUENTO.getOutputConstraint()));
			importe_de_Descuento = null;
			
			row.put(RAMO, StringUtils.leftPad(row.get(RAMO), RAMO.getOutputConstraint()));

			row.put(FECHA_INICIO, StringUtils.leftPad(row.get(FECHA_INICIO), FECHA_INICIO.getOutputConstraint()));

			// Add Gender Column
			row.put(SEXO, "M");

			// Add ARCHIVO_ORIGINARIO
			row.put(ARCHIVO_ORIGINARIO, StringUtils.leftPad(trimmedfileName, ARCHIVO_ORIGINARIO.getOutputConstraint()));

			// Add MES_REPORTADO
			row.put(MES_PAGO, StringUtils.leftPad(monthName, MES_PAGO.getOutputConstraint()));

			// Add Id
			String id = new StringBuilder(row.get(CONCEPTO)).append("-").append(row.get(RAMO).trim()).toString();
			row.put(ID, StringUtils.leftPad(id, ID.getOutputConstraint()));
			
			//Add Poliza
			String concepto = row.get(CONCEPTO).replaceFirst(removeLeadingZeros, "");
			
			StringBuilder concep_ramo = new StringBuilder();
			concep_ramo.append(row.get(CONCEPTO).trim().replaceFirst(removeLeadingZeros, ""))
			.append("-").append(row.get(RAMO).trim().replaceFirst(removeLeadingZeros, ""));
			
			if((Integer.parseInt(concepto) >= 75 && Integer.parseInt(concepto) <=79) ||
					(Integer.parseInt(concepto) >= 101 && Integer.parseInt(concepto) <=105)) {
				String poliza = getPolicyFromRicsiCat(row.get(NUM_PENSION));
				
				row.put(POLIZA, StringUtils.leftPad(poliza, POLIZA.getOutputConstraint()));
			} else {
				
				String poliza = getPolicyFromISSTECat(concep_ramo);
				row.put(POLIZA, StringUtils.leftPad(poliza, POLIZA.getOutputConstraint()));
			}
			
			//Add Nombre Cliente
			String nombre_cliente = getNombreClienteFromISSTECat(concep_ramo);
			row.put(NOMBRE_CLIENTE, StringUtils.leftPad(nombre_cliente, NOMBRE_CLIENTE.getOutputConstraint()));
			
			//Add SubGrupo
			if((Integer.parseInt(concepto) >= 75 && Integer.parseInt(concepto) <=79) ||
					(Integer.parseInt(concepto) >= 101 && Integer.parseInt(concepto) <=105)) {
				row.put(SUBGRUPO, StringUtils.leftPad(POTENCIACION, SUBGRUPO.getOutputConstraint()));
			} else {
				
				String subGrupo = getSubgrupoFromIssteCat(concep_ramo);
				row.put(SUBGRUPO, StringUtils.leftPad(subGrupo, SUBGRUPO.getOutputConstraint()));
			}

		});
		
		c = null;
		logger.info("Output processing for file : {} {}", fileName, "completed.");
		fileWriteService.writeToTextFile(hashMapOfAllRows, fileName, parentFileName);
		
		return hashMapOfAllRows;
	}

	/**
	 * @param concep_ramo
	 * @return SUBGRUPO
	 */
	private String getSubgrupoFromIssteCat(StringBuilder concep_ramo) {
		if(null == issteCatalog.get(concep_ramo.toString())) {
			return NO_ENCONTRADO;
		}
		else {
			return issteCatalog.get(concep_ramo.toString()).get(5);
		}
	}


	/**
	 * @param concep_ramo
	 * @return NOMBRE CLIENTE
	 */
	private String getNombreClienteFromISSTECat(StringBuilder concep_ramo) {
		
		if(null == issteCatalog.get(concep_ramo.toString())) {
			//logger.error("No NOMBRE CLIENTE present for concept: {}", concep_ramo);
			return "";
		}
		else {
			return issteCatalog.get(concep_ramo.toString()).get(3);
		}
	}


	/**
	 * @param concep_ramo
	 * @return POLIZA
	 */
	private String getPolicyFromISSTECat(StringBuilder concep_ramo) {
		if(null == issteCatalog.get(concep_ramo.toString())) {
			//logger.error("No Poliza present for concept-ramo: {}", concep_ramo);
			return "";
		}
		else {
			return issteCatalog.get(concep_ramo.toString()).get(3);
		}
	}


	/**
	 * @param string
	 * @return POLIZA
	 */
	private String getPolicyFromRicsiCat(String string) {
		return ricsiCatalog.get(Integer.parseInt(string.trim().replaceFirst(removeLeadingZeros, "")));
	}

}
