package mx.com.metlife.da.tom.services.service.isste05;

public class ConstantISSSTE5 {

	public static final String CONCEPTO_ERROR = "CONCEPTO is not numeric value";
	public static final String LOCALIDAD_ERROR = "LOCALIDAD is not alphaNumeric  value";
	public static final String NUM_PENSION_ERROR = "NUM_PENSION is not numeric value";
	public static final String RFC_ERROR = "RFC is not in alphaNumeric value";
	public static final String NOMBRE_ERROR = "NOMBRE is not in alphabetical value";
	public static final String RAMO_ERROR = "RAMO is not in numeric value";
	

	public static final String OUTPUTFILE = "-Output.txt";
	
}
