/**
 * 
 */
package mx.com.metlife.da.tom.services.service.LoadPendingReceipt;

/**
 * @author Capgemini
 * @since 09-07-2019
 */

public enum Layout_LoadPendingRcpt {
	
	/*
	 * Banco_Id("Banco_Id", 2), Folio_Carga("Folio_Carga", 10),
	 * Numero_Movimiento("Numero_Movimiento", 10),
	 * Referencia_Bancaria("Referencia_Bancaria", 30), Concepto("Concepto", 30),
	 * Fecha_Pago("Fecha_Pago", 8), Importe_Pago("Importe_Pago", 15),
	 * Fecha_Carga("Fecha_Carga", 14), Importe_Restante("Importe_Restante", 15);
	 */
	
	Numero_Poliza("Numero_Poliza", 10),
	Fecha_Vig_Recibo("Fecha_Vig_Recibo",8 ),
	Fecha_Fin_Vig_Recibo("Fecha_Fin_Vig_Recibo", 8),
	Estatus_Id("Estatus_Id", 1),
	Importe("Importe", 12),
	Ramo_SubRamo("Ramo_SubRamo", 5),
	Folio("Folio", 10),
	Folio_Fiscal("Folio_Fiscal", 11);
	
	private final String columnName;
    private final Integer outputConstraint;

    Layout_LoadPendingRcpt(String key, Integer value) {
        this.columnName = key;
        this.outputConstraint = value;
    }

	public String getColumnName() {
		return columnName;
	}

	public Integer getOutputConstraint() {
		return outputConstraint;
	}
    
}
