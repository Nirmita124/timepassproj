package mx.com.metlife.da.tom.services.utility.readUtils;

import java.text.SimpleDateFormat;

import org.apache.commons.lang3.StringUtils;

public class StringUtilsOverRide extends StringUtils {
	
	public static boolean isAlphaSpaceDotApostrophe(final CharSequence cs) {
        if (cs == null) {
            return false;
        }
        final int sz = cs.length();
        for (int i = 0; i < sz; i++) {
            if (Character.isLetter(cs.charAt(i)) == false && cs.charAt(i) != ' ') {
            	return cs.charAt(i) == '.' || String.valueOf(cs.charAt(i)).equals("'") ? true : false ;
            }
        }
        return true;
    }
	
	public static boolean isAlphaSpaceDotHyphen(final CharSequence cs) {
        if (cs == null) {
            return false;
        }
        final int sz = cs.length();
        for (int i = 0; i < sz; i++) {
            if (Character.isLetter(cs.charAt(i)) == false) {
            	return cs.charAt(i) == '.' || String.valueOf(cs.charAt(i)).equals("-") || String.valueOf(cs.charAt(i)).equals(" ") ? true : false ;
            }
        }
        return true;
    }
	
	public static boolean isDateformat1(final CharSequence cs) {
        if (cs == null) {
            return false;
        }
        final int sz = cs.length();
        for (int i = 0; i < sz; i++) {
            if (Character.isDigit(cs.charAt(i)) == false) {
            	return String.valueOf(cs.charAt(i)).equals("/")  ? true : false ;
            }
        }
       
       return true;
    }

}
