package mx.com.metlife.da.tom.services.service.LoadPendingReceipt;

public interface LoadPendingRcptDao {

	
	
}
