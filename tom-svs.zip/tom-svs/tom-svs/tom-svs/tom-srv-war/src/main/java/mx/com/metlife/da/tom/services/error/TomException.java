package mx.com.metlife.da.tom.services.error;

/**
 * Exception class to handle custom exceptions.
 * 
 * @author Capgemini
 * @since 03/15/2019
 */
public class TomException extends Exception {

	private static final long serialVersionUID = -8453192529050470811L;

	public TomException() {
		super();
	}

	public TomException(String message) {
		super(message);
	}

	public TomException(String message, Throwable cause) {
		super(message, cause);
	}
}
