package mx.com.metlife.da.tom.services.web.controller;

import static org.slf4j.LoggerFactory.getLogger;

import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import mx.com.metlife.da.tom.services.service.ReadFromFileService;
import mx.com.metlife.da.tom.services.service.fone.vida.LayoutFoneVida;
import mx.com.metlife.da.tom.services.service.fone.vida.ReadFileServiceVida;
import mx.com.metlife.da.tom.services.service.isste.FileReadService;


/**
 * TomController is the REST controller which forwards the request to service
 * implementation.
 * 
 * @author Capgemini
 * @since 26/03/2019
 */
@RestController
@PropertySource({ "classpath:endpoint.properties", "classpath:application.properties" })
public class TomController {
	
	
	@PersistenceContext
	EntityManager entityManager;
	public TomController() {
		// TODO Auto-generated constructor stub
		System.out.println("entity Manager-- " +entityManager);
	}
	
	private static final Logger logger = getLogger(TomController.class);

	@Value("${headers.values}")
	private String[] headersArray;
	
	@Autowired
	private FileReadService fileReadService;
	
	@Autowired
	private ReadFileServiceVida readFileService1;

	@PostMapping("/api/upload")
	public ResponseEntity<HashMap<?, ?>> uploadFile(@RequestParam("file") CommonsMultipartFile file, HttpSession session)
			throws IOException, Exception {

		LocalDateTime startTime = LocalDateTime.now();
		logger.info(
				file.getOriginalFilename() + " " + session.getServletContext().getRealPath("/") + " " + file.getName());
		
		String fileName = file.getOriginalFilename();
		System.out.println("uploaded file name is: " + fileName);

		/*
		 * try { readFileThroughFileCOnversion(file); } catch (Exception e) {
		 * e.printStackTrace(); }
		 */
		HashMap<String, List<String>> readFileThroughIS = new HashMap<>();
		try {
			readFileThroughIS = fileReadService.readFileThroughIS(file,fileName);
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}

		Duration duration = Duration.between(startTime, LocalDateTime.now());
		System.out.println("ReadFromFile2: " + duration);

		if (readFileThroughIS.isEmpty()) {
			HashMap<String, String> res = new HashMap<String, String>();
			res.put("Errors", "All is Well");
			return new ResponseEntity<HashMap<?, ?>>(res, HttpStatus.OK);
		} else {
			return new ResponseEntity<HashMap<?, ?>>(readFileThroughIS, HttpStatus.OK);

		}
		// InputStream fileInputStream = new FileInputStream(convFile);
		// ReadFromFile.readFileData(fileInputStream,
		// ReadFromFile.getFileExtension(fileName));

	}
	
	
	@PostMapping("/api/upload1")
	public ResponseEntity<HashMap<?, ?>> uploadFile1(@RequestParam("file") CommonsMultipartFile file, HttpSession session)
			throws IOException, Exception {

		LocalDateTime startTime = LocalDateTime.now();
		logger.info(
				file.getOriginalFilename() + " " + session.getServletContext().getRealPath("/") + " " + file.getName());
		
		String fileName = file.getOriginalFilename();
		System.out.println("uploaded file name is: " + fileName);

		/*
		 * try { readFileThroughFileCOnversion(file); } catch (Exception e) {
		 * e.printStackTrace(); }
		 */
		ArrayList<String> readFileThroughIS1 = new ArrayList<>();
		try {
			File convertedFile = readFileService1.convertToFile(file);
//			readFileThroughIS1 = readFileService1.readFileThroughIS1(convertedFile,fileName);
			
			
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}

		Duration duration = Duration.between(startTime, LocalDateTime.now());
		System.out.println("ReadFromFile2: " + duration);

		if (readFileThroughIS1.isEmpty()) {
			HashMap<String, String> res = new HashMap<String, String>();
			res.put("Errors", "All is Well");
			return new ResponseEntity<HashMap<?, ?>>(res, HttpStatus.OK);
		} else {
			return new ResponseEntity<HashMap<?, ?>>(HttpStatus.OK);

		}
		// InputStream fileInputStream = new FileInputStream(convFile);
		// ReadFromFile.readFileData(fileInputStream,
		// ReadFromFile.getFileExtension(fileName));

	}
	

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@PostMapping("/api/uploadMultipleFiles")
	public ResponseEntity<?> uploadMultipleFiles(@RequestParam("files") CommonsMultipartFile[] files) {

		StringBuilder outputReport = new StringBuilder("");
		for (CommonsMultipartFile file : files) {
			String fileName = file.getOriginalFilename();
			System.out.println("file Name is: " + fileName);
			outputReport.append(fileName + " " + ReadFromFileService.readData(file) + "\n");
		}

		return new ResponseEntity("Response Messages \n" + outputReport.toString(), HttpStatus.OK);
	}

	// save uploaded file to this folder
	/*
	 * private static String UPLOADED_FOLDER = "C://temp//";
	 * 
	 * 
	 * @PostMapping("/upload") public String multiFileUpload(@ModelAttribute
	 * UploadForm form, RedirectAttributes redirectAttributes) {
	 * 
	 * StringJoiner sj = new StringJoiner(" , ");
	 * 
	 * for (MultipartFile file : form.getFiles()) {
	 * 
	 * if (file.isEmpty()) { continue; // next pls }
	 * 
	 * try { byte[] bytes = file.getBytes(); Path path = Paths.get(UPLOADED_FOLDER +
	 * file.getOriginalFilename()); Files.write(path, bytes);
	 * 
	 * sj.add(file.getOriginalFilename());
	 * 
	 * } catch (IOException e) { e.printStackTrace(); }
	 * 
	 * }
	 * 
	 * String uploadedFileName = sj.toString(); if
	 * (StringUtils.isEmpty(uploadedFileName)) {
	 * redirectAttributes.addFlashAttribute("message",
	 * "Please select a file to upload"); } else {
	 * redirectAttributes.addFlashAttribute("message", "You successfully uploaded '"
	 * + uploadedFileName + "'"); }
	 * 
	 * return "redirect:/uploadStatus";
	 * 
	 * }
	 */
	
	
	@GetMapping("/con")
	public EntityManager getEntityManager() {
		
		return entityManager;
	}
	
	
	
	

}
