/**
 * 
 */
package mx.com.metlife.da.tom.services.service.isste.layout0;

import static org.slf4j.LoggerFactory.getLogger;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.springframework.stereotype.Service;

/**
 * @author Capgemini
 * @since 07-08-2019
 */
@Service
public class FileWriteService {
	
	private static final Logger logger = getLogger(FileWriteService.class);
	
	public Object writeToTextFile(HashMap<Integer, HashMap<Layout_ISSSTE_0, String>> hashMapOfAllRows, String fileName, String parentFileName) {

		logger.info("Starting Appending the file data, filename : {}", fileName);
		File op = new File(fileName.concat(" - Output.txt"));
		System.out.println(op.getAbsolutePath());

		List<String> collect = hashMapOfAllRows.entrySet().stream().map(row -> {
			StringBuilder sb = new StringBuilder();
			for (Layout_ISSSTE_0 key : Layout_ISSSTE_0.values()) {
				String value = row.getValue().get(key) == null ? "" : row.getValue().get(key);
				sb.append(value);
			}
			return sb.toString();
		}).collect(Collectors.toList());

		hashMapOfAllRows = null;

		try (FileWriter fw = new FileWriter(parentFileName.concat("-Output.txt"), true);
				BufferedWriter bw = new BufferedWriter(fw);
				PrintWriter out = new PrintWriter(bw)) {
			collect.forEach(out::println);
		} catch (IOException e) {
			logger.error("Error Writing file: {} , Error: {}", fileName, e.getMessage());
		}

		collect = null;
		logger.info("Appended the File data of {}. Available at location {}", fileName, op.getAbsolutePath());
		return null;
	}
	
	public void processAndWriteErrorCSV(HashMap<Integer, ArrayList<String>> errorLibyLNandEval, String fileName) throws IOException {

		File csvOutputFile = new File("Error.csv");
		FileWriter fw = null;
		BufferedReader fr = null;
		try {
			fw = new FileWriter(csvOutputFile, true);
			fr = new BufferedReader( new FileReader(csvOutputFile));
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		
		try (PrintWriter pw = new PrintWriter(fw, true)) {

			if(fr.readLine() == null) {
				String header = Arrays.asList("Registro", "Nombre del Archivo", "Detalle Error").stream()
						.collect(Collectors.joining(","));
				pw.println(header);
			}
			
			String fileNameForErrorColumn = fileName.substring(fileName.lastIndexOf("/") + 1, fileName.length());
			
			errorLibyLNandEval.entrySet().stream().map(row -> {
				return String.join(",", Arrays.asList(String.valueOf(row.getKey()), fileNameForErrorColumn,
						row.getValue().get(0).concat(" - ").concat(row.getValue().get(1))));
			}).forEach(pw::println);
		}
		System.out.println(csvOutputFile.getAbsolutePath());
	}

}
