package mx.com.metlife.da.tom.services.service;

public interface UploadFileService {

	public String uploadFile(String claimNum);
}
