/**
 * 
 */
package mx.com.metlife.da.tom.services.service.isste03;

import static mx.com.metlife.da.tom.services.service.isste03.EnumISSTE3.APELLIDO_MATERNO;
import static mx.com.metlife.da.tom.services.service.isste03.EnumISSTE3.APELLIDO_PATERNO;
import static mx.com.metlife.da.tom.services.service.isste03.EnumISSTE3.CPTO;
import static mx.com.metlife.da.tom.services.service.isste03.EnumISSTE3.CURP;
/*import static mx.com.metlife.da.tom.services.service.foneSecore.EnumISSTE3.CTA_INTERBANCARIA;*/
import static mx.com.metlife.da.tom.services.service.isste03.EnumISSTE3.DESCRIPCION;
import static mx.com.metlife.da.tom.services.service.isste03.EnumISSTE3.HOMO;
import static mx.com.metlife.da.tom.services.service.isste03.EnumISSTE3.NIV_TAB;
import static mx.com.metlife.da.tom.services.service.isste03.EnumISSTE3.NUMPEN;
import static mx.com.metlife.da.tom.services.service.isste03.EnumISSTE3.PERCEPCION;
import static mx.com.metlife.da.tom.services.service.isste03.EnumISSTE3.PERIODO;
import static mx.com.metlife.da.tom.services.service.isste03.EnumISSTE3.PRIMA;
import static mx.com.metlife.da.tom.services.service.isste03.EnumISSTE3.PRIMA_BASICA;
import static mx.com.metlife.da.tom.services.service.isste03.EnumISSTE3.RAMO;
import static mx.com.metlife.da.tom.services.service.isste03.EnumISSTE3.RFC;
import static mx.com.metlife.da.tom.services.service.isste03.EnumISSTE3.SEXO;
import static mx.com.metlife.da.tom.services.service.isste03.EnumISSTE3.NOMBRE;
import static org.slf4j.LoggerFactory.getLogger;

import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Service;



/**
 * @author Capgemini
 * @since 08-07-2019
 */

@Service
@PropertySource({ "classpath:fone.properties" })
public class ValidateDataTextISSSTE03 {

	private static final Logger logger = getLogger(ReadFileServiceISSSTE03.class);

	@Autowired
	private ProcessDataForOutputISSSTE03 processOutput;

	@Autowired
	private FileWriteServiceISSSTE03 fileWrite;

	public ArrayList<String> validateDataTexts(HashMap<Integer, HashMap<EnumISSTE3, String>> hashMapOfAllRows,
			String parentFileName, String fileName) throws Exception {

		processOutput = new ProcessDataForOutputISSSTE03();
		Instant validationStart = Instant.now();

		ExecutorService executor = Executors.newFixedThreadPool(15);

		List<Callable<Map<Integer, HashMap<EnumISSTE3, String>>>> callables = Arrays.asList(
			   /*() -> {
					// ENTIDAD
					Stream<Entry<Integer, HashMap<EnumISSTE3, String>>> stream = hashMapOfAllRows.entrySet().stream();
		
					Map<Integer, HashMap<EnumISSTE3, String>> collect2 = stream.filter(row -> {
						return !StringUtils.isAsciiPrintable(row.getValue().get(PERIODO));
					}).collect(Collectors.toMap(entry -> entry.getKey(), entry -> entry.getValue()));
		
					return collect2;
				},*/

				() -> {

					// NUMPEN
					Stream<Entry<Integer, HashMap<EnumISSTE3, String>>> stream = hashMapOfAllRows.entrySet().stream();

					Map<Integer, HashMap<EnumISSTE3, String>> collect2 = stream.filter(row -> {
						return !StringUtils.isNumericSpace(row.getValue().get(NUMPEN));
					}).collect(Collectors.toMap(entry -> entry.getKey(), entry -> entry.getValue()));

					return collect2;
				}, () -> {

					// RAMO
					Stream<Entry<Integer, HashMap<EnumISSTE3, String>>> stream = hashMapOfAllRows.entrySet().stream();

					Map<Integer, HashMap<EnumISSTE3, String>> collect2 = stream.filter(row -> {
						return !StringUtils.isNumeric(row.getValue().get(RAMO));
					}).collect(Collectors.toMap(entry -> entry.getKey(), entry -> entry.getValue()));

					return collect2;
				}, () -> {

					// CPTO
					Stream<Entry<Integer, HashMap<EnumISSTE3, String>>> stream = hashMapOfAllRows.entrySet().stream();

					Map<Integer, HashMap<EnumISSTE3, String>> collect2 = stream.filter(row -> {
						return !StringUtils.isAlphanumericSpace(row.getValue().get(CPTO));
					}).collect(Collectors.toMap(entry -> entry.getKey(), entry -> entry.getValue()));

					return collect2;
				}, /*() -> {

					// CURP
					Stream<Entry<Integer, HashMap<EnumISSTE3, String>>> stream = hashMapOfAllRows.entrySet().stream();

					Map<Integer, HashMap<EnumISSTE3, String>> collect2 = stream.filter(row -> {
						return !StringUtils.isAlphanumericSpace(row.getValue().get(CURP));
					}).collect(Collectors.toMap(entry -> entry.getKey(), entry -> entry.getValue()));

					return collect2;
				},*/ () -> {

					// RFC
					Stream<Entry<Integer, HashMap<EnumISSTE3, String>>> stream = hashMapOfAllRows.entrySet().stream();

					Map<Integer, HashMap<EnumISSTE3, String>> collect2 = stream.filter(row -> {
						return !StringUtils.isAlphanumericSpace(row.getValue().get(RFC));
					}).collect(Collectors.toMap(entry -> entry.getKey(), entry -> entry.getValue()));

					return collect2;
				}, /*() -> {

					// CLC
					Stream<Entry<Integer, HashMap<EnumISSTE3, String>>> stream = hashMapOfAllRows.entrySet().stream();

					Map<Integer, HashMap<EnumISSTE3, String>> collect2 = stream.filter(row -> {
						return !StringUtils.isNumericSpace(row.getValue().get(APELLIDO_PATERNO));
					}).collect(Collectors.toMap(entry -> entry.getKey(), entry -> entry.getValue()));

					return collect2;
				}, () -> {

					// CVE_CONCEPTO
					Stream<Entry<Integer, HashMap<EnumISSTE3, String>>> stream = hashMapOfAllRows.entrySet().stream();

					Map<Integer, HashMap<EnumISSTE3, String>> collect2 = stream.filter(row -> {
						return !StringUtils.isNumericSpace(row.getValue().get(APELLIDO_MATERNO));
					}).collect(Collectors.toMap(entry -> entry.getKey(), entry -> entry.getValue()));

					return collect2;
				},*/ () -> {

					// DESCRIPCION
					Stream<Entry<Integer, HashMap<EnumISSTE3, String>>> stream = hashMapOfAllRows.entrySet().stream();

					Map<Integer, HashMap<EnumISSTE3, String>> collect2 = stream.filter(row -> {
						return !StringUtils.isAlphanumericSpace(row.getValue().get(DESCRIPCION));
					}).collect(Collectors.toMap(entry -> entry.getKey(), entry -> entry.getValue()));

					return collect2;
				}, /*() -> {

					// IMPORTE
					Stream<Entry<Integer, HashMap<EnumISSTE3, String>>> stream = hashMapOfAllRows.entrySet().stream();

					Map<Integer, HashMap<EnumISSTE3, String>> collect2 = stream.filter(row -> {
						return !StringUtils.isAsciiPrintable(row.getValue().get(HOMO));
					}).collect(Collectors.toMap(entry -> entry.getKey(), entry -> entry.getValue()));

					return collect2;
				}, */() -> {

					// IMPORTE
					Stream<Entry<Integer, HashMap<EnumISSTE3, String>>> stream = hashMapOfAllRows.entrySet().stream();

					Map<Integer, HashMap<EnumISSTE3, String>> collect2 = stream.filter(row -> {
						return !StringUtils.isAlphaSpace(row.getValue().get(SEXO));
					}).collect(Collectors.toMap(entry -> entry.getKey(), entry -> entry.getValue()));

					return collect2;
				}, /*() -> {

					// IMPORTE
					Stream<Entry<Integer, HashMap<EnumISSTE3, String>>> stream = hashMapOfAllRows.entrySet().stream();

					Map<Integer, HashMap<EnumISSTE3, String>> collect2 = stream.filter(row -> {
						return !StringUtils.isAsciiPrintable(row.getValue().get(NIV_TAB));
					}).collect(Collectors.toMap(entry -> entry.getKey(), entry -> entry.getValue()));

					return collect2;
				}, () -> {

					// IMPORTE
					Stream<Entry<Integer, HashMap<EnumISSTE3, String>>> stream = hashMapOfAllRows.entrySet().stream();

					Map<Integer, HashMap<EnumISSTE3, String>> collect2 = stream.filter(row -> {
						return !StringUtils.isAsciiPrintable(row.getValue().get(PERCEPCION));
					}).collect(Collectors.toMap(entry -> entry.getKey(), entry -> entry.getValue()));

					return collect2;
				}, () -> {

					// IMPORTE
					Stream<Entry<Integer, HashMap<EnumISSTE3, String>>> stream = hashMapOfAllRows.entrySet().stream();

					Map<Integer, HashMap<EnumISSTE3, String>> collect2 = stream.filter(row -> {
						return !StringUtils.isAsciiPrintable(row.getValue().get(PRIMA_BASICA));
					}).collect(Collectors.toMap(entry -> entry.getKey(), entry -> entry.getValue()));

					return collect2;
				},*/ () -> {

					// IMPORTE
					Stream<Entry<Integer, HashMap<EnumISSTE3, String>>> stream = hashMapOfAllRows.entrySet().stream();

					Map<Integer, HashMap<EnumISSTE3, String>> collect2 = stream.filter(row -> {
						return !StringUtils.isAsciiPrintable(row.getValue().get(NOMBRE));
					}).collect(Collectors.toMap(entry -> entry.getKey(), entry -> entry.getValue()));

					return collect2;
				} /*() -> {

					// IMPORTE
					Stream<Entry<Integer, HashMap<EnumISSTE3, String>>> stream = hashMapOfAllRows.entrySet().stream();

					Map<Integer, HashMap<EnumISSTE3, String>> collect2 = stream.filter(row -> {
						return !StringUtils.isAsciiPrintable(row.getValue().get(PRIMA));
					}).collect(Collectors.toMap(entry -> entry.getKey(), entry -> entry.getValue()));

					return collect2;
				}*/);

		List<Future<Map<Integer, HashMap<EnumISSTE3, String>>>> futures = null;
		try {
			futures = executor.invokeAll(callables);
		} catch (InterruptedException e1) {
			e1.printStackTrace();
			throw new Exception("Error executing Executer service...");
		}
		ArrayList<String> listOfAllError = new ArrayList<>();
		HashMap<Integer, ArrayList<String>> errorInLine = new HashMap<>();

		for (int i = 0; i < futures.size(); i++) {
			switch (i) {
			/*case 0:
				try {
					Map<Integer, HashMap<EnumISSTE3, String>> list = futures.get(i).get();
					list.forEach((lineNumber, row) -> {
						ArrayList<String> errorLineandVal = new ArrayList<>();
						errorLineandVal.addAll(Arrays.asList(Constants.ENTIDAD_ERR, row.get(PERIODO)));
						errorInLine.put(lineNumber, errorLineandVal);
					});
				} catch (InterruptedException | ExecutionException e) {
					throw new Exception(e);
				}
				break;*/
			case 1:
				try {
					Map<Integer, HashMap<EnumISSTE3, String>> list = futures.get(i).get();
					list.forEach((lineNumber, row) -> {
						ArrayList<String> errorLineandVal = new ArrayList<>();
						errorLineandVal.addAll(Arrays.asList(ConstantsISSSTE03.NUMPEN_ERR, row.get(NUMPEN)));
						errorInLine.put(lineNumber, errorLineandVal);
					});
				} catch (InterruptedException | ExecutionException e) {
					throw new Exception(e);
				}
				break;
			case 2:
				try {
					Map<Integer, HashMap<EnumISSTE3, String>> list = futures.get(i).get();
					list.forEach((lineNumber, row) -> {
						ArrayList<String> errorLineandVal = new ArrayList<>();
						errorLineandVal.addAll(Arrays.asList(ConstantsISSSTE03.RAMO_ERR, row.get(RAMO)));
						errorInLine.put(lineNumber, errorLineandVal);
					});
				} catch (InterruptedException | ExecutionException e) {
					throw new Exception(e);
				}
				break;
			case 3:
				try {
					Map<Integer, HashMap<EnumISSTE3, String>> list = futures.get(i).get();
					list.forEach((lineNumber, row) -> {
						ArrayList<String> errorLineandVal = new ArrayList<>();
						errorLineandVal.addAll(Arrays.asList(ConstantsISSSTE03.CPTO_ERR, row.get(CPTO)));
						errorInLine.put(lineNumber, errorLineandVal);
					});
				} catch (InterruptedException | ExecutionException e) {
					throw new Exception(e);
				}
				break;
			/*case 4:
				try {
					Map<Integer, HashMap<EnumISSTE3, String>> list = futures.get(i).get();
					list.forEach((lineNumber, row) -> {
						ArrayList<String> errorLineandVal = new ArrayList<>();
						errorLineandVal
								.addAll(Arrays.asList(Constants.SEGUNDO_APELLIDO_ERR, row.get(APELLIDO_PATERNO)));
						errorInLine.put(lineNumber, errorLineandVal);
					});
				} catch (InterruptedException | ExecutionException e) {
					throw new Exception(e);
				}
				break;*/
			/*case 5:
				try {
					Map<Integer, HashMap<EnumISSTE3, String>> list = futures.get(i).get();
					list.forEach((lineNumber, row) -> {
						ArrayList<String> errorLineandVal = new ArrayList<>();
						errorLineandVal.addAll(Arrays.asList(Constants.CURP_ERR, row.get(CURP)));
						errorInLine.put(lineNumber, errorLineandVal);
					});
				} catch (InterruptedException | ExecutionException e) {
					throw new Exception(e);
				}
				break;*/
			case 6:
				try {
					Map<Integer, HashMap<EnumISSTE3, String>> list = futures.get(i).get();
					list.forEach((lineNumber, row) -> {
						ArrayList<String> errorLineandVal = new ArrayList<>();
						errorLineandVal.addAll(Arrays.asList(ConstantsISSSTE03.RFC_ERR, row.get(RFC)));
						errorInLine.put(lineNumber, errorLineandVal);
					});
				} catch (InterruptedException | ExecutionException e) {
					throw new Exception(e);
				}
				break;
			/*case 7:
				try {
					Map<Integer, HashMap<EnumISSTE3, String>> list = futures.get(i).get();
					list.forEach((lineNumber, row) -> {
						ArrayList<String> errorLineandVal = new ArrayList<>();
						errorLineandVal.addAll(Arrays.asList(Constants.CLC_ERR, row.get(APELLIDO_MATERNO)));
						errorInLine.put(lineNumber, errorLineandVal);
					});
				} catch (InterruptedException | ExecutionException e) {
					throw new Exception(e);
				}
				break;*/
			/*case 8:
				try {
					Map<Integer, HashMap<EnumISSTE3, String>> list = futures.get(i).get();
					list.forEach((lineNumber, row) -> {
						ArrayList<String> errorLineandVal = new ArrayList<>();
						errorLineandVal.addAll(Arrays.asList(Constants.CVE_CONCEPTO_ERR, row.get(HOMO)));
						errorInLine.put(lineNumber, errorLineandVal);
					});
				} catch (InterruptedException | ExecutionException e) {
					throw new Exception(e);
				}
				break;*/
			case 9:
				try {
					Map<Integer, HashMap<EnumISSTE3, String>> list = futures.get(i).get();
					list.forEach((lineNumber, row) -> {
						ArrayList<String> errorLineandVal = new ArrayList<>();
						errorLineandVal.addAll(Arrays.asList(ConstantsISSSTE03.DESCRIPCION_ERR, row.get(DESCRIPCION)));
						errorInLine.put(lineNumber, errorLineandVal);
					});
				} catch (InterruptedException | ExecutionException e) {
					throw new Exception(e);
				}
				break;
			case 10:
				try {
					Map<Integer, HashMap<EnumISSTE3, String>> list = futures.get(i).get();
					list.forEach((lineNumber, row) -> {
						ArrayList<String> errorLineandVal = new ArrayList<>();
						errorLineandVal.addAll(Arrays.asList(ConstantsISSSTE03.SEXO_ERR, row.get(SEXO)));
						errorInLine.put(lineNumber, errorLineandVal);
					});
				} catch (InterruptedException | ExecutionException e) {
					throw new Exception(e);
				}
				break;

			/*case 11:
				try {
					Map<Integer, HashMap<EnumISSTE3, String>> list = futures.get(i).get();
					list.forEach((lineNumber, row) -> {
						ArrayList<String> errorLineandVal = new ArrayList<>();
						errorLineandVal.addAll(Arrays.asList("SUMADEIMPORTE is not numeric value", row.get(NIV_TAB)));
						errorInLine.put(lineNumber, errorLineandVal);
					});
				} catch (InterruptedException | ExecutionException e) {
					throw new Exception(e);
				}
				break;*/

			/*case 12:
				try {
					Map<Integer, HashMap<EnumISSTE3, String>> list = futures.get(i).get();
					list.forEach((lineNumber, row) -> {
						ArrayList<String> errorLineandVal = new ArrayList<>();
						errorLineandVal.addAll(Arrays.asList(Constants.SUMADEIMPORTE_ERR, row.get(PERCEPCION)));
						errorInLine.put(lineNumber, errorLineandVal);
					});
				} catch (InterruptedException | ExecutionException e) {
					throw new Exception(e);
				}
				break;*/

			/*case 13:
				try {
					Map<Integer, HashMap<EnumISSTE3, String>> list = futures.get(i).get();
					list.forEach((lineNumber, row) -> {
						ArrayList<String> errorLineandVal = new ArrayList<>();
						errorLineandVal.addAll(Arrays.asList(Constants.SUMADEIMPORTE_ERR, row.get(PRIMA_BASICA)));
						errorInLine.put(lineNumber, errorLineandVal);
					});
				} catch (InterruptedException | ExecutionException e) {
					throw new Exception(e);
				}
				break;*/

				/*case 14:
				try {
					Map<Integer, HashMap<EnumISSTE3, String>> list = futures.get(i).get();
					list.forEach((lineNumber, row) -> {
						ArrayList<String> errorLineandVal = new ArrayList<>();
						errorLineandVal.addAll(Arrays.asList(Constants.SUMADEIMPORTE_ERR, row.get(PRIMA)));
						errorInLine.put(lineNumber, errorLineandVal);
					});
				} catch (InterruptedException | ExecutionException e) {
					throw new Exception(e);
				}
				break;*/
				
			case 15:
				try {
					Map<Integer, HashMap<EnumISSTE3, String>> list = futures.get(i).get();
					list.forEach((lineNumber, row) -> {
						ArrayList<String> errorLineandVal = new ArrayList<>();
						errorLineandVal.addAll(Arrays.asList(ConstantsISSSTE03.NOMBRE_ERR, row.get(NOMBRE)));
						errorInLine.put(lineNumber, errorLineandVal);
					});
				} catch (InterruptedException | ExecutionException e) {
					throw new Exception(e);
				}
				break;
			}
		}

		try {
			executor.shutdown();
			executor.awaitTermination(20, TimeUnit.MILLISECONDS);
		} catch (InterruptedException e) {
			e.printStackTrace();
		} finally {
			if (!executor.isTerminated()) {
				logger.info("NOt terminated");
			}
			executor.shutdownNow();
		}

		logger.info("Validation time : ", String.valueOf(Duration.between(validationStart, Instant.now()).toMillis()));

		// if (errorInLine.isEmpty()) {
		logger.info("Validation complete for file: {}", fileName);
		processOutput.processTextOutPut(hashMapOfAllRows, parentFileName, fileName);
		// } //else {
		fileWrite = new FileWriteServiceISSSTE03();
		logger.info("Error in file {}", fileName);
		fileWrite.processAndWriteErrorCSV(errorInLine, fileName);
		listOfAllError.add("Error File Generated");
		// }
		return listOfAllError;
	}

}
