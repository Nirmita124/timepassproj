/**
 * 
 */
package mx.com.metlife.da.tom.services.service.isste;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.io.FileUtils;
import org.springframework.stereotype.Service;

/**
 * @author Capgemini
 * @since 07-08-2019
 */
@Service
public class FileWriteService {

	public Object writeToTextFile(ArrayList<ArrayList<String>> arrayListOfRows) {

		File op = new File("Output.txt");
		System.out.println(op.getAbsolutePath());

		List<String> collect = arrayListOfRows.stream().map(row -> {
			return row.stream().collect(Collectors.joining(""));
		}).collect(Collectors.toList());

		arrayListOfRows = null;

		try {
			FileUtils.writeLines(op, collect);
		} catch (IOException e) {
			e.printStackTrace();
		}

		collect = null;

		return null;
	}

}
