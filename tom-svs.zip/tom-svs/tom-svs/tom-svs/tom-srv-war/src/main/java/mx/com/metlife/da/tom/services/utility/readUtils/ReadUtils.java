package mx.com.metlife.da.tom.services.utility.readUtils;

import java.util.Arrays;

public class ReadUtils {
private static String[] extensionsAllowed = {"txt", "xls", "xlsx", "zip", "dat", "csv"};
	
	public static boolean isAlphaSpaceDotApostrophe(final CharSequence cs) {
        if (cs == null) {
            return false;
        }
        final int sz = cs.length();
        for (int i = 0; i < sz; i++) {
            if (Character.isLetter(cs.charAt(i)) == false && cs.charAt(i) != ' ') {
            	return cs.charAt(i) == '.' || String.valueOf(cs.charAt(i)).equals("'") ? true : false ;
            }
        }
        return true;
    }
	
	public static boolean checkIfFileIsAllowed(String s) {
	    return Arrays.stream(extensionsAllowed).anyMatch(entry -> s.endsWith(entry));
	}
}
