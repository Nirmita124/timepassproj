package mx.com.metlife.da.tom.services.initializer;

import org.springframework.web.servlet.support.AbstractAnnotationConfigDispatcherServletInitializer;

import mx.com.metlife.da.tom.services.config.MvcConfig;
import mx.com.metlife.da.tom.services.config.ServiceConfig;

/**
 * ApplicationInitializer class is used to initialise the configuration files and 
 * it will map the spring’s dispatcher servlet and bootstrap it.
 * 
 * @author Capgemini
 * @since 26/03/2019
 */
public class ApplicationInitializer extends AbstractAnnotationConfigDispatcherServletInitializer {

	@Override
	protected Class<?>[] getRootConfigClasses() {
		return new Class[] { ServiceConfig.class};
	}

	@Override
	protected Class<?>[] getServletConfigClasses() {
		return new Class[] { MvcConfig.class };
	}

	@Override
	protected String[] getServletMappings() {
		return new String[] { "/" };
	}

}
