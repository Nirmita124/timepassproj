package mx.com.metlife.da.tom.services.service.dto;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Range;

import lombok.Data;

@Data
public class FileDataFilter {

	@NotEmpty
	@Size(min = 0, max = 20, message = "Intidad length cannot exceed more than 20.")
	private String entidad;
	
	@NotNull
    @Range(min = 0, max = 99, message = "IdEntidad length should be single/double digit.")
	private int idEntidad;

	@NotEmpty
	@Size(min = 0, max = 20, message = "NoArchivo length cannot exceed more than 20.")
	private String noArchivo;

	@NotEmpty
	@Size(min = 0, max = 7, message = "ProcesoDeNomina length cannot exceed more than 10.")
	private String procesoDeNomina;
	
	@NotEmpty
	@Size(min = 0, max = 30, message = "Name length cannot exceed more than 30.")
	private String nombre;
	
	@NotEmpty
	@Size(min = 0, max = 20, message = "primerPaterno Paterno length cannot exceed more than 20.")
	private String primerPaterno;
	
	@NotEmpty(message = "SegundoMaterino value is empty.")
	@Size(min = 1, max = 20, message = "segundoMaterino Materno length should lie between 1-20.")
	private String segundoMaterino;
	
	@NotEmpty
	@Size(min = 18, max = 18, message = "Curp length should be 18.")
	private String curp;
	
	@NotEmpty
	@Size(min = 0, max = 13, message = "RFC length cannot exceed more than 13 and less than 10.")
	private String rfc;
	
	@NotNull
	@Range(min = 1900, max = 2019, message = "CLC length not 4 digit")
	private int clc;

	@NotEmpty
	@Size(min = 0, max = 3, message = "cveConCepto length cannot exceed more than 1.")
	private String cveConCepto;
	
	@NotEmpty
	@Size(min = 0, max = 30, message = "description length cannot exceed more than 1.")
	private String description;
	
	@NotNull
	@Range(min = 0, max = 10, message = "sumaDeImporte not in proper double format.")
	private double sumaDeImporte;
}
