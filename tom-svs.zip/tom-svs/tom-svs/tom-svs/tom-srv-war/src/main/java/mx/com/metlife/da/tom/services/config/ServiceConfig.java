package mx.com.metlife.da.tom.services.config;


import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

/**
 * ServiceConfig class will bootstrap the spring mvc application and set package to scan controllers and resources.
 * 
 * @author Capgemini
 * @since 26/03/2019
 */
@Configuration
@ComponentScan("mx.com.metlife.da.tom.services.service")
public class ServiceConfig {

}
