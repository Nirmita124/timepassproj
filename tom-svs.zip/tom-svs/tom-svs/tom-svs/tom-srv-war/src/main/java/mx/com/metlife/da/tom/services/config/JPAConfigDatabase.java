package mx.com.metlife.da.tom.services.config;


import static org.slf4j.LoggerFactory.getLogger;

import javax.sql.DataSource;

//import javax.activation.DataSource;

import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.PropertySource;
import org.springframework.dao.annotation.PersistenceExceptionTranslationPostProcessor;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import mx.com.metlife.da.tom.services.error.TomException;


/**
 * JPAConfigDatabase class is created to set up configuration for database, transaction related to EOS database.
 * 
 * @author Capgemini
 * @since 26/03/2018
 */
@Configuration
@EnableTransactionManagement
@ComponentScan("mx.com.metlife.da.tom.services")
@EnableJpaRepositories(entityManagerFactoryRef = "entityManager",
        			   basePackages = {"mx.com.metlife.da.tom.services.model.repository"},
        			   transactionManagerRef = "transactionManager")

@PropertySource(value = {"classpath:application.properties"})
public class JPAConfigDatabase {

	private static final Logger logger = getLogger(JPAConfigDatabase.class);
	/**
	 * This is the method which creates a dataSource connection with EOS database using JNDI configuration.
	 * 
	 * @return DataSource
	 * @throws TomException 
	 */
	/*
	 * @Primary
	 * 
	 * @Bean(name = "dataSource") public DataSource dataSource() throws TomException
	 * { DataSource dataSource = null; try { dataSource = (DataSource) new
	 * JndiTemplate().lookup("jndi/moii"); } catch (NamingException e) {
	 * logger.error(e.getMessage()); throw new TomException(e.getMessage()); }
	 * return dataSource ; }
	 */
	@Value("${spring.datasource.driverClassName}")
	private String DB_DRIVER;
	
	@Value("${spring.datasource.url}")
	private String SPRING_DATASOURCE_URL;
	
	@Value("${spring.datasource.username}")
	private String SPRING_DATASOURCE_USERNAME;
	
	@Value("${spring.datasource.password}")
	private String SPRING_DATASOURCE_PASSWORD;
	
	@Bean(name = "dataSource")
    public DataSource dataSource()
    {
        DriverManagerDataSource dataSource = new DriverManagerDataSource();
        dataSource.setDriverClassName(DB_DRIVER);
        dataSource.setUrl(SPRING_DATASOURCE_URL);
        dataSource.setUsername(SPRING_DATASOURCE_USERNAME);
        dataSource.setPassword(SPRING_DATASOURCE_PASSWORD);
        return dataSource;
    }

	
	/**
	 * This method is used to create EntityManagerFactory.
	 * 
	 * @return LocalContainerEntityManagerFactoryBean
	 * @throws TomException 
	 */
	@Primary
	@Bean(name = "entityManager")
	public LocalContainerEntityManagerFactoryBean entityManagerFactoryBean() throws TomException {
		LocalContainerEntityManagerFactoryBean factoryBean = new LocalContainerEntityManagerFactoryBean();
		factoryBean.setDataSource(dataSource());
		factoryBean.setPackagesToScan( "mx.com.metlife.da.tom.services.service.LoadPendingReceipt","mx.com.metlife.da.tom.services.service.LoadBankStatement");;
		HibernateJpaVendorAdapter vendorAdapter = new HibernateJpaVendorAdapter();
		vendorAdapter.setShowSql(true);
		factoryBean.setJpaVendorAdapter(vendorAdapter);
		return factoryBean;
	}
	
	/**
	 * This method is used create isolated transactions.
	 * @return PlatformTransactionManager
	 * @throws TomException 
	 */
	
	@Primary
	@Bean(name = "transactionManager")
	public PlatformTransactionManager transactionManager() throws TomException {
		JpaTransactionManager transactionManager = new JpaTransactionManager();
		transactionManager.setEntityManagerFactory(entityManagerFactoryBean().getObject());
		return transactionManager;
	}

	/**
	 * 
	 * @return
	 */
	@Primary
	@Bean
	public PersistenceExceptionTranslationPostProcessor exceptionTranslation() {
		return new PersistenceExceptionTranslationPostProcessor();
	}

}
