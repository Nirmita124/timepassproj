/**
 * 
 */
package mx.com.metlife.da.tom.services.service.LoadBankStatement;

/**
 * @author Capgemini
 * @since 09-07-2019
 */

public enum Layout_LoadBankStatement {
	
	Banco_Id("Banco_Id", 2),
	Folio_Carga("Folio_Carga", 10),
	Numero_Movimiento("Numero_Movimiento", 10),
	Referencia_Bancaria("Referencia_Bancaria", 30),
	Concepto("Concepto", 30),
	Fecha_Pago("Fecha_Pago", 8),
	Importe_Pago("Importe_Pago", 15),
	Fecha_Carga("Fecha_Carga", 14),
	Importe_Restante("Importe_Restante", 15);
	
	private final String columnName;
    private final Integer outputConstraint;

    Layout_LoadBankStatement(String key, Integer value) {
        this.columnName = key;
        this.outputConstraint = value;
    }

	public String getColumnName() {
		return columnName;
	}

	public Integer getOutputConstraint() {
		return outputConstraint;
	}
    
}
