package mx.com.metlife.da.tom.services.service.LoadPendingReceipt;
import javax.persistence.*;


@Entity
@Table(name="[Recibos_Pendientes")
public class LoadPendingRcptBean {
	
	@Id
	@Column(name = "numero_Poliza")
	private String numero_Poliza;
	
	@Id
	@Column(name = "ramo_SubRamo")
	private String ramo_SubRamo;
	
	@Id
	@Column(name = "fecha_Vig_Recibo")
	 private java.util.Date fecha_Vig_Recibo;
	
	@Column(name = "fecha_Fin_Vig_Recibo")
	 private java.util.Date fecha_Fin_Vig_Recibo;
	
	@Id
	@Column(name = "folio")
	private String folio;
	
	@Column(name = "estatus_Id")
	   private int estatus_Id;
	
	@Column(name = "importe")
	   private double importe;
	
	@Column(name = "folio_Fiscal")
	   private String folio_Fiscal;
	
	
	public LoadPendingRcptBean() {
	}

	public LoadPendingRcptBean(int banco_Id, long folio_Carga, long numero_Movimiento, String referencia_Bancaria,
			String concepto, java.util.Date fecha_Pago, double importe_Pago, java.util.Date fecha_Carga,
			double importe_Restante) {
		super();
		
		this.numero_Poliza = numero_Poliza;
		this.ramo_SubRamo = ramo_SubRamo;
		this.folio = folio;
		this.fecha_Vig_Recibo = fecha_Vig_Recibo;
		this.fecha_Fin_Vig_Recibo = fecha_Fin_Vig_Recibo;
		this.estatus_Id = estatus_Id;
		this.importe = importe;
		this.folio_Fiscal = folio_Fiscal;
	}

	public String getNumero_Poliza() {
		return numero_Poliza;
	}

	public void setNumero_Poliza(String numero_Poliza) {
		this.numero_Poliza = numero_Poliza;
	}

	public String getRamo_SubRamo() {
		return ramo_SubRamo;
	}

	public void setRamo_SubRamo(String ramo_SubRamo) {
		this.ramo_SubRamo = ramo_SubRamo;
	}

	public String getFolio() {
		return folio;
	}

	public void setFolio(String folio) {
		this.folio = folio;
	}

	public java.util.Date getFecha_Vig_Recibo() {
		return fecha_Vig_Recibo;
	}

	public void setFecha_Vig_Recibo(java.util.Date fecha_Vig_Recibo) {
		this.fecha_Vig_Recibo = fecha_Vig_Recibo;
	}

	public java.util.Date getFecha_Fin_Vig_Recibo() {
		return fecha_Fin_Vig_Recibo;
	}

	public void setFecha_Fin_Vig_Recibo(java.util.Date fecha_Fin_Vig_Recibo) {
		this.fecha_Fin_Vig_Recibo = fecha_Fin_Vig_Recibo;
	}

	public int getEstatus_Id() {
		return estatus_Id;
	}

	public void setEstatus_Id(int estatus_Id) {
		this.estatus_Id = estatus_Id;
	}

	public double getImporte() {
		return importe;
	}

	public void setImporte(double importe) {
		this.importe = importe;
	}

	public String getFolio_Fiscal() {
		return folio_Fiscal;
	}

	public void setFolio_Fiscal(String folio_Fiscal) {
		this.folio_Fiscal = folio_Fiscal;
	}

	
}
