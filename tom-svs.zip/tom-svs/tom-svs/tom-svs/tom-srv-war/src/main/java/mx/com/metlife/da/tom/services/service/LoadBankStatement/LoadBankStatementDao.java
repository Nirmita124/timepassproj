package mx.com.metlife.da.tom.services.service.LoadBankStatement;

public interface LoadBankStatementDao {

	
	
}
