package mx.com.metlife.da.tom.services.web.controller;

import static mx.com.metlife.da.tom.services.utility.ConstantUtility.ERROR_CODE_400;
import static mx.com.metlife.da.tom.services.utility.ConstantUtility.ERROR_CODE_401;
import static mx.com.metlife.da.tom.services.utility.ConstantUtility.ERROR_CODE_500;
import static mx.com.metlife.da.tom.services.utility.ConstantUtility.ERROR_MESSAGE_500;
import static mx.com.metlife.da.tom.services.utility.ConstantUtility.UN_AUTHORIZED_USER;
import static mx.com.metlife.da.tom.services.utility.MethodUtility.getElementForValidation;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import mx.com.metlife.da.tom.services.error.AuthorizationException;
import mx.com.metlife.da.tom.services.error.ErrorExtensionVO;
import mx.com.metlife.da.tom.services.error.HeaderValidationException;
import mx.com.metlife.da.tom.services.error.MessagesErrorVO;
import mx.com.metlife.da.tom.services.error.TomException;
import mx.com.metlife.da.tom.services.error.ValidationException;

/**
 * TomErrorController is the controller which handles the error thrown by the code
 * 
 * @author Capgemini
 * @since 04/30/2019
 */
@RestControllerAdvice
public class TomErrorController {
	
	
	@ExceptionHandler(value = {ValidationException.class, HeaderValidationException.class})
	public @ResponseBody ResponseEntity<MessagesErrorVO> validationException(ValidationException exception) {
		
		ErrorExtensionVO specific = new ErrorExtensionVO(null,exception.getMessage());
		MessagesErrorVO messagesErrorVO = new MessagesErrorVO(ERROR_CODE_400, exception.getMessage(),getElementForValidation(exception.getMessage()), specific);
		return new ResponseEntity<>(messagesErrorVO, HttpStatus.BAD_REQUEST);
		
	}
	
	@ExceptionHandler(AuthorizationException.class)
	public @ResponseBody ResponseEntity<MessagesErrorVO> authorizationException(AuthorizationException exception) {
		
		ErrorExtensionVO specific = new ErrorExtensionVO(null,exception.getMessage());
		MessagesErrorVO messagesErrorVO = new MessagesErrorVO(ERROR_CODE_401, exception.getMessage(),UN_AUTHORIZED_USER, specific);
		return new ResponseEntity<>(messagesErrorVO, HttpStatus.UNAUTHORIZED);
		
	}
	
	/*@ExceptionHandler(TomException.class)
	public @ResponseBody ResponseEntity<MessagesErrorVO> noDataException(TomException exception) {
		
		ErrorExtensionVO specific = new ErrorExtensionVO(null,NO_DATA_FOUND);
		MessagesErrorVO messagesErrorVO = new MessagesErrorVO(ERROR_CODE_202, NO_DATA_FOUND,RESULT_SET_EMPTY, specific);
		return new ResponseEntity<>(messagesErrorVO, HttpStatus.ACCEPTED);
	}*/
	
	@ExceptionHandler(TomException.class)
	public @ResponseBody ResponseEntity<MessagesErrorVO> generalPortfolioException(TomException exception) {
		
		ErrorExtensionVO specific = new ErrorExtensionVO(null,ERROR_MESSAGE_500);
		MessagesErrorVO messagesErrorVO = new MessagesErrorVO(ERROR_CODE_500, exception.getMessage(),"", specific);
		return new ResponseEntity<>(messagesErrorVO, HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	@ExceptionHandler(Exception.class)
	public @ResponseBody ResponseEntity<MessagesErrorVO> generalException(Exception exception) {
		System.out.println("****************Error Occured" + exception.getMessage());
		ErrorExtensionVO specific = new ErrorExtensionVO(null,ERROR_MESSAGE_500);
		MessagesErrorVO messagesErrorVO = new MessagesErrorVO(ERROR_CODE_500, exception.getMessage(),"", specific);
		return new ResponseEntity<>(messagesErrorVO, HttpStatus.INTERNAL_SERVER_ERROR);
	}

}
