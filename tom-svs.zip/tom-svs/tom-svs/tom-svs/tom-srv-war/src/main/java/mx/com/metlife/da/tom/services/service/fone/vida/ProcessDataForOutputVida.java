package mx.com.metlife.da.tom.services.service.fone.vida;

import static mx.com.metlife.da.tom.services.service.fone.vida.LayoutFoneVida.APELLIDO_MATERNO;
import static mx.com.metlife.da.tom.services.service.fone.vida.LayoutFoneVida.APELLIDO_PATERNO;
import static mx.com.metlife.da.tom.services.service.fone.vida.LayoutFoneVida.APORTACION;
import static mx.com.metlife.da.tom.services.service.fone.vida.LayoutFoneVida.CICLO;
import static mx.com.metlife.da.tom.services.service.fone.vida.LayoutFoneVida.CURP;
import static mx.com.metlife.da.tom.services.service.fone.vida.LayoutFoneVida.CVE_CONCEPTO;
import static mx.com.metlife.da.tom.services.service.fone.vida.LayoutFoneVida.CVE_MES;
import static mx.com.metlife.da.tom.services.service.fone.vida.LayoutFoneVida.CVE_PLAZA;
import static mx.com.metlife.da.tom.services.service.fone.vida.LayoutFoneVida.CVE_UR;
import static mx.com.metlife.da.tom.services.service.fone.vida.LayoutFoneVida.CÓDIGO;
import static mx.com.metlife.da.tom.services.service.fone.vida.LayoutFoneVida.IMPORTE;
import static mx.com.metlife.da.tom.services.service.fone.vida.LayoutFoneVida.IS_ISR;
import static mx.com.metlife.da.tom.services.service.fone.vida.LayoutFoneVida.MODELO;
import static mx.com.metlife.da.tom.services.service.fone.vida.LayoutFoneVida.NIVEL;
import static mx.com.metlife.da.tom.services.service.fone.vida.LayoutFoneVida.NOMBRE;
import static mx.com.metlife.da.tom.services.service.fone.vida.LayoutFoneVida.NO_NOMINA;
import static mx.com.metlife.da.tom.services.service.fone.vida.LayoutFoneVida.NUM_COMPROBANTE;
import static mx.com.metlife.da.tom.services.service.fone.vida.LayoutFoneVida.NUM_PERIODO;
import static mx.com.metlife.da.tom.services.service.fone.vida.LayoutFoneVida.PERIODO;
import static mx.com.metlife.da.tom.services.service.fone.vida.LayoutFoneVida.PORCENTAJE;
import static mx.com.metlife.da.tom.services.service.fone.vida.LayoutFoneVida.RFC;
import static mx.com.metlife.da.tom.services.service.fone.vida.LayoutFoneVida.TIPO_CONCEPTO;
import static mx.com.metlife.da.tom.services.service.fone.vida.LayoutFoneVida.TIPO_NOMINA;
import static mx.com.metlife.da.tom.services.service.fone.vida.LayoutFoneVida.TIPO_PERIODO;
import static mx.com.metlife.da.tom.services.service.fone.vida.LayoutFoneVida.ZONA_ECONOMICA;

import java.util.HashMap;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Service;

@Service
@PropertySource({"classpath:application.properties","classpath:vidaReadWrite.properties"})
public class ProcessDataForOutputVida {
	
	@Autowired
	private FileWriteServiceVida fileWriteServiceVida;

	public Object processTextOutPutVida(HashMap<Integer, HashMap<LayoutFoneVida, String>> arrayListOfSTringsBR,
			String parentFileName, String fileName) {

		
		
		String trimmedfileName = StringUtils.leftPad(fileName, 30);

		arrayListOfSTringsBR.forEach((lineNumber, row) -> {

			row.put(CVE_UR, StringUtils.leftPad(row.get(CVE_UR), 3));
			row.put(CICLO, StringUtils.leftPad(row.get(CICLO), 4));
			row.put(CVE_MES, StringUtils.leftPad(row.get(CVE_MES), 2));
			row.put(PERIODO, StringUtils.leftPad(row.get(PERIODO), 7));
			row.put(TIPO_NOMINA, StringUtils.leftPad(row.get(TIPO_NOMINA), 14));
			row.put(NO_NOMINA, StringUtils.leftPad(row.get(NO_NOMINA), 1));
			row.put(CURP, StringUtils.leftPad(row.get(CURP), 18));
			row.put(RFC, StringUtils.leftPad(row.get(RFC), 13));
			row.put(TIPO_PERIODO, StringUtils.leftPad(row.get(TIPO_PERIODO), 9));
			row.put(NUM_PERIODO, StringUtils.leftPad(row.get(NUM_PERIODO), 2));
			row.put(NUM_COMPROBANTE, StringUtils.leftPad(row.get(NUM_COMPROBANTE), 7));
			row.put(CVE_CONCEPTO, StringUtils.leftPad(row.get(CVE_CONCEPTO), 2));
			row.put(IMPORTE, StringUtils.leftPad(row.get(IMPORTE), 2));
			row.put(TIPO_CONCEPTO, StringUtils.leftPad(row.get(TIPO_CONCEPTO), 1));
			row.put(CVE_PLAZA, StringUtils.leftPad(row.get(CVE_PLAZA), 30));
			row.put(NOMBRE, StringUtils.leftPad(row.get(NOMBRE), 20));
			row.put(APELLIDO_PATERNO, StringUtils.leftPad(row.get(APELLIDO_PATERNO), 20));
			row.put(APELLIDO_MATERNO, StringUtils.leftPad(row.get(APELLIDO_MATERNO), 20));
			row.put(ZONA_ECONOMICA, StringUtils.leftPad(row.get(ZONA_ECONOMICA), 20));
			row.put(NIVEL, StringUtils.leftPad(row.get(NIVEL), 2));
			row.put(CÓDIGO, StringUtils.leftPad(row.get(CÓDIGO), 10));
			row.put(IS_ISR, StringUtils.leftPad(row.get(IS_ISR), 1));
			row.put(MODELO, StringUtils.leftPad(row.get(MODELO), 1));
			row.put(PORCENTAJE, StringUtils.leftPad(row.get(PORCENTAJE), 2));
			row.put(APORTACION, StringUtils.leftPad(row.get(APORTACION), 2));

		});

		fileWriteServiceVida = new FileWriteServiceVida();
		return fileWriteServiceVida.writeToTextFileVida(arrayListOfSTringsBR, parentFileName, fileName);

	}
}
