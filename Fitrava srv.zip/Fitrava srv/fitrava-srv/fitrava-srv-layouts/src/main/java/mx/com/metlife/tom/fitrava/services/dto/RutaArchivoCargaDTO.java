package mx.com.metlife.tom.fitrava.services.dto;

import lombok.Data;

@Data
public class RutaArchivoCargaDTO {

	private String path = null;

	public RutaArchivoCargaDTO() {
		super();
	}

	public RutaArchivoCargaDTO(String path) {
		super();
		this.path = path;
	}
	
}
