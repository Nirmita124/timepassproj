
package mx.com.metlife.tom.fitrava.services.web.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import mx.com.metlife.tom.fitrava.services.dto.AplicacionDTO;
import mx.com.metlife.tom.fitrava.services.dto.EstatusProcesoDTO;
import mx.com.metlife.tom.fitrava.services.dto.MenuDTO;
import mx.com.metlife.tom.fitrava.services.dto.OperacionCampoDTO;
import mx.com.metlife.tom.fitrava.services.dto.OperacionDTO;
import mx.com.metlife.tom.fitrava.services.dto.RoleDTO;
import mx.com.metlife.tom.fitrava.services.dto.TipoDatoDTO;
import mx.com.metlife.tom.fitrava.services.error.FitravaException;
import mx.com.metlife.tom.fitrava.services.error.ValidationException;
import mx.com.metlife.tom.fitrava.services.service.AdminCatalogosService;
import mx.com.metlife.tom.fitrava.services.serviceimpl.beans.FitravaSrvMessages;

@RestController
@RequestMapping(value = "/admincatalogosrv")
public class AdminCatalogosFitravaController extends FitravaController {

	private static final String CLID = AdminCatalogosFitravaController.class.getSimpleName();
	
	@Autowired
	private AdminCatalogosService adminCatalogosService = null;
	@Autowired
	private FitravaSrvMessages messages;	

	@CrossOrigin
	@GetMapping("/v1/allOperacionCampo")
	public @ResponseBody ResponseEntity<List<OperacionCampoDTO>> getAllOperacionCampo() throws ValidationException, FitravaException {
		return new ResponseEntity<>(adminCatalogosService.getAllOperacionCampos(), HttpStatus.OK);
	}
	
	@CrossOrigin
	@GetMapping("/v1/allTipoDatos")
	public @ResponseBody ResponseEntity<List<TipoDatoDTO>> getAllTipoDatos() throws ValidationException, FitravaException {
		return new ResponseEntity<>(adminCatalogosService.getAllTipoDatos(), HttpStatus.OK);
	}
	
	@CrossOrigin
	@GetMapping("/v1/allOperaciones")
	public @ResponseBody ResponseEntity<List<OperacionDTO>> getAllOperaciones() throws ValidationException, FitravaException {
		return new ResponseEntity<>(adminCatalogosService.getAllOperaciones(), HttpStatus.OK);
	}
	
	@CrossOrigin
	@GetMapping("/v1/allAplicaciones")
	public @ResponseBody ResponseEntity<List<AplicacionDTO>> getAllAplicaciones() throws ValidationException, FitravaException {
		return new ResponseEntity<>(adminCatalogosService.getAllAplicaciones(), HttpStatus.OK);
	}
	
	@CrossOrigin
	@GetMapping("/v1/allProcesosEstatus")
	public @ResponseBody ResponseEntity<List<EstatusProcesoDTO>> getAllProcesosEstatus() throws ValidationException, FitravaException {
		return new ResponseEntity<>(adminCatalogosService.getAllProcesosEstatus(), HttpStatus.OK);
	}
	
	@CrossOrigin
	@GetMapping("/v1/allRoles")
	public @ResponseBody ResponseEntity<List<RoleDTO>> getAllRoles() throws ValidationException, FitravaException {
		return new ResponseEntity<>(adminCatalogosService.getAllRoles(), HttpStatus.OK);
	}
	
	@CrossOrigin
	@GetMapping("/v1/getRoleById")
	public @ResponseBody ResponseEntity<RoleDTO> getRoleById(@RequestParam("roleId") Integer roleId) throws ValidationException, FitravaException {
		log.info("En el getRoleById(roleId: {})", roleId);
		if (roleId == null || roleId <= 0) {			
			throw new ValidationException(messages.get(CLID, "MSG_ERR_ROLE_ID_CANT_BE_NULL"));
		}
		return new ResponseEntity<>(adminCatalogosService.getRoleById(roleId), HttpStatus.OK);
	}
	
	@CrossOrigin
	@GetMapping("/v1/allMenus")
	public @ResponseBody ResponseEntity<List<MenuDTO>> getAllMenus() throws ValidationException, FitravaException {
		return new ResponseEntity<>(adminCatalogosService.getAllMenus(), HttpStatus.OK);
	}
	
}



