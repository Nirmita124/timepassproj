package mx.com.metlife.tom.fitrava.services.dto;

import lombok.Data;

@SuppressWarnings("serial")
@Data
public class HeaderFooterDetalleDTO implements java.io.Serializable{

	private Long layoutHdDtlId = null;

	private Long layoutHdId = null;

	private Integer fldOrdNum = null;

	private String lblDscr = null;

	private Integer hdLnthNum = null;


}
