package mx.com.metlife.tom.fitrava.services.web.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import mx.com.metlife.tom.fitrava.services.dto.ProcesoDTO;
import mx.com.metlife.tom.fitrava.services.dto.ProcesoFileDTO;
import mx.com.metlife.tom.fitrava.services.dto.ProcesoRegistroDTO;
import mx.com.metlife.tom.fitrava.services.dto.ProcesoRegistroSumaryDTO;
import mx.com.metlife.tom.fitrava.services.error.FitravaException;
import mx.com.metlife.tom.fitrava.services.error.ValidationException;
import mx.com.metlife.tom.fitrava.services.service.ProcesoService;
import mx.com.metlife.tom.fitrava.services.serviceimpl.beans.FitravaSrvMessages;

@RestController
@RequestMapping(value = "/procesosrv")
public class ProcesoFitravaController extends FitravaController {
	
	private static final String CLID = ProcesoFitravaController.class.getSimpleName();
	private static Logger log = LoggerFactory.getLogger(ProcesoFitravaController.class);

	@Autowired
	private ProcesoService procesoService = null;
	@Autowired
	private FitravaSrvMessages messages;	
	
	@CrossOrigin
	@GetMapping("/v1/proceso")
	public @ResponseBody ResponseEntity<ProcesoDTO> getProceso(@RequestParam("dcn") String dcn) throws ValidationException, FitravaException {
		log.info("Executing >>> getProceso(dcn: {})", dcn);
		if (dcn == null || dcn.trim().length() != 20) {
			throw new ValidationException(String.format(messages.get(CLID, "MSG_ERR_PROCCESS_DCN_IS_MALFORMED"), dcn));
		}
		return new ResponseEntity<>(procesoService.getProcesoByDcn(dcn), HttpStatus.OK);
	}

	@CrossOrigin
	@GetMapping("/v1/allProcesosByFlujoId")
	public @ResponseBody ResponseEntity<List<ProcesoDTO>> getAllProcesoByFlujo(@RequestParam("flujoId") Long flujoId) throws ValidationException, FitravaException {
		log.info("Executing >>> getAllProcesoByFlujo(flujoId: {})", flujoId);
		if (flujoId == null || flujoId <= 0) {
			throw new ValidationException(String.format(messages.get(CLID, "MSG_ERR_PROCCESS_FLOWID_IS_MALFORMED"), flujoId));
		}
		return new ResponseEntity<>(procesoService.getAllProcesosByFlujoId(flujoId), HttpStatus.OK);
	}

	@CrossOrigin
	@GetMapping("/v1/allProcesosByEaiAndRetainer")
	public @ResponseBody ResponseEntity<List<ProcesoDTO>> getAllProcesoByEaiAndRetainer
			(@RequestParam(value = "retenedorId", required = false) String retenedorId, 
					@RequestParam(value = "eaiCd", required = false) String eaiCd) throws ValidationException, FitravaException {
		
		log.info("Executing >>> getAllProcesoByEaiAndRetainer(retenedor: {}, eaiCd: {})", retenedorId, eaiCd);
		if ((retenedorId == null || retenedorId.trim().length() == 0) && (eaiCd == null || eaiCd.trim().length() == 0)) {
			throw new ValidationException(messages.get(CLID, "MSG_ERR_RET_AND_FLOW_EAI_CANT_BE_NULL"));
		}
		return new ResponseEntity<>(procesoService.getAllProcesosByEaiAndRetainer(retenedorId, eaiCd), HttpStatus.OK);
	}

	@CrossOrigin
	@GetMapping("/v1/allProcesosByUsuarioAndEstatus")
	public @ResponseBody ResponseEntity<List<ProcesoDTO>> getAllProcesoByUsuarioAndEstatus
		(@RequestParam(value = "usuario", required = false) String usuario, 
				@RequestParam(value = "estatus", required = false) Integer estatus) throws ValidationException, FitravaException {
	
		log.info("Executing >>> getAllProcesoByUsuarioAndEstatus(usuario: {}, estatus: {})", usuario, estatus);
		if ((usuario == null || usuario.trim().length() == 0) && (estatus == null || estatus <= 0)) {
			throw new ValidationException(messages.get(CLID, "MSG_ERR_RET_AND_FLOW_EAI_CANT_BE_NULL"));
		}
		return new ResponseEntity<>(procesoService.getAllProcesosByUsuarioAndEstatus(usuario, estatus), HttpStatus.OK);
	}

	@CrossOrigin
	@PutMapping("/v1/actualiza")
	public @ResponseBody ResponseEntity<ProcesoDTO> putActualiza(@RequestBody ProcesoDTO procesoDTO) throws ValidationException, FitravaException {
		log.info("Executing >>> putActualiza(procesoDTO: {})", procesoDTO);
		if (procesoDTO == null) {
			throw new ValidationException(messages.get(CLID, "MSG_ERR_PROCCESS_CANT_BE_NULL"));
		}
		if (procesoDTO.getDcn() == null || procesoDTO.getDcn().trim().length() < 20) {
			throw new ValidationException(String.format(messages.get(CLID, "MSG_ERR_PROCCESS_DCN_IS_MALFORMED"), procesoDTO.getDcn()));
		}
		return new ResponseEntity<>(procesoService.actualizaProceso(procesoDTO), HttpStatus.OK);
	}
	
	@CrossOrigin
	@PostMapping("/v1/guarda")
	public @ResponseBody ResponseEntity<ProcesoDTO> postGuarda(@RequestBody ProcesoDTO procesoDTO) throws ValidationException, FitravaException {
		log.info("Executing >>> postGuarda(procesoDTO: {})", procesoDTO);
		if (procesoDTO == null ) {
			throw new ValidationException(messages.get(CLID, "MSG_ERR_PROCCESS_CANT_BE_NULL"));
		}		
		return new ResponseEntity<>(procesoService.guardaProceso(procesoDTO), HttpStatus.OK);
	}

	@CrossOrigin
	@PutMapping("/v1/actualizaEstatusProceso")
	public @ResponseBody ResponseEntity<Boolean> putActivaProceso(@RequestParam("dcn") String dcn, @RequestParam("estatus") Integer estatus) throws ValidationException, FitravaException {
		log.info("Executing >>> putActivaProceso(dcn: {}, estatus {})", dcn, estatus);
		if (dcn == null || dcn.trim().length() < 20) {
			throw new ValidationException(messages.get(CLID, "MSG_ERR_PROCCESS_DCN_CANT_BE_NULL_OR_LESS_THAN_20"));
		}
		if (estatus == null || estatus <= 0 || estatus > 6 ) {
			throw new ValidationException(messages.get(CLID, "MSG_ERR_STATUS_ISNT_VALID"));
		}
		
		return new ResponseEntity<>(procesoService.actualizaProceso(dcn, estatus), HttpStatus.OK);
	}
	
	@CrossOrigin
	@DeleteMapping("/v1/borra")
	public @ResponseBody ResponseEntity<Boolean> deleteProceso(@RequestParam("dcn") String dcn) throws FitravaException {
		log.info("Executing >>> deletProceso(dcn: {})", dcn);
		procesoService.deleteProceso(dcn);
		return new ResponseEntity<>(Boolean.TRUE, HttpStatus.OK);
	}	
	
	@CrossOrigin
	@GetMapping("/v1/procesoFile")
	public @ResponseBody ResponseEntity<ProcesoFileDTO> getProcesoFile(@RequestParam("dcn") String dcn, @RequestParam("archivo") String archivo) throws ValidationException, FitravaException {
		log.info("Executing >>> getProcesoFile(dcn: {}, archivo: {})", dcn, archivo);
		if (dcn == null || dcn.trim().length() != 20) {
			throw new ValidationException(String.format(messages.get(CLID, "MSG_ERR_PROCCESS_DCN_IS_MALFORMED"), dcn));
		}
		if (archivo == null || archivo.trim().length() == 0) {
			throw new ValidationException(messages.get(CLID, "MSG_PROCCESS_FILE_NAME_IS_MALFORMED"));
		}
		return new ResponseEntity<>(procesoService.getProcesoFileById(dcn, archivo), HttpStatus.OK);
	}

	@CrossOrigin
	@GetMapping("/v1/allProcesosFileByDcn")
	public @ResponseBody ResponseEntity<List<ProcesoFileDTO>> getAllProcesoFileByDcn(@RequestParam("dcn") String dcn) throws ValidationException, FitravaException {
		log.info("Executing >>> getAllProcesoFileByDcn(dcn: {})", dcn);
		if (dcn == null || dcn.trim().length() != 20) {
			throw new ValidationException(String.format(messages.get(CLID, "MSG_ERR_PROCCESS_DCN_IS_MALFORMED"), dcn));
		}
		return new ResponseEntity<>(procesoService.getAllProcesoFileByDcn(dcn), HttpStatus.OK);
	}
	
	@CrossOrigin
	@GetMapping("/v1/allProcesosRecByDcnAndFileName")
	public @ResponseBody ResponseEntity<List<ProcesoRegistroDTO>> getAllProcesosRecByDcnAndFileName(@RequestParam("dcn") String dcn,@RequestParam("fileName") String fileName) throws ValidationException, FitravaException {
		log.info("Executing >>> getallProcesosRecByDcnAndFileName(dcn: {}, fileName: {})", dcn, fileName);
		if ((dcn == null || dcn.trim().length() != 20) || (fileName == null )) {
			throw new ValidationException(String.format(messages.get(CLID, "MSG_ERR_PROCCESS_DCN_IS_MALFORMED"), dcn));
		}
		return new ResponseEntity<>(procesoService.getProcRecByDcnAndFileName(dcn, fileName), HttpStatus.OK);
	}
	
	@CrossOrigin
	@GetMapping("/v1/procesosRecSumByDcnAndFileName")
	public @ResponseBody ResponseEntity<ProcesoRegistroSumaryDTO> getProcesosSumByDcnAndFileName(@RequestParam("dcn") String dcn,@RequestParam("fileName") String fileName) throws ValidationException, FitravaException {
		log.info("Executing >>> getProcesosSumByDcnAndFileName(dcn: {}, fileName: {})", dcn, fileName);
		if ((dcn == null || dcn.trim().length() != 20) || (fileName == null )) {
			throw new ValidationException(String.format(messages.get(CLID, "MSG_ERR_PROCCESS_DCN_IS_MALFORMED"), dcn));
		}
		return new ResponseEntity<>(procesoService.getProcRecSumByDcnAndFileName(dcn, fileName), HttpStatus.OK);
	}
	
	@CrossOrigin
	@GetMapping("/v1/procesoByDcn")
	public @ResponseBody ResponseEntity<ProcesoDTO> getProcesoByDcn(@RequestParam("dcn") String dcn) throws ValidationException, FitravaException {
		log.info("Executing >>> getProceso(dcn: {})", dcn);
		if (dcn == null || dcn.trim().length() != 20) {
			throw new ValidationException(String.format(messages.get(CLID, "MSG_ERR_PROCCESS_DCN_IS_MALFORMED"), dcn));
		}
		return new ResponseEntity<>(procesoService.getProcByDcn(dcn), HttpStatus.OK);
	}


}
