package mx.com.metlife.tom.fitrava.services.web.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import mx.com.metlife.tom.fitrava.services.dto.CampoDTO;
import mx.com.metlife.tom.fitrava.services.dto.HeaderFooterDTO;
import mx.com.metlife.tom.fitrava.services.dto.TransformacionCampoDTO;
import mx.com.metlife.tom.fitrava.services.error.FitravaException;
import mx.com.metlife.tom.fitrava.services.error.ValidationException;
import mx.com.metlife.tom.fitrava.services.service.LayoutService;
import mx.com.metlife.tom.fitrava.services.serviceimpl.beans.FitravaSrvMessages;

@RestController
@RequestMapping(value = "/camposrv")
@PropertySource("classpath:${env_var:dev}-fitrava.properties")
public class CamposFitravaController extends FitravaController {
	
	private static final String CLID = CamposFitravaController.class.getSimpleName();
	private static Logger log = LoggerFactory.getLogger(CamposFitravaController.class);
	
	@Value("#{'${field.special.operations}'.split(',')}")
	private List<Long> lstExcludeOperations;

	@Autowired
	private LayoutService layoutService = null;
	@Autowired
	private FitravaSrvMessages messages;

	@CrossOrigin
	@GetMapping("/v1/campo")
	public @ResponseBody ResponseEntity<CampoDTO> getCampo(@RequestParam("fieldId") Long fieldId) throws ValidationException, FitravaException {
		log.info("Executing >>> getCampo(fieldId: {})", fieldId);
		if (fieldId == null || fieldId <= 0) {
			throw new ValidationException(String.format(messages.get(CLID, "MSG_FIELD_ID_NOT_NULL"), fieldId));
		}
		return new ResponseEntity<>(layoutService.getCampoById(fieldId), HttpStatus.OK);
	}

	@CrossOrigin
	@GetMapping("/v1/allCampos")
	public @ResponseBody ResponseEntity<List<CampoDTO>> getAllCampo(@RequestParam("layoutId") Long layoutId) throws ValidationException, FitravaException {
		log.info("Executing >>> getAllCampo(layoutId: {})", layoutId);
		if (layoutId == null || layoutId <= 0) {
			throw new ValidationException(String.format(messages.get(CLID, "MSG_LAYOUT_ID_NOT_NULL"), layoutId));
		}
		return new ResponseEntity<>(layoutService.getAllCamposByLayoutId(layoutId), HttpStatus.OK);
	}

	@CrossOrigin
	@PutMapping("/v1/actualiza")
	public @ResponseBody ResponseEntity<CampoDTO> putActualiza(@RequestBody CampoDTO campoDTO) throws ValidationException, FitravaException {
		log.info("Executing >>> putActualiza(campoDTO: {})", campoDTO);
		if (campoDTO == null) {
			throw new ValidationException(messages.get(CLID, "MSG_FIELD_NOT_NULL"));
		}
		if (campoDTO.getLayoutFldId() == null || campoDTO.getLayoutFldId() <= 0) {
			throw new ValidationException(messages.get(CLID, "MSG_INVALID_ID"));
		}
		return new ResponseEntity<>(layoutService.actualizaCampo(campoDTO), HttpStatus.OK);
	}
	
	@CrossOrigin
	@PostMapping("/v1/guarda")
	public @ResponseBody ResponseEntity<CampoDTO> postGuarda(@RequestBody CampoDTO campoDTO) throws ValidationException, FitravaException {
		log.info("Executing >>> postGuarda(fieldDTO: {})", campoDTO);
		if (campoDTO == null) {
			throw new ValidationException(messages.get(CLID, "MSG_ID_NOT_NULL2"));
		}
		return new ResponseEntity<>(layoutService.guardaCampo(campoDTO), HttpStatus.OK);
	}

	@CrossOrigin
	@DeleteMapping("/v1/borra")
	public @ResponseBody ResponseEntity<Boolean> deleteCampo(@RequestParam("fieldId") Long fieldId) throws FitravaException {
		log.info("Executing >>> deleteCampo(fieldId: {})", fieldId);
		layoutService.deleteCampo(fieldId);
		return new ResponseEntity<>(Boolean.TRUE, HttpStatus.OK);
	}

	@CrossOrigin
	@PostMapping("/v1/transformacion/guarda")
	public @ResponseBody ResponseEntity<TransformacionCampoDTO> postTransformacionGuarda(@RequestBody TransformacionCampoDTO transformacionCampoDTO) throws ValidationException, FitravaException {
		log.info("Executing >>> postTransformacionGuarda(transformacionCampoDTO: {})", transformacionCampoDTO);
		return new ResponseEntity<>(layoutService.guardaTransformacionCampo(transformacionCampoDTO), HttpStatus.OK);
	}
	
	@CrossOrigin
	@PutMapping("/v1/transformacion/actualiza")
	public @ResponseBody ResponseEntity<TransformacionCampoDTO> putTransformacionGuarda(@RequestBody TransformacionCampoDTO transformacionCampoDTO) throws ValidationException, FitravaException {
		log.info("En el postTransformacionGuarda(putTransformacionGuarda: {})", transformacionCampoDTO);
		return new ResponseEntity<>(layoutService.actualizaTransformacionCampo(transformacionCampoDTO), HttpStatus.OK);
	}
	
	@CrossOrigin
	@GetMapping("/v1/transformacion")
	public @ResponseBody ResponseEntity<List<TransformacionCampoDTO>> getTransformacion(@RequestParam("layoutFldId") Long layoutFldId) throws ValidationException, FitravaException {
		log.info("En el getTransformacion(layoutFldId: {})", layoutFldId);		
		if (layoutFldId == null || layoutFldId <= 0) {
			throw new ValidationException(String.format("El layoutFldId de la tranformacion no puede ser null o menor o igual a cero: %1$s", layoutFldId));
		}
		return new ResponseEntity<>(layoutService.getTransformacionCampo(layoutFldId), HttpStatus.OK);
	}
	
	@CrossOrigin
	@DeleteMapping("/v1/transformacion/borra")
	public @ResponseBody ResponseEntity<Boolean> deleteTranformacion(@RequestParam("fldTformId") Long fldTformId) throws FitravaException {
		log.info("En el deleteTranformacion(fldTformId: {})", fldTformId);
		layoutService.deleteTransform(fldTformId);
		return new ResponseEntity<>(Boolean.TRUE, HttpStatus.OK);
	}

	//header y footer

	@CrossOrigin
	@GetMapping("/v1/headerFooter")
	public @ResponseBody ResponseEntity<HeaderFooterDTO> getHeaderFooter(@RequestParam("headerFooterId") Long headerFooterId) throws ValidationException, FitravaException {
		log.info("Executing >>> getHeaderFooter(headerFooterId: {})", headerFooterId);
		if (headerFooterId == null || headerFooterId <= 0) {
			throw new ValidationException(String.format(messages.get(CLID, "MSG_ID_HEADER_NOT_NULL"), headerFooterId));
		}
		return new ResponseEntity<>(layoutService.getHeaderFooterById(headerFooterId), HttpStatus.OK);
	}

	@CrossOrigin
	@GetMapping("/v1/allHeaderFooter")
	public @ResponseBody ResponseEntity<List<HeaderFooterDTO>> getAllHeaderFooter(@RequestParam("layoutId") Long layoutId) throws ValidationException, FitravaException {
		log.info("Executing >>> getAllHeaderFooter(layoutId: {})", layoutId);
		if (layoutId == null || layoutId <= 0) {
			throw new ValidationException(String.format(messages.get(CLID, "MSG_LAYOUTID_HEADER_NOT_NULL"), layoutId));
		}
		return new ResponseEntity<>(layoutService.getAllHeaderFootersByLayoutId(layoutId), HttpStatus.OK);
	}

	@CrossOrigin
	@PutMapping("/v1/actualizaHeaderFooter")
	public @ResponseBody ResponseEntity<HeaderFooterDTO> putActualiza(@RequestBody HeaderFooterDTO headerFooterDTO) throws ValidationException, FitravaException {
		log.info("Executing >>> putActualiza(headerFooterDTO: {})", headerFooterDTO);
		if (headerFooterDTO == null) {
			throw new ValidationException(messages.get(CLID, "MSG_HEADER_FOOTER_NOT_NULL"));
		}
		if (headerFooterDTO.getLayoutHdId() == null || headerFooterDTO.getLayoutHdId() <= 0) {
			throw new ValidationException(messages.get(CLID, "MSG_ID_HEADER_INVALID"));
		}
		layoutService.deleteHeaderFooterDtl(headerFooterDTO.getLayoutHdId());
		return new ResponseEntity<>(layoutService.actualizaHeaderFooter(headerFooterDTO), HttpStatus.OK);
	}

	@CrossOrigin
	@PostMapping("/v1/guardaHeaderFooter")
	public @ResponseBody ResponseEntity<HeaderFooterDTO> postGuardaHeader(@RequestBody HeaderFooterDTO headerFooter) throws ValidationException, FitravaException {
		log.info("Executing >>> postGuardaHeader(headerFooter: {})", headerFooter);
		if (headerFooter == null ) {
			throw new ValidationException(messages.get(CLID, "MSG_HEADER_FOOTER_NOT_NULL2"));
		}
		return new ResponseEntity<>(layoutService.guardaHeaderFooter(headerFooter), HttpStatus.OK);
	}
	
	@CrossOrigin
	@DeleteMapping("/v1/borraHeaderFooter")
	public @ResponseBody ResponseEntity<Boolean> deleteHeaderFooter(@RequestParam("headerFooterId") Long headerFooterId) throws FitravaException {
		log.info("Executing >>> deletLayout(headerFooterId: {})", headerFooterId);
		layoutService.deleteHeaderFooter(headerFooterId);
		return new ResponseEntity<>(Boolean.TRUE, HttpStatus.OK);
	}
	
	@CrossOrigin
	@GetMapping("/v1/allCamposExcludeEspecialOpers")
	public @ResponseBody ResponseEntity<List<CampoDTO>> getAllCamposExcludeEspecialOpers(@RequestParam("layoutId") Long layoutId) throws ValidationException, FitravaException {
		log.info("Executing >>> getAllCampo(layoutId: {})", layoutId);
		if (layoutId == null || layoutId <= 0) {
			throw new ValidationException(String.format(messages.get(CLID, "MSG_LAYOUT_ID_NOT_NULL"), layoutId));
		}
		return new ResponseEntity<>(layoutService.getAllCamposWithoutSpecialOperationsByLayoutId(layoutId, lstExcludeOperations), HttpStatus.OK);
	}
	
	@CrossOrigin
	@PostMapping("/v1/transformacion/sobreescribe/{layoutFldId}")
	public @ResponseBody ResponseEntity<List<TransformacionCampoDTO>> postTransformacionGuarda(@PathVariable("layoutFldId") long layoutFldId,@RequestBody List<TransformacionCampoDTO> lstTransformacionCampoDTO) throws ValidationException, FitravaException {
		log.info("Executing >>> postTransformacionGuarda(lstTransformacionCampoDTO: {})", lstTransformacionCampoDTO);
		return new ResponseEntity<>(layoutService.sobreescribeTransformacionCampo(layoutFldId, lstTransformacionCampoDTO), HttpStatus.OK);
	}
}

