package mx.com.metlife.tom.fitrava.services.web.controller;

import static mx.com.metlife.tom.fitrava.services.utility.Constantes.SPACE;
import static mx.com.metlife.tom.fitrava.services.utility.Constantes.ERROR_CODE_500;
import static mx.com.metlife.tom.fitrava.services.utility.Constantes.ERROR_MESSAGE_500;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import mx.com.metlife.tom.fitrava.services.error.ErrorExtensionVO;
import mx.com.metlife.tom.fitrava.services.error.FitravaException;
import mx.com.metlife.tom.fitrava.services.error.MessagesErrorVO;
import mx.com.metlife.tom.fitrava.services.serviceimpl.beans.FitravaSrvMessages;

public abstract class FitravaController {
	
	private static final String CLID = FitravaController.class.getSimpleName();
	protected static Logger log = LoggerFactory.getLogger(FitravaController.class);
	
	@Autowired
	private FitravaSrvMessages messages;
	
	@GetMapping("/ping")
	public @ResponseBody ResponseEntity<String> hola(@RequestParam("ping") String ping) {
		return new ResponseEntity<>(messages.get(CLID, "MSG_HELLO_WORLD") + SPACE + ping, HttpStatus.OK);
	}
		

	protected @ResponseBody ResponseEntity<MessagesErrorVO> manejaFiltravaException(FitravaException exception) {
		ErrorExtensionVO specific = new ErrorExtensionVO(null, ERROR_MESSAGE_500);
		MessagesErrorVO messagesErrorVO = new MessagesErrorVO(ERROR_CODE_500, exception.getMessage(),"", specific);
		return new ResponseEntity<>(messagesErrorVO, HttpStatus.INTERNAL_SERVER_ERROR);
	}
}

 