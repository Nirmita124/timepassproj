package mx.com.metlife.tom.fitrava.services.dto;

import java.util.List;

import lombok.Data;

@SuppressWarnings("serial")
@Data
public class CampoDTO implements java.io.Serializable{

	private Long layoutFldId = null;

	private Long layoutId = null;

	private String layoutFldNm = null;

	private String layoutFldDscr = null;

	private Integer datatypId = null;

	private Boolean mndtLayoutFldInd = null;

	private Integer layoutFldLnthNum = null;

	private String seprtrDecVal = null;

	private Integer decPstnCnt = null;

	private Integer initPstnNum = null;

	private Integer fnlPstnNum = null;

	private Boolean cifraCtrlInd = null;

	private String layoutFldLblNm = null;

	private Integer operId = null;
	
	private Character hdnInd = null;

	private List<AttributeDTO> listTLayoutFldAtrb;

	private OperacionDTO tOper;

	private TipoDatoDTO tDatatyp;
	
	private List<TransformacionCampoDTO> listTFldTform;


}
