package mx.com.metlife.tom.fitrava.services.web.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import mx.com.metlife.tom.fitrava.services.dto.RoleDTO;
import mx.com.metlife.tom.fitrava.services.dto.RoleMenuDTO;

import mx.com.metlife.tom.fitrava.services.dto.UserDTO;
import mx.com.metlife.tom.fitrava.services.error.FitravaException;
import mx.com.metlife.tom.fitrava.services.error.ValidationException;
import mx.com.metlife.tom.fitrava.services.service.UserManagementService;
import mx.com.metlife.tom.fitrava.services.serviceimpl.beans.FitravaSrvMessages;

@RestController
@RequestMapping(value = "/usersrv")
public class UserManagementController {

	private static final String CLID = UserManagementController.class.getSimpleName();
	private static Logger log = LoggerFactory.getLogger(UserManagementController.class);

	@Autowired
	private UserManagementService userManagementService = null;
	@Autowired
	private FitravaSrvMessages messages;
	
	@CrossOrigin
	@GetMapping("/v1/allUsers")
	public @ResponseBody ResponseEntity<List<UserDTO>> getAllUsers() throws ValidationException, FitravaException {
		log.info("Executing >>> getAllUsers()");
		return new ResponseEntity<>(userManagementService.findAllUser(), HttpStatus.OK);
	}

	@CrossOrigin
	@PostMapping("/v1/guarda")
	public @ResponseBody ResponseEntity<UserDTO> postGuarda(@RequestBody UserDTO user)
			throws ValidationException, FitravaException {
		log.info("Executing >>> postGuarda(userDTO: {})", user);
		if (user == null) {
			throw new ValidationException(messages.get(CLID, "MSG_ERR_USER_CANT_BE_NULL"));
		}
		return new ResponseEntity<>(userManagementService.saveUser(user), HttpStatus.OK);
	}

	@CrossOrigin
	@GetMapping("/v1/getById")
	public @ResponseBody ResponseEntity<UserDTO> getById(@RequestParam("id") String id)
			throws ValidationException, FitravaException {
		log.info("Executing >>> getById(id: {})", id);
		if (id == null) {
			throw new ValidationException(messages.get(CLID, "MSG_ERR_ID_CANT_BE_NULL"));
		}
		return new ResponseEntity<>(userManagementService.findById(id), HttpStatus.OK);
	}

	@CrossOrigin
	@PutMapping("/v1/actualiza/{id}")
	public ResponseEntity<?> patchActualiza(@PathVariable("id") String id, @RequestParam("roleId") Integer roleId,
			@RequestParam("status") Integer status)throws ValidationException, FitravaException {

		log.info("Executing >>> patchActualiza(id: {}, idRole: {}, status: {})", id, roleId, status);
		if (id == null && roleId == null && status == null) {
			throw new ValidationException(messages.get(CLID, "MSG_ERR_NO_ONE_DATUM_CAN_BE_NULL"));
		}
		return new ResponseEntity<>(userManagementService.updateUser(id, roleId, status), HttpStatus.OK);
	}
	
	@CrossOrigin
	@GetMapping("/v1/allRolesMenus")
	public @ResponseBody ResponseEntity<List<RoleMenuDTO>> getAllRolesMenus() throws ValidationException, FitravaException {
		log.info("Executing >>> getAllUsers()");
		return new ResponseEntity<>(userManagementService.findAllRoleMenus(), HttpStatus.OK);
	}
	
	@CrossOrigin
	@DeleteMapping("/v1/deleteRolesMenus/{id}")
	public @ResponseBody ResponseEntity<Boolean> deleteRolesMenus(@PathVariable("id") Integer id)
			throws ValidationException, FitravaException {
		log.info("Executing >>> deleteRolesMenus()");
		userManagementService.deleteRoleMenuByRoleId(id);
		return new ResponseEntity<>(Boolean.TRUE, HttpStatus.OK);
	}
	
	@CrossOrigin
	@PutMapping("/v1/actualizaRole")
	public ResponseEntity<?> putActualizaRole(@RequestBody RoleDTO roleDto)throws ValidationException, FitravaException {

		log.info("Executing >>> putActualizaRole(roleDto: {})", roleDto);
		if (roleDto == null) {
			throw new ValidationException(messages.get(CLID, "MSG_ERR_ROL_CANT_BE_NULL"));
		}
		return new ResponseEntity<>(userManagementService.updateRole(roleDto), HttpStatus.OK);
	}
}
