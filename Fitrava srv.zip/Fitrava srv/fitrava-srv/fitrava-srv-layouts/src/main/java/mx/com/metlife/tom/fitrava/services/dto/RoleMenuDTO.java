package mx.com.metlife.tom.fitrava.services.dto;


import lombok.Data;

@Data
public class RoleMenuDTO implements java.io.Serializable{

	private static final long serialVersionUID = 7050492616033000367L;
	
	private Long roleMenuId = null;

	private Integer roleId = null;

	private Integer menuId = null;	
}
