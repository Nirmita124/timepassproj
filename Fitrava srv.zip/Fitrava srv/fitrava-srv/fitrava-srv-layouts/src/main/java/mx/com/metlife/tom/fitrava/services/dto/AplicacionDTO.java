package mx.com.metlife.tom.fitrava.services.dto;

import org.dozer.Mapping;

import lombok.Data;

@SuppressWarnings("serial")
@Data
public class AplicacionDTO implements java.io.Serializable{

	@Mapping("eaiCd")
	private String eaiCd = null;

	@Mapping("eaiDscr")
	private String eaiDscr = null;

	@Mapping("dirOrigDscr")
	private String dirOrigDscr = null;

	@Mapping("dirDestDscr")
	private String dirDestDscr = null;


}
