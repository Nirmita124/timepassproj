package mx.com.metlife.tom.fitrava.services.serviceimpl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.dozer.DozerBeanMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import mx.com.metlife.tom.fitrava.services.dto.FlujoArchivoDTO;
import mx.com.metlife.tom.fitrava.services.dto.FlujoDTO;
import mx.com.metlife.tom.fitrava.services.dto.FlujoMapeoDTO;
import mx.com.metlife.tom.fitrava.services.dto.FlujoMapeoDetalleDTO;
import mx.com.metlife.tom.fitrava.services.dto.LayoutDTO;
import mx.com.metlife.tom.fitrava.services.error.FitravaException;
import mx.com.metlife.tom.fitrava.services.error.FitravaPersistenceException;
import mx.com.metlife.tom.fitrava.services.error.ValidationException;
import mx.com.metlife.tom.fitrava.services.model.customer.TFlowCustomerRepository;
import mx.com.metlife.tom.fitrava.services.model.entity.TFlow;
import mx.com.metlife.tom.fitrava.services.model.entity.TFlowEntrncLayout;
import mx.com.metlife.tom.fitrava.services.model.entity.TFlowExtFile;
import mx.com.metlife.tom.fitrava.services.model.entity.TFlowMapping;
import mx.com.metlife.tom.fitrava.services.model.entity.TFlowMappingDtl;
import mx.com.metlife.tom.fitrava.services.model.entity.TLayout;
import mx.com.metlife.tom.fitrava.services.model.repository.TFlowEntrncLayoutRepository;
import mx.com.metlife.tom.fitrava.services.model.repository.TFlowExtFileRepository;
import mx.com.metlife.tom.fitrava.services.model.repository.TFlowMappingDtlRepository;
import mx.com.metlife.tom.fitrava.services.model.repository.TFlowMappingRepository;
import mx.com.metlife.tom.fitrava.services.model.repository.TFlowRepository;
import mx.com.metlife.tom.fitrava.services.service.FlujoService;
import mx.com.metlife.tom.fitrava.services.serviceimpl.beans.FitravaSrvMessages;
import mx.com.metlife.tom.fitrava.services.utility.Constantes;
import mx.com.metlife.tom.fitrava.services.utility.Util;

@Service
public class FlujoServiceImpl implements FlujoService {

	private static final String CLID = FlujoServiceImpl.class.getSimpleName();
	private static Logger log = LoggerFactory.getLogger(FlujoServiceImpl.class);

	@Autowired
	private TFlowRepository tFlowRepository;
	@Autowired
	private TFlowCustomerRepository tFlowCustomerRepository;
	@Autowired
	private TFlowExtFileRepository tFlowExtFileRepository;
	@Autowired
	private TFlowEntrncLayoutRepository tFlowEntrncLayoutRepository;
	@Autowired
	private TFlowMappingRepository tFlowMappingRepository;
	@Autowired
	private TFlowMappingDtlRepository tFlowMappingDtlRepository;
	@Autowired
	private DozerBeanMapper mapper;
	@Autowired
	private FitravaSrvMessages messages;

	@Override
	public FlujoDTO getFlujoById(Long id) throws ValidationException, FitravaException {
		TFlow flow = null;
		FlujoDTO flujoDTO = null;
		List<TLayout> layouts = null;
		List<LayoutDTO> layoutsDTOs = null;
		try {
			Optional<TFlow> optional = tFlowRepository.findById(id);
			if (optional.isPresent()) {
				flow = optional.get();
			}
		} catch (Exception e) {
			log.error(String.format(messages.get(CLID, "MSG_ERR_GETTING_FLOW_BY_ID"), id), e);
			throw new FitravaException(
					String.format(messages.get(CLID, "MSG_ERR_GETTING_FLOW_BY_ID_S1_S2"), id, e.getCause()));
		}
		if (flow == null) {
			throw new ValidationException(String.format(messages.get(CLID, "MSG_CANT_FID_ANY_FLOW_BY_ID"), id));
		}
		try {
			layouts = tFlowEntrncLayoutRepository.findAllLayoutsByFlowId(flow.getFlowId());
		} catch (Exception e) {
			log.error(String.format("Error al obtener los Layouts por el flujo id: %1$s", flow.getFlowId()), e);
			throw new FitravaException(
					String.format(messages.get(CLID, "MSG_CANT_FID_ANY_FLOW_BY_ID"), flow.getFlowId(), e.getCause()));
		}
		flujoDTO = mapper.map(flow, FlujoDTO.class);
		if (layouts != null && !layouts.isEmpty()) {
			layoutsDTOs = new ArrayList<>();
			for (TLayout tl : layouts) {
				layoutsDTOs.add(mapper.map(tl, LayoutDTO.class));
			}
			flujoDTO.setListTLayout(layoutsDTOs);
		}
		return flujoDTO;
	}

	@Override
	public List<FlujoDTO> getAllFlujosBy(String retenedorId, String eaiCd)
			throws ValidationException, FitravaException {
		log.info("Executing >>> getAllFlujosBy(retenedor: {}, eaiCd: {})", retenedorId, eaiCd);
		List<TFlow> flujos = null;
		List<FlujoDTO> flujosDTOs = null;
		try {
			flujos = tFlowCustomerRepository.findAllBy(retenedorId, eaiCd);
		} catch (FitravaPersistenceException e) {
			log.error(String.format("error al obtener el flujo por el retenedorId: %1$s y el eai: %2$s", retenedorId,
					eaiCd), e);
			throw new FitravaException(Constantes.ERROR_DATA_BASE, e);
		} catch (Exception e) {
			log.error(String.format("error al obtener el flujo por el retenedorId: %1$s y el eai: %2$s", retenedorId,
					eaiCd), e);
			throw new FitravaException(String.format(messages.get(CLID, "MSG_ERR_GETTING_LAYOUT_BY_RETID"), retenedorId,
					eaiCd, e.getCause()));
		}
		if (flujos == null || flujos.isEmpty()) {
			throw new ValidationException(
					String.format(messages.get(CLID, "MSG_CANT_FIND_ANY_LAYOUT_BY_EAICD"), retenedorId, eaiCd));
		}
		flujosDTOs = new ArrayList<>();
		for (TFlow l : flujos) {
			flujosDTOs.add(mapper.map(l, FlujoDTO.class));
		}
		return flujosDTOs;
	}

	@Override
	@Transactional
	public FlujoDTO guardaFlujo(FlujoDTO flujoDTO) throws ValidationException, FitravaException {
		log.info("Executing >>> guardaFlujo(flujoDTO: {})", flujoDTO);
		TFlow tFlow = null;
		Date hoy = null;
		List<LayoutDTO> listTLayout = null;
		List<FlujoArchivoDTO> listTFlowExtFile = null;
		Long flowId = null;
		try {
			tFlow = tFlowRepository.findByName(flujoDTO.getFlowNm());
		}catch (Exception e) {
			log.error(String.format("No se puede obtern el flujo por el Nombre", flujoDTO), e);
			throw new FitravaException("Ya existe un registro con ese nombre");
		}
		if (tFlow != null ) {
			throw new FitravaException("Ya existe un registro con ese nombre: " + flujoDTO.getFlowNm());
		}
		try {
			hoy = new Date();
			listTLayout = flujoDTO.getListTLayout();
			listTFlowExtFile = flujoDTO.getListTFlowExtFile();
			tFlow = mapper.map(flujoDTO, TFlow.class);
			tFlow.setCrtTs(hoy);
			tFlow.setUpdtTs(hoy);
			tFlow.setListTFlowExtFile(null);
			tFlow = tFlowRepository.saveAndFlush(tFlow);
			if (tFlow == null || tFlow.getFlowId() == null) {
				throw new ValidationException(messages.get(CLID, "MSG_CANT_SAVE_TFLOW"));
			}
			flowId = tFlow.getFlowId();
			if (listTLayout != null) {
				int i = 0;
				for (LayoutDTO l : listTLayout) {
					tFlowEntrncLayoutRepository.saveAndFlush(new TFlowEntrncLayout(flowId, l.getLayoutId(), i++));
				}
			}
			if (listTFlowExtFile != null) {
				for (FlujoArchivoDTO fa : listTFlowExtFile) {
					tFlowExtFileRepository
							.saveAndFlush(new TFlowExtFile(flowId, fa.getFlowExtFileNm(), fa.getFlowExtFileRteNm()));
				}
			}
			flujoDTO = mapper.map(tFlow, FlujoDTO.class);
			flujoDTO.setListTLayout(listTLayout);
			flujoDTO.setListTFlowExtFile(listTFlowExtFile);
			return flujoDTO;
		} catch (Exception e) {
			log.error(String.format("error al guardar el flujo: %1$s", flujoDTO), e);
			throw new FitravaException(
					String.format(messages.get(CLID, "MSG_ERR_SAVING_FLOW"), flujoDTO, e.getCause()));
		}
	}

	@Override
	@Transactional
	public FlujoDTO actualizaFlujo(FlujoDTO flujoDTO) throws FitravaException {
		log.info("Executing >>> actualizaFlujo(flujoDTO: {})", flujoDTO);
		TFlow aCambiar = null;
		List<LayoutDTO> listTLayout = null;
		List<FlujoArchivoDTO> listTFlowExtFile = null;
		Long flowId = null;
		try {
			listTLayout = flujoDTO.getListTLayout();
			listTFlowExtFile = flujoDTO.getListTFlowExtFile();
			aCambiar = mapper.map(flujoDTO, TFlow.class);
			aCambiar.setUpdtTs(new Date());
			aCambiar.setListTFlowExtFile(null);
			aCambiar = tFlowRepository.save(aCambiar);
			if (listTLayout != null) {
				flowId = aCambiar.getFlowId();
				tFlowEntrncLayoutRepository.deleteByFlowId(flowId);
				int i = 0;
				for (LayoutDTO l : listTLayout) {
					tFlowEntrncLayoutRepository.saveAndFlush(new TFlowEntrncLayout(flowId, l.getLayoutId(), i++));
				}
			}
			if (listTFlowExtFile != null) {
				flowId = aCambiar.getFlowId();
				tFlowExtFileRepository.deleteByFlowId(flowId);
				for (FlujoArchivoDTO fa : listTFlowExtFile) {
					tFlowExtFileRepository
							.saveAndFlush(new TFlowExtFile(flowId, fa.getFlowExtFileNm(), fa.getFlowExtFileRteNm()));
				}
			}
			flujoDTO = mapper.map(aCambiar, FlujoDTO.class);
			flujoDTO.setListTLayout(listTLayout);
			flujoDTO.setListTFlowExtFile(listTFlowExtFile);
			return flujoDTO;
		} catch (Exception e) {
			log.error(String.format("error al actualizar el flujo: %1$s", flujoDTO), e);
			throw new FitravaException(
					String.format(messages.get(CLID, "MSG_ERR_UPDATING_FLOW"), aCambiar, e.getCause()));
		}
	}

	@Override
	@Transactional
	public Boolean actualizaActivaFlujo(Long flujoId) throws FitravaException {
		log.info("Executing >>> actualizaActivaFlujo(flujoId: {})", flujoId);
		Boolean resultado = null;
		try {
			resultado = tFlowCustomerRepository.mergeEstatus(flujoId, Constantes.ESTATUS_ACTIVO);
		} catch (FitravaPersistenceException e) {
			log.error(String.format("error al actualizar el flujo: %1$s", flujoId), e);
			throw new FitravaException(Constantes.ERROR_DATA_BASE, e);
		} catch (Exception e) {
			log.error(String.format("error al actualizar el estatus del Flujo con ID: %1$s", flujoId), e);
			throw new FitravaException(
					String.format(messages.get(CLID, "MSG_ERR_UPDATING_FLOW_STATE_BY_ID"), flujoId, e.getCause()));
		}
		return resultado;
	}

	@Override
	@Transactional
	public void deleteFlujo(Long id) throws FitravaException {
		log.info("Executing >>> deleteFlujo(id: {})", id);
		try {
			tFlowExtFileRepository.deleteByFlowId(id);
			tFlowEntrncLayoutRepository.deleteByFlowId(id);
			tFlowRepository.deleteById(id);
		} catch (Exception e) {
			log.error(String.format("error al borrar el Flujo con ID: %1$s", id), e);
			throw new FitravaException(
					String.format(messages.get(CLID, "MSG_ERR_DELETING_FLOW_BY_ID"), id, e.getCause()));
		}
	}

	@Override
	public FlujoArchivoDTO getFlujoArchivoById(Integer id) throws FitravaException {
		log.info("Executing >>> getFlujoArchivoById(id: {})", id);
		TFlowExtFile flow = null;
		try {
			Optional<TFlowExtFile> optional = tFlowExtFileRepository.findById(id);
			if (optional.isPresent()) {
				flow = optional.get();
			}
		} catch (Exception e) {
			log.error(String.format("error al obtener el FlujoArchivo con ID: %1$s", id), e);
			throw new FitravaException(
					String.format(messages.get(CLID, "MSG_ERR_GETTING_FILEFLOW_BY_ID"), id, e.getCause()));
		}
		if (flow == null) {
			throw new FitravaException(String.format(messages.get(CLID, "MSG_CANT_FIND_ANY_FILEFLOW_BY_GIVEN_ID"), id));
		}
		return mapper.map(flow, FlujoArchivoDTO.class);
	}

	@Override
	public List<FlujoArchivoDTO> getAllFlujosArchivoByFlujoId(Long flowId)
			throws ValidationException, FitravaException {
		log.info("Executing >>> getAllFlujosArchivoByFlujoId(flujoId: {})", flowId);
		List<TFlowExtFile> flujos = null;
		List<FlujoArchivoDTO> flujosDTOs = null;
		try {
			flujos = tFlowExtFileRepository.findByFlowId(flowId);
		} catch (Exception e) {
			log.error(String.format("error al obtener los FlujoArchivo con flowId: %1$s", flowId), e);
			throw new FitravaException(
					String.format(messages.get(CLID, "MSG_ER_GETTING_FILEFLOW_BY_ID_S1_S2"), flowId, e.getCause()));
		}
		if (flujos == null || flujos.isEmpty()) {
			throw new ValidationException(
					String.format(messages.get(CLID, "MSG_CANT_FIND_ANY_FILEFLOW_BY_GIVEN_ID_S1"), flowId));
		}
		flujosDTOs = new ArrayList<>();
		for (TFlowExtFile l : flujos) {
			flujosDTOs.add(mapper.map(l, FlujoArchivoDTO.class));
		}
		return flujosDTOs;
	}

	@Override
	@Transactional
	public FlujoArchivoDTO guardaFlujoArchivo(FlujoArchivoDTO flujoArchivoDTO)
			throws ValidationException, FitravaException {
		log.info("Executing >>> guardaFlujoArchivo(flujoArchivoDTO: {})", flujoArchivoDTO);
		TFlowExtFile flow = null;
		try {
			flow = tFlowExtFileRepository.saveAndFlush(mapper.map(flujoArchivoDTO, TFlowExtFile.class));
		} catch (Exception e) {
			log.error(String.format("error al guardar el FlujoArchivo: %1$s", flujoArchivoDTO), e);
			throw new FitravaException(
					String.format(messages.get(CLID, "MSG_ERR_SAVING_FILEFLOW"), flujoArchivoDTO, e.getCause()));
		}
		if (flow == null) {
			throw new ValidationException(messages.get(CLID, "MSG_CANT_FIND_ANY_FILEFLOW"));
		}
		return mapper.map(flow, FlujoArchivoDTO.class);
	}

	@Override
	@Transactional
	public FlujoArchivoDTO actualizaFlujoArchivo(FlujoArchivoDTO flujoArchivoDTO) throws FitravaException {
		log.info("Executing >>> actualizaFlujoArchivo(flujoArchivoDTO: {})", flujoArchivoDTO);
		TFlowExtFile aCambiar = null;
		try {
			aCambiar = tFlowExtFileRepository.save(mapper.map(flujoArchivoDTO, TFlowExtFile.class));
		} catch (Exception e) {
			log.error(String.format(messages.get(CLID, "MSG_ERR_UPDATING_FILE_FLOW"), flujoArchivoDTO), e);
			throw new FitravaException(
					String.format("error al actualizar el FlujoArchivo: %1$s, Error: %2$s", aCambiar, e.getCause()));
		}
		return mapper.map(aCambiar, FlujoArchivoDTO.class);
	}

	@Override
	@Transactional
	public void deleteFlujoArchivo(Integer id) throws FitravaException {
		log.info("Executing >>> deleteFlujoArchivo(id: {})", id);
		try {
			tFlowExtFileRepository.deleteById(id);
		} catch (Exception e) {
			log.error(String.format("error al borrar el FlujoArchivo con ID: %1$s", id), e);
			throw new FitravaException(
					String.format(messages.get(CLID, "MSG_ERR_DELETING_FILEFLOW_BY_ID_S1_S2"), id, e.getCause()));
		}
	}

	@Override
	@Transactional
	public void addOrReplaceAllLayoutsEntrada(Long flujoId, Long... layoutIds) throws FitravaException {
		log.info("Executing >>> addOrReplaceAllLayoutsEntrada(flujoId: {}, layoutIds: {})", flujoId,
				Util.getArrayToString(layoutIds));
		int posicion = 0;
		try {
			// 1ero borramos todos,
			tFlowEntrncLayoutRepository.deleteByFlowId(flujoId);
			// ahora ingresamos los nuevos
			for (Long id : layoutIds) {
				tFlowEntrncLayoutRepository.saveAndFlush(new TFlowEntrncLayout(flujoId, id, posicion++));
			}
		} catch (Exception e) {
			log.error(Constantes.ERROR_DATA_BASE, e);
			throw new FitravaException(
					String.format(messages.get(CLID, "MSG_CANT_UPDATE_INPUT_LAYOUTS_BY_ID"), flujoId, e.getCause()));
		}
	}

	@Override
	@Transactional
	public void addOrReplaceLayoutEntrada(Long flujoId, Long layoutId) throws FitravaException {
		log.info("Executing >>> addAllLayoutsEntrada(flujoId: {} layoutId: {})", flujoId, layoutId);
		Long cuenta = null;
		try {
			tFlowEntrncLayoutRepository.deleteById(flujoId, layoutId);
			cuenta = tFlowEntrncLayoutRepository.countBy(flujoId, layoutId);
			cuenta++;
			tFlowEntrncLayoutRepository.saveAndFlush(new TFlowEntrncLayout(flujoId, layoutId, cuenta.intValue()));
		} catch (Exception e) {
			log.error(String.format("No se pudo pudo sobrescribir en el flujoId: %1$s, layoutId: %2$s", flujoId,
					layoutId), e);
			throw new FitravaException(
					String.format(messages.get(CLID, "MSG_CANT_OVERWRITE_FLOW_D"), flujoId, layoutId, e.getCause()));
		}
	}

	@Override
	@Transactional
	public void addOrReplaceLayoutSalida(Long flujoId, Long layoutId) throws FitravaException {
		log.info("Executing >>> addAllLayoutsEntrada(flujoId: {}, layoutId: {})", flujoId, layoutId);
		try {
			tFlowRepository.mergeLayoutSalida(flujoId, layoutId);
		} catch (Exception e) {
			log.error(String.format(
					"No se pudo pudo agregar el Flujo con el flujoId: %1$s y  layoutId: %2$s como de salida", flujoId,
					layoutId), e);
			throw new FitravaException(String.format(messages.get(CLID, "MSG_CANT_OVERWRITE_FLOWID_S1_S2_S3"), flujoId,
					layoutId, e.getCause()));
		}
	}

	@Override
	@Transactional
	public void deleteLayoutFromFlujo(Long flujoId, Long layoutId) throws FitravaException {
		log.info("Executing >>> deleteLayoutFromFlujo(flujoId: {}, layoutId: {})", flujoId, layoutId);
		try {
			tFlowEntrncLayoutRepository.deleteById(flujoId, layoutId);
		} catch (Exception e) {
			log.error(String.format("No se pudo pudo borrar en el flujoId: %1$s, layoutId: %2$s", flujoId, layoutId),
					e);
			throw new FitravaException(
					String.format(messages.get(CLID, "MSG_CANT_DELETE_FLOWID"), flujoId, layoutId, e.getCause()));
		}
	}

	@Override
	public FlujoMapeoDTO getFlujoMapeoById(Long flujoMapeoId) throws FitravaException {
		log.info("Executing >>> getFlujoMapeoById(flujoMapeoId: {})", flujoMapeoId);
		TFlowMapping tfm = null;
		try {
			Optional<TFlowMapping> optional = tFlowMappingRepository.findById(flujoMapeoId);
			if (optional.isPresent()) {
				tfm = optional.get();
			}
		} catch (Exception e) {
			log.error(String.format("error al obtener el FlujoMapeo con ID: %1$s", flujoMapeoId), e);
			throw new FitravaException(
					String.format(messages.get(CLID, "MSG_CANT_DELETE_FLOWID"), flujoMapeoId, e.getCause()));
		}
		if (tfm == null) {
			throw new FitravaException(
					String.format(messages.get(CLID, "MSG_CANT_FIND_ANY_MAPFLOW_BY_MAPFLOWID"), flujoMapeoId));
		}
		return mapper.map(tfm, FlujoMapeoDTO.class);
	}

	@Override
	public List<FlujoMapeoDTO> getAllFlujoMapeosByFlujoIdAndLayoutEntradaId(Long flujoId, Long layoutEntradaId)
			throws ValidationException, FitravaException {
		log.info("Executing >>> getAllFlujosMapeoByFlujoId(flujoId: {}, layoutEntradaId: {})", flujoId,
				layoutEntradaId);
		List<TFlowMapping> flujoMapeos = null;
		List<FlujoMapeoDTO> flujoMapeoDTOs = null;
		try {
			flujoMapeos = tFlowMappingRepository.findByFlowIdAndLayoutEntradaId(flujoId, layoutEntradaId);
		} catch (Exception e) {
			log.error(String.format("error al obtener los FlujoMapeo con flujoId: %1$s y el layout de entrada: %2$s",
					flujoId, layoutEntradaId), e);
			throw new FitravaException(String.format(messages.get(CLID, "MSG_ERR_GETTING_FMAP_FLOW_BY_FLOWID"), flujoId,
					layoutEntradaId, e.getCause()));
		}
		if (flujoMapeos == null || flujoMapeos.isEmpty()) {
			throw new ValidationException(
					String.format(messages.get(CLID, "MSG_CANT_FIND_ANY_MAPFLOW_BY_FLOWID"), flujoId, layoutEntradaId));
		}
		flujoMapeoDTOs = new ArrayList<>();
		for (TFlowMapping l : flujoMapeos) {
			flujoMapeoDTOs.add(mapper.map(l, FlujoMapeoDTO.class));
		}
		return flujoMapeoDTOs;
	}

	@Override
	@Transactional
	public FlujoMapeoDTO guardaFlujoMapeo(FlujoMapeoDTO flujoMapeoDTO) throws ValidationException, FitravaException {
		log.info("Executing >>> guardaFlujoMapeo(flujoMapeoDTO: {})", flujoMapeoDTO);
		TFlowMapping flujoMapeo = null;
		List<FlujoMapeoDetalleDTO> listTFlowMappingDtl = null;

		TFlowMappingDtl flujoMapeoDtl = null;
		List<TFlowMappingDtl> listFlujoMapeoDtl = null;
		Long flowMappingId = null;
		try {
			listTFlowMappingDtl = flujoMapeoDTO.getListTFlowMappingDtl();
			flujoMapeo = mapper.map(flujoMapeoDTO, TFlowMapping.class);
			flujoMapeo.setListTFlowMappingDtl(null);
			flujoMapeo = tFlowMappingRepository.saveAndFlush(flujoMapeo);
			if (flujoMapeo != null && flujoMapeo.getFlowMappingId() != null && listTFlowMappingDtl != null
					&& !listTFlowMappingDtl.isEmpty()) {
				flowMappingId = flujoMapeo.getFlowMappingId();
				listFlujoMapeoDtl = new ArrayList<>();
				for (FlujoMapeoDetalleDTO fmd : listTFlowMappingDtl) {
					flujoMapeoDtl = mapper.map(fmd, TFlowMappingDtl.class);
					flujoMapeoDtl.setFlowMappingId(flowMappingId);
					flujoMapeoDtl = tFlowMappingDtlRepository.save(flujoMapeoDtl);
					listFlujoMapeoDtl.add(flujoMapeoDtl);
				}
				flujoMapeo.setListTFlowMappingDtl(listFlujoMapeoDtl);
			}
			return mapper.map(flujoMapeo, FlujoMapeoDTO.class);
		} catch (Exception e) {
			log.error(String.format("error al guardar el FlujoMapeo: %1$s", flujoMapeoDTO), e);
			throw new FitravaException(
					String.format(messages.get(CLID, "MSG_ERR_SAVING_MAPFLOW"), flujoMapeoDTO, e.getCause()));
		}
	}

	@Override
	@Transactional
	public FlujoMapeoDTO actualizaFlujoMapeo(FlujoMapeoDTO flujoMapeoDTO) throws FitravaException {
		TFlowMapping flujoMapeo = null;
		TFlowMappingDtl flujoMapeoDtl = null;

		List<TFlowMappingDtl> listFlujoMapeoDtl = null;
		List<FlujoMapeoDetalleDTO> listTFlowMappingDtl = null;
		Long flowMappingId = null;
		try {
			listTFlowMappingDtl = flujoMapeoDTO.getListTFlowMappingDtl();
			flujoMapeoDTO.setListTFlowMappingDtl(null);
			flujoMapeo = tFlowMappingRepository.save(mapper.map(flujoMapeoDTO, TFlowMapping.class));
			if (flujoMapeo != null && listTFlowMappingDtl != null && !listTFlowMappingDtl.isEmpty()) {
				flowMappingId = flujoMapeo.getFlowMappingId();
				listFlujoMapeoDtl = new ArrayList<>();
				for (FlujoMapeoDetalleDTO fmd : listTFlowMappingDtl) {
					flujoMapeoDtl = mapper.map(fmd, TFlowMappingDtl.class);
					flujoMapeoDtl.setFlowMappingId(flowMappingId);
					flujoMapeoDtl = tFlowMappingDtlRepository.save(flujoMapeoDtl);
					listFlujoMapeoDtl.add(flujoMapeoDtl);
				}
				flujoMapeo.setListTFlowMappingDtl(listFlujoMapeoDtl);
			}
			return mapper.map(flujoMapeo, FlujoMapeoDTO.class);
		} catch (Exception e) {
			log.error(String.format("error al guardar el FlujoMapeo: %1$s", flujoMapeoDTO), e);
			throw new FitravaException(
					String.format(messages.get(CLID, "MSG_ERR_SAVING_MAPFLOW_S1_S2"), flujoMapeoDTO, e.getCause()));
		}
	}

	@Override
	@Transactional
	public void deleteFlujoMapeo(Long flujoMapeoId) throws FitravaException {
		log.info("En el deleteFlujoMapeo(flujoMapeoId: {})", flujoMapeoId);
		try {
			tFlowMappingDtlRepository.deleteByFlowMappingId(flujoMapeoId);
			tFlowMappingRepository.deleteById(flujoMapeoId);
		} catch (Exception e) {
			log.error(String.format("error al borrar el FlujoMapeo con ID: %1$s", flujoMapeoId), e);
			throw new FitravaException(
					String.format(messages.get(CLID, "MSG_ERR_DELETING_MAPFLOW_BY_ID"), flujoMapeoId, e.getCause()));
		}
	}

	@Override
	@Transactional
	public void deleteFlujoMapeoDtl(Long flujoMapeoId) throws FitravaException {
		log.info("Executing >>> deleteFlujoMapeoDtl(flujoMapeoId: {})", flujoMapeoId);
		try {
			tFlowMappingDtlRepository.deleteByFlowMappingId(flujoMapeoId);
		} catch (Exception e) {
			log.error(String.format("error al borrar el FlujoMapeoDtl con ID: %1$s", flujoMapeoId), e);
			throw new FitravaException(
					String.format(messages.get(CLID, "MSG_ERR_DELETING_MAPFLOWDTL_BY_ID"), flujoMapeoId, e.getCause()));
		}
	}

	@Override
	public List<FlujoDTO> getFlowsByEaiAndExt(String eai, String ext) throws ValidationException, FitravaException {
		log.info("Executing >>> getAllLayoutsIntoFlowsByEai(eai: {}, ext: {})", eai, ext);
		List<TFlow> flows = null;
		List<FlujoDTO> flujoDTOs = null;
		List<TLayout> layouts = null;
		List<LayoutDTO> layoutsDTOs = null;
		try {
			flows = tFlowRepository.findFlowsByEaiAndExt(eai, "%" + ext + "%");
		} catch (Exception e) {
			log.error(String.format("Error al obtener los flujos por el eai: %1$s y la extencion: %1$s", eai, ext), e);
			throw new FitravaException(
					String.format(messages.get(CLID, "MSG_ERR_GETTING_FLOW_BY_EAI"), eai, ext, e.getCause()));
		}
		if (flows == null || flows.isEmpty()) {
			throw new ValidationException(
					String.format(messages.get(CLID, "MSG_ERR_GETTING_FLOW_BY_EAI_S1"), eai, ext));
		}
		flujoDTOs = new ArrayList<>();
		for (TFlow l : flows) {
			flujoDTOs.add(mapper.map(l, FlujoDTO.class));
		}

		// Obteniendo y setteando lista de layouts de entrada
		for (FlujoDTO flujoDTO : flujoDTOs) {
			try {
				layouts = tFlowEntrncLayoutRepository.findAllLayoutsByFlowId(flujoDTO.getFlowId());
			} catch (Exception e) {
				log.error(String.format("Error al obtener los Layouts por el flujo id: %1$s", flujoDTO.getFlowId()), e);
				throw new FitravaException(String.format(messages.get(CLID, "MSG_CANT_FID_ANY_FLOW_BY_ID"),
						flujoDTO.getFlowId(), e.getCause()));
			}

			if (layouts != null && !layouts.isEmpty()) {
				layoutsDTOs = new ArrayList<>();
				for (TLayout tl : layouts) {
					layoutsDTOs.add(mapper.map(tl, LayoutDTO.class));
				}
				flujoDTO.setListTLayout(layoutsDTOs);
			}

		}

		return flujoDTOs;
	}

}
