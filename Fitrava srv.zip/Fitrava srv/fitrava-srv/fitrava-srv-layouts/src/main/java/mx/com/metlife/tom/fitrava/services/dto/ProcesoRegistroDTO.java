package mx.com.metlife.tom.fitrava.services.dto;

import org.dozer.Mapping;

import lombok.Data;

@SuppressWarnings("serial")
@Data
public class ProcesoRegistroDTO implements java.io.Serializable{

	@Mapping("dstnctCtrlNum")
	private String dcn = null;

	private Long recNum = null;

	private String fileNm = null;

	private Long layoutFldId = null;

	private String origVal = null;

	private String newVal = null;

	private Boolean badRsltInd = null;

	private String msgTxt = null;


}
