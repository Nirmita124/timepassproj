package mx.com.metlife.tom.fitrava.services.serviceimpl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.dozer.DozerBeanMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import mx.com.metlife.tom.fitrava.services.dto.CampoDTO;
import mx.com.metlife.tom.fitrava.services.dto.CharactersSkipDTO;
import mx.com.metlife.tom.fitrava.services.dto.LayoutDTO;
import mx.com.metlife.tom.fitrava.services.dto.LayoutExcelDTO;
import mx.com.metlife.tom.fitrava.services.dto.ParametroTransformacionParametroDTO;
import mx.com.metlife.tom.fitrava.services.dto.HeaderFooterDTO;
import mx.com.metlife.tom.fitrava.services.dto.HeaderFooterDetalleDTO;
import mx.com.metlife.tom.fitrava.services.dto.TransformacionCampoDTO;
import mx.com.metlife.tom.fitrava.services.error.FitravaException;
import mx.com.metlife.tom.fitrava.services.error.FitravaPersistenceException;
import mx.com.metlife.tom.fitrava.services.error.ValidationException;
import mx.com.metlife.tom.fitrava.services.model.customer.TLayoutCustomerRepository;
import mx.com.metlife.tom.fitrava.services.model.entity.TFldTform;
import mx.com.metlife.tom.fitrava.services.model.entity.TLayout;
import mx.com.metlife.tom.fitrava.services.model.entity.TLayoutFld;
import mx.com.metlife.tom.fitrava.services.model.entity.TLayoutHd;
import mx.com.metlife.tom.fitrava.services.model.entity.TLayoutHdDtl;
import mx.com.metlife.tom.fitrava.services.model.entity.TLayoutXcel;
import mx.com.metlife.tom.fitrava.services.model.entity.TLayoutXcelId;
import mx.com.metlife.tom.fitrava.services.model.entity.TSkpChar;
import mx.com.metlife.tom.fitrava.services.model.repository.TFldTformParmRepository;
import mx.com.metlife.tom.fitrava.services.model.repository.TFldTformRepository;
import mx.com.metlife.tom.fitrava.services.model.repository.TLayoutFldRepository;
import mx.com.metlife.tom.fitrava.services.model.repository.TLayoutHdDtlRepository;
import mx.com.metlife.tom.fitrava.services.model.repository.TLayoutHdRepository;
import mx.com.metlife.tom.fitrava.services.model.repository.TLayoutRepository;
import mx.com.metlife.tom.fitrava.services.model.repository.TLayoutXcelRepository;
import mx.com.metlife.tom.fitrava.services.model.repository.TSkpCharRepository;
import mx.com.metlife.tom.fitrava.services.service.LayoutService;
import mx.com.metlife.tom.fitrava.services.serviceimpl.beans.FitravaSrvMessages;
import mx.com.metlife.tom.fitrava.services.utility.Constantes;
import mx.com.metlife.tom.fitrava.services.utility.Util;

@Service
public class LayoutServiceImpl implements LayoutService {

	private static final String CLID = LayoutServiceImpl.class.getSimpleName();
	private static Logger log = LoggerFactory.getLogger(LayoutServiceImpl.class);

	@Autowired
	private TLayoutRepository tLayoutRepository;
	@Autowired
	private TLayoutFldRepository tLayoutFldRepository;
	@Autowired
	private TLayoutCustomerRepository tLayoutCustomerRepository;
	@Autowired
	private TFldTformRepository tFldTformRepository;
	@Autowired
	private TLayoutHdRepository tLayoutHdRepository;
	@Autowired
	private TLayoutHdDtlRepository tLayoutHdDtlRepository;

	@Autowired
	private TFldTformParmRepository tFldTformParmRepository;

	@Autowired
	private TSkpCharRepository tSkpCharRepository;

	@Autowired
	private DozerBeanMapper mapper;
	@Autowired
	private FitravaSrvMessages messages;

	@Autowired
	private TLayoutXcelRepository tLayoutXcelRepository;

	@Override
	public String getDate() throws FitravaException {
		try {
			return Util.dateToString(tLayoutCustomerRepository.getDate());
		} catch (FitravaPersistenceException e) {
			throw new FitravaException(Constantes.ERROR_DATA_BASE, e);
		}
	}

	@Override
	public LayoutDTO getLayoutById(Long layoutId) throws ValidationException, FitravaException {
		log.info("Executing >>> getLayoutById(layoutId: {})", layoutId);
		TLayout layout = null;
		try {
			layout = tLayoutRepository.findById(layoutId);
		} catch (Exception e) {
			log.error(String.format("Error al obtener el Layout por el id: %1$s", layoutId), e);
			throw new FitravaException(
					String.format(messages.get(CLID, "MSG_ERR_GETTING_LAYOUT_BY_ID"), layoutId, e.getCause()));
		}
		if (layout == null) {
			throw new ValidationException(
					String.format(messages.get(CLID, "MSG_CANT_FIND_ANY_LAYOUT_BY_GIVEN_ID"), layoutId));
		}
		return convert(layout);
	}

	@Override
	public LayoutDTO getLayoutByName(String nameLayout) throws ValidationException, FitravaException {
		log.info("Executing >>> getLayoutById(nameLayout: {})", nameLayout);
		TLayout layout = null;
		try {
			layout = tLayoutRepository.findByLayoutNm(nameLayout);
		} catch (Exception e) {
			log.error(String.format("Error al obtener el Layout por el nombre: %1$s", nameLayout), e);
			throw new FitravaException(String.format(messages.get(CLID, "MSG_ERR_GETTING_LAYOUT_BY_NAME_S1_S2"),
					nameLayout, e.getCause()));
		}
		if (layout == null) {
			throw new ValidationException(
					String.format(messages.get(CLID, "MSG_ERR_GETTING_LAYOUT_BY_NAME_S1"), nameLayout));
		}
		return convert(layout);
	}

	@Override
	public List<LayoutDTO> getAllLayoutsByEai(String eai) throws ValidationException, FitravaException {
		log.info("Executing >>> getAllLayoutsByEai(eai: {})", eai);
		List<TLayout> layouts = null;
		List<LayoutDTO> layoutDTOs = null;
		try {
			layouts = tLayoutCustomerRepository.findAllByEaid(eai);
		} catch (FitravaPersistenceException e) {
			log.error(Constantes.ERROR_DATA_BASE, e);
			throw new FitravaException(Constantes.ERROR_DATA_BASE, e);
		} catch (Exception e) {
			log.error(String.format("Error al obtener los Layout por el eai: %1$s", eai), e);
			throw new FitravaException(
					String.format(messages.get(CLID, "MSG_ERR_GETTING_LAYOUT_BY_EAI"), eai, e.getCause()));
		}
		if (layouts == null || layouts.isEmpty()) {
			throw new ValidationException(String.format(messages.get(CLID, "MSG_ERR_GETTING_AYOUT_BY_EAI_S1"), eai));
		}
		layoutDTOs = new ArrayList<>();
		for (TLayout l : layouts) {
			layoutDTOs.add(mapper.map(l, LayoutDTO.class));
		}
		return layoutDTOs;
	}

	@Override
	@Transactional
	public LayoutDTO guardaLayout(LayoutDTO layoutDTO) throws ValidationException, FitravaException {
		log.info("Executing >>> guardaLayout(layoutDTO: {})", layoutDTO);
		TLayout tLayout = null;
		Date hoy = null;
		try {
			tLayout = tLayoutRepository.findByLayoutNm(layoutDTO.getLayoutNm());
		} catch (Exception e) {
			log.error(String.format("Error al guardar el Layout: %1$s", layoutDTO), e);
			throw new FitravaException(
					String.format("No se ecnontro el layout con el id: %1$s", layoutDTO.getLayoutNm()));
		}
		if (tLayout != null) {
			throw new ValidationException(messages.get(CLID, "Msg_ERR_LAYOUT_NAME_ISNT_REPEATED"));
		}
		try {
			hoy = new Date();
			tLayout = mapper.map(layoutDTO, TLayout.class);
			tLayout.setCrtTs(hoy);
			tLayout.setUpdtTs(hoy);
			tLayout = tLayoutRepository.saveAndFlush(tLayout);
		} catch (Exception e) {
			log.error(String.format("Error al guardar el Layout: %1$s", layoutDTO), e);
			throw new FitravaException("No se pudo guardar");
		}
		return mapper.map(tLayout, LayoutDTO.class);
	}

	@Override
	@Transactional
	public LayoutDTO actualizaLayout(LayoutDTO layoutDTO) throws FitravaException {
		log.info("Executing >>> actualizaLayout(layoutDTO: {})", layoutDTO);
		TLayout aCambiar = null;
		try {
			aCambiar = mapper.map(layoutDTO, TLayout.class);
			aCambiar.setUpdtTs(new Date());
			aCambiar = tLayoutRepository.save(aCambiar);
		} catch (Exception e) {
			log.error(String.format("Error al actualizar el Layout: %1$s", layoutDTO), e);
			throw new FitravaException(
					String.format(messages.get(CLID, "MSG_ERR_UPDATING_LAYOUT"), aCambiar, e.getCause()));
		}
		return mapper.map(aCambiar, LayoutDTO.class);
	}

	@Override
	@Transactional
	public Boolean actualizaActivaLayout(Long layoutId) throws FitravaException {
		TLayout tlayout = null;
		List<TLayoutFld> fields = null;
		try {
			tlayout = tLayoutRepository.findById(layoutId);
			fields = tLayoutFldRepository.findByLayoutId(layoutId);
			if (fields != null) {
				tlayout.setNumColumns(fields.size());
				Integer suma = 0;
				for (TLayoutFld campo : fields) {
					suma += campo.getLayoutFldLnthNum();
				}
				if (tlayout.getDlmtInd()) {
					suma += (fields.size() - 1);// sumarle el delimitador, para obtener el registro exacto
				}
				tlayout.setXpctRecLnthNum(suma);
			}
			// TODO
			// ahora, hay que ver que para el mismo X no haya 2 layouts con el mismo numero
			// de columnas o bien la misma longitud
			// Si hay, no se deja actualizar, y se manda el mensaje de error
			tlayout.setLayoutActInd(Boolean.TRUE);
			tLayoutRepository.save(tlayout);
			return Boolean.TRUE;
		} catch (Exception e) {
			log.error(String.format("Error al actualizar el estatus del Layout por el ID: %1$s", layoutId), e);
			throw new FitravaException(
					String.format(messages.get(CLID, "MSG_ERR_UPDATING_LAYOUT_STATUS_BY_ID"), layoutId, e.getCause()));
		}
	}

	@Override
	@Transactional
	public void deleteLayout(Long id) throws FitravaException {
		log.info("Executing >>> deleteLayout(id: {})", id);
		try {
			tLayoutRepository.deleteById(id);
		} catch (Exception e) {
			log.error(String.format("Error al borrar por el Layout por el ID: %1$s", id), e);
			throw new FitravaException(
					String.format(messages.get(CLID, "MSG_ERR_DELETING_LAYOUT_BY_ID"), id, e.getCause()));
		}

	}

	// Field
	@Override
	public CampoDTO getCampoById(Long id) throws ValidationException, FitravaException {
		log.info("Executing >>> getFieldById(id: {})", id);
		TLayoutFld field = null;
		try {
			Optional<TLayoutFld> optional = tLayoutFldRepository.findById(id);
			if (optional.isPresent()) {
				field = optional.get();
			}
		} catch (Exception e) {
			log.error(String.format("Error al obtener el Campo por el id: %1$s", id), e);
			throw new FitravaException(
					String.format(messages.get(CLID, "MSG_ERR_GETTING_FIELD_BY_ID"), id, e.getCause()));
		}
		if (field == null) {
			throw new ValidationException(String.format(messages.get(CLID, "MSG_CANT_FIND_ANY_FIELD_BY_ID"), id));
		}
		return mapper.map(field, CampoDTO.class);
	}

	@Override
	public List<CampoDTO> getAllCamposByLayoutId(Long layoutId) throws ValidationException, FitravaException {
		log.info("Executing >>> getAllFieldsByLayoutId(layoutId: {})", layoutId);
		List<TLayoutFld> fields = null;
		List<CampoDTO> campoDTOs = null;
		try {
			fields = tLayoutFldRepository.findByLayoutId(layoutId);
		} catch (Exception e) {
			log.error(String.format("Error al obtener los Campos por el id: %1$s", layoutId), e);
			throw new FitravaException(
					String.format(messages.get(CLID, "MSG_ERR_GETTING_FIELDS_BY_LAYOUTID"), layoutId, e.getCause()));
		}
		if (fields == null || fields.isEmpty()) {
			throw new ValidationException(
					String.format(messages.get(CLID, "MSG_CANT_FIND_ANY_FIELD_BY_LAYOUTID_S1"), layoutId));
		}
		campoDTOs = new ArrayList<>();
		for (TLayoutFld l : fields) {
			campoDTOs.add(mapper.map(l, CampoDTO.class));
		}
		return campoDTOs;
	}

	@Override
	@Transactional
	public CampoDTO guardaCampo(CampoDTO campoDTO) throws ValidationException, FitravaException {
		log.info("Executing >>> guardaField(fieldDTO: {})", campoDTO);
		TLayoutFld tField = null;
		try {
			tField = tLayoutFldRepository.saveAndFlush(mapper.map(campoDTO, TLayoutFld.class));
		} catch (Exception e) {
			log.error(String.format("Error al guardar el Campo por el id: %1$s", campoDTO), e);
			throw new FitravaException(
					String.format(messages.get(CLID, "MSG_ERR_SAVING_FIELD"), campoDTO, e.getCause()));
		}
		if (tField == null) {
			throw new ValidationException(messages.get(CLID, "MSG_CANT_FIND_ANY_FIELD"));
		}
		return mapper.map(tField, CampoDTO.class);
	}

	@Override
	@Transactional
	public CampoDTO actualizaCampo(CampoDTO campoDTO) throws FitravaException {
		log.info("Executing >>> actualizaField(fieldDTO: {})", campoDTO);
		TLayoutFld aCambiar = null;
		try {
			aCambiar = tLayoutFldRepository.save(mapper.map(campoDTO, TLayoutFld.class));
		} catch (Exception e) {
			log.error(String.format("Error al actualizar el Campo: %1$s", campoDTO), e);
			throw new FitravaException(
					String.format(messages.get(CLID, "MSG_ERR_UPDATING_FIELD"), aCambiar, e.getCause()));
		}
		return mapper.map(aCambiar, CampoDTO.class);
	}

	@Override
	@Transactional
	public void deleteCampo(Long id) throws FitravaException {
		log.info("Executing >>> deleteField(id: {})", id);
		try {
			tLayoutFldRepository.deleteById(id);
		} catch (Exception e) {
			log.error(String.format("Error al borrar el Campo por el id: %1$s", id), e);
			throw new FitravaException(
					String.format(messages.get(CLID, "MSG_ERR_DELETING_FIELD_BY_ID"), id, e.getCause()));
		}
	}

	@Override
	@Transactional
	public TransformacionCampoDTO guardaTransformacionCampo(TransformacionCampoDTO transformacionCampoDTO)
			throws ValidationException, FitravaException {
		log.info("Executing >>> guardaTransformacionCampo(transformacionCampoDTO: {})", transformacionCampoDTO);
		TFldTform tFldTform = null;
		try {
			tFldTform = tFldTformRepository.saveAndFlush(mapper.map(transformacionCampoDTO, TFldTform.class));
		} catch (Exception e) {
			log.error(String.format("Error al guardar la transformacion: %1$s", transformacionCampoDTO), e);
			throw new FitravaException(String.format(messages.get(CLID, "MSG_ERR_SAVING_TRANSFORMATION"),
					transformacionCampoDTO, e.getCause()));
		}
		if (tFldTform == null) {
			throw new ValidationException(messages.get(CLID, "MSG_CANT_FIND_ANY_TRANSFORMING_TYPE"));
		}
		return mapper.map(tFldTform, TransformacionCampoDTO.class);
	}

	@Override
	public HeaderFooterDTO getHeaderFooterById(Long headerFooterId) throws ValidationException, FitravaException {
		log.info("Executing >>> getHeaderFooterById(headerFooterId: {})", headerFooterId);
		TLayoutHd headerFooter = null;
		try {
			Optional<TLayoutHd> optional = tLayoutHdRepository.findById(headerFooterId);
			if (optional.isPresent()) {
				headerFooter = optional.get();
			}
		} catch (Exception e) {
			log.error(String.format("Error al obtener el HeaderFooter por el headerFooterId: %1$s", headerFooterId), e);
			throw new FitravaException(String.format(messages.get(CLID, "MSG_ERR_GETTING_HEADER_BY_HEADERID"),
					headerFooterId, e.getCause()));
		}
		if (headerFooter == null) {
			throw new ValidationException(
					String.format(messages.get(CLID, "MSG_CANT_FIND_ANY_HEADER_BY_HEADERID"), headerFooterId));
		}
		return mapper.map(headerFooter, HeaderFooterDTO.class);
	}

	@Override
	public List<HeaderFooterDTO> getAllHeaderFootersByLayoutId(Long layoutId)
			throws ValidationException, FitravaException {
		log.info("Executing >>> getAllHeaderFootersByLayoutId(layoutId: {})", layoutId);
		List<TLayoutHd> headerFooters = null;
		List<HeaderFooterDTO> headerFooterDTOs = null;
		try {
			headerFooters = tLayoutHdRepository.findByLayoutId(layoutId);
		} catch (Exception e) {
			log.error(String.format("Error al obtener los HeaderFooters por el layoutId: %1$s", layoutId), e);
			throw new FitravaException(
					String.format(messages.get(CLID, "MSG_ERR_GETTING_HEADER_BY_LAYOUT_ID"), layoutId, e.getCause()));
		}
		if (headerFooters == null || headerFooters.isEmpty()) {
			throw new ValidationException(
					String.format(messages.get(CLID, "MSG_CANT_FIND_ANY_HEADER_BY_LAYOUTID"), layoutId));
		}
		headerFooterDTOs = new ArrayList<>();
		for (TLayoutHd l : headerFooters) {
			headerFooterDTOs.add(mapper.map(l, HeaderFooterDTO.class));
		}
		return headerFooterDTOs;
	}

	@Override
	@Transactional
	public HeaderFooterDTO guardaHeaderFooter(HeaderFooterDTO headerFooter)
			throws ValidationException, FitravaException {
		log.info("Executing >>> guardaHeaderFooter(headerFooter: {})", headerFooter);
		TLayoutHd tLayoutHd = null;
		List<HeaderFooterDetalleDTO> listHeaderDet = null;
		List<TLayoutHdDtl> listTLayoutHdDtl = null;
		TLayoutHdDtl tLayoutHdDtl = null;
		Long layoutHdId = null;
		try {
			listHeaderDet = headerFooter.getListTLayoutHdDtl();
			headerFooter.setListTLayoutHdDtl(null);
			tLayoutHd = mapper.map(headerFooter, TLayoutHd.class);
			tLayoutHd = tLayoutHdRepository.saveAndFlush(tLayoutHd);
			if (tLayoutHd != null && tLayoutHd.getLayoutHdId() != null && listHeaderDet != null
					&& !listHeaderDet.isEmpty()) {
				layoutHdId = tLayoutHd.getLayoutHdId();
				listTLayoutHdDtl = new ArrayList<>();
				for (HeaderFooterDetalleDTO tl : listHeaderDet) {
					tLayoutHdDtl = mapper.map(tl, TLayoutHdDtl.class);
					tLayoutHdDtl.setLayoutHdId(layoutHdId);
					tLayoutHdDtl = tLayoutHdDtlRepository.saveAndFlush(tLayoutHdDtl);
					listTLayoutHdDtl.add(tLayoutHdDtl);
				}
				tLayoutHd.setListTLayoutHdDtl(listTLayoutHdDtl);
			}
		} catch (Exception e) {
			log.error(String.format("Error al guardar el LayoutHeader: %1$s", headerFooter), e);
			throw new FitravaException(
					String.format(messages.get(CLID, "MSG_ERR_SAVING_LAYOUT_SI_S2"), headerFooter, e.getCause()));
		}
		return mapper.map(tLayoutHd, HeaderFooterDTO.class);
	}

	@Override
	@Transactional
	public HeaderFooterDTO actualizaHeaderFooter(HeaderFooterDTO headerFooter)
			throws ValidationException, FitravaException {
		log.info("Executing >>> actualizaHeaderFooter(headerFooterDTO: {})", headerFooter);
		TLayoutHd tLayoutHd = null;
		List<HeaderFooterDetalleDTO> listHeaderDet = null;
		List<TLayoutHdDtl> listTLayoutHdDtl = null;
		TLayoutHdDtl tLayoutHdDtl = null;
		Long layoutHdId = null;
		try {
			listHeaderDet = headerFooter.getListTLayoutHdDtl();
			headerFooter.setListTLayoutHdDtl(null);
			layoutHdId = headerFooter.getLayoutHdId();
			tLayoutHd = tLayoutHdRepository.save(mapper.map(headerFooter, TLayoutHd.class));
			if (listHeaderDet != null && !listHeaderDet.isEmpty()) {
				listTLayoutHdDtl = new ArrayList<>();
				for (HeaderFooterDetalleDTO tl : listHeaderDet) {
					tl.setLayoutHdId(layoutHdId);
					tLayoutHdDtl = tLayoutHdDtlRepository.saveAndFlush(mapper.map(tl, TLayoutHdDtl.class));
					listTLayoutHdDtl.add(tLayoutHdDtl);
				}
				tLayoutHd.setListTLayoutHdDtl(listTLayoutHdDtl);
			}
			return mapper.map(tLayoutHd, HeaderFooterDTO.class);
		} catch (Exception e) {
			log.error(String.format("Error al actualizar el HeaderFooter: %1$s", headerFooter), e);
			throw new FitravaException(
					String.format(messages.get(CLID, "MSG_ERR_UPDATING_HEADER"), headerFooter, e.getCause()));
		}
	}

	@Override
	@Transactional
	public void deleteHeaderFooter(Long layoutHdId) throws FitravaException {
		log.info("Executing >>> deleteHeaderFooter(layoutHdId: {})", layoutHdId);
		try {
			tLayoutHdDtlRepository.deleteByLayoutHdId(layoutHdId);
			tLayoutHdRepository.deleteById(layoutHdId);
		} catch (Exception e) {
			log.error(String.format("Error al borrar el LayoutHeader por el layoutHdId: %1$s", layoutHdId), e);
			throw new FitravaException(String.format(messages.get(CLID, "MSG_ERR_DELETING_LAYOUT_HEADER_BY_LAYOUTID"),
					layoutHdId, e.getCause()));
		}
	}

	@Override
	@Transactional
	public void deleteHeaderFooterDtl(Long layoutHdId) throws FitravaException {
		log.info("Executing >>> deleteHeaderFooterDtl(layoutHdId: {})", layoutHdId);
		try {
			tLayoutHdDtlRepository.deleteByLayoutHdId(layoutHdId);
		} catch (Exception e) {
			log.error(String.format("Error al borrar el LayoutHeader por el layoutHdId: %1$s", layoutHdId), e);
			throw new FitravaException(String.format(
					messages.get(CLID, "MSG_ERR_DELETING_LAYOU_HEADER_BY_LAYOUT_ID_SI_S2"), layoutHdId, e.getCause()));
		}
	}

	private LayoutDTO convert(TLayout layout) throws FitravaException {
		List<TLayoutFld> listTLayoutFld = null;
		List<TLayoutHd> listTLayoutHd = null;

		LayoutDTO layoutDTO = null;
		List<CampoDTO> campos = null;
		List<HeaderFooterDTO> headers = null;
		try {
			layoutDTO = mapper.map(layout, LayoutDTO.class);
			listTLayoutFld = tLayoutFldRepository.findByLayoutId(layout.getLayoutId());
			listTLayoutHd = tLayoutHdRepository.findByLayoutId(layout.getLayoutId());
			if (listTLayoutFld != null && !listTLayoutFld.isEmpty()) {
				campos = new ArrayList<>();
				for (TLayoutFld t : listTLayoutFld) {
					campos.add(mapper.map(t, CampoDTO.class));
				}
				layoutDTO.setListTLayoutFld(campos);
			}
			if (listTLayoutHd != null && !listTLayoutHd.isEmpty()) {
				headers = new ArrayList<>();
				for (TLayoutHd t : listTLayoutHd) {
					headers.add(mapper.map(t, HeaderFooterDTO.class));
				}
				layoutDTO.setListTLayoutHd(headers);
			}
			return layoutDTO;
		} catch (Exception e) {
			log.error(String.format("Error al obtener el obtener los campos y headers del Layout por el layoutId: %1$s",
					layout.getLayoutId()), e);
			throw new FitravaException(String.format(messages.get(CLID, "MSG_ERR_GETTING_FIELDS_AND_HEADERS"),
					layout.getLayoutId(), e.getCause()));
		}
	}

	@Override
	public List<TransformacionCampoDTO> getTransformacionCampo(Long layoutFldId)
			throws ValidationException, FitravaException {
		log.info("En el getTransformacionCampo(layoutFldId: {})", layoutFldId);
		List<TFldTform> fieldTransforms = null;
		List<TransformacionCampoDTO> fieldTransformDTOs = null;
		try {
			fieldTransforms = tFldTformRepository.findByLayoutFldId(layoutFldId);
		} catch (Exception e) {
			log.error(String.format("Error al obtener los FieldTransforms por el layoutId: %1$s", layoutFldId), e);
			throw new FitravaException(
					String.format("Error al obtener los FieldTransforms por el layoutId: %1$s, Error: %2$s",
							layoutFldId, e.getCause()));
		}
		if (fieldTransforms == null || fieldTransforms.isEmpty()) {
			throw new ValidationException(
					String.format("No se encuentra ningun FieldTransforms con el layoutId: %1$s", layoutFldId));
		}
		fieldTransformDTOs = new ArrayList<>();
		for (TFldTform l : fieldTransforms) {
			fieldTransformDTOs.add(mapper.map(l, TransformacionCampoDTO.class));
		}
		return fieldTransformDTOs;
	}

	@Override
	public void deleteTransform(Long fldTformId) throws FitravaException {
		log.info("En el deleteTransform(fldTformId: {})", fldTformId);
		try {
			tFldTformRepository.deleteById(fldTformId);
		} catch (Exception e) {
			log.error(String.format("Error al borrar la tranformacion por el fldTformId: %1$s", fldTformId), e);
			throw new FitravaException(String.format(
					"error al borrar la tranformacion por el fldTformId: %1$s, Error: %2$s", fldTformId, e.getCause()));
		}
	}

	@Override
	@Transactional
	public TransformacionCampoDTO actualizaTransformacionCampo(TransformacionCampoDTO transformacionCampoDTO)
			throws ValidationException, FitravaException {
		log.info("En el actualizaTransformacionCampo(transformacionCampoDTO: {})", transformacionCampoDTO);
		TFldTform tFldTform = null;
		try {
			tFldTformParmRepository.deleteByFldTformId(transformacionCampoDTO.getFldTformId());// Borrando los
																								// parametros actuales
			tFldTform = tFldTformRepository.saveAndFlush(mapper.map(transformacionCampoDTO, TFldTform.class));
		} catch (Exception e) {
			log.error(String.format("Error al actualizar la transformacion: %1$s", transformacionCampoDTO), e);
			throw new FitravaException(String.format("Error al actualizar la transformacion: %1$s, Error: %2$s",
					transformacionCampoDTO, e.getCause()));
		}
		if (tFldTform == null) {
			throw new ValidationException("No se encuentro ningun TransformacionCampo");
		}
		return mapper.map(tFldTform, TransformacionCampoDTO.class);
	}

	public TLayout getEntityLayoutById(Long layoutId) throws ValidationException, FitravaException {
		log.info("Executing >>> getLayoutById(layoutId: {})", layoutId);
		TLayout layout = null;
		try {
			layout = tLayoutRepository.findById(layoutId);
		} catch (Exception e) {
			log.error(String.format("Error al obtener el Layout por el id: %1$s", layoutId), e);
			throw new FitravaException(
					String.format(messages.get(CLID, "MSG_ERR_GETTING_LAYOUT_BY_ID"), layoutId, e.getCause()));
		}
		if (layout == null) {
			throw new ValidationException(
					String.format(messages.get(CLID, "MSG_CANT_FIND_ANY_LAYOUT_BY_GIVEN_ID"), layoutId));
		}
		return layout;
	}

	@Override
	public List<TLayout> getLayoutsByIds(List<Long> lstLayoutId) throws ValidationException, FitravaException {
		List<TLayout> lstLayouts = new ArrayList<>();
		TLayout tLayout = null;

		for (Long layoutId : lstLayoutId) {
			try {
				tLayout = getEntityLayoutById(layoutId);
				lstLayouts.add(tLayout);
			} catch (Exception e) {
				// Conteniendo excepcion
			}
		}
		return lstLayouts;
	}

	@Override
	public List<LayoutDTO> getAllLayoutsIntoFlowsByEai(String eai, String ext)
			throws ValidationException, FitravaException {
		log.info("Executing >>> getAllLayoutsIntoFlowsByEai(eai: {}, ext: {})", eai, ext);
		List<TLayout> layouts = null;
		List<LayoutDTO> layoutDTOs = null;
		try {
			layouts = tLayoutRepository.findAllIntoFlowsByEai(eai, "%" + ext + "%");
		} catch (Exception e) {
			log.error(String.format("Error al obtener los Layout por el eai: %1$s", eai), e);
			throw new FitravaException(
					String.format(messages.get(CLID, "MSG_ERR_GETTING_LAYOUT_BY_EAI"), eai, e.getCause()));
		}
		if (layouts == null || layouts.isEmpty()) {
			throw new ValidationException(String.format(messages.get(CLID, "MSG_ERR_GETTING_AYOUT_BY_EAI_S1"), eai));
		}
		layoutDTOs = new ArrayList<>();
		for (TLayout l : layouts) {
			layoutDTOs.add(mapper.map(l, LayoutDTO.class));
		}
		return layoutDTOs;
	}

	@Override
	public List<LayoutExcelDTO> guardaLstLayoutExcel(List<LayoutExcelDTO> lstLayoutExcelDTO)
			throws ValidationException, FitravaException {
		log.info("Executing >>> guardaLstLayoutExcel(lstLayoutExcelDTO: {})", lstLayoutExcelDTO);
		List<LayoutExcelDTO> lstLayoutExcelDTOResponse = new ArrayList<>();
		TLayoutXcel tLayoutXcel;
		for (LayoutExcelDTO layoutExcelDTO : lstLayoutExcelDTO) {
			try {
				tLayoutXcel = tLayoutXcelRepository.saveAndFlush(mapper.map(layoutExcelDTO, TLayoutXcel.class));
			} catch (Exception e) {
				log.error(String.format("Error al guardar el LayoutExcel : %1$s", layoutExcelDTO), e);
				throw new FitravaException(
						String.format(messages.get(CLID, "MSG_ERR_SAVING_LAYOUT_EXCEL"), layoutExcelDTO, e.getCause()));
			}
			if (tLayoutXcel == null) {
				throw new ValidationException(messages.get(CLID, "MSG_CANT_FIND_ANY_LAYOUT_EXCEL_TYPE"));
			}
			lstLayoutExcelDTOResponse.add(mapper.map(tLayoutXcel, LayoutExcelDTO.class));
		}

		return lstLayoutExcelDTOResponse;
	}

	@Override
	public void deleteLayoutExcel(Long layoutId, String xcelSheetNm) throws FitravaException {
		log.info("En el deleteLayoutExcel(layoutId: {}, layoutId: {})", layoutId, xcelSheetNm);
		TLayoutXcelId tLayoutXcelId = null;
		try {
			tLayoutXcelId = new TLayoutXcelId(layoutId, xcelSheetNm);
			tLayoutXcelRepository.deleteById(tLayoutXcelId);
		} catch (Exception e) {
			log.error(String.format("Error al borrar el LayoutExcel por el layoutId: %1$s y xcelSheetNm: %2$s",
					layoutId, xcelSheetNm), e);
			throw new FitravaException(
					String.format("error al borrar el LayoutExcel por el layoutId: %1$s y xcelSheetNm: %2$s,  %3$s ",
							layoutId, xcelSheetNm, e.getCause()));
		}

	}

	@Override
	public List<LayoutExcelDTO> actualizaLstLayoutExcel(Long layoutId, List<LayoutExcelDTO> lstLayoutExcelDTO)
			throws ValidationException, FitravaException {
		log.info("Executing >>> actualizaLstLayoutExcel(layoutId: {}, lstLayoutExcelDTO: {})", layoutId,
				lstLayoutExcelDTO);
		List<LayoutExcelDTO> lstLayoutExcelDTOResponse = new ArrayList<>();
		TLayoutXcel tLayoutXcel;

		tLayoutXcelRepository.deleteByLayoutId(layoutId);

		for (LayoutExcelDTO layoutExcelDTO : lstLayoutExcelDTO) {
			try {
				tLayoutXcel = tLayoutXcelRepository.saveAndFlush(mapper.map(layoutExcelDTO, TLayoutXcel.class));
			} catch (Exception e) {
				log.error(String.format("Error al actualizar el LayoutExcel : %1$s", layoutExcelDTO), e);
				throw new FitravaException(String.format(messages.get(CLID, "MSG_ERR_UPDATING_LAYOUT_EXCEL"),
						layoutExcelDTO, e.getCause()));
			}
			if (tLayoutXcel == null) {
				throw new ValidationException(messages.get(CLID, "MSG_CANT_FIND_ANY_LAYOUT_EXCEL_TYPE"));
			}
			lstLayoutExcelDTOResponse.add(mapper.map(tLayoutXcel, LayoutExcelDTO.class));
		}

		return lstLayoutExcelDTOResponse;
	}

	@Override
	public List<CampoDTO> getAllCamposWithoutSpecialOperationsByLayoutId(Long layoutId, List<Long> lstExcludeOperations)
			throws ValidationException, FitravaException {
		log.info("Executing >>> getAllCamposWithoutSpecialOperationsByLayoutId(layoutId: {}, lstExcludeOperations: {})",
				layoutId, lstExcludeOperations);
		List<TLayoutFld> fields = null;
		List<CampoDTO> campoDTOs = null;
		try {
			fields = tLayoutFldRepository.findAllWithoutSpecialOperations(layoutId, lstExcludeOperations);
		} catch (Exception e) {
			log.error(String.format("Error al obtener los Campos por el id: %1$s", layoutId), e);
			throw new FitravaException(
					String.format(messages.get(CLID, "MSG_ERR_GETTING_FIELDS_BY_LAYOUTID"), layoutId, e.getCause()));
		}
		if (fields == null || fields.isEmpty()) {
			throw new ValidationException(
					String.format(messages.get(CLID, "MSG_CANT_FIND_ANY_FIELD_BY_LAYOUTID_S1"), layoutId));
		}
		campoDTOs = new ArrayList<>();
		for (TLayoutFld l : fields) {
			campoDTOs.add(mapper.map(l, CampoDTO.class));
		}
		return campoDTOs;
	}

	@Override
	public List<CharactersSkipDTO> guardaLstCharactersToSkip(List<CharactersSkipDTO> lstCharactersToSkip)
			throws ValidationException, FitravaException {
		log.info("Executing >>> guardaLstCharactersToSkip(lstCharactersToSkip: {})", lstCharactersToSkip);
		List<CharactersSkipDTO> lstSkipCharsDTOResponse = new ArrayList<>();
		TSkpChar tSkpChar;
		for (CharactersSkipDTO charactersSkipDTO : lstCharactersToSkip) {
			try {
				tSkpChar = tSkpCharRepository.saveAndFlush(mapper.map(charactersSkipDTO, TSkpChar.class));
			} catch (Exception e) {
				log.error(String.format("Error al guardar el CharactersSkipDTO : %1$s", charactersSkipDTO), e);
				throw new FitravaException(
						String.format(messages.get(CLID, "MSG_ERR_SAVING_SKIP_CHAR"), charactersSkipDTO, e.getCause()));
			}
			if (tSkpChar == null) {
				throw new ValidationException(messages.get(CLID, "MSG_CANT_FIND_ANY_SKIP_CHAR_TYPE"));
			}
			lstSkipCharsDTOResponse.add(mapper.map(tSkpChar, CharactersSkipDTO.class));
		}

		return lstSkipCharsDTOResponse;
	}

	@Override
	public List<CharactersSkipDTO> actualizaLstCharactersToSkip(Long layoutId,
			List<CharactersSkipDTO> lstCharactersToSkip) throws ValidationException, FitravaException {
		log.info("Executing >>> actualizaLstCharactersToSkip(layoutId:{} ,stCharactersToSkip: {})", layoutId,
				lstCharactersToSkip);
		List<CharactersSkipDTO> lstSkipCharsDTOResponse = new ArrayList<>();
		TSkpChar tSkpChar;

		// eliminando caracteres actuales
		tSkpCharRepository.deleteByLayoutId(layoutId);

		for (CharactersSkipDTO charactersSkipDTO : lstCharactersToSkip) {
			try {
				tSkpChar = tSkpCharRepository.saveAndFlush(mapper.map(charactersSkipDTO, TSkpChar.class));
			} catch (Exception e) {
				log.error(String.format("Error al guardar el CharactersSkipDTO : %1$s", charactersSkipDTO), e);
				throw new FitravaException(
						String.format(messages.get(CLID, "MSG_ERR_SAVING_SKIP_CHAR"), charactersSkipDTO, e.getCause()));
			}
			if (tSkpChar == null) {
				throw new ValidationException(messages.get(CLID, "MSG_CANT_FIND_ANY_SKIP_CHAR_TYPE"));
			}
			lstSkipCharsDTOResponse.add(mapper.map(tSkpChar, CharactersSkipDTO.class));
		}

		return lstSkipCharsDTOResponse;
	}

	@Override
	public List<TransformacionCampoDTO> sobreescribeTransformacionCampo(Long layoutFldId,
			List<TransformacionCampoDTO> lstTransformacionCampoDTO) throws ValidationException, FitravaException {
		log.info("Executing >>> sobreescribeTransformacionCampo(lstTransformacionCampoDTO: {})",
				lstTransformacionCampoDTO);

		TFldTform tFldTform = null;
		List<ParametroTransformacionParametroDTO> listTFldTformParm = null;
		List<TransformacionCampoDTO> lstTransformacionCampoDTOResponse = new ArrayList<>();

		// eliminando tranformaciones actuales
		tFldTformRepository.deleteByLayoutFldId(layoutFldId);

		for (TransformacionCampoDTO transformacionCampoDTO : lstTransformacionCampoDTO) {
			try {
				listTFldTformParm = transformacionCampoDTO.getListTFldTformParm();
				transformacionCampoDTO.setListTFldTformParm(null);
				tFldTform = tFldTformRepository.saveAndFlush(mapper.map(transformacionCampoDTO, TFldTform.class));
				Long id = tFldTform.getFldTformId();
				listTFldTformParm.parallelStream().forEach(e -> e.setFldTformId(id));
				transformacionCampoDTO.setListTFldTformParm(listTFldTformParm);
				transformacionCampoDTO.setFldTformId(id);
				tFldTform = tFldTformRepository.saveAndFlush(mapper.map(transformacionCampoDTO, TFldTform.class));

				lstTransformacionCampoDTOResponse.add(mapper.map(tFldTform, TransformacionCampoDTO.class));

			} catch (Exception e) {
				log.error(String.format("Error al guardar la transformacion: %1$s", transformacionCampoDTO), e);
				throw new FitravaException(String.format(messages.get(CLID, "MSG_ERR_SAVING_TRANSFORMATION"),
						transformacionCampoDTO, e.getCause()));
			}
			if (tFldTform == null) {
				throw new ValidationException(messages.get(CLID, "MSG_CANT_FIND_ANY_TRANSFORMING_TYPE"));
			}

		}

		return lstTransformacionCampoDTOResponse;
	}

	@Override
	public List<CharactersSkipDTO> getLstCharactersToSkip(Long layoutId) throws ValidationException, FitravaException {
		log.info("Executing >>> getLstCharactersToSkip(layoutId: {})",
				layoutId);
		List<TSkpChar> chars = null;
		List<CharactersSkipDTO> caracteres = null;
		try {
			chars = tSkpCharRepository.findByLayoutId(layoutId);
		} catch (Exception e) {
			log.error(String.format("Error al obtener los Caracteres por el idLayout: %1$s", layoutId), e);
			throw new FitravaException(
					String.format(messages.get(CLID, "MSG_ERR_GETTING_CHARS_BY_LAYOUTID"), layoutId, e.getCause()));
		}
		
		if (chars == null || chars.isEmpty()) {
			throw new ValidationException(
					String.format(messages.get(CLID, "MSG_CANT_FIND_ANY_CHARS_BY_LAYOUTID_S1"), layoutId));
		}
		caracteres = new ArrayList<>();
		for (TSkpChar l : chars) {
			caracteres.add(mapper.map(l, CharactersSkipDTO.class));
		}
		return caracteres;
	}
}
