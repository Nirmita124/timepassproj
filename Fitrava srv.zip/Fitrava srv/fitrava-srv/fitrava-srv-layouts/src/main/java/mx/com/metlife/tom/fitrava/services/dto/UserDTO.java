package mx.com.metlife.tom.fitrava.services.dto;

import lombok.Data;

@Data
public class UserDTO  implements java.io.Serializable{

	private static final long serialVersionUID = 7050492616033000367L;

	private String userCve = null;
	
	private String userIdentifier = null;
	
	private String userNm = null;
	
	private String userApePat = null;

	private String userApeMat = null;

	private String userEmail = null;

	private String userTel = null;

	private String userTelExt = null;

	private Integer userActInd = null;
	
	private Integer roleId = null;

//	private RoleDTO tRole;
}
