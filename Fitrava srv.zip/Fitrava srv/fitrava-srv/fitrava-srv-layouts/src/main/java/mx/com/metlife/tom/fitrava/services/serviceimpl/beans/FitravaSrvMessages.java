package mx.com.metlife.tom.fitrava.services.serviceimpl.beans;

import org.springframework.context.support.MessageSourceAccessor;
import org.springframework.context.support.ReloadableResourceBundleMessageSource;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;

/**
 * Class for accessing message resource-file entries
 * @author abritohe (adapted)
 *
 */
@Component
public class FitravaSrvMessages {

    private MessageSourceAccessor messageSourceAccessor;

    /**
     * Initializes component. 
     * PostConstruct ensures all dependencies are already injected, 
     * therefore an instance of [MessageSource] has been already created.
     */
    @PostConstruct
    private void init() {
    	/*
    	 * The Configuration MVC-Class [MvcConfig, mx.com.metlife.tom.fitrava.services.config.MvcConfig;]
    	 * defines: localeResolver and LocaleChangeInterceptor
    	 * Note: Each message-resource-file must be specified through the method [source].setBasenames  
    	 */
    	ReloadableResourceBundleMessageSource source = new ReloadableResourceBundleMessageSource();		
    	source.setBasenames("classpath:messages", "classpath:messages_es");
    	source.setDefaultEncoding("UTF-8");		
    	messageSourceAccessor = new MessageSourceAccessor(source);
    }
    
	/**
	 * Gets an entry in the message resource-file by given the key full-name
	 * @param key parameter full-name
	 * @return string parameter
	 */
    public String get(String key) {
        return messageSourceAccessor.getMessage(key);
    }
    
    /***
     * Gets an entry in the message resource-file by creating the key: [moduleName + "." + key]
     * @param moduleName class name
     * @param key parameter name
     * @return string parameter
     */
    public String get(String moduleName, String key) {
        return messageSourceAccessor.getMessage(moduleName + "." + key);
    }
}