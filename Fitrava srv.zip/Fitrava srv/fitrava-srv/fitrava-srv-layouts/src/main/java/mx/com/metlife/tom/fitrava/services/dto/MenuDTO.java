package mx.com.metlife.tom.fitrava.services.dto;

import java.util.List;

import lombok.Data;

@Data
public class MenuDTO implements java.io.Serializable {

	private static final long serialVersionUID = 7050492616033000367L;
	
	private Integer menuId = null;

	private String menuNm = null;

	private String menuDscr = null;

	private String menuLnkNm = null;

	private String menuIconNm = null;

	private String menuToolTipDscr = null;

	private Integer prntMenuId = null;
	
	private List<MenuDTO> tMenus;

}
