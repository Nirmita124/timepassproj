package mx.com.metlife.tom.fitrava.services.service;

import java.util.List;

import mx.com.metlife.tom.fitrava.services.dto.AplicacionDTO;
import mx.com.metlife.tom.fitrava.services.dto.EstatusProcesoDTO;
import mx.com.metlife.tom.fitrava.services.dto.MenuDTO;
import mx.com.metlife.tom.fitrava.services.dto.OperacionCampoDTO;
import mx.com.metlife.tom.fitrava.services.dto.OperacionDTO;
import mx.com.metlife.tom.fitrava.services.dto.RoleDTO;
import mx.com.metlife.tom.fitrava.services.dto.TipoDatoDTO;
import mx.com.metlife.tom.fitrava.services.error.FitravaException;
import mx.com.metlife.tom.fitrava.services.error.ValidationException;

public interface AdminCatalogosService {

	AplicacionDTO getAplicacionById(String id) throws ValidationException, FitravaException;
	List<AplicacionDTO> getAllAplicaciones() throws ValidationException, FitravaException;	
	AplicacionDTO guardaAplicacion(AplicacionDTO dto) throws ValidationException, FitravaException;
	AplicacionDTO actualizaAplicacion(AplicacionDTO dto) throws ValidationException, FitravaException;	
	void deleteAplicacion(String id) throws ValidationException, FitravaException;
	
	OperacionCampoDTO getOperacionCampoById(Long id) throws ValidationException, FitravaException;
	List<OperacionCampoDTO> getAllOperacionCampos() throws ValidationException, FitravaException;	
	OperacionCampoDTO guardaOperacionCampo(OperacionCampoDTO dto) throws ValidationException, FitravaException;
	OperacionCampoDTO actualizaOperacionCampo(OperacionCampoDTO dto) throws ValidationException, FitravaException;	
	void deleteOperacionCampo(Long id) throws ValidationException, FitravaException;
	
	TipoDatoDTO getTipoDatoById(Integer id) throws ValidationException, FitravaException;
	List<TipoDatoDTO> getAllTipoDatos() throws ValidationException, FitravaException;	
	TipoDatoDTO guardaTipoDato(TipoDatoDTO dto) throws ValidationException, FitravaException;
	TipoDatoDTO actualizaTipoDato(TipoDatoDTO dto) throws ValidationException, FitravaException;	
	void deleteTipoDato(Integer id) throws ValidationException, FitravaException;
	
	OperacionDTO getOperacionById(Integer id) throws ValidationException, FitravaException;
	List<OperacionDTO> getAllOperaciones() throws ValidationException, FitravaException;	
	OperacionDTO guardaOperacion(OperacionDTO dto) throws ValidationException, FitravaException;
	OperacionDTO actualizaOperacion(OperacionDTO dto) throws ValidationException, FitravaException;	
	void deleteOperacion(Integer id) throws ValidationException, FitravaException;
	
	List<EstatusProcesoDTO> getAllProcesosEstatus() throws ValidationException, FitravaException;	
	List<RoleDTO> getAllRoles() throws ValidationException, FitravaException;	
	List<MenuDTO> getAllMenus() throws ValidationException, FitravaException;
	RoleDTO getRoleById(Integer id) throws ValidationException, FitravaException;
}
