package mx.com.metlife.tom.fitrava.services.dto;

import java.util.Date;
import java.util.List;

import lombok.Data;

@SuppressWarnings("serial")
@Data
public class FlujoDTO implements java.io.Serializable {

	private Long flowId = null;
	private String eaiCd = null;
	private String flowNm = null;
	private String flowDscr = null;
	private Long dfltEntrncLayoutId = null;
	private Long outputLayoutId = null;
	private String crtUsrId = null;
	private String allwExtTxt = null;
	private String outputFilePtrnNm = null;
	private Date crtTs = null;
	private Date updtTs = null;
	private String lstModUsrId = null;
	private Integer flowActInd = null; 
	
	private List<FlujoArchivoDTO> listTFlowExtFile;
	private List<LayoutDTO> listTLayout;

}
