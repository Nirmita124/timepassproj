package mx.com.metlife.tom.fitrava.services.web.controller;

import static mx.com.metlife.tom.fitrava.services.utility.UtilCommon.getArrayToString;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import mx.com.metlife.tom.fitrava.services.dto.DownloadCatalogDTO;
import mx.com.metlife.tom.fitrava.services.dto.RutaArchivoCargaDTO;
import mx.com.metlife.tom.fitrava.services.dto.UploadFileDTO;
import mx.com.metlife.tom.fitrava.services.error.FitravaException;
import mx.com.metlife.tom.fitrava.services.error.ValidationException;
import mx.com.metlife.tom.fitrava.services.service.ProcesoService;
import mx.com.metlife.tom.fitrava.services.serviceimpl.SFTPSrevice;
import mx.com.metlife.tom.fitrava.services.serviceimpl.beans.FitravaSrvMessages;
import mx.com.metlife.tom.fitrava.services.utility.Util;

@RestController
@RequestMapping(value = "/uploadfilesrv")
public class UploadFileFitravaController extends FitravaController {

	private static final String CLID = UploadFileFitravaController.class.getSimpleName();
	private static Logger log = LoggerFactory.getLogger(UploadFileFitravaController.class);

	@Autowired
	private ProcesoService procesoService;
	@Autowired
	private FitravaSrvMessages messages;	
	@Autowired
	private SFTPSrevice sFTPUtil;
	
	@CrossOrigin
	@PostMapping("/v1/saveFiles")
	public @ResponseBody ResponseEntity<Boolean> postUploadFile (@RequestPart(name ="JSON", required = false ) UploadFileDTO uploadFileDTO, @RequestPart("file") MultipartFile...files) 
		throws ValidationException, FitravaException 
	{
		log.info("Executing >>> postUploadFile(uploadFileDTO: {}, files: {})", uploadFileDTO, getArrayToString(files));
		
		if (uploadFileDTO == null) {
			throw new ValidationException(messages.get(CLID, "MSG_ERR_UPLOAD_FILE_DTO_ISNT_VALID"));
		}
		if (files == null || files.length == 0) {
			throw new ValidationException(messages.get(CLID, "MSG_ERR_REQUIRED_FILES_TO_DOWNLOAD"));
		}
		procesoService.guardaArchivo(uploadFileDTO, files);
		return new ResponseEntity<>(Boolean.TRUE, HttpStatus.OK);
	}
	
	@CrossOrigin
	@GetMapping("/v1/processFiles")
	public @ResponseBody ResponseEntity<Boolean> getProcessFile (@RequestParam("dcn") String dcn) 
		throws ValidationException, FitravaException 
	{
		log.info("Executing >>> postProcessFile(dcn: {})", dcn);
		
		if (dcn == null) {
			throw new ValidationException(messages.get(CLID, "MSG_ERR_DCN_ISNT_VALID"));
		}
		
		procesoService.procesaArchivo(dcn);
		return new ResponseEntity<>(Boolean.TRUE, HttpStatus.OK);
	}
	
	
	/**
	 * ONLY FOR TEST
	 * @return
	 * @throws ValidationException
	 * @throws FitravaException
	 */
	@CrossOrigin
	@PostMapping("/v1/pingSFTP")
	public @ResponseBody ResponseEntity<Boolean> pingSFTP () 
		throws ValidationException, FitravaException 
	{
		log.info("Executing >>> pingSFTP()");
		
		sFTPUtil.testConnection();		
		return new ResponseEntity<>(Boolean.TRUE, HttpStatus.OK);
	}
	
	
	@CrossOrigin
	@PostMapping("/v1/downloadCatalogsLaunch")
	public @ResponseBody ResponseEntity<Boolean> downloadCatalogsLaunch (@RequestBody DownloadCatalogDTO catalog) 
		throws FitravaException 
	{
		log.info("Executing >>> downloadCatalogsLaunch(catalog: {})", catalog);
		
		sFTPUtil.download(catalog);	
		return new ResponseEntity<>(Boolean.TRUE, HttpStatus.OK);
	}
	
	
	/**
	 * ONLY FOR TEST
	 * @param path
	 * @return
	 * @throws ValidationException
	 * @throws FitravaException
	 *
	 */
	@CrossOrigin
	@GetMapping("/v1/lsDirecotrySFTP")
	public @ResponseBody ResponseEntity<String> lsDirecotrySFTP (@RequestParam("path") String path, @RequestParam("domain") String domain) 
		throws FitravaException 
	{
		log.info("Executing >>> lsDirecotrySFTP(path: {})", path);
		
		String fileNames=sFTPUtil.viewSFTPDirectory(path, domain);		
		return new ResponseEntity<>(fileNames, HttpStatus.OK);
	}
	
	
    /**
     * ONLY FOR TEST
     * @param fileName
     * @return
     * @throws FitravaException
     */
	@CrossOrigin
	@PostMapping("/v1/uploadFile")
	public @ResponseBody ResponseEntity<Boolean> uploadFileSFTP (@RequestParam("dcn") String dcn) throws FitravaException {
		log.info("Executing >>> uploadFileSFTP(dcn: {})", dcn);
		
		sFTPUtil.upload(dcn);
		return new ResponseEntity<>(Boolean.TRUE, HttpStatus.OK);
	}
	
	@GetMapping("/v1/download")
	public ResponseEntity<Resource> downloadErrorData(@RequestParam("dcn") String dcn, @RequestParam("fileName") String fileName) throws Exception {
        File zip = procesoService.downloadFiles(dcn, fileName);

        HttpHeaders headers = new HttpHeaders();
        headers.add("Cache-Control", "no-cache, no-store, must-revalidate");
        headers.add("Pragma", "no-cache");
        headers.add("Expires", "0");
        headers.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename="+dcn+".zip");
        
        Path path = Paths.get(zip.getAbsolutePath());
        ByteArrayResource resource = new ByteArrayResource(Files.readAllBytes(path));
        
        zip.deleteOnExit();

        return ResponseEntity.ok()
                .headers(headers)
                .contentLength(zip.length())
                .contentType(MediaType.parseMediaType("application/octet-stream"))
                .body(resource);
	}
	
	//New services
	
	@CrossOrigin
	@PostMapping("/v1/saveLargeFile")
	public @ResponseBody ResponseEntity<RutaArchivoCargaDTO> postUploadFile
		(@RequestParam("file") MultipartFile file, @RequestParam("isEnd") Boolean isEnd, 
				@RequestParam("name") String name, @RequestParam("key")  String key) 
				throws ValidationException, FitravaException  
	{
		
		if (file == null || file.getSize() == 0 || file.getOriginalFilename() == null) {
			throw new ValidationException("El archivo es invalido");
		}
		File archivo = null;
		String path = null;
		try {
			path = Util.getAleatoriaPath(key);
			archivo = new File(path, name);
			log.info("Executing >>> postUploadFile(archivo: {}, isEnd: {}, name: {}, key: {})", archivo, isEnd, name, key);
			FileUtils.writeByteArrayToFile(archivo, file.getBytes(), true);
			return new ResponseEntity<>(new RutaArchivoCargaDTO(path), HttpStatus.OK);
		} catch (IOException e) {
			throw new FitravaException(String.format("No se pudo descargar el archivo: %1$s, excepcion: %2$s", file.getOriginalFilename(), e.getMessage()), e);
		}
	}
	
	@CrossOrigin
	@DeleteMapping("/v1/deleteFile")
	public ResponseEntity<Boolean> deleteFiles( @RequestParam("path") String path) throws ValidationException, FitravaException  {
		
		log.info("Executing >>> deleteFiles(path: {})", path);
		if (path == null || path.isEmpty()) {
			throw new ValidationException("La ruta es invalida");
		}
		
		procesoService.validaRuta(path);
		File file = null;
		try {
			file = new File(path);
			if (!file.exists()) {
				return new ResponseEntity<>(Boolean.FALSE, HttpStatus.OK);
			}
			FileUtils.deleteDirectory(file);
			return new ResponseEntity<>(Boolean.TRUE, HttpStatus.OK);
		} catch (IOException e) {
			throw new FitravaException(String.format("No se pudo borrar el path: %1$s, excepcion: %2$s", path, e.getMessage()), e);
		}
	}	

	@CrossOrigin
	@PostMapping("/v1/replaceLargeFile")
	public @ResponseBody ResponseEntity<RutaArchivoCargaDTO> postReplaceFile(
				@RequestParam("file") MultipartFile file, @RequestParam("path") String path,
				@RequestParam("isEnd") Boolean isEnd, @RequestParam("name") String name, 
				@RequestParam("key") String key) 
	throws ValidationException, FitravaException  {
		log.info("Executing >>> postReplaceFile(path: {}, isEnd: {}, name: {}, key: {})", path, isEnd, name, key);
		deleteFiles(path);
		return postUploadFile(file, isEnd, name, key);
	}

	@CrossOrigin
	@PostMapping("/v1/initProcessFiles")
	public @ResponseBody ResponseEntity<Boolean> postInitProcessFiles (@RequestBody UploadFileDTO uploadFileDTO) 
		throws ValidationException, FitravaException 
	{
		log.info("Executing >>> postInitProcessFiles(uploadFileDTO: {})", uploadFileDTO);
		
		if (uploadFileDTO == null) {
			throw new ValidationException(messages.get(CLID, "MSG_ERR_UPLOAD_FILE_DTO_ISNT_VALID"));
		}
		procesoService.procesaArchivo(uploadFileDTO);
		return new ResponseEntity<>(Boolean.TRUE, HttpStatus.OK);
	}
	
}
