package mx.com.metlife.tom.fitrava.services.service;

import java.util.List;

import mx.com.metlife.tom.fitrava.services.dto.CampoDTO;
import mx.com.metlife.tom.fitrava.services.dto.CharactersSkipDTO;
import mx.com.metlife.tom.fitrava.services.dto.HeaderFooterDTO;
import mx.com.metlife.tom.fitrava.services.dto.LayoutDTO;
import mx.com.metlife.tom.fitrava.services.dto.LayoutExcelDTO;
import mx.com.metlife.tom.fitrava.services.dto.TransformacionCampoDTO;
import mx.com.metlife.tom.fitrava.services.error.FitravaException;
import mx.com.metlife.tom.fitrava.services.error.ValidationException;
import mx.com.metlife.tom.fitrava.services.model.entity.TLayout;

public interface LayoutService {

	// justForTest
	String getDate() throws FitravaException;

	LayoutDTO getLayoutById(Long layoutId) throws ValidationException, FitravaException;

	LayoutDTO getLayoutByName(String nameLayout) throws ValidationException, FitravaException;

	List<LayoutDTO> getAllLayoutsByEai(String eai) throws ValidationException, FitravaException;

	LayoutDTO guardaLayout(LayoutDTO layoutDTO) throws ValidationException, FitravaException;

	LayoutDTO actualizaLayout(LayoutDTO layoutDTO) throws FitravaException;

	Boolean actualizaActivaLayout(Long layoutId) throws FitravaException;

	void deleteLayout(Long layoutId) throws FitravaException;

	List<TLayout> getLayoutsByIds(List<Long> lstLayoutId) throws ValidationException, FitravaException;
	List<LayoutDTO> getAllLayoutsIntoFlowsByEai(String eai, String ext) throws ValidationException, FitravaException;

	
	//Campos y demas
	CampoDTO getCampoById(Long id) throws ValidationException, FitravaException;

	List<CampoDTO> getAllCamposByLayoutId(Long layoutId) throws ValidationException, FitravaException;

	CampoDTO guardaCampo(CampoDTO campoDTO) throws ValidationException, FitravaException;

	CampoDTO actualizaCampo(CampoDTO campoDTO) throws FitravaException;

	void deleteCampo(Long fieldId) throws FitravaException;
List<CampoDTO> getAllCamposWithoutSpecialOperationsByLayoutId(Long layoutId, List<Long> lstExcludeOperations) throws ValidationException, FitravaException;
	

	TransformacionCampoDTO guardaTransformacionCampo(TransformacionCampoDTO transformacionCampoDTO) throws ValidationException, FitravaException;
	
	List<TransformacionCampoDTO> sobreescribeTransformacionCampo(Long layoutFldId,List<TransformacionCampoDTO> lstTransformacionCampoDTO) throws ValidationException, FitravaException;

	List<TransformacionCampoDTO> getTransformacionCampo(Long layoutFldId) throws ValidationException, FitravaException;

	void deleteTransform(Long fldTformId) throws FitravaException;

	TransformacionCampoDTO actualizaTransformacionCampo(TransformacionCampoDTO transformacionCampoDTO)throws ValidationException, FitravaException;

	HeaderFooterDTO getHeaderFooterById(Long headerFooterId) throws ValidationException, FitravaException;

	List<HeaderFooterDTO> getAllHeaderFootersByLayoutId(Long layoutId) throws ValidationException, FitravaException;

	HeaderFooterDTO actualizaHeaderFooter(HeaderFooterDTO headerFooterDTO) throws ValidationException, FitravaException;

	HeaderFooterDTO guardaHeaderFooter(HeaderFooterDTO headerFooterDTO) throws ValidationException, FitravaException;

	void deleteHeaderFooter(Long headerFooterId) throws FitravaException;

	void deleteHeaderFooterDtl(Long layoutHdId) throws FitravaException;

	//Hojas de excel a omitir
	List<LayoutExcelDTO> guardaLstLayoutExcel(List<LayoutExcelDTO> lstLayoutExcelDTO) throws ValidationException, FitravaException;

	List<LayoutExcelDTO> actualizaLstLayoutExcel(Long layoutId, List<LayoutExcelDTO> lstLayoutExcelDTO) throws ValidationException, FitravaException;

	void deleteLayoutExcel(Long layoutId, String xcelSheetNm) throws FitravaException;
	
	//Caracteres a omitir
	List<CharactersSkipDTO> guardaLstCharactersToSkip(List<CharactersSkipDTO> lstCharactersToSkip) throws ValidationException, FitravaException;

	List<CharactersSkipDTO> actualizaLstCharactersToSkip(Long layoutId, List<CharactersSkipDTO> lstCharactersToSkip) throws ValidationException, FitravaException;

	List<CharactersSkipDTO> getLstCharactersToSkip(Long layoutId) throws ValidationException, FitravaException;
}
