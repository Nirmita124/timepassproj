package mx.com.metlife.tom.fitrava.services.dto;


import lombok.Data;

@SuppressWarnings("serial")
@Data
public class CharactersSkipDTO implements java.io.Serializable{

	private Long skpCharId = null;
	
	private Long layoutId = null;
	
	private String charVal = null;

	private String charCd = null;
}
