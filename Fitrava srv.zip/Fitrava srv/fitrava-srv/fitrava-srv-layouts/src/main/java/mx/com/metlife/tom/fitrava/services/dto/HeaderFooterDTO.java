package mx.com.metlife.tom.fitrava.services.dto;

import java.util.List;

import lombok.Data;

@SuppressWarnings("serial")
@Data
public class HeaderFooterDTO implements java.io.Serializable{

	private Long layoutHdId = null;

	private Long layoutId = null;

	private Boolean ftrInd = null;

	private List<HeaderFooterDetalleDTO> listTLayoutHdDtl = null;

}
