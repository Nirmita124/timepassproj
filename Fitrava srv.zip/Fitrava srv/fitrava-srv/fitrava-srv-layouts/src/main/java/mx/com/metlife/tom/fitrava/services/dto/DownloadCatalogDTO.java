package mx.com.metlife.tom.fitrava.services.dto;

import lombok.Data;

@SuppressWarnings("serial")
@Data
public class DownloadCatalogDTO implements java.io.Serializable{

	private String domain=null;
	
	private String fileName=null;
	
	private String fileType= null;
	
	private String mailBox=null;
}
