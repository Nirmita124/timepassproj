package mx.com.metlife.tom.fitrava.services.dto;

import lombok.Data;

@SuppressWarnings("serial")
@Data
public class FlujoEntradaLayoutDTO implements java.io.Serializable{

	private Long flowId = null;
	private Long layoutId = null;
	private Integer flowEntrncLayoutOrdNum = null;
}
