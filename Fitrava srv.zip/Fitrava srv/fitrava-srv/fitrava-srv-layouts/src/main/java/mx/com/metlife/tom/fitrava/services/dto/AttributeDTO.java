package mx.com.metlife.tom.fitrava.services.dto;

import lombok.Data;

@Data
public class AttributeDTO implements java.io.Serializable{


	private static final long serialVersionUID = 1118915983218582468L;

	private Long layoutFldAtrbId = null;
	
	private Long layoutFldId = null;

	private Integer layoutFldOrdNum = null;

	private Integer minLnthNum = null;

	private Integer maxLnthNum = null;

	private Integer fixLnthNum = null;

	private Boolean leftTrimInd = null;

	private Boolean rghtTrimInd = null;

	private String leftFillCharVal = null;

	private String rghtFillCharVal = null;

	private Boolean leftAlgnInd = null;

	private Boolean rghtAlgnInd = null;

	private String regXprsnTxt = null;

}
