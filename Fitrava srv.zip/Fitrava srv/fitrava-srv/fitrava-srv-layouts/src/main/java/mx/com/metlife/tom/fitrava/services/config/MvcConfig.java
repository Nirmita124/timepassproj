package mx.com.metlife.tom.fitrava.services.config;

import java.util.Locale;

import javax.servlet.annotation.MultipartConfig;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ReloadableResourceBundleMessageSource;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;
import org.springframework.web.servlet.LocaleResolver;
import org.springframework.web.servlet.config.annotation.DefaultServletHandlerConfigurer;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.i18n.LocaleChangeInterceptor;
import org.springframework.web.servlet.i18n.SessionLocaleResolver;
import org.springframework.web.servlet.resource.ResourceUrlEncodingFilter;

/**
 * MvcConfig class will bootstrap the spring mvc application and set package to
 * scan controllers and resources.
 * 
 * @author Capgemini
 * @since 26/03/2019
 */
@Configuration
@EnableWebMvc
@MultipartConfig
@ComponentScan(basePackages = { "mx.com.metlife.tom.fitrava.services.web.controller" })
public class MvcConfig implements WebMvcConfigurer {

	private long maxUploadSizeInMb = 94371840L;//90 * 1024 * 1024; // 5 MB
	
    @Bean(name = "multipartResolver")
    public CommonsMultipartResolver multipartResolver() {
        CommonsMultipartResolver cmr = new CommonsMultipartResolver();
        cmr.setMaxUploadSize(maxUploadSizeInMb * 2);	// 10MB
        cmr.setMaxUploadSizePerFile(maxUploadSizeInMb); // Bytes
        return cmr;
    }
    
	@Bean
	public ResourceUrlEncodingFilter urlEncodingFilter() {
		return new ResourceUrlEncodingFilter();
	}

	@Bean(name = "messageSource")
	public ReloadableResourceBundleMessageSource getMessageSource() {
		ReloadableResourceBundleMessageSource resource = new ReloadableResourceBundleMessageSource();		
		resource.setBasenames("classpath:messages", "classpath:messages_es");
		resource.setDefaultEncoding("UTF-8");
		return resource;
	}
    
    @Bean
    public LocaleResolver localeResolver() {
        SessionLocaleResolver slr = new SessionLocaleResolver();
        Locale locale = new Locale("es");
        slr.setDefaultLocale(locale);
        return slr;
    }
	
    @Bean
    public LocaleChangeInterceptor localeChangeInterceptor() {
        LocaleChangeInterceptor lci = new LocaleChangeInterceptor();
        lci.setParamName("lang");
        return lci;
    }
    
	@Override
	public void configureDefaultServletHandling(DefaultServletHandlerConfigurer configurer) {
		configurer.enable();
	}    

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(localeChangeInterceptor());
    }    
}
