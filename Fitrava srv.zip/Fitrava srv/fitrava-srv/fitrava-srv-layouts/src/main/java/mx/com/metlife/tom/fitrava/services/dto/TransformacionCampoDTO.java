package mx.com.metlife.tom.fitrava.services.dto;

import java.util.List;

import org.dozer.Mapping;

import lombok.Data;

@SuppressWarnings("serial")
@Data
public class TransformacionCampoDTO  implements java.io.Serializable{
	
	@Mapping("fldTformId")
	private Long fldTformId = null;

	@Mapping("layoutFldId")
	private Long layoutFldId = null;

	@Mapping("fldOperId")
	private Long fldOperId = null;

	@Mapping("cnstVal")
	private String cnstVal = null;	
	
	@Mapping("listTFldTformParm")
	private List<ParametroTransformacionParametroDTO> listTFldTformParm;
	

}
