package mx.com.metlife.tom.fitrava.services.dto;

import lombok.Data;

@SuppressWarnings("serial")
@Data
public class FlujoArchivoDTO implements java.io.Serializable{

	private Integer flowExtFileId = null;
	private Long flowId = null;
	private String flowExtFileNm = null;
	private String flowExtFileRteNm = null;


}
