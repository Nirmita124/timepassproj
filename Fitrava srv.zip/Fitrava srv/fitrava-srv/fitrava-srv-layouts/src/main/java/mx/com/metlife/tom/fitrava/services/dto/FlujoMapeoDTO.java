package mx.com.metlife.tom.fitrava.services.dto;

import java.util.List;

import lombok.Data;

@Data
public class FlujoMapeoDTO implements java.io.Serializable {


	private static final long serialVersionUID = 2641439743539835050L;

	private Long flowMappingId = null;
	private Long flowId = null;
	private Long entrncLayoutId = null;
	
	private List<FlujoMapeoDetalleDTO> listTFlowMappingDtl = null;

	
}
