package mx.com.metlife.tom.fitrava.services.dto;


import java.util.List;

import lombok.Data;

@Data
public class UploadFileDTO implements java.io.Serializable {
	
	private static final long serialVersionUID = 8664298574170723004L;


	private Boolean isMassive 	= null;
	private String crtUsrId 	= null;
	private String dcn 			= null;
	private Long flowId 		= null;	
	private String source 		= null;
	private String ruta 		= null; 
	private List<UploadExternalDataDTO> lstExternalData = null;
}
