package mx.com.metlife.tom.fitrava.services.web.controller;

import static mx.com.metlife.tom.fitrava.services.utility.Constantes.ERROR_CODE_400;
import static mx.com.metlife.tom.fitrava.services.utility.Constantes.ERROR_CODE_401;
import static mx.com.metlife.tom.fitrava.services.utility.Constantes.ERROR_CODE_500;
import static mx.com.metlife.tom.fitrava.services.utility.Constantes.ERROR_MESSAGE_500;
import static mx.com.metlife.tom.fitrava.services.utility.Constantes.UN_AUTHORIZED_USER;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import mx.com.metlife.tom.fitrava.services.error.AuthorizationException;
import mx.com.metlife.tom.fitrava.services.error.ErrorExtensionVO;
import mx.com.metlife.tom.fitrava.services.error.FitravaException;
import mx.com.metlife.tom.fitrava.services.error.HeaderValidationException;
import mx.com.metlife.tom.fitrava.services.error.MessagesErrorVO;
import mx.com.metlife.tom.fitrava.services.error.ValidationException;

@RestControllerAdvice
public class FitravaErrorController {
	
	@ExceptionHandler(value = {ValidationException.class, HeaderValidationException.class})
	public @ResponseBody ResponseEntity<MessagesErrorVO> validationException(ValidationException exception) {
		
		ErrorExtensionVO specific = new ErrorExtensionVO(null, exception.getMessage());
		MessagesErrorVO messagesErrorVO = new MessagesErrorVO(ERROR_CODE_400, exception.getMessage(),exception.getMessage(), specific);
		return new ResponseEntity<>(messagesErrorVO, HttpStatus.BAD_REQUEST);		
	}

	@ExceptionHandler(value = {FitravaException.class})
	public @ResponseBody ResponseEntity<MessagesErrorVO> fitravaException(FitravaException exception) {
		
		ErrorExtensionVO specific = new ErrorExtensionVO(null, exception.getMessage());
		MessagesErrorVO messagesErrorVO = new MessagesErrorVO(ERROR_CODE_500, exception.getMessage(), exception.getMessage(), specific);
		return new ResponseEntity<>(messagesErrorVO, HttpStatus.BAD_REQUEST);
	}
	
	@ExceptionHandler(AuthorizationException.class)
	public @ResponseBody ResponseEntity<MessagesErrorVO> authorizationException(AuthorizationException exception) {
		
		ErrorExtensionVO specific = new ErrorExtensionVO(null,exception.getMessage());
		MessagesErrorVO messagesErrorVO = new MessagesErrorVO(ERROR_CODE_401, exception.getMessage(),UN_AUTHORIZED_USER, specific);
		return new ResponseEntity<>(messagesErrorVO, HttpStatus.UNAUTHORIZED);		
	}
	
	@ExceptionHandler(Exception.class)
	public @ResponseBody ResponseEntity<MessagesErrorVO> generalException(Exception exception) {
	
		ErrorExtensionVO specific = new ErrorExtensionVO(null,ERROR_MESSAGE_500);
		MessagesErrorVO messagesErrorVO = new MessagesErrorVO(ERROR_CODE_500, exception.getMessage(),"", specific);
		return new ResponseEntity<>(messagesErrorVO, HttpStatus.INTERNAL_SERVER_ERROR);
	}

}
