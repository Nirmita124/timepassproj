package mx.com.metlife.tom.fitrava.services.service;

import java.util.List;

import mx.com.metlife.tom.fitrava.services.dto.FlujoArchivoDTO;
import mx.com.metlife.tom.fitrava.services.dto.FlujoDTO;
import mx.com.metlife.tom.fitrava.services.dto.FlujoMapeoDTO;
import mx.com.metlife.tom.fitrava.services.error.FitravaException;
import mx.com.metlife.tom.fitrava.services.error.ValidationException;

public interface FlujoService {

	// FlujoDTO
	FlujoDTO getFlujoById(Long id) throws ValidationException, FitravaException;

	List<FlujoDTO> getAllFlujosBy(String retenedorId, String eaiCd) throws ValidationException, FitravaException;

	FlujoDTO guardaFlujo(FlujoDTO flujoDTO) throws ValidationException, FitravaException;

	FlujoDTO actualizaFlujo(FlujoDTO flujoDTO) throws FitravaException;

	Boolean actualizaActivaFlujo(Long flujoId) throws FitravaException;

	void deleteFlujo(Long id) throws FitravaException;

	List<FlujoDTO> getFlowsByEaiAndExt(String eai, String ext) throws ValidationException, FitravaException;

	// FlujoArchivoDTO
	FlujoArchivoDTO getFlujoArchivoById(Integer id) throws FitravaException;

	List<FlujoArchivoDTO> getAllFlujosArchivoByFlujoId(Long flowId) throws ValidationException, FitravaException;

	FlujoArchivoDTO guardaFlujoArchivo(FlujoArchivoDTO flujoArchivoDTO) throws ValidationException, FitravaException;

	FlujoArchivoDTO actualizaFlujoArchivo(FlujoArchivoDTO flujoArchivoDTO) throws FitravaException;

	void deleteFlujoArchivo(Integer id) throws FitravaException;

	// layouts
	void addOrReplaceAllLayoutsEntrada(Long flujoId, Long... layoutIds) throws FitravaException;

	void addOrReplaceLayoutEntrada(Long flujoId, Long layoutId) throws FitravaException;

	void addOrReplaceLayoutSalida(Long flujoId, Long layoutId) throws FitravaException;

	void deleteLayoutFromFlujo(Long flujoId, Long layoutId) throws FitravaException;

	// Mapeos
	FlujoMapeoDTO getFlujoMapeoById(Long flujoMapeoId) throws ValidationException, FitravaException;

	List<FlujoMapeoDTO> getAllFlujoMapeosByFlujoIdAndLayoutEntradaId(Long flujoId, Long layoutEntradaId)
			throws ValidationException, FitravaException;

	FlujoMapeoDTO guardaFlujoMapeo(FlujoMapeoDTO flujoMapeoDTO) throws ValidationException, FitravaException;

	FlujoMapeoDTO actualizaFlujoMapeo(FlujoMapeoDTO flujoMapeoDTO) throws FitravaException;

	void deleteFlujoMapeo(Long flujoMapeoId) throws FitravaException;

	void deleteFlujoMapeoDtl(Long flujoMapeoId) throws FitravaException;

}
