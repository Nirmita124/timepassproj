package mx.com.metlife.tom.fitrava.services.dto;

import org.dozer.Mapping;

import lombok.Data;

@SuppressWarnings("serial")
@Data
public class TipoDatoDTO implements java.io.Serializable{

	@Mapping("datatypId")
	private Integer datatypId = null;
	
	@Mapping("datatypNm")
	private String datatypNm = null;
	
	@Mapping("datatypDscr")
	private String datatypDscr = null;

}
