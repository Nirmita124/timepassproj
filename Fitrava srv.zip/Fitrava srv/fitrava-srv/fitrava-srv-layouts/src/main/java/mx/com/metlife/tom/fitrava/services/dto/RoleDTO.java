package mx.com.metlife.tom.fitrava.services.dto;

import java.util.List;

import lombok.Data;

@Data
public class RoleDTO implements java.io.Serializable {

	private static final long serialVersionUID = 7050492616033000367L;

	private Integer roleId = null;
	
	private String roleNm = null;

	private String roleDscr = null;

	private Integer roleActInd = null; 
	
	private List<MenuDTO> tmenus;
}
