package mx.com.metlife.tom.fitrava.services.dto;

import java.util.Date;
import java.util.List;

import org.dozer.Mapping;

import lombok.Data;

@Data
public class ProcesoDTO implements java.io.Serializable{

	private static final long serialVersionUID = 30994389505055382L;

	@Mapping("dstnctCtrlNum")
	private String dcn = null;

	private Long flowId = null;

	private Date rcptnTs = null;

	private Integer prtyNum = null;

	private String crtUsrId = null;

	private Integer clctSttsId = null;

	private String rsltDscr = null;

	
	private List<ProcesoFileDTO> listProcesoFile = null; 
	
	private List<LogProcesoDTO> listLogProceso = null;
	
	private FlujoDTO tFlow;
	
}
