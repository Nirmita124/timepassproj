package mx.com.metlife.tom.fitrava.services.serviceimpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.dozer.DozerBeanMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import mx.com.metlife.tom.fitrava.services.dto.MenuDTO;
import mx.com.metlife.tom.fitrava.services.dto.RoleDTO;
import mx.com.metlife.tom.fitrava.services.dto.RoleMenuDTO;
import mx.com.metlife.tom.fitrava.services.dto.UserDTO;
import mx.com.metlife.tom.fitrava.services.error.FitravaException;
import mx.com.metlife.tom.fitrava.services.error.ValidationException;
import mx.com.metlife.tom.fitrava.services.model.entity.TMenu;
import mx.com.metlife.tom.fitrava.services.model.entity.TRole;
import mx.com.metlife.tom.fitrava.services.model.entity.TRoleMenu;
import mx.com.metlife.tom.fitrava.services.model.entity.TUsr;
import mx.com.metlife.tom.fitrava.services.model.repository.TRoleMenuRepository;
import mx.com.metlife.tom.fitrava.services.model.repository.TRoleRepository;
import mx.com.metlife.tom.fitrava.services.model.repository.TUsrRepository;
import mx.com.metlife.tom.fitrava.services.service.UserManagementService;
import mx.com.metlife.tom.fitrava.services.serviceimpl.beans.FitravaSrvMessages;

@Service
public class UserManagementServiceImpl implements UserManagementService {

	private static final String CLID = UserManagementServiceImpl.class.getSimpleName();
	private static Logger log = LoggerFactory.getLogger(UserManagementServiceImpl.class);

	@Autowired
	private DozerBeanMapper mapper;
	@Autowired
	private TUsrRepository tUsrRepository;
	@Autowired
	private TRoleMenuRepository tRoleMenuRepository;
	@Autowired
	private TRoleRepository tRoleRepository;
	@Autowired
	private FitravaSrvMessages messages;

	@Override
	public UserDTO saveUser(UserDTO userDto) throws ValidationException, FitravaException {
		log.info("Executing >>> saveUser(userDto: {})", userDto);
		TUsr tUser = null;
		try {
			tUser = mapper.map(userDto, TUsr.class);
			tUser = tUsrRepository.saveAndFlush(tUser);
		} catch (Exception e) {
			log.error(String.format("Error al guardar el Usuario: %1$s", userDto), e);
			throw new FitravaException(String.format(messages.get(CLID, "MSG_ERR_SAVING_FILE"), userDto, e.getCause()));
		}
		if (tUser == null) {
			throw new ValidationException(messages.get(CLID, "MSG_ERR_CANT_FIND_ANY_USER"));
		}
		return mapper.map(tUser, UserDTO.class);
	}

	@Override
	public List<UserDTO> findAllUser() throws ValidationException, FitravaException {
		log.debug("En el findAllUser()");
		List<TUsr> dbObjects = null;
		List<UserDTO> dtos = null;

		try {
			dbObjects = tUsrRepository.findAll();
		} catch (Exception e) {
			throw new FitravaException(String.format(messages.get(CLID, "MSG_ERR_GETTING_USERS"), e.getCause()));
		}
		if (dbObjects == null || dbObjects.isEmpty()) {
			throw new FitravaException(messages.get(CLID, "MSG_CANT_FIND_ANY_USER"));
		}
		dtos = new ArrayList<>();
		for (TUsr l : dbObjects) {
			dtos.add(mapper.map(l, UserDTO.class));
		}
		return dtos;
	}

	@Override
	public UserDTO findById(String id) throws ValidationException, FitravaException {
		log.info("Executing >>> findById(String id {})", id);
		TUsr tUser = null;

		try {
			Optional<TUsr> optional = tUsrRepository.findById(id);
			if (optional.isPresent()) {
				tUser = optional.get();
			}

		} catch (Exception e) {
			log.error(String.format(messages.get(CLID, "MSG_ERR_GETTING_USER_BY_ID"), id), e);
			throw new FitravaException(
					String.format("error al obtener el Usuario con el ID: %1$s, Error: %2$s", id, e.getCause()));
		}
		if (tUser == null) {
			throw new ValidationException(messages.get(CLID, "MSG_ERR_CANT_FIND_ANY_USER2"));
		}

		return mapper.map(tUser, UserDTO.class);
	}

	@Override
	public Boolean updateUser(String id, Integer roleId, Integer status) throws ValidationException, FitravaException {
		TUsr tUser = null;

		try {
			Optional<TUsr> optional = tUsrRepository.findById(id);
			if (optional.isPresent()) {
				tUser = optional.get();
			}
			if (tUser != null) {
				tUser.setUserActInd(status);
				tUser.setRoleId(roleId);
			}
			tUsrRepository.save(tUser);
			return Boolean.TRUE;
		} catch (Exception e) {
			log.error(String.format("Error al actualizar el Usuario del Layout con ID: %1$s", id), e);
			throw new FitravaException(
					String.format(messages.get(CLID, "MSG_ERR_UPDATING_USER_BY_ID"), id, e.getCause()));
		}
	}

	@Override
	public List<RoleMenuDTO> findAllRoleMenus() throws ValidationException, FitravaException {
		log.debug("En el findAllUser()");
		List<TRoleMenu> dbObjects = null;
		List<RoleMenuDTO> dtos = null;

		try {
			dbObjects = tRoleMenuRepository.findAll();
		} catch (Exception e) {
			throw new FitravaException(String.format(messages.get(CLID, "MSG_ERR_GETTING_MENUROLS"), e.getCause()));
		}
		if (dbObjects == null || dbObjects.isEmpty()) {
			throw new FitravaException(messages.get(CLID, "MSG_CANT_FIND_ANY_MENU_ROLE"));
		}
		dtos = new ArrayList<>();
		for (TRoleMenu l : dbObjects) {
			dtos.add(mapper.map(l, RoleMenuDTO.class));
		}
		return dtos;
	}

	@Override
	public RoleDTO updateRole(RoleDTO roleDto) throws ValidationException, FitravaException {
		TRole tRole = null;
		TRoleMenu tRoleMenu;
		List<TMenu> tMenus = null;
		List<MenuDTO> lstMenusDto = null;
		Integer roleId = null;

		try {
			lstMenusDto = roleDto.getTmenus();
			roleDto.setTmenus(null);
			tRole = tRoleRepository.save(mapper.map(roleDto, TRole.class));
			if (tRole != null && lstMenusDto != null && !lstMenusDto.isEmpty()) {
				tMenus = new ArrayList<>();
				roleId = tRole.getRoleId();
				tRoleMenuRepository.deleteByRoleId(roleId);
				for (MenuDTO menu : lstMenusDto) {
					tRoleMenu = new TRoleMenu();
					tRoleMenu.setRoleId(roleId);
					tRoleMenu.setMenuId(menu.getMenuId());
					tRoleMenu = tRoleMenuRepository.save(tRoleMenu);
					for (MenuDTO submenu : menu.getTMenus()) {
						TRoleMenu tRoleMenuAux = new TRoleMenu();
						tRoleMenuAux.setRoleId(roleId);
						tRoleMenuAux.setMenuId(submenu.getMenuId());
						tRoleMenuAux = tRoleMenuRepository.save(tRoleMenuAux);
					}
					tMenus.add(mapper.map(menu, TMenu.class));
				}
				tRole.setTmenus(tMenus);
			}
			return mapper.map(tRole, RoleDTO.class);
		} catch (Exception e) {
			log.error(String.format("error al guardar el Role: %1$s", roleDto), e);
			throw new FitravaException(String.format(messages.get(CLID, "MSG_ERR_SAVING_ROLE"), roleDto, e.getCause()));
		}
	}

	@Override
	public void deleteRoleMenuByRoleId(Integer id) throws ValidationException, FitravaException {
		log.info("Executing >>> deleteRoleMenuByRoleId(id: {})", id);
		try {
			tRoleMenuRepository.deleteByRoleId(id);
		} catch (Exception e) {
			log.error(String.format("Error al borrar el RoleMenu por el RoleId: %1$s", id), e);
			throw new FitravaException(
					String.format(messages.get(CLID, "MSG_ERR_DELETING_MENU_ROLE_BY_ROLEID"), id, e.getCause()));
		}

	}
}
