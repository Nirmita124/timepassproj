package mx.com.metlife.tom.fitrava.services.config;

import org.dozer.DozerBeanMapper;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;



/**
 * ServiceConfig class will bootstrap the spring mvc application and set package
 * to scan controllers and resources.
 * 
 * @author Capgemini
 * @since 26/03/2019
 */
@Configuration
@ComponentScan("mx.com.metlife.tom.fitrava.services.serviceimpl")
@PropertySource("classpath:${env_var:dev}-fitrava.properties")
public class ServiceConfig {
	
	@Bean
	public DozerBeanMapper getMapper() {
		return new DozerBeanMapper();
	}
}
