package mx.com.metlife.tom.fitrava.services.serviceimpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.dozer.DozerBeanMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import mx.com.metlife.tom.fitrava.services.dto.AplicacionDTO;
import mx.com.metlife.tom.fitrava.services.dto.EstatusProcesoDTO;
import mx.com.metlife.tom.fitrava.services.dto.MenuDTO;
import mx.com.metlife.tom.fitrava.services.dto.OperacionCampoDTO;
import mx.com.metlife.tom.fitrava.services.dto.OperacionDTO;
import mx.com.metlife.tom.fitrava.services.dto.RoleDTO;
import mx.com.metlife.tom.fitrava.services.dto.TipoDatoDTO;
import mx.com.metlife.tom.fitrava.services.error.FitravaException;
import mx.com.metlife.tom.fitrava.services.error.ValidationException;
import mx.com.metlife.tom.fitrava.services.model.entity.TApp;
import mx.com.metlife.tom.fitrava.services.model.entity.TClctStts;
import mx.com.metlife.tom.fitrava.services.model.entity.TDatatyp;
import mx.com.metlife.tom.fitrava.services.model.entity.TFldOper;
import mx.com.metlife.tom.fitrava.services.model.entity.TMenu;
import mx.com.metlife.tom.fitrava.services.model.entity.TOper;
import mx.com.metlife.tom.fitrava.services.model.entity.TRole;
import mx.com.metlife.tom.fitrava.services.model.repository.TAppRepository;
import mx.com.metlife.tom.fitrava.services.model.repository.TClctSttsRepository;
import mx.com.metlife.tom.fitrava.services.model.repository.TDatatypRepository;
import mx.com.metlife.tom.fitrava.services.model.repository.TFldOperRepository;
import mx.com.metlife.tom.fitrava.services.model.repository.TMenuRepository;
import mx.com.metlife.tom.fitrava.services.model.repository.TOperRepository;
import mx.com.metlife.tom.fitrava.services.model.repository.TRoleRepository;
import mx.com.metlife.tom.fitrava.services.service.AdminCatalogosService;
import mx.com.metlife.tom.fitrava.services.serviceimpl.beans.FitravaSrvMessages;

@Service
public class AdminCatalogosServiceImpl implements AdminCatalogosService {

	private static final String CLID = AdminCatalogosServiceImpl.class.getSimpleName();
	private static Logger log = LoggerFactory.getLogger(AdminCatalogosServiceImpl.class);

	@Autowired
	private DozerBeanMapper mapper;

	@Autowired
	private TAppRepository tAppRepository;
	@Autowired
	private TFldOperRepository tFldOperRepository;
	@Autowired
	private TDatatypRepository tDatatypRepository;
	@Autowired
	private TOperRepository tOperRepository;
	@Autowired
	private TClctSttsRepository tClctSttsRepository;
	@Autowired
	private TRoleRepository tRoleRepository;
	@Autowired
	private TMenuRepository tMenuRepository;
	@Autowired
	private FitravaSrvMessages messages;

	// Aplicacion
	@Override
	public AplicacionDTO getAplicacionById(String id) throws ValidationException, FitravaException {
		log.debug(String.format("Executing >>> getAplicacionById(id: %1$s)", id));
		if (id == null || id.trim().length() == 0) {
			throw new FitravaException(String.format(messages.get(CLID, "MSG_APP_ID_NOT_NULL"), id));
		}
		TApp dbObject = null;

		try {
			Optional<TApp> optional = tAppRepository.findById(id);
			if (optional.isPresent()) {
				dbObject = optional.get();
			}
		} catch (Exception e) {
			throw new FitravaException(
					String.format(messages.get(CLID, "MSG_ERR_GETTING_APP_BY_ID"), id, e.getCause()));
		}
		if (dbObject == null) {
			throw new FitravaException(String.format(messages.get(CLID, "MSG_APP_NOT_FOUND_BY_GIVEN_ID"), id));
		}
		return mapper.map(dbObject, AplicacionDTO.class);
	}

	@Override
	public List<AplicacionDTO> getAllAplicaciones() throws ValidationException, FitravaException {
		log.debug("En el getAllAplicaciones()");
		List<TApp> dbObjects = null;
		List<AplicacionDTO> dtos = null;

		try {
			dbObjects = tAppRepository.findAll();
		} catch (Exception e) {
			throw new FitravaException(String.format(messages.get(CLID, "MSG_ERR_GETTING_APPS"), e.getCause()));
		}
		if (dbObjects == null || dbObjects.isEmpty()) {
			throw new FitravaException(messages.get(CLID, "MSG_CANT_FIND_ANY_APP1"));
		}
		dtos = new ArrayList<>();
		for (TApp l : dbObjects) {
			dtos.add(mapper.map(l, AplicacionDTO.class));
		}
		return dtos;
	}

	@Override
	@Transactional
	public AplicacionDTO guardaAplicacion(AplicacionDTO dto) throws ValidationException, FitravaException {
		log.debug(String.format("Executing >>> guardaAplicacion(dto: %1$s)", dto));
		TApp tAplicacion = null;

		try {
			tAplicacion = tAppRepository.saveAndFlush(mapper.map(dto, TApp.class));
		} catch (Exception e) {
			throw new FitravaException(String.format(messages.get(CLID, "MSG_ERR_SAVING_APP"), dto, e.getCause()));
		}
		if (tAplicacion == null) {
			throw new FitravaException(messages.get(CLID, "MSG_CANT_FIND_ANY_APP2"));
		}
		return mapper.map(tAplicacion, AplicacionDTO.class);
	}

	@Override
	@Transactional
	public AplicacionDTO actualizaAplicacion(AplicacionDTO dto) throws ValidationException, FitravaException {
		log.debug(String.format("Executing >>> actualizaAplicacion(dto: %1$s)", dto));
		TApp aCambiar = null;
		String idOriginal = null;

		if (dto == null) {
			throw new FitravaException(messages.get(CLID, "MSG_APP_CANT_BE_NULL1"));
		}
		idOriginal = dto.getEaiCd();
		if (idOriginal == null || idOriginal.trim().length() == 0) {
			throw new FitravaException(
					String.format(messages.get(CLID, "MSG_INVALID_APP_ID_CANT_PERFORM_UPDATE"), dto, idOriginal));
		}
		aCambiar = mapper.map(dto, TApp.class);
		aCambiar.setEaiCd(idOriginal);

		try {
			aCambiar = tAppRepository.save(aCambiar);
		} catch (Exception e) {
			throw new FitravaException(
					String.format(messages.get(CLID, "MSG_ERR_UPDATING_APP"), aCambiar, e.getCause()));
		}
		return mapper.map(aCambiar, AplicacionDTO.class);
	}

	@Override
	@Transactional
	public void deleteAplicacion(String id) throws ValidationException, FitravaException {
		log.debug(String.format("Executing >>> deleteAplicacion(id: %1$s)", id));
		try {
			tAppRepository.deleteById(id);
		} catch (Exception e) {
			throw new FitravaException(
					String.format(messages.get(CLID, "MSG_ERR_DELETING_APP_BY_ID"), id, e.getCause()));
		}

	}

	// OperacionCampo
	@Override
	public OperacionCampoDTO getOperacionCampoById(Long id) throws ValidationException, FitravaException {
		log.debug(String.format("Executing >>> getOperacionCampoById(id: %1$s)", id));

		if (id == null || id <= 0) {
			throw new FitravaException(String.format(messages.get(CLID, "MSG_OPER_ID_CANT_BE_NULL"), id));
		}
		TFldOper dbObject = null;

		try {
			Optional<TFldOper> optional = tFldOperRepository.findById(id);
			if (optional.isPresent()) {
				dbObject = optional.get();
			}
		} catch (Exception e) {
			throw new FitravaException(
					String.format(messages.get(CLID, "MSG_ERR_GETTING_OPER_BY_ID_2"), id, e.getCause()));
		}
		if (dbObject == null) {
			throw new FitravaException(String.format(messages.get(CLID, "MSG_NO_OPERATION_FOUND_BY_GIVEN_ID"), id));
		}
		return mapper.map(dbObject, OperacionCampoDTO.class);
	}

	@Override
	public List<OperacionCampoDTO> getAllOperacionCampos() throws ValidationException, FitravaException {
		log.debug("Executing >>> getAllOperacionCampo()");
		List<TFldOper> dbObjects = null;
		List<OperacionCampoDTO> dtos = null;
		try {
			dbObjects = tFldOperRepository.findAll();
		} catch (Exception e) {
			throw new FitravaException(String.format(messages.get(CLID, "MSG_ERR_GETTING_OPERATION"), e.getCause()));
		}

		if (dbObjects == null || dbObjects.isEmpty()) {
			throw new ValidationException(messages.get(CLID, "MSG_CANT_FIND_ANY_OPERATION"));
		}
		dtos = new ArrayList<>();
		for (TFldOper l : dbObjects) {
			dtos.add(mapper.map(l, OperacionCampoDTO.class));
		}
		return dtos;
	}

	@Override
	@Transactional
	public OperacionCampoDTO guardaOperacionCampo(OperacionCampoDTO dto) throws ValidationException, FitravaException {
		log.debug(String.format("Executing >>> guardaOperacionCampo(dto: %1$s)", dto));
		TFldOper tOperacionCampo = null;
		try {
			tOperacionCampo = tFldOperRepository.saveAndFlush(mapper.map(dto, TFldOper.class));
		} catch (Exception e) {
			throw new FitravaException(
					String.format(messages.get(CLID, "MSG_ERR_SAVING_OPERATION"), dto, e.getCause()));
		}
		if (tOperacionCampo == null) {
			throw new FitravaException(messages.get(CLID, "MSG_CANT_FIND_ANY_OPERATION2"));
		}
		return mapper.map(tOperacionCampo, OperacionCampoDTO.class);
	}

	@Override
	@Transactional
	public OperacionCampoDTO actualizaOperacionCampo(OperacionCampoDTO dto)
			throws ValidationException, FitravaException {
		log.debug(String.format("Executing >>> actualizaOperacionCampo(dto: %1$s)", dto));
		TFldOper aCambiar = null;
		Long idOriginal = null;
		if (dto == null) {
			throw new FitravaException(messages.get(CLID, "MSG_OPERATION_CANT_BE_NULL"));
		}
		idOriginal = dto.getFldOperId();
		if (idOriginal == null || idOriginal <= 0) {
			throw new FitravaException(String.format(messages.get(CLID, "MSG_CANT_UPDATE_OPERATION"), dto, idOriginal));
		}
		aCambiar = mapper.map(dto, TFldOper.class);
		aCambiar.setFldOperId(idOriginal);
		try {
			aCambiar = tFldOperRepository.save(aCambiar);
		} catch (Exception e) {
			throw new FitravaException(
					String.format(messages.get(CLID, "MSG_ERR_UPDATING_OPERATION"), aCambiar, e.getCause()));
		}
		return mapper.map(aCambiar, OperacionCampoDTO.class);
	}

	@Override
	@Transactional
	public void deleteOperacionCampo(Long id) throws ValidationException, FitravaException {
		log.debug(String.format("Executing >>> deleteOperacionCampo(id: %1$s)", id));
		try {
			tFldOperRepository.deleteById(id);
		} catch (Exception e) {
			throw new FitravaException(
					String.format(messages.get(CLID, "MSG_ERR_DELETING_OPERATION_BY_ID"), id, e.getCause()));
		}
	}

	// TipoDato
	@Override
	public TipoDatoDTO getTipoDatoById(Integer id) throws ValidationException, FitravaException {
		log.debug(String.format("Executing >>> getTipoDatoById(id: %1$s)", id));
		if (id == null || id <= 0) {
			throw new FitravaException(String.format(messages.get(CLID, "MSG_DATATYPE_ID_CANT_BE_NULL"), id));
		}
		TDatatyp dbObject = null;
		try {
			Optional<TDatatyp> optional = tDatatypRepository.findById(id);
			if (optional.isPresent()) {
				dbObject = optional.get();
			}
		} catch (Exception e) {
			throw new FitravaException(
					String.format(messages.get(CLID, "MSG_ERR_GETTING_DATATYPE_BY_ID"), id, e.getCause()));
		}
		if (dbObject == null) {
			throw new FitravaException(String.format(messages.get(CLID, "MSG_CANT_FIND_ANY_DATATYPE_BY_ID"), id));
		}
		return mapper.map(dbObject, TipoDatoDTO.class);
	}

	@Override
	public List<TipoDatoDTO> getAllTipoDatos() throws ValidationException, FitravaException {
		log.debug("Executing >>> getAllTipoDato()");
		List<TDatatyp> dbObjects = null;
		List<TipoDatoDTO> dtos = null;
		try {
			dbObjects = tDatatypRepository.findAll();
		} catch (Exception e) {
			throw new FitravaException(String.format(messages.get(CLID, "MSG_ERR_GETTING_DATATYPE"), e.getCause()));
		}
		if (dbObjects == null || dbObjects.isEmpty()) {
			throw new ValidationException(messages.get(CLID, "MSG_CANT_FIND_ANY_DATATYPE"));
		}
		dtos = new ArrayList<>();
		for (TDatatyp l : dbObjects) {
			dtos.add(mapper.map(l, TipoDatoDTO.class));
		}
		return dtos;
	}

	@Override
	@Transactional
	public TipoDatoDTO guardaTipoDato(TipoDatoDTO dto) throws ValidationException, FitravaException {
		log.debug(String.format("Executing >>> guardaTipoDato(dto: %1$s)", dto));
		TDatatyp tTipoDato = null;

		try {
			tTipoDato = tDatatypRepository.saveAndFlush(mapper.map(dto, TDatatyp.class));
		} catch (Exception e) {
			throw new FitravaException(String.format(messages.get(CLID, "MSG_ERR_SAVING_DATATYPE"), dto, e.getCause()));
		}
		if (tTipoDato == null) {
			throw new FitravaException(messages.get(CLID, "MSG_CANT_FIND_ANY_DATA_TYPE2"));
		}
		return mapper.map(tTipoDato, TipoDatoDTO.class);
	}

	@Override
	@Transactional
	public TipoDatoDTO actualizaTipoDato(TipoDatoDTO dto) throws ValidationException, FitravaException {
		log.debug(String.format("Executing >>> actualizaTipoDato(dto: %1$s)", dto));
		TDatatyp aCambiar = null;
		Integer idOriginal = null;

		if (dto == null) {
			throw new FitravaException(messages.get(CLID, "MSG_DATATYPE_CANT_BE_NULL"));
		}
		idOriginal = dto.getDatatypId();
		if (idOriginal == null || idOriginal <= 0) {
			throw new FitravaException(String.format(messages.get(CLID, "MSG_CANT_UPDATE_DATATYPE"), dto, idOriginal));
		}
		aCambiar = mapper.map(dto, TDatatyp.class);
		aCambiar.setDatatypId(idOriginal);
		try {
			aCambiar = tDatatypRepository.save(aCambiar);
		} catch (Exception e) {
			throw new FitravaException(
					String.format(messages.get(CLID, "MSG_ERR_UPDATING_DATATYPE"), aCambiar, e.getCause()));
		}
		return mapper.map(aCambiar, TipoDatoDTO.class);
	}

	@Override
	@Transactional
	public void deleteTipoDato(Integer id) throws ValidationException, FitravaException {
		log.debug(String.format("Executing >>> deleteTipoDato(id: %1$s)", id));
		try {
			tDatatypRepository.deleteById(id);
		} catch (Exception e) {
			throw new FitravaException(
					String.format(messages.get(CLID, "MSG_ERR_DELETING_DATATYPE"), id, e.getCause()));
		}

	}

	// Operacion
	@Override
	public OperacionDTO getOperacionById(Integer id) throws ValidationException, FitravaException {
		log.debug(String.format("Executing >>> getOperacionById(id: %1$s)", id));
		if (id == null || id <= 0) {
			throw new FitravaException(String.format(messages.get(CLID, "MSG_OPERATION_ID_CANT_BE_NULL"), id));
		}
		TOper dbObject = null;

		try {
			Optional<TOper> optional = tOperRepository.findById(id);
			if (optional.isPresent()) {
				dbObject = optional.get();
			}
		} catch (Exception e) {
			throw new FitravaException(
					String.format(messages.get(CLID, "MSG_ERR_GETTING_OPERATION_BY_ID"), id, e.getCause()));
		}
		if (dbObject == null) {
			throw new FitravaException(
					String.format(messages.get(CLID, "MSG_CANT_FIND_ANY_OPERATION_BY_GIVEN_ID"), id));
		}
		return mapper.map(dbObject, OperacionDTO.class);
	}

	@Override
	public List<OperacionDTO> getAllOperaciones() throws ValidationException, FitravaException {
		log.debug("Executing >>> getAllOperaciones()");
		List<TOper> dbObjects = null;
		List<OperacionDTO> dtos = null;

		try {
			dbObjects = tOperRepository.findAll();
		} catch (Exception e) {
			throw new FitravaException(String.format(messages.get(CLID, "MSG_ERR_GETTING_OPERATION2"), e.getCause()));
		}
		if (dbObjects == null || dbObjects.isEmpty()) {
			throw new ValidationException(messages.get(CLID, "MSG_CANT_FIND_ANY_OPERATION3"));
		}
		dtos = new ArrayList<>();
		for (TOper l : dbObjects) {
			dtos.add(mapper.map(l, OperacionDTO.class));
		}
		return dtos;
	}

	@Override
	@Transactional
	public OperacionDTO guardaOperacion(OperacionDTO dto) throws ValidationException, FitravaException {
		log.debug(String.format("Executing >>> guardaOperacion(dto: %1$s)", dto));
		TOper tOperacion = null;

		try {
			tOperacion = tOperRepository.saveAndFlush(mapper.map(dto, TOper.class));
		} catch (Exception e) {
			throw new FitravaException(
					String.format(messages.get(CLID, "MSG_ERR_SAVING_OPERATION2"), dto, e.getCause()));
		}
		if (tOperacion == null) {
			throw new FitravaException(messages.get(CLID, "MSG_CANT_FIND_ANY_OPERATION4"));
		}
		return mapper.map(tOperacion, OperacionDTO.class);
	}

	@Override
	@Transactional
	public OperacionDTO actualizaOperacion(OperacionDTO dto) throws ValidationException, FitravaException {
		log.debug(String.format("Executing >>> actualizaOperacion(dto: %1$s)", dto));
		TOper aCambiar = null;
		Integer idOriginal = null;

		if (dto == null) {
			throw new FitravaException(messages.get(CLID, "MSG_OPERATION_CANT_BE_NULL2"));
		}
		idOriginal = dto.getOperId();
		if (idOriginal == null || idOriginal <= 0) {
			throw new FitravaException(
					String.format(messages.get(CLID, "MSG_CANT_UPDATE_OPERATION2"), dto, idOriginal));
		}
		aCambiar = mapper.map(dto, TOper.class);
		aCambiar.setOperId(idOriginal);
		try {
			aCambiar = tOperRepository.save(aCambiar);
		} catch (Exception e) {
			throw new FitravaException(
					String.format(messages.get(CLID, "MSG_ERR_UPDATING_OPERATION3"), aCambiar, e.getCause()));
		}
		return mapper.map(aCambiar, OperacionDTO.class);
	}

	@Override
	@Transactional
	public void deleteOperacion(Integer id) throws ValidationException, FitravaException {
		log.debug(String.format("Executing >>> deleteOperacion(id: %1$s)", id));
		try {
			tOperRepository.deleteById(id);
		} catch (Exception e) {
			throw new FitravaException(
					String.format(messages.get(CLID, "MSG_ERR_DELETING_OPERATION"), id, e.getCause()));
		}
	}

	@Override
	public List<EstatusProcesoDTO> getAllProcesosEstatus() throws ValidationException, FitravaException {
		log.debug("Executing >>> getAllProcesosEstatus()");
		List<TClctStts> dbObjects = null;
		List<EstatusProcesoDTO> dtos = null;

		try {
			dbObjects = tClctSttsRepository.findAll();
		} catch (Exception e) {
			throw new FitravaException(String.format(messages.get(CLID, "MSG_ERR_GETTING_STATUS"), e.getCause()));
		}
		if (dbObjects == null || dbObjects.isEmpty()) {
			throw new FitravaException(messages.get(CLID, "MSG_CANT_FIND_ANY_STATUS"));
		}
		dtos = new ArrayList<>();
		for (TClctStts l : dbObjects) {
			dtos.add(mapper.map(l, EstatusProcesoDTO.class));
		}
		return dtos;
	}

	@Override
	public List<RoleDTO> getAllRoles() throws ValidationException, FitravaException {
		log.debug("Executing >>> findAllRoles()");
		List<TRole> dbObjects = null;
		List<RoleDTO> dtos = null;

		try {
			dbObjects = tRoleRepository.findAll();
		} catch (Exception e) {
			throw new FitravaException(String.format(messages.get(CLID, "MSG_ERR_GETTING_ROLES"), e.getCause()));
		}
		if (dbObjects == null || dbObjects.isEmpty()) {
			throw new FitravaException(messages.get(CLID, "MSG_CANT_FIND_ANY_ROLE"));
		}
		dtos = new ArrayList<>();
		for (TRole l : dbObjects) {
			dtos.add(mapper.map(l, RoleDTO.class));
		}

		// Tratamiento de los menus
		List<MenuDTO> filteredParentsMenus = null;
		List<MenuDTO> submenus = null;
		List<MenuDTO> menus = null;
		for (RoleDTO dto : dtos) {
			filteredParentsMenus = dto.getTmenus().stream().filter(m -> m.getPrntMenuId() == null)
					.collect(Collectors.toList());
			menus = new ArrayList<>();
			for (MenuDTO menu : filteredParentsMenus) {
				menu.setTMenus(null);
				submenus = dto.getTmenus().stream().filter(submenu -> submenu.getPrntMenuId() == menu.getMenuId())
						.collect(Collectors.toList());
				menu.setTMenus(submenus);
				menus.add(menu);
			}
			dto.setTmenus(null);
			dto.setTmenus(menus);
		}
		return dtos;
	}

	@Override
	public List<MenuDTO> getAllMenus() throws ValidationException, FitravaException {
		log.debug("Executing >>> getAllMenus()");
		List<TMenu> dbObjectsFiltered = null;
		List<TMenu> dbObjects = null;
		List<MenuDTO> dtos = null;

		try {
			dbObjects = tMenuRepository.findAll();
			dbObjectsFiltered = dbObjects.stream().filter(e -> !e.getTMenus().isEmpty()).collect(Collectors.toList());

		} catch (Exception e) {
			throw new FitravaException(String.format(messages.get(CLID, "MSG_ERR_GETTING_MENUS"), e.getCause()));
		}
		if (dbObjects == null || dbObjects.isEmpty()) {
			throw new FitravaException(messages.get(CLID, "MSG_CANT_FIND_ANY_MENU"));
		}
		dtos = new ArrayList<>();
		for (TMenu l : dbObjectsFiltered) {
			dtos.add(mapper.map(l, MenuDTO.class));
		}
		return dtos;
	}

	@Override
	public RoleDTO getRoleById(Integer id) throws ValidationException, FitravaException {
		log.debug("Executing >>> getRoleById(id {})", id);
		TRole dbObject = null;
		RoleDTO dto = null;

		try {
			Optional<TRole> optional = tRoleRepository.findById(id);
			if (optional.isPresent()) {
				dbObject = optional.get();
			}
		} catch (Exception e) {
			throw new FitravaException(String.format(messages.get(CLID, "MSG_ERR_GETTING_ROLE2"), e.getCause()));
		}
		if (dbObject == null) {
			throw new FitravaException(messages.get(CLID, "MSG_CANT_FIND_ANY_ROLE2"));
		}
		dto = (mapper.map(dbObject, RoleDTO.class));

		// Tratamiento de los menus
		List<MenuDTO> filteredParentsMenus = null;
		List<MenuDTO> submenus = null;
		List<MenuDTO> menus = null;
		filteredParentsMenus = dto.getTmenus().stream().filter(m -> m.getPrntMenuId() == null)
				.collect(Collectors.toList());
		filteredParentsMenus = filteredParentsMenus.stream().distinct().collect(Collectors.toList());
		menus = new ArrayList<>();
		for (MenuDTO menu : filteredParentsMenus) {
			menu.setTMenus(null);
			submenus = dto.getTmenus().stream().filter(submenu -> submenu.getPrntMenuId() == menu.getMenuId())
					.collect(Collectors.toList());
			menu.setTMenus(submenus);
			menus.add(menu);
		}
		dto.setTmenus(null);
		dto.setTmenus(menus);

		return dto;
	}

}
