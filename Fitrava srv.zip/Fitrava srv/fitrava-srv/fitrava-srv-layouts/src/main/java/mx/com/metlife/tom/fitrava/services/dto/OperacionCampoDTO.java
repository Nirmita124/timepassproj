package mx.com.metlife.tom.fitrava.services.dto;

import org.dozer.Mapping;

import lombok.Data;

@SuppressWarnings("serial")
@Data
public class OperacionCampoDTO implements java.io.Serializable{

	@Mapping("fldOperId")
	private Long fldOperId = null;

	@Mapping("fldOperNm")
	private String fldOperNm = null;

	@Mapping("fldOperDscr")
	private String fldOperDscr = null;

	@Mapping("fldOperClassNm")
	private String fldOperClassNm = null;

	@Mapping("fldOperMthdNm")
	private String fldOperMthdNm = null;


}
