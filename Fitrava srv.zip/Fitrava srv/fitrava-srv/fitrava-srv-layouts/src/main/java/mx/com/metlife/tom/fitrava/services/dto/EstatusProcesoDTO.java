package mx.com.metlife.tom.fitrava.services.dto;

import lombok.Data;

@SuppressWarnings("serial")
@Data
public class EstatusProcesoDTO implements java.io.Serializable{

	private Integer clctSttsId = null;

	private String clctSttsNm = null;


}
