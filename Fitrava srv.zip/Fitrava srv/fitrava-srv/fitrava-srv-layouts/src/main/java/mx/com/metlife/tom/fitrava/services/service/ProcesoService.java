package mx.com.metlife.tom.fitrava.services.service;

import java.io.File;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import mx.com.metlife.tom.fitrava.services.dto.GranArchivoDTO;
import mx.com.metlife.tom.fitrava.services.dto.ProcesoDTO;
import mx.com.metlife.tom.fitrava.services.dto.ProcesoFileDTO;
import mx.com.metlife.tom.fitrava.services.dto.ProcesoRegistroDTO;
import mx.com.metlife.tom.fitrava.services.dto.ProcesoRegistroSumaryDTO;
import mx.com.metlife.tom.fitrava.services.dto.UploadFileDTO;
import mx.com.metlife.tom.fitrava.services.error.FitravaException;
import mx.com.metlife.tom.fitrava.services.error.ValidationException;



public interface ProcesoService {

	ProcesoDTO getProcesoByDcn(String dcn) throws ValidationException, FitravaException;
	
	List<ProcesoDTO> getAllProcesosByFlujoId(Long flujoId) throws ValidationException, FitravaException;
	
	List<ProcesoDTO> getAllProcesosByEaiAndRetainer(String retainerId, String eaiCd) throws ValidationException, FitravaException;
	
	List<ProcesoDTO> getAllProcesosByUsuarioAndEstatus(String usuario, Integer estatus) throws ValidationException, FitravaException;	
	
	ProcesoDTO guardaProceso(ProcesoDTO procesoDTO) throws ValidationException, FitravaException;
	
	ProcesoDTO actualizaProceso(ProcesoDTO procesoDTO) throws FitravaException;	
	
	Boolean actualizaProceso(String dcn, Integer estatus) throws FitravaException;
	
	void deleteProceso(String dcn) throws FitravaException;
	
	ProcesoFileDTO getProcesoFileById(String dcn, String archivo) throws ValidationException, FitravaException;
	
	List<ProcesoFileDTO> getAllProcesoFileByDcn(String dcn) throws ValidationException, FitravaException;
	
	void guardaArchivo(UploadFileDTO uploadFileDTO, MultipartFile...files) throws ValidationException, FitravaException;
	
	List<ProcesoRegistroDTO> getProcRecByDcnAndFileName(String dcn,String fileName)throws ValidationException, FitravaException;
	
	ProcesoRegistroSumaryDTO getProcRecSumByDcnAndFileName(String dcn, String fileName)throws ValidationException, FitravaException;
	
	ProcesoDTO getProcByDcn(String dcn) throws ValidationException, FitravaException;
	
	void procesaArchivo(String dcn) throws ValidationException, FitravaException;
	
	File downloadFiles(String dcn, String fileName)throws FitravaException ;

	void procesaArchivo(UploadFileDTO uploadFileDTO) throws ValidationException, FitravaException;
	
	void validaRuta(String path) throws ValidationException;
	
	//test
	void guardaArchivosGrandes(MultipartFile file, String dcn, String fileName) throws ValidationException, FitravaException;
	
	File downloadGrandesArchivos(String dcn, String fileName)throws FitravaException;
	
	GranArchivoDTO getGrandesArchivos(String dcn, String fileName)throws FitravaException;


}