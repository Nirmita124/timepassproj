package mx.com.metlife.tom.fitrava.services.web.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import mx.com.metlife.tom.fitrava.services.dto.GranArchivoDTO;
import mx.com.metlife.tom.fitrava.services.error.FitravaException;
import mx.com.metlife.tom.fitrava.services.error.ValidationException;
import mx.com.metlife.tom.fitrava.services.service.ProcesoService;
import mx.com.metlife.tom.fitrava.services.utility.Util;

@RestController
@RequestMapping(value = "/uploadbigfilesrv")
public class UploadBigFileFitravaController extends FitravaController {

	@Autowired
	private ProcesoService procesoService;

	@CrossOrigin
	@PostMapping("/v1/saveBigFiles")
	public ResponseEntity<Map<String, Object>> largeFIleUpload(
			@RequestParam(required = true, value = "file") MultipartFile file,
			@RequestParam(required = true, value = "dcn") String dcn,
			@RequestParam(required = false, value = "fileName") String fileName) throws ValidationException, FitravaException 
	{
		log.info("En el largeFIleUploads");
		String originalFilename = file.getOriginalFilename();
		String fileExtension = Util.getExtension(originalFilename);
		log.debug("File recieved: {}, extension: {}", originalFilename, fileExtension);
		
		procesoService.guardaArchivosGrandes(file, dcn, fileName);
		
		Map<String, Object> resp = new HashMap<>();
		
		resp.put("fileName", originalFilename);
		resp.put("fileSize", Double.valueOf(file.getSize())/(1024*1024));
		resp.put("sizeIn", "MB");
		resp.put("fileExtension", fileExtension);
		
		return new ResponseEntity<>(resp, HttpStatus.OK);
	}
	
	@CrossOrigin
	@GetMapping("/v1/downloadBigFiles")
	public ResponseEntity<Resource> downloadErrorData(@RequestParam("dcn") String dcn, @RequestParam("fileName") String fileName) throws FitravaException {
        log.info("En el downloadErrorData(dcn: {}, fileName: {}", dcn, fileName);
        GranArchivoDTO granArchivo = null;
        
        HttpHeaders headers = null;
        ByteArrayResource resource;
		try {
			granArchivo = procesoService.getGrandesArchivos(dcn, fileName);
			log.info("bigFile: {}", granArchivo);
			
	        headers = new HttpHeaders();
	        headers.add("Cache-Control", "no-cache, no-store, must-revalidate");
	        headers.add("Pragma", "no-cache");
	        headers.add("Expires", "0");
	        
	        headers.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + granArchivo.getBigFileNm());
	        resource = new ByteArrayResource(granArchivo.getFile());

	        return ResponseEntity.ok()
	                .headers(headers)
	                .contentLength(granArchivo.getFile().length)
	                .contentType(MediaType.parseMediaType("application/octet-stream"))
	                .body(resource);

		} catch (Exception e) {
				throw new FitravaException("No se pudo enviar el archivo", e);
		}
        
	}
	
}
