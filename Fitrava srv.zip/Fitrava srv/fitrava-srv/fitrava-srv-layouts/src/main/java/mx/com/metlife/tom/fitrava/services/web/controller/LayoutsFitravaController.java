package mx.com.metlife.tom.fitrava.services.web.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import mx.com.metlife.tom.fitrava.services.dto.CharactersSkipDTO;
import mx.com.metlife.tom.fitrava.services.dto.LayoutDTO;
import mx.com.metlife.tom.fitrava.services.dto.LayoutExcelDTO;
import mx.com.metlife.tom.fitrava.services.error.FitravaException;
import mx.com.metlife.tom.fitrava.services.error.ValidationException;
import mx.com.metlife.tom.fitrava.services.service.LayoutService;
import mx.com.metlife.tom.fitrava.services.serviceimpl.beans.FitravaSrvMessages;

@RestController
@RequestMapping(value = "/layoutsrv")
public class LayoutsFitravaController extends FitravaController {

	private static final String CLID = LayoutsFitravaController.class.getSimpleName();
	private static Logger log = LoggerFactory.getLogger(LayoutsFitravaController.class);
	
	@Autowired
	private LayoutService layoutService = null;
	@Autowired
	private FitravaSrvMessages messages;	
	
	//JustForTest
	@GetMapping("/getDate")
	public @ResponseBody ResponseEntity<String> getDate() throws FitravaException {
		return new ResponseEntity<>(layoutService.getDate(), HttpStatus.OK);
	}

	@CrossOrigin
	@GetMapping("/v1/layout")
	public @ResponseBody ResponseEntity<LayoutDTO> getLayout(@RequestParam("layoutId") Long layoutId) throws ValidationException, FitravaException {
		log.info("Executing >>> getLayout(id: {})", layoutId);
		if (layoutId == null || layoutId <= 0) {
			throw new ValidationException(String.format(messages.get(CLID, "MSG_ERR_LAYOUT_ID_CANT_BE_NULL"), layoutId));
		}
		return new ResponseEntity<>(layoutService.getLayoutById(layoutId), HttpStatus.OK);
	}

	@CrossOrigin
	@GetMapping("/v1/layoutByNombre")
	public @ResponseBody ResponseEntity<LayoutDTO> getLayout(@RequestParam("nombre") String nombre) throws ValidationException, FitravaException {
		log.info("Executing >>> getLayout(nombre: {})", nombre);
		if (nombre == null || nombre.trim().length() == 0) {
			throw new ValidationException(String.format(messages.get(CLID, "Msg_ERR_LAYOUT_NAME_ISNT_VALID"), nombre));
		}
		return new ResponseEntity<>(layoutService.getLayoutByName(nombre), HttpStatus.OK);
	}

	@CrossOrigin
	@GetMapping("/v1/allLayouts")
	public @ResponseBody ResponseEntity<List<LayoutDTO>> getAllLayout(@RequestParam("eaiCd") String eai) throws ValidationException, FitravaException {
		log.info("Executing >>> getAllLayout(eai: {})", eai);
		if (eai == null || eai.trim().length()  == 0) {
			throw new ValidationException(String.format(messages.get(CLID, "MSG_ERR_LAYOUT_EAT_CANT_BE_NULL"), eai));
		}
		return new ResponseEntity<>(layoutService.getAllLayoutsByEai(eai), HttpStatus.OK);
	}

	@CrossOrigin
	@PutMapping("/v1/actualiza")
	public @ResponseBody ResponseEntity<LayoutDTO> putActualiza(@RequestBody LayoutDTO layoutDTO) throws ValidationException, FitravaException {
		log.info("Executing >>> putActualiza(layoutId: {})", layoutDTO);
		if (layoutDTO == null) {
			throw new ValidationException(messages.get(CLID, "MSG_ERR_LAYOUT_CANT_BE_NULL"));
		}
		if (layoutDTO.getLayoutId() == null || layoutDTO.getLayoutId() <= 0) {
			throw new ValidationException(messages.get(CLID, "MSG_ERR_LAYOUT_ID_CANT_BE_NULL2"));
		}
		return new ResponseEntity<>(layoutService.actualizaLayout(layoutDTO), HttpStatus.OK);
	}
	
	@CrossOrigin
	@PostMapping("/v1/guarda")
	public @ResponseBody ResponseEntity<LayoutDTO> postGuarda(@RequestBody LayoutDTO layoutDTO) throws ValidationException, FitravaException {
		log.info("Executing >>> postGuarda(layoutId: {})", layoutDTO);
		if (layoutDTO == null ) {
			throw new ValidationException(messages.get(CLID, "MSG_ERR_LAYOUT_CANT_BE_NULL2"));
		}
		return new ResponseEntity<>(layoutService.guardaLayout(layoutDTO), HttpStatus.OK);
	}

	@CrossOrigin
	@PutMapping("/v1/activaLayout")
	public @ResponseBody ResponseEntity<Boolean> putActivaLayout(@RequestParam("layoutId") Long layoutId) throws ValidationException, FitravaException {
		log.info("Executing >>> putActivaLayout(layoutId: {})", layoutId);
		if (layoutId == null || layoutId <= 0) {
			throw new ValidationException(messages.get(CLID, "MSG_ERR_ID_CANT_BE_NULL"));
		}
		return new ResponseEntity<>(layoutService.actualizaActivaLayout(layoutId), HttpStatus.OK);
	}

	
	@CrossOrigin
	@DeleteMapping("/v1/borra")
	public @ResponseBody ResponseEntity<Boolean> deleteLayout(@RequestParam("layoutId") Long layoutId) throws FitravaException {
		log.info("Executing >>> deletLayout(layoutId: {})", layoutId);
		layoutService.deleteLayout(layoutId);
		return new ResponseEntity<>(Boolean.TRUE, HttpStatus.OK);
	}
	
	@CrossOrigin
	@GetMapping("/v1/getAllLayoutsByEai")
	public @ResponseBody ResponseEntity<List<LayoutDTO>> getAllLayoutsByEai(@RequestParam("eaiCd") String eai, @RequestParam("ext") String ext) throws ValidationException, FitravaException {
		log.info("Executing >>> getAllLayout(eai: {}, ext: {})", eai, ext);
		if (eai == null || eai.trim().length()  == 0) {
			throw new ValidationException(String.format(messages.get(CLID, "MSG_ERR_LAYOUT_EAT_CANT_BE_NULL"), eai));
		}
		return new ResponseEntity<>(layoutService.getAllLayoutsIntoFlowsByEai(eai, ext), HttpStatus.OK);
	}
	
	
	@CrossOrigin
	@DeleteMapping("/v1/borraLayoutExcel")
	public @ResponseBody ResponseEntity<Boolean> deleteLayoutExcel(@RequestParam("layoutId") Long layoutId, @RequestParam("xcelSheetNm") String xcelSheetNm) throws FitravaException {
		log.info("Executing >>> deleteLayoutExcel(layoutId: {}, xcelSheetNm: {})",layoutId,xcelSheetNm);
		layoutService.deleteLayoutExcel(layoutId, xcelSheetNm);
		return new ResponseEntity<>(Boolean.TRUE, HttpStatus.OK);
	}
	
	@CrossOrigin
	@PostMapping("/v1/guardaLayoutExcel")
	public @ResponseBody ResponseEntity<List<LayoutExcelDTO>> postGuardaLayoutExcel(@RequestBody List<LayoutExcelDTO> lstLayoutExcelDTO) throws ValidationException, FitravaException {
		log.info("Executing >>> postGuardaLayoutExcel(lstLayoutExcelDTO: {})", lstLayoutExcelDTO);
		if (lstLayoutExcelDTO == null || lstLayoutExcelDTO.isEmpty()) {
			throw new ValidationException(messages.get(CLID, "MSG_ERR_LAYOUT_CANT_BE_NULL2"));
		}
		return new ResponseEntity<>(layoutService.guardaLstLayoutExcel(lstLayoutExcelDTO), HttpStatus.OK);
	}
	
	@CrossOrigin
	@PutMapping("/v1/actualizaLayoutExcel/{layoutId}")
	public @ResponseBody ResponseEntity<List<LayoutExcelDTO>> putGuardaLayoutExcel(@PathVariable("layoutId") Long layoutId,@RequestBody List<LayoutExcelDTO> lstLayoutExcelDTO) throws ValidationException, FitravaException {
		log.info("Executing >>> postGuardaLayoutExcel(lstLayoutExcelDTO: {})", lstLayoutExcelDTO);
		if (layoutId== null) {
			throw new ValidationException(messages.get(CLID, "MSG_ERR_LAYOUT_CANT_BE_NULL2"));
		}
		return new ResponseEntity<>(layoutService.actualizaLstLayoutExcel(layoutId, lstLayoutExcelDTO), HttpStatus.OK);
	}
	
	@CrossOrigin
	@PostMapping("/v1/guardaCaracteresOmitir")
	public @ResponseBody ResponseEntity<List<CharactersSkipDTO>> postGuardaCaracteresOmitir(@RequestBody List<CharactersSkipDTO> lstCharactersToSkip) throws ValidationException, FitravaException {
		log.info("Executing >>> postGuardaCaracteresOmitir(lstCharactersToSkip: {})", lstCharactersToSkip);
		if (lstCharactersToSkip == null || lstCharactersToSkip.isEmpty()) {
			throw new ValidationException(messages.get(CLID, "MSG_ERR_LAYOUT_CANT_BE_NULL2"));
		}
		return new ResponseEntity<>(layoutService.guardaLstCharactersToSkip(lstCharactersToSkip), HttpStatus.OK);
	}
	
	@CrossOrigin
	@PutMapping("/v1/actualizaCaracteresOmitir/{layoutId}")
	public @ResponseBody ResponseEntity<List<CharactersSkipDTO>> putActualizaCaracteresOmitir(@PathVariable("layoutId") Long layoutId,@RequestBody List<CharactersSkipDTO> lstCharactersToSkip) throws ValidationException, FitravaException {
		log.info("Executing >>> putActualizaCaracteresOmitir(layoutId: {}, lstLayoutExcelDTO: {})",layoutId, lstCharactersToSkip);
		if (layoutId== null) {
			throw new ValidationException(messages.get(CLID, "MSG_ERR_LAYOUT_CANT_BE_NULL2"));
		}
		return new ResponseEntity<>(layoutService.actualizaLstCharactersToSkip(layoutId, lstCharactersToSkip), HttpStatus.OK);
	}
	
	@CrossOrigin
	@GetMapping("/v1/getCaracteresOmitir")
	public @ResponseBody ResponseEntity<List<CharactersSkipDTO>> getCaracteresOmitir(@RequestParam("layoutId") Long layoutId) throws ValidationException, FitravaException {
		log.info("Executing >>> getActualizaCaracteresOmitir(layoutId: {})", layoutId);
		if (layoutId== null) {
			throw new ValidationException(messages.get(CLID, "MSG_ERR_LAYOUT_CANT_BE_NULL2"));
		}
		return new ResponseEntity<>(layoutService.getLstCharactersToSkip(layoutId), HttpStatus.OK);
	}
	
}
