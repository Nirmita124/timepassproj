package mx.com.metlife.tom.fitrava.services.error;

import lombok.Data;

/**
 * This class is created to handle the error message.
 * 
 * @author Capgemini
 * @since 03/15/2019
 *
 */
@Data
public class ErrorExtensionVO {

	private String providerCode;
	private String providerDescription;

	public ErrorExtensionVO() {
	}

	public ErrorExtensionVO(String providerCode, String providerDescription) {

		this.providerCode = providerCode;
		this.providerDescription = providerDescription;
	}

}
