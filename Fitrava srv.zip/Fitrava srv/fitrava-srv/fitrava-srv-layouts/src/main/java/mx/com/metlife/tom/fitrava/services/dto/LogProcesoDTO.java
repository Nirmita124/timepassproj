package mx.com.metlife.tom.fitrava.services.dto;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@SuppressWarnings("serial")
@Data
@Entity
@Table(name = "T_LOG_PROC")
public class LogProcesoDTO implements java.io.Serializable{

	@Id
	@Column(name = "DSTNCT_CTRL_NUM")
	private String dstnctCtrlNum = null;

	@Column(name = "CLCT_STTS_ID")
	private Integer clctSttsId = null;

	@Column(name = "LOG_PROC_STRT_TS")
	private Date logProcStrtTs = null;

	@Column(name = "LOG_PROC_END_TS")
	private Date logProcEndTs = null;


}
