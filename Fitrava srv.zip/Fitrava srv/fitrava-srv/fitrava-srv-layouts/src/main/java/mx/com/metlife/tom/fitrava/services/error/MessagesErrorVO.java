package mx.com.metlife.tom.fitrava.services.error;

import lombok.Data;

/**
 * This class is used to handle error messages.
 * 
 * @author Capgemini
 * @since 03/15/2019
 */
@Data
public class MessagesErrorVO {

	private String code;
	private String description;
	private String element;
	private ErrorExtensionVO extension;

	public MessagesErrorVO() {
	}

	public MessagesErrorVO(String code, String description, String element, ErrorExtensionVO extension) {
		this.code = code;
		this.description = description;
		this.element = element;
		this.extension = extension;
	}
}
