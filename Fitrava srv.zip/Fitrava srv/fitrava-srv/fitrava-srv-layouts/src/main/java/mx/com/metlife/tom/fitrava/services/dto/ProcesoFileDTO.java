package mx.com.metlife.tom.fitrava.services.dto;

import java.util.Date;
import java.util.List;

import org.dozer.Mapping;

import lombok.Data;

@SuppressWarnings("serial")
@Data
public class ProcesoFileDTO implements java.io.Serializable{

	@Mapping("dstnctCtrlNum")
	private String dcn = null;

	private String fileNm = null;

	private Integer procFileOrdNum = null;

	private Integer clctSttsId = null;

	private Date procFileStrtTs = null;

	private Date procFileEndTs = null;


	private List<ProcesoRegistroDTO> listProcesoRegistro = null;
	
	private ProcesoRegistroSumaryDTO tProcRecSum = null;

	private LayoutDTO layoutEntrada = null;
}
