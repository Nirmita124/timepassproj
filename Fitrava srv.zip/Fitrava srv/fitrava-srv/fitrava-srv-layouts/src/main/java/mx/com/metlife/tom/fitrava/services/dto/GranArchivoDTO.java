package mx.com.metlife.tom.fitrava.services.dto;

import java.util.Date;

import lombok.Data;

@Data
public class GranArchivoDTO implements java.io.Serializable {

	private static final long serialVersionUID = 6481543862297511980L;

	private Integer fileId;
	private byte[] file;
	private Double sizeMB;
	private String bigFileNm;
	private String dstnctCtrlNum;
	private Date uloadDt;
	private String crtUsrId;

}
