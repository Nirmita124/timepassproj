package mx.com.metlife.tom.fitrava.services.service;

import mx.com.metlife.tom.fitrava.services.error.FitravaException;
import mx.com.metlife.tom.fitrava.services.error.ValidationException;

import java.util.List;

import javax.transaction.Transactional;

import mx.com.metlife.tom.fitrava.services.dto.RoleMenuDTO;
import mx.com.metlife.tom.fitrava.services.dto.UserDTO;
import mx.com.metlife.tom.fitrava.services.dto.RoleDTO;

public interface UserManagementService {

	UserDTO saveUser(UserDTO userDto)throws ValidationException, FitravaException;
	
	List<UserDTO> findAllUser()throws ValidationException, FitravaException;	
	
	UserDTO findById(String id)throws ValidationException, FitravaException;
	
	Boolean updateUser(String id, Integer roleId, Integer status) throws ValidationException, FitravaException;
	
	List<RoleMenuDTO> findAllRoleMenus()throws ValidationException, FitravaException;
	
	RoleDTO updateRole(RoleDTO roleDto)throws ValidationException, FitravaException;
	
	@Transactional
	void deleteRoleMenuByRoleId(Integer id)throws ValidationException, FitravaException;
}
