package mx.com.metlife.tom.fitrava.services.dto;

import lombok.Data;

@Data
public class UploadExternalDataDTO implements java.io.Serializable{

	private static final long serialVersionUID = 30994389505055382L;
	
	private Long uloadExternalDataId;
	
	private String dstnctCtrlNum;
	
	private String key;
	
	private String value;
}
