package mx.com.metlife.tom.fitrava.services.dto;

import lombok.Data;

@Data
public class LayoutExcelDTO implements java.io.Serializable {

	private static final long serialVersionUID = 7050492616033000367L;
	
	private Long  layoutId= null;
	
	private String  xcelSheetNm= null;

}
