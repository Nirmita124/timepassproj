package mx.com.metlife.tom.fitrava.services.utility;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.ObjectMapper;

public class JavaToJson {

	private static final Logger log = LoggerFactory.getLogger(JavaToJson.class);
	
	public static void main(String[] args) {
		ObjectMapper Obj = null;
    	Map<String, String> ob = null;
        String jsonStr = null;
	    try { 
			Obj = new ObjectMapper(); 
	    	ob = new HashMap<>();
	        jsonStr = Obj.writeValueAsString(ob); 
	        // Displaying JSON String 
	        log.info(jsonStr); 
	    } 
	    catch (IOException e) { 
	        log.error("Error: {} ", e.getMessage());
	    } 
	}
}
