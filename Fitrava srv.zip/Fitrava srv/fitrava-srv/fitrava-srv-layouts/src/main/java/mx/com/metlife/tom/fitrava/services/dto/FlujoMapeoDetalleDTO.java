package mx.com.metlife.tom.fitrava.services.dto;

import lombok.Data;

@Data
public class FlujoMapeoDetalleDTO implements java.io.Serializable {

	private static final long serialVersionUID = 5732092710983497069L;

	private Long flowMappingId = null;
	private Long flowId = null;
	private Long outLayoutFldId = null;
	private Long entrncLayoutFldId = null;
	
	
}
