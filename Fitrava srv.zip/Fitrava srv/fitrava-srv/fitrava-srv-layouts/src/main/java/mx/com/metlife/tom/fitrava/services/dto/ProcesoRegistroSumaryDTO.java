package mx.com.metlife.tom.fitrava.services.dto;

import java.util.List;

import org.dozer.Mapping;

import lombok.Data;

@SuppressWarnings("serial")
@Data
public class ProcesoRegistroSumaryDTO implements java.io.Serializable {

	@Mapping("dstnctCtrlNum")
	private String dcn = null;

	private Integer procRecSumSeqNum = null;

	private String fileNm = null;

	private String extCd = null;

	private Integer clctSttsId = null;

	private Long totRecCnt = null;

	private Long totErrRecCnt = null;


	private List<ProcesoRegistroSumaryDetalleDTO> listTProcRecSumDtl = null;
}
