package mx.com.metlife.tom.fitrava.services.web.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import mx.com.metlife.tom.fitrava.services.dto.FlujoArchivoDTO;
import mx.com.metlife.tom.fitrava.services.dto.FlujoDTO;
import mx.com.metlife.tom.fitrava.services.dto.FlujoMapeoDTO;
import mx.com.metlife.tom.fitrava.services.error.FitravaException;
import mx.com.metlife.tom.fitrava.services.error.ValidationException;
import mx.com.metlife.tom.fitrava.services.service.FlujoService;
import mx.com.metlife.tom.fitrava.services.serviceimpl.beans.FitravaSrvMessages;
import mx.com.metlife.tom.fitrava.services.utility.Util;

@RestController
@RequestMapping(value = "/flujosrv")
public class FlowFitravaController extends FitravaController {

	private static final String CLID = FlowFitravaController.class.getSimpleName();
	private static Logger log = LoggerFactory.getLogger(FlowFitravaController.class);

	@Autowired
	private FlujoService flujoService;
	@Autowired
	private FitravaSrvMessages messages;	
	
	@CrossOrigin
	@GetMapping("/v1/flujo")
	public @ResponseBody ResponseEntity<FlujoDTO> getFlujo(@RequestParam("flujoId") Long flujoId) throws ValidationException, FitravaException {
		log.info("Executing >>> getFlujo(flujoId: {})", flujoId);
		if (flujoId == null || flujoId <= 0) {
			throw new ValidationException(String.format(messages.get(CLID, "MSG_ERR_FLOW_ID_CANT_BE_NULL"), flujoId));
		}
		return new ResponseEntity<>(flujoService.getFlujoById(flujoId), HttpStatus.OK);
	}	

	@CrossOrigin
	@GetMapping("/v1/allFlujos")
	public @ResponseBody ResponseEntity<List<FlujoDTO>> getAllFlujos
		(@RequestParam(value = "retenedorId", required = false) String retenedorId, 
				@RequestParam(value = "eaiCd", required = false) String eaiCd) 
						throws ValidationException, FitravaException {
		
		log.info("Executing >>> getAllFlujos(retenedorId: {}, eaiCd: {})", retenedorId, eaiCd);
		if ((retenedorId == null || retenedorId.trim().length() == 0) && (eaiCd == null || eaiCd.trim().length() == 0)) {
			throw new ValidationException(messages.get(CLID, "MSG_ERR_RETID_AND_EAI_CANT_BE_NULL"));
		}
		return new ResponseEntity<>(flujoService.getAllFlujosBy(retenedorId, eaiCd), HttpStatus.OK);
	}	

	@CrossOrigin
	@PostMapping("/v1/guardaFlujo")
	public @ResponseBody ResponseEntity<FlujoDTO> postGuardaFlujo(@RequestBody FlujoDTO flujoDTO) throws ValidationException, FitravaException {
		log.info("Executing >>> postGuardaFlujo(flujoDTO: {})", flujoDTO);
		if (flujoDTO == null) {
			throw new ValidationException(messages.get(CLID, "MSG_ERR_FLOW_TO_SAVE_IS_NULL"));
		}
		return new ResponseEntity<>(flujoService.guardaFlujo(flujoDTO), HttpStatus.OK);
	}

	@CrossOrigin
	@PutMapping("/v1/actualizaFlujo")
	public @ResponseBody ResponseEntity<FlujoDTO> putActualizaFlujo(@RequestBody FlujoDTO flujoDTO) throws ValidationException, FitravaException {
		log.info("Executing >>> putActualizaFlujo(flujoDTO: {})", flujoDTO);
		if (flujoDTO == null ) {
			throw new ValidationException(messages.get(CLID, "MSG_ERR_FLOW_TO_UPDATE_IS_NULL"));
		}
		if (flujoDTO.getFlowId() == null || flujoDTO.getFlowId() <= 0) {
			throw new ValidationException(messages.get(CLID, "MSG_ERR_FLOW_ID_ISNT_VALID"));
		}
		return new ResponseEntity<>(flujoService.actualizaFlujo(flujoDTO), HttpStatus.OK);
	}
	
	@CrossOrigin
	@PutMapping("/v1/activaFlujo")
	public @ResponseBody ResponseEntity<Boolean> putActivaFlujo(@RequestParam("flujoId") Long flujoId) throws ValidationException, FitravaException{
		log.info("Executing >>> putActivaFlujo(flujoId: {})", flujoId);
		if (flujoId == null || flujoId <= 0) {
			throw new ValidationException(messages.get(CLID, "MSG_ERR_FLOW_ID_CANT_BE_NULL_2"));
		}
		return new ResponseEntity<>(flujoService.actualizaActivaFlujo(flujoId), HttpStatus.OK);
	}

	@CrossOrigin
	@DeleteMapping("/v1/borraFlujo")
	public @ResponseBody ResponseEntity<Boolean> deleteFlujo(@RequestParam("flujoId") Long flujoId) throws ValidationException, FitravaException {
		log.info("Executing >>> deleteFlujo(flujoId: {})", flujoId);
		if (flujoId == null || flujoId <= 0) {
			throw new ValidationException(messages.get(CLID, "MSG_ERR_FLOW_ID_CANT_BE_NULL"));
		}
		flujoService.deleteFlujo(flujoId);
		return new ResponseEntity<>(Boolean.TRUE, HttpStatus.OK);
	}

	@CrossOrigin
	@GetMapping("/v1/flujoArchivo")
	public @ResponseBody ResponseEntity<FlujoArchivoDTO> getFlujoArchivo(@RequestParam("flujoArchivoId") Integer flujoArchivoId) throws ValidationException, FitravaException {
		log.info("Executing >>> getFlujoArchivoById(flujoArchivoId: {})", flujoArchivoId);
		if (flujoArchivoId == null || flujoArchivoId <= 0) {
			throw new ValidationException(String.format(messages.get(CLID, "MSG_ERR_FILEFLOW_ID_CANT_BE_NULL_S1"), flujoArchivoId));
		}
		return new ResponseEntity<>(flujoService.getFlujoArchivoById(flujoArchivoId), HttpStatus.OK);
	}

	@CrossOrigin
	@GetMapping("/v1/allFlujosArchivos")
	public @ResponseBody ResponseEntity<List<FlujoArchivoDTO>> getAllFlujosArchivos(@RequestParam("flujoId") Long flujoId) throws ValidationException, FitravaException {
		log.info("Executing >>> getAllFlujosArchivos(flujoId: {})", flujoId);
		if (flujoId == null || flujoId <= 0) {
			throw new ValidationException(messages.get(CLID, "MSG_ERR_FLOWID_CANT_BE_NULL"));
		}
		return new ResponseEntity<>(flujoService.getAllFlujosArchivoByFlujoId(flujoId), HttpStatus.OK);
	}

	@CrossOrigin
	@PostMapping("/v1/guardaFlujosArchivos")
	public @ResponseBody ResponseEntity<FlujoArchivoDTO> postGuardaFlujoArchivo(@RequestBody FlujoArchivoDTO flujoArchivoDTO) throws ValidationException, FitravaException {
		log.info("Executing >>> postGuardaFlujoArchivo(flujoArchivoDTO: {})", flujoArchivoDTO);
		if (flujoArchivoDTO == null) {
			throw new ValidationException(messages.get(CLID, "MSG_ERR_FLOW_CANT_BE_NULL"));
		}
		return new ResponseEntity<>(flujoService.guardaFlujoArchivo(flujoArchivoDTO), HttpStatus.OK);
	}

	@CrossOrigin
	@PutMapping("/v1/actualizaFlujosArchivos")
	public @ResponseBody ResponseEntity<FlujoArchivoDTO> putActualizaFlujoArchivo(@RequestBody FlujoArchivoDTO flujoArchivoDTO) throws ValidationException, FitravaException {
		log.info("Executing >>> putActualizaFlujoArchivo(flujoArchivoDTO: {})", flujoArchivoDTO);
		if (flujoArchivoDTO == null ) {
			throw new ValidationException(messages.get(CLID, "MSG_ERR_FLOW_CANT_BE_NULL"));
		}
		return new ResponseEntity<>(flujoService.actualizaFlujoArchivo(flujoArchivoDTO), HttpStatus.OK);
	}

	@CrossOrigin
	@DeleteMapping("/v1/borraFlujosArchivos")
	public @ResponseBody ResponseEntity<Boolean> deleteFlujoArchivo(@RequestParam("flujoArchivoId") Integer flujoArchivoId) throws ValidationException, FitravaException {
		log.info("Executing >>> deleteFlujoArchivo(flujoArchivoId: {})", flujoArchivoId);
		if (flujoArchivoId == null || flujoArchivoId <= 0) {
			throw new ValidationException(messages.get(CLID, "MSG_ERR_FILEFLOW_ID_CANT_BE_NULL"));
		}
		flujoService.deleteFlujoArchivo(flujoArchivoId);
		return new ResponseEntity<>(Boolean.TRUE, HttpStatus.OK);
	}
	

	@CrossOrigin
	@PutMapping("/v1/addOrReplaceAllLayouts/entrada")
	public @ResponseBody ResponseEntity<Boolean> putAddOrReplaceAllLayoutsEntrada(@RequestParam("flujoId") Long flujoId, @RequestParam("layoutIds") Long... layoutIds) throws ValidationException, FitravaException {
		log.info("Executing >>> putAddOrReplaceAllLayoutsEntrada(flujoId: {}, layoutIds: {})", flujoId, Util.getArrayToString(layoutIds));
		if (flujoId == null ) {
			throw new ValidationException(messages.get(CLID, "MSG_ERR_FLOW_CANT_BE_NULL2"));
		}
		if (layoutIds == null || layoutIds.length == 0) {
			throw new ValidationException(messages.get(CLID, "MSG_ERR_LAYOUTS_CANT_BE_NULL"));
		}
		flujoService.addOrReplaceAllLayoutsEntrada(flujoId, layoutIds);
		return new ResponseEntity<>(Boolean.TRUE, HttpStatus.OK);
	}

	@CrossOrigin
	@PutMapping("/v1/addOrReplaceLayout/entrada")
	public @ResponseBody ResponseEntity<Boolean> putAddOrReplaceLayoutEntrada(@RequestParam("flujoId") Long flujoId, @RequestParam("layoutId") Long layoutId) throws ValidationException, FitravaException {
		log.info("Executing >>> putAddOrReplaceLayoutEntrada(flujoId: {}, layoutId: {})", flujoId, layoutId);
		if (flujoId == null || flujoId < 0) {
			throw new ValidationException(messages.get(CLID, "MSG_ERR_FLOW_ID_CANT_BE_NULL"));
		}
		if (layoutId == null || layoutId < 0) {
			throw new ValidationException(messages.get(CLID, "MSG_ERR_LAYOUT_ID_CANT_BE_NULL"));
		}
		flujoService.addOrReplaceLayoutEntrada(flujoId, layoutId);
		return new ResponseEntity<>(Boolean.TRUE, HttpStatus.OK);
	}

	@CrossOrigin
	@PutMapping("/v1/addOrReplaceLayout/salida")
	public @ResponseBody ResponseEntity<Boolean> putAddOrReplaceLayoutSalida(@RequestParam("flujoId") Long flujoId, @RequestParam("layoutId") Long layoutId) throws ValidationException, FitravaException {
		log.info("Executing >>> putAddOrReplaceLayoutSalida(flujoId: {}, layoutId: {})", flujoId, layoutId);
		if (flujoId == null || flujoId < 0) {
			throw new ValidationException(messages.get(CLID, "MSG_ERR_FLOW_ID_CANT_BE_NULL"));
		}
		if (layoutId == null || layoutId < 0) {
			throw new ValidationException(messages.get(CLID, "MSG_ERR_LAYOUT_ID_CANT_BE_NULL"));
		}
		flujoService.addOrReplaceLayoutSalida(flujoId, layoutId);
		return new ResponseEntity<>(Boolean.TRUE, HttpStatus.OK);
	}
	
	@CrossOrigin
	@DeleteMapping("/v1/deleteLayoutFromFlujo")
	public @ResponseBody ResponseEntity<Boolean> deleteLayoutFromFlujo(@RequestParam("flujoId")Long flujoId, @RequestParam("layoutId")Long layoutId) throws ValidationException, FitravaException {
		log.info("Executing >>> deleteLayoutFromFlujo(flujoId: {}, layoutId: {})", flujoId, layoutId);
		if (flujoId == null || flujoId < 0) {
			throw new ValidationException(messages.get(CLID, "MSG_ERR_FLOW_ID_CANT_BE_NULL"));
		}
		if (layoutId == null || layoutId < 0) {
			throw new ValidationException(messages.get(CLID, "MSG_ERR_LAYOUT_ID_CANT_BE_NULL"));
		}
		flujoService.deleteLayoutFromFlujo(flujoId, layoutId);
		return new ResponseEntity<>(Boolean.TRUE, HttpStatus.OK);
	}
	
	
	@CrossOrigin
	@GetMapping("/v1/mapeo")
	public @ResponseBody ResponseEntity<FlujoMapeoDTO> getFlujoMapeo(@RequestParam("flujoMapeoId") Long flujoMapeoId) throws ValidationException, FitravaException {
		log.info("Executing >>> getFlujoMapeo(flujoMapeoId: {})", flujoMapeoId);
		if (flujoMapeoId == null || flujoMapeoId <= 0) {
			throw new ValidationException(String.format(messages.get(CLID, "MSG_ERR_MAPFLOW_ID_CANT_BE_NULL"), flujoMapeoId));
		}
		return new ResponseEntity<>(flujoService.getFlujoMapeoById(flujoMapeoId), HttpStatus.OK);
	}	

	@CrossOrigin
	@GetMapping("/v1/allFlujoMapeos")
	public @ResponseBody ResponseEntity<List<FlujoMapeoDTO>> getAllFlujoMapeos(@RequestParam("flujoId") Long flujoId, @RequestParam("layoutEntradaId") Long layoutEntradaId) throws ValidationException, FitravaException {
		log.info("Executing >>> getAllFlujoMapeos(flujoId: {})", flujoId);
		if (flujoId == null || flujoId <= 0) {
			throw new ValidationException(messages.get(CLID, "MSG_ERR_FLOWID_ISNT_VALID"));
		}
		if (layoutEntradaId == null || layoutEntradaId <= 0) {
			throw new ValidationException(messages.get(CLID, "MSG_ERR_INPUT_LAYOUT_ID_ISNT_VALID"));
		}
		return new ResponseEntity<>(flujoService.getAllFlujoMapeosByFlujoIdAndLayoutEntradaId(flujoId, layoutEntradaId), HttpStatus.OK);
	}

	@CrossOrigin
	@PostMapping("/v1/guardaFlujoMapeo")
	public @ResponseBody ResponseEntity<FlujoMapeoDTO> postGuardaFlujoMapeo(@RequestBody FlujoMapeoDTO flujoMapeoDTO) throws ValidationException, FitravaException {
		log.info("Executing >>> postGuardaFlujoMapeo(flujoMapeoDTO: {})", flujoMapeoDTO);
		if (flujoMapeoDTO == null) {
			throw new ValidationException(messages.get(CLID, "MSG_ERR_MAPFLOW_TO_SAVE_IS_NULL"));
		}
		return new ResponseEntity<>(flujoService.guardaFlujoMapeo(flujoMapeoDTO), HttpStatus.OK);
	}

	@CrossOrigin
	@PutMapping("/v1/actualizaFlujoMapeo")
	public @ResponseBody ResponseEntity<FlujoMapeoDTO> putActualizaFlujoMapeo(@RequestBody FlujoMapeoDTO flujoMapeoDTO) throws ValidationException, FitravaException {
		log.info("Executing >>> putActualizaFlujoMapeo(flujoMapeoDTO: {})", flujoMapeoDTO);
		if (flujoMapeoDTO == null ) {
			throw new ValidationException(messages.get(CLID, "MSG_ERR_MAPFLOW_TO_UPDATE_IS_NULL"));
		}
		if (flujoMapeoDTO.getFlowMappingId() == null || flujoMapeoDTO.getFlowMappingId() <= 0) {
			throw new ValidationException(messages.get(CLID, "MSG_MAPFLOW_ID_ISNT_VALID"));
		}
		flujoService.deleteFlujoMapeoDtl(flujoMapeoDTO.getFlowMappingId());
		return new ResponseEntity<>(flujoService.actualizaFlujoMapeo(flujoMapeoDTO), HttpStatus.OK);
	}	

	@CrossOrigin
	@DeleteMapping("/v1/borraFlujoMapeo")
	public @ResponseBody ResponseEntity<Boolean> deleteFlujoMapeo(@RequestParam("flujoMapeoId") Long flujoMapeoId) throws ValidationException, FitravaException {
		log.info("Executing >>> deleteFlujoMapeo(flujoMapeoId: {})", flujoMapeoId);
		if (flujoMapeoId == null || flujoMapeoId <= 0) {
			throw new ValidationException(messages.get(CLID, "MSG_ID_CANT_BE_NULL"));
		}
		flujoService.deleteFlujoMapeo(flujoMapeoId);
		return new ResponseEntity<>(Boolean.TRUE, HttpStatus.OK);
	}
	
	
	@CrossOrigin
	@GetMapping("/v1/getFlowsByEaiAndExt")
	public @ResponseBody ResponseEntity<List<FlujoDTO>> getFlowsByEaiAndExt(@RequestParam("eaiCd") String eai, @RequestParam("ext") String ext) throws ValidationException, FitravaException {
		log.info("Executing >>> getFlowsByEaiAndExt(eai: {}, ext: {})", eai, ext);
		if (eai == null || eai.trim().length()  == 0) {
			throw new ValidationException(String.format(messages.get(CLID, "MSG_ERR_FLOW_EAT_CANT_BE_NULL"), eai));
		}
		return new ResponseEntity<>(flujoService.getFlowsByEaiAndExt(eai, ext), HttpStatus.OK);
	}
	
}
