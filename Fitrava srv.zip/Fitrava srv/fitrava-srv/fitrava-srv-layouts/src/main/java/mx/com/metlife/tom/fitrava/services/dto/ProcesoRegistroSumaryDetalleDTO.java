package mx.com.metlife.tom.fitrava.services.dto;

import org.dozer.Mapping;

import lombok.Data;

@SuppressWarnings("serial")
@Data
public class ProcesoRegistroSumaryDetalleDTO implements java.io.Serializable{

	@Mapping("dstnctCtrlNum")
	private String dcn = null;

	private Integer procRecSumSeqNum = null;

	private Long layoutFldId = null;

	private String recSumVal = null;

	private String rsltMsgTxt = null;


}
