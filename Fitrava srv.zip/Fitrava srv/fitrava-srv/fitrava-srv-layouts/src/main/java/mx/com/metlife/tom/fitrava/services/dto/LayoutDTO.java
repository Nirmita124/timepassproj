package mx.com.metlife.tom.fitrava.services.dto;

import java.util.Date;
import java.util.List;

import lombok.Data;

@Data
public class LayoutDTO implements java.io.Serializable {

	private static final long serialVersionUID = 7050492616033000367L;

	private Long layoutId = null;

	private String eaiCd = null;

	private Boolean layoutActInd = null;

	private String layoutNm = null;

	private String layoutDscr = null;

	private Integer xpctRecLnthNum = null;

	private Boolean hdInd = null;

	private Boolean ftrInd = null;

	private String extCd = null;

	private Boolean dlmtInd = null;
	
	private String dlmtChar = null;

	private Integer omitInitRecCnt = null;

	private String crtUsrId = null;

	private Date crtTs = null;

	private String updtUsrId = null;	

	private Date updtTs = null;
	
	private Integer numColumns = null;
	
	private List<CampoDTO> listTLayoutFld;

	private List<HeaderFooterDTO> listTLayoutHd;
	
	private List<LayoutExcelDTO> lstTLayoutXcel;
	
//	private Float errorUmbral = null;
}
