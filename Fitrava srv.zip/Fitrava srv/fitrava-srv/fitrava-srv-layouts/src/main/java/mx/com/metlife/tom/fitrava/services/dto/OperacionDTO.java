package mx.com.metlife.tom.fitrava.services.dto;

import org.dozer.Mapping;

import lombok.Data;

@SuppressWarnings("serial")
@Data
public class OperacionDTO implements java.io.Serializable{

	@Mapping("operId")
	private Integer operId = null;
	
	@Mapping("operNm")
	private String operNm = null;

	@Mapping("operDscr")
	private String operDscr = null;

	@Mapping("operClassNm")
	private String operClassNm = null;

	@Mapping("operMthdDscr")
	private String operMthdDscr = null;

}
