package mx.com.metlife.tom.fitrava.services.serviceimpl;

import static org.slf4j.LoggerFactory.getLogger;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.List;
import java.util.Vector;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Service;

import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpATTRS;
import com.jcraft.jsch.SftpException;
import com.jcraft.jsch.SftpProgressMonitor;

import mx.com.metlife.tom.fitrava.services.dto.DownloadCatalogDTO;
import mx.com.metlife.tom.fitrava.services.error.FitravaException;
import mx.com.metlife.tom.fitrava.services.error.ValidationException;
import mx.com.metlife.tom.fitrava.services.model.entity.TApp;
import mx.com.metlife.tom.fitrava.services.model.entity.TProcFile;
import mx.com.metlife.tom.fitrava.services.model.entity.TUloadExt;
import mx.com.metlife.tom.fitrava.services.model.repository.TAppRepository;
import mx.com.metlife.tom.fitrava.services.model.repository.TLayoutRepository;
import mx.com.metlife.tom.fitrava.services.model.repository.TProcFileRepository;
import mx.com.metlife.tom.fitrava.services.model.repository.TUloadExtRepository;
import mx.com.metlife.tom.fitrava.services.utility.Util;

@Service
@PropertySource("classpath:${env_var:dev}-fitrava.properties")
public class SFTPSrevice {

	private static final Logger logger = getLogger(SFTPSrevice.class);

	@Value("${sftp.host.name.cobranza}")
	private String remoteHostCobranza;
	@Value("${sftp.user.name.cobranza}")
	private String usernameCobranza;
	@Value("${sftp.password.cobranza}")
	private String passwordCobranza;
	@Value("${sftp.host.port.cobranza}")
	private int portCobranza;

	@Value("${sftp.host.name.endoso}")
	private String remoteHostEndoso;
	@Value("${sftp.user.name.endoso}")
	private String usernameEndoso;
	@Value("${sftp.password.endoso}")
	private String passwordEndoso;
	@Value("${sftp.host.port.endoso}")
	private int portEndoso;

	@Value("${sftp.host.name.emision}")
	private String remoteHostEmision;
	@Value("${sftp.user.name.emision}")
	private String usernameEmision;
	@Value("${sftp.password.emision}")
	private String passwordEmision;
	@Value("${sftp.host.port.emision}")
	private int portEmision;

	@Value("${sftp.get.destination.folder}")
	private String getDestFolder;

	@Value("${sftp.get.destination.temp.folder}")
	private String getDestTempFolder;

	@Value("${sftp.put.destination.folder}")
	private String putDestFolder;

	@Value("${sftp.get.origin.folder}")
	private String getOrigFolder;

	@Value("${sftp.put.origin.folder}")
	private String putOrigFolder;

	@Value("#{'${sftp.catalogs}'.split(',')}")
	private List<String> nameCatalogs;

	@Value("${files.complete.status}")
	private Integer completeStatus;

	@Value("${file.name.external.data.param}")
	private String fileNameExternalParam;

	@Autowired
	private TProcFileRepository tProcFileRepository;

	@Autowired
	private TUloadExtRepository tUloadExtRepository;

	@Autowired
	private TLayoutRepository tLayoutRepository;

	@Value("${file.name.layout.desc.size}")
	private Integer fileNameLayoutDescSize;

	@Autowired
	private TAppRepository tAppRepository;

	@Value("${domain.name.cobranza}")
	private String domainNameCobranza;
	@Value("${domain.name.endoso}")
	private String domainNameEndoso;
	@Value("${domain.name.emision}")
	private String domainNameEmision;

	public void testConnection() throws FitravaException, ValidationException {
		try {
			Session session = getSession("COBRANZA");
			session.connect();
			logger.info("Creating SFTP Channel.");
			ChannelSftp sftpChannel = (ChannelSftp) session.openChannel("sftp");
			sftpChannel.connect();

//			Util.zipFiles(putOrigFolder + "comprimido",
//					new String[] { "C:/josue/TOM/documetos/catalogos txt/catFone.txt",
//							"C:/josue/TOM/documetos/catalogos txt/catIssste.txt",
//							"C:/josue/TOM/documetos/catalogos txt/catRisci.txt" });

			logger.info("Disconnect");
			sftpChannel.disconnect();
			session.disconnect();
		} catch (JSchException e) {
			logger.error("Error: "+e.getMessage());
		}

	}

	public String viewSFTPDirectory(String path, String domain) throws FitravaException {
		String fileNames = new String();
		try {

			Session session = getSession(domain);

			session.connect();
			logger.info("Connection established.");
			logger.info("Creating SFTP Channel.");
			ChannelSftp sftpChannel = (ChannelSftp) session.openChannel("sftp");
			sftpChannel.connect();

			fileNames += sftpChannel.pwd() + " \n";

			if (path != null && !path.isEmpty()) {
				sftpChannel.cd(path);
			}

			fileNames += sftpChannel.pwd() + " \n";

			@SuppressWarnings("unchecked")
			Vector<ChannelSftp.LsEntry> list = sftpChannel.ls("*.*");
			for (ChannelSftp.LsEntry entry : list) {
				fileNames += sftpChannel.pwd() + " \n";
				fileNames += entry.getFilename() + " \n";
				logger.info(sftpChannel.pwd());
				logger.info(entry.getFilename());
			}

			logger.info("Disconnect");
			sftpChannel.disconnect();
			session.disconnect();
		} catch (JSchException e) {
			throw new FitravaException(String.format("JSchException , Error: %1$s", e.getMessage()));
		} catch (SftpException e) {
			throw new FitravaException(String.format("SftpException , Error: %1$s", e.getMessage()));
		}
		return fileNames;
	}


	private Session getSession(String domain) throws JSchException, FitravaException {
		JSch jsch = null;
		Session session = null;

		String remoteHost = null;
		String username = null;
		int port=0;
		String password = null;
		boolean usersDoamin=false;

		if (domain.equalsIgnoreCase(domainNameCobranza)) {
			remoteHost = remoteHostCobranza;
			username = usernameCobranza;
			port = portCobranza;
			password = passwordCobranza;
			usersDoamin=true;
		} else if (domain.equalsIgnoreCase(domainNameEndoso)) {
			remoteHost = remoteHostEndoso;
			username = usernameEndoso;
			port = portEndoso;
			password = passwordEndoso;
			usersDoamin=true;
		} else if (domain.equalsIgnoreCase(domainNameEmision)) {
			remoteHost = remoteHostEmision;
			username = usernameEmision;
			port = portEmision;
			password = passwordEmision;
			usersDoamin=true;
		}

		if (!usersDoamin) {
			throw new FitravaException(
					String.format("No existe un usuario de servicio para el dominio: %1$s ", domain));
		}
		try {
			logger.info(remoteHost + " " + username + " " + port);
			jsch = new JSch();
			java.util.Properties config = new java.util.Properties();
			config.put("StrictHostKeyChecking", "no");
			JSch.setConfig(config);
			session = jsch.getSession(username, remoteHost, port);
			session.setPassword(password);

		} catch (JSchException e) {
			logger.info("error in file Transfer");
			// return e.getMessage();
			throw e;
		}
		return session;
	}

	private boolean checkDirectoryExixts(ChannelSftp sftpChannel, String dir) throws SftpException {
		String currentDirectory = sftpChannel.pwd();
		SftpATTRS attrs = null;
		try {
			attrs = sftpChannel.stat(currentDirectory + "/" + dir);
		} catch (Exception e) {
			logger.error(currentDirectory + "/" + dir + " not found");
		}

		if (attrs != null) {
			return true;
		} else {
			return false;
		}

	}

	@SuppressWarnings("unused")
	private void makeDirectory(ChannelSftp sftpChannel, String... folders) throws SftpException {
		List<String> lstFolders = Arrays.asList(folders);
		String fullPath = new String(".");
		for (String folder : lstFolders) {
			fullPath += "/" + folder;
			sftpChannel.mkdir(fullPath);
		}
	}

	public void download(DownloadCatalogDTO catalog) throws FitravaException {
		try {

			Session session = getSession(catalog.getDomain());

			session.connect();
			logger.info("Creating SFTP Channel.");
			ChannelSftp sftpChannel = (ChannelSftp) session.openChannel("sftp");
			sftpChannel.connect();

			String dir = catalog.getMailBox();

			if (checkDirectoryExixts(sftpChannel, dir + catalog.getFileName())) {
				logger.info("El catalogo " + catalog.getFileName() + " si existe en la ruta " + dir);
			} else {
				throw new FitravaException(String.format(
						"El catalogo " + catalog.getFileName() + " no exixte en la ruta: %1$s, Error: %2$s", dir,
						"Catalogo no encontrado"));
			}

			Thread downloadThread = new Thread(() -> {
				try {
					sftpChannel.cd(dir);

					sftpChannel.get(catalog.getFileName(), getDestTempFolder + catalog.getFileName(),
							progressDownloadMonitor());

					File f = new File(new File(getDestTempFolder), catalog.getFileName());
					if (!f.exists()) {
						f = null;
						logger.error("Descarga de catalogo :" + getDestTempFolder + catalog.getFileName() + " fallo!");
					} else {
						logger.info("Moviendo de :" + getDestTempFolder + catalog.getFileName() + " a :" + getDestFolder
								+ catalog.getFileName());
						Files.move(Paths.get(getDestTempFolder + catalog.getFileName()),
								Paths.get(getDestFolder + catalog.getFileName()));
					}

				} catch (SftpException e) {
					logger.error("Error de conexion SFTP: " + e.getCause());
				} catch (IOException e) {
					logger.error("Error al mover el archivo: " + e.getCause());
				}

				logger.info("Disconnect");
				sftpChannel.disconnect();
				session.disconnect();
			});
			downloadThread.setDaemon(true);
			downloadThread.start();

		} catch (JSchException e) {
			throw new FitravaException(String.format("Error de conexion, Error: %1$s", e.getCause()));
		} catch (SftpException e) {
			throw new FitravaException(String.format("Error de conexion, Error: %1$s", e.getCause()));
		}
	}

	public void upload(String dcn) throws FitravaException {
		try {

			// Obteniendo path dependoiendo del producto
			TApp tapp = tAppRepository.findDirDestOfOutputLayoutByFlow(dcn);
			String path = tapp.getDirDestDscr();
			logger.info("..... :::path::: ..... :" + path);

			// Creando nombre del zip
			String fileName = new String(dcn);

			// Creando nombre del archivo
			TUloadExt tUloadExt = tUloadExtRepository.findByDstnctCtrlNumAndKey(dcn, fileNameExternalParam);

			if (tUloadExt != null) {
				fileName += "_" + tUloadExt.getValue();
			} else {
				String desc = tLayoutRepository.findDescOfOutputLayoutByFlow(dcn);
				if (desc != null) {
					fileName += "_" + desc.substring(0,
							desc.length() >= fileNameLayoutDescSize ? fileNameLayoutDescSize : desc.length() - 1)
							.replace(' ', '_');
				}
			}

			logger.info("..... :::fileName::: ..... :" + fileName);

			Session session = getSession(tapp.getEaiCd());
			session.connect();
			logger.info("Creating SFTP Channel.");
			ChannelSftp sftpChannel = (ChannelSftp) session.openChannel("sftp");
			sftpChannel.connect();

			String dir = putOrigFolder;
			sftpChannel.cd(path);

			// get files by dcn
			List<TProcFile> lstFiles = tProcFileRepository.findByDstnctCtrlNum(dcn);

			List<String> lstFilNames = lstFiles.parallelStream().map(e -> e.getFileNm()).map(e -> putOrigFolder + e)
					.collect(Collectors.toList());

			if (lstFilNames == null || lstFilNames.isEmpty()) {
				logger.error("No existen archivos completados asociados al DCN: " + dcn);
				throw new FitravaException(String.format(
						"No existen archivos completados asociados al DCN: %1$s , Error: %2$s", dcn, "File not Found"));
			}

			// Zipping files
			try {
				Util.zipFiles(dir + fileName, lstFilNames);
			} catch (ValidationException e1) {
				logger.error("Error al zppear los archivos: " + fileName);
				throw new FitravaException(String.format("Error al zppear los archivos,  Error: %1$s", e1.getCause()));
			}

			File f = new File(dir + fileName + ".zip");
			if (!f.exists()) {
				f = null;
				logger.error("El archivo:" + dir + fileName + ".zip no existe!");
				throw new FitravaException(String.format("Error al suvir el archivo, Error: %1$s", "File not Found"));
			}

			// Subiendo archivo principal
			sftpChannel.put(dir + fileName + ".zip", fileName + ".zip", progressUploadMonitor());

			// Creando archivo bandera
			File file = new File(dir + fileName + ".flag");
			boolean createStatues=file.createNewFile();

			File flag = new File(dir + fileName + ".flag");
			if (!createStatues || !flag.exists()) {
				flag = null;
				logger.error("El archivo:" + dir + fileName + ".flag" + " no existe!");
				throw new FitravaException(
						String.format("El archivo bandera no existe, Error: %1$s", "File not Found"));
			}

			// Subiendo archivo bandera
			sftpChannel.put(dir + fileName + ".flag", fileName + ".flag", progressUploadMonitor());

			logger.info("Disconnect");
			sftpChannel.disconnect();
			session.disconnect();
		} catch (JSchException e) {
			logger.error(String.format("Error de conexion, Error: %1$s", e.getCause()));
			throw new FitravaException(String.format("Error de conexion, Error: %1$s", e.getCause()));
		} catch (SftpException e) {
			logger.error(String.format("Error de conexion, Error: %1$s", e.getCause()));
			throw new FitravaException(String.format("Error de conexion, Error: %1$s", e.getCause()));
		} catch (IOException e) {
			logger.error(String.format("Error al crear el archivo bandera, Error: %1$s", e.getCause()));
			throw new FitravaException(String.format("Error al crear el archivo bandera, Error: %1$s", e.getCause()));
		}

	}

	private SftpProgressMonitor progressUploadMonitor() {
		SftpProgressMonitor progress = new SftpProgressMonitor() {

			private long max = 0;
			private long count = 0;
			private long percent = 0;

			@Override
			public void init(int arg0, String src, String dest, long max) {
				logger.info("File Upload begin..");
				this.max = max;
				logger.info(src); // Origin destination
				logger.info(dest); // Destination path
				logger.info("" + max); // Total filesize
			}

			@Override
			public void end() {
				logger.info("Upload of file  succeeded.");
			}

			@Override
			public boolean count(long bytes) {
				this.count += bytes;
				long percentNow = (this.count * 100) / max;
				if (percentNow > this.percent) {
					this.percent = percentNow;

					logger.info("progress: " + this.percent + "%"); // Progress 0,0
//					logger.info("" + max); // Total ilesize
//					logger.info("" + this.count); // Progress in bytes from the total
				}

				return (true);
			}

		};
		return progress;
	}

	private SftpProgressMonitor progressDownloadMonitor() {
		SftpProgressMonitor progress = new SftpProgressMonitor() {

			private long max = 0;
			private long count = 0;
			private long percent = 0;

			@Override
			public void init(int arg0, String src, String dest, long max) {
				logger.info("File download begin..");
				this.max = max;
				logger.info(src); // Origin destination
				logger.info(dest); // Destination path
				logger.info("" + max); // Total filesize
			}

			@Override
			public void end() {
				logger.info("Dowload of file  succeeded.");
			}

			@Override
			public boolean count(long bytes) {
				this.count += bytes;
				long percentNow = (this.count * 100) / max;
				if (percentNow > this.percent) {
					this.percent = percentNow;

					logger.info("progress: " + this.percent + "%"); // Progress 0,0
//					logger.info("" + max); // Total ilesize
//					logger.info("" + this.count); // Progress in bytes from the total
				}

				return (true);
			}

		};
		return progress;
	}

}
