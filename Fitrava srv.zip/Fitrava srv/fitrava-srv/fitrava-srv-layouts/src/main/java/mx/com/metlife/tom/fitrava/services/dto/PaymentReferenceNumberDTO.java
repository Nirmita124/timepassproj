package mx.com.metlife.tom.fitrava.services.dto;

import javax.validation.constraints.Size;

import lombok.Data;

@Data
public class PaymentReferenceNumberDTO {	

	/*
	 * TODO - Uncomment this line after testing validation-annotation-messages.
	 * 		  (***Do the same for the other methods below.***)
	 * Size(min = 0, max = 4, message = "{PaymentReferenceNumberDTO.MSG_Size_templateID}")
	 * 	
	 */
	@Size(min = 0, max = 4, message = "Template ID length cannot exceed more than 4.")
	String templateID;
	
	/*
	 * @Size(min = 0, max = 4, message = "{PaymentReferenceNumberDTO.MSG1_Size_retainerID}")
	 */
	@Size(min = 0, max = 4, message = "retainerID length cannot exceed more than 4.")
	String retainerID;
	
	/*
	 * @Size(min = 0, max = 3, message = "{PaymentReferenceNumberDTO.MSG1_Size_paymentUnit}")
	 */
	@Size(min = 0, max = 3, message = "paymentUnit length cannot exceed more than 3.")
	String paymentUnit;
	
	/*
	 * 
	 * @Size(min = 0, max = 10, message = "{PaymentReferenceNumberDTO.MSG1_Size_policyGKY}")
	 */
	@Size(min = 0, max = 10, message = "policyGKY length cannot exceed more than 10.")
	String policyGKY;
}


