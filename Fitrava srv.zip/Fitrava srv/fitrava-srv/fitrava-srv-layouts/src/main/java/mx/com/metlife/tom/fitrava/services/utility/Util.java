package mx.com.metlife.tom.fitrava.services.utility;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.multipart.MultipartFile;

import mx.com.metlife.tom.fitrava.services.error.FitravaException;
import mx.com.metlife.tom.fitrava.services.error.ValidationException;

public final class Util extends UtilCommon {

	private static final Logger log = LoggerFactory.getLogger(Util.class);

	public static final File guardaArchivoDiscoDuro(MultipartFile file) throws FitravaException {
		return guardaArchivoDiscoDuro(file, null, null);
	}

	public static final File guardaArchivoDiscoDuro(MultipartFile file, String name, String ruta)
			throws FitravaException {
		String filename = name != null ? name : file.getOriginalFilename();
		String path = ruta != null ? ruta : PATH_DEFAULT;
		byte[] barr = null;
		BufferedOutputStream bout = null;
		File temp = null;
		try {
			if (!path.endsWith(File.separator)) {
				path += File.separator;
			}
			temp = new File(path);
			createDirectory(temp);
			barr = file.getBytes();
			bout = new BufferedOutputStream(new FileOutputStream(new File(temp, filename)));
			bout.write(barr);
			return temp;
		} catch (IOException e) {
			log.error("Error en el guardado de archivo", e);
			throw new FitravaException(String.format("No se pudo guardar el archivo: %1$s", file.getName()), e);
		} finally {
			if (bout != null) {
				try {
					bout.flush();
					bout.close();
				} catch (Exception e) {
				}
			}
		}
	}

	public static final void guardaAllArchivosDiscoDuro(MultipartFile... files) throws FitravaException {
		guardaAllArchivosDiscoDuro(files, null, null);
	}

	public static final void guardaAllArchivosDiscoDuro(MultipartFile[] files, String name, String ruta)
			throws FitravaException {
		if (files == null || files.length == 0) {
			throw new FitravaException("No existen archivos a guardar");
		}
		for (MultipartFile file : files) {
			guardaArchivoDiscoDuro(file, name, ruta);
		}
	}

	public static List<File> getBisFilesFromZip(File directorioBase, MultipartFile zip) throws FitravaException {
		ZipInputStream zis = null;
		ZipEntry zipEntry = null;
		File fileZip = null;
		List<File> files = null;
		try {
			createDirectory(directorioBase);
			files = new ArrayList<>();
			fileZip = new File(directorioBase, zip.getOriginalFilename());
			zip.transferTo(fileZip);
			zis = new ZipInputStream(new FileInputStream(fileZip));
			while ((zipEntry = zis.getNextEntry()) != null) {
				files.add(newFile(directorioBase, zipEntry, zis));
			}
			return files;
		} catch (Exception e) {
			throw new FitravaException(String.format("No se pudo descomprimir el archivo: %1$s", zip), e);
		} finally {
			try {
				if (zis != null) {
					zis.closeEntry();
				}
			} catch (IOException e) {
			}
			try {
				if (zis != null) {
					zis.close();
				}
			} catch (IOException e) {
			}
		}
	}

	public static File newFile(File directorioBase, ZipEntry zipEntry, ZipInputStream zis) throws FitravaException {
		File destFile = null;
		FileOutputStream fos = null;
		int len = 0;
		byte[] buffer = null;
		try {
			destFile = new File(directorioBase, zipEntry.getName());
			buffer = new byte[1024];
			fos = new FileOutputStream(destFile);
			while ((len = zis.read(buffer)) > 0) {
				fos.write(buffer, 0, len);
			}
			destFile.deleteOnExit();
			return destFile;
		} catch (Exception e) {
			throw new FitravaException(String.format("Error al descomprimir el archivo: %1$s", zipEntry), e);
		} finally {
			try {
				if (fos != null) {
					fos.close();
				}
			} catch (IOException e) {
			}
		}
	}

	public static List<File> getFilesFromZip(File directorioBase, MultipartFile zip) throws FitravaException {
		File fileZip = null;
		try {
			fileZip = new File(directorioBase, zip.getOriginalFilename());
			zip.transferTo(fileZip);
			List<File> list = getFilesFromZip(directorioBase, fileZip);
			// fileZip.deleteOnExit();
			// boolean result = Files.deleteIfExists(fileZip.toPath());
			deleteFiles(directorioBase.getPath(), ".zip");
			return list;
		} catch (IOException e) {
			throw new FitravaException(String.format("Error al descomprimir el archivo: %1$s", zip), e);
		}
	}

	public static List<File> getFilesFromZip(File directorioBase, File zip) throws FitravaException {
		ZipInputStream zis = null;
		ZipEntry zipEntry = null;
		File fileZip = null;
		List<File> files = null;
		File nuevo = null;
		try {
			createDirectory(directorioBase);
			files = new ArrayList<>();
			fileZip = new File(directorioBase, zip.getName());
			// System.out.println("fileZip: " + fileZip.getName());
			zis = new ZipInputStream(new FileInputStream(fileZip));
			while ((zipEntry = zis.getNextEntry()) != null) {
				nuevo = newFile(directorioBase, zipEntry, zis, zip.getName());
				// System.out.println("nuevo: " + nuevo.getName());
				if (nuevo.getName().toLowerCase().endsWith(Constantes.ZIP)) {
					files.addAll(getFilesFromZip(directorioBase, nuevo));
				}
				files.add(nuevo);
			}
			fileZip.deleteOnExit();
			return files;
		} catch (Exception e) {
			throw new FitravaException(String.format("No se pudo descomprimir el archivo: %1$s", zip), e);
		} finally {
			try {
				if (zis != null) {
					zis.closeEntry();
				}
			} catch (IOException e) {
			}
			try {
				if (zis != null) {
					zis.close();
				}
			} catch (IOException e) {
			}
		}
	}

	public static File newFile(File directorioBase, ZipEntry zipEntry, ZipInputStream zis, String zipName)
			throws FitravaException {
		// System.out.println(String.format("en el newFile(directorioBase: %1$s,
		// zipEntry: %2$s, zis: %3$s, name: %4$s", directorioBase, zipEntry, zis,
		// zipName));
		File destFile = null;
		FileOutputStream fos = null;
		int len = 0;
		byte[] buffer = null;
		String nombre = zipName != null ? zipName + "_" + zipEntry.getName() : zipEntry.getName();
		// System.out.println("nombre: " + nombre);
		try {
			destFile = new File(directorioBase, nombre);
			buffer = new byte[1024];
			fos = new FileOutputStream(destFile);
			while ((len = zis.read(buffer)) > 0) {
				fos.write(buffer, 0, len);
			}
			destFile.deleteOnExit();
			return destFile;
		} catch (Exception e) {
			throw new FitravaException(String.format("Error al descomprimir el archivo: %1$s", zipEntry), e);
		} finally {
			try {
				if (fos != null) {
					fos.close();
				}
			} catch (IOException e) {
			}
		}
	}

	public static List<File> convertMutipartToFile(File directorioBase, MultipartFile... files)
			throws ValidationException, FitravaException {
		List<File> archivos = null;
		File f = null;
		try {
			if (files == null || files.length == 0) {
				return null;
			}
			createDirectory(directorioBase);
			archivos = new ArrayList<>();
			for (MultipartFile mpf : files) {
				if (mpf.getOriginalFilename().toLowerCase().endsWith(Constantes.ZIP)) {
					archivos.addAll(getFilesFromZip(directorioBase, mpf));
					continue;
				}
				f = new File(directorioBase, mpf.getOriginalFilename());
				mpf.transferTo(f);
				archivos.add(f);
			}
			return removeFiles(archivos);
		} catch (Exception e) {
			log.error("Error al convertir los multipart a file", e);
			throw new FitravaException("Error al convertir los multipart a file, " + e.getMessage(), e);
		}
	}

	public static Boolean validaZip(MultipartFile... files) throws ValidationException {
		String ext = files[0].getOriginalFilename();
		ext = ext.substring(ext.lastIndexOf(Constantes.DOT) + 1);
		if (ext.equalsIgnoreCase(Constantes.ZIP)) {
			if (files.length > 1) {
				throw new ValidationException("Los zip solo se puede recibir uno a la vez");
			}
			return Boolean.TRUE;
		}
		return Boolean.FALSE;
	}

	public static void zipFiles(String zipName, List<String> lstFilePaths) throws ValidationException {
		String zipFileName = null;
		FileOutputStream fos = null;
		ZipOutputStream zos = null;
		try {
			zipFileName = zipName.concat(Constantes.DOT).concat(Constantes.ZIP);
			fos = new FileOutputStream(zipFileName);
			zos = new ZipOutputStream(fos);

			for (String aFile : lstFilePaths) {
				zos.putNextEntry(new ZipEntry(new File(aFile).getName()));
				byte[] bytes = Files.readAllBytes(Paths.get(aFile));
				zos.write(bytes, 0, bytes.length);
				zos.closeEntry();
			}

		} catch (FileNotFoundException ex) {
			throw new ValidationException("Un archivo no existe: " + ex.getCause());
		} catch (IOException ex) {
			throw new ValidationException("Error de lectura: " + ex.getCause());
		} finally {
			if (fos != null) {
				try {
					fos.flush();
				} catch (IOException e) {
				}
				try {
					fos.close();
				} catch (IOException e) {
				}
			}
			if (zos != null) {
				try {
					zos.flush();
				} catch (IOException e) {
				}
				try {
					zos.close();
				} catch (IOException e) {
				}
			}

		}
	}

	public static final List<File> removeFiles(List<File> archivos) {
		List<File> files = null;
		if (archivos != null && !archivos.isEmpty()) {
			files = new ArrayList<>();
			for (File f : archivos) {
				if (!validaExtensionesPermitidas(f)) {
					continue;
				}
				files.add(f);
			}
		}
		return files;
	}

	public static Map<String, File> getMapNombresOriginales(List<File> archivos) {
		String nombreArchivo = null;
		Map<String, File> map = new HashMap<>();

		for (File f : archivos) {
			nombreArchivo = getFileNameOriginal(f);
			map.put(nombreArchivo, f);
		}

		return map;
	}

	public static Map<String, File> getMapNombresOriginales(String directorio) {
		
		File dir = new File(directorio);
		if (!dir.isDirectory()) {
			return null;
		}
		File[] archivos = dir.listFiles();
		String nombreArchivo = null;
		Map<String, File> map = new HashMap<>();
		for (File f : archivos) {
			nombreArchivo = getFileNameOriginal(f);
			map.put(nombreArchivo, f);
		}
		return map;
	}

	static void deleteFiles(String folder, String ext) {
		File dir = new File(folder);
		log.info("...::::: Directorio zips ::::.....: " + folder);
		if (!dir.exists())
			return;
		File[] files = dir.listFiles(new GenericExtFilter(ext));
		for (File file : files) {
			if (!file.isDirectory()) {
				log.info("...::::: Borrando ::::.....: " + file.getPath());
				boolean result = file.delete();
				log.info(result ? "...::::: Borrado exitosamente ::::.....: "
						: "...::::: No se pudo borrar ::::.....: ");
			}
		}
	}

	public static String getFileNameOriginal(File f) {
		String last = ".zip_";
		String nombreArchivo = f.getName();
		return nombreArchivo.indexOf(last) > 0
				? nombreArchivo.substring(nombreArchivo.lastIndexOf(last) + last.length())
				: nombreArchivo;
	}

	public static Predicate<String> existsInFolder() {
		return p -> {
			File f = new File(p);
			return f.exists();
		};
	}
	
	public static String getAleatoriaPath(String name) throws IOException {
		if (name == null || name.isEmpty()) {
			return null;
		}
		String path = Constantes.TEMP_ROOT_DIRECTORY_ORIGEN_TEMP + Math.abs(name.hashCode());
		File f = new File (path);
		/*if (!f.exists()) {
			f.mkdirs();
		}*/
		if (!Files.exists(f.toPath())) {
			Files.createDirectories(f.toPath());
		}
		return path;
	}
	
	public static String getAleatoriaPath(File file) throws IOException {
		if (file == null || file.getName() == null) {
			return null;
		}
		String path = Constantes.TEMP_ROOT_DIRECTORY_ORIGEN_TEMP + Math.abs(file.getName().hashCode());
		System.out.println("--->" + path);
		File f = new File (path);
		/*if (!f.exists()) {
			f.mkdirs();
		}*/
		if (!Files.exists(f.toPath())) {
			Files.createDirectories(f.toPath());
		}
		return path;
	}
	
	public static List<String> getFilesFromPath(String path) {
		File dir = new File(path);
		if (!dir.exists())
			return null;
		File[] files = dir.listFiles();
		return (Arrays.asList(files)
				.parallelStream()
				.map(e -> e.getName())) 
				.collect(Collectors.toList());
		
	}
	
	public static void main(String[] args) {
		String dir = "C:\\wlp\\usr\\servers\\defaultServer";
		List<String> archivos = getFilesFromPath(dir);
		archivos.forEach(e-> System.out.println(e));
		
	}
	

}
