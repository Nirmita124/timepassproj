package mx.com.metlife.tom.fitrava.services.dto;

import org.dozer.Mapping;
import lombok.Data;

@SuppressWarnings("serial")
@Data
public class ParametroTransformacionParametroDTO implements java.io.Serializable{
	
	
	@Mapping("fldTformParmId")
	private Long fldTformParmId = null;
	@Mapping("fldTformId")
	private Long fldTformId = null;
	@Mapping("parmNm")
	private String parmNm = null;
	@Mapping("fldTformParmOrdNum")
	private Integer fldTformParmOrdNum = null;
	@Mapping("fldTformParmVal")
	private String fldTformParmVal = null;
	@Mapping("layoutFldId")
	private Long layoutFldId = null;

}
