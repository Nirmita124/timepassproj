package mx.com.metlife.tom.fitrava.services.serviceimpl;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.dozer.DozerBeanMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import mx.com.metlife.tom.fitrava.services.dto.GranArchivoDTO;
import mx.com.metlife.tom.fitrava.services.dto.ProcesoDTO;
import mx.com.metlife.tom.fitrava.services.dto.ProcesoFileDTO;
import mx.com.metlife.tom.fitrava.services.dto.ProcesoRegistroDTO;
import mx.com.metlife.tom.fitrava.services.dto.ProcesoRegistroSumaryDTO;
import mx.com.metlife.tom.fitrava.services.dto.UploadExternalDataDTO;
import mx.com.metlife.tom.fitrava.services.dto.UploadFileDTO;
import mx.com.metlife.tom.fitrava.services.error.FitravaException;
import mx.com.metlife.tom.fitrava.services.error.FitravaPersistenceException;
import mx.com.metlife.tom.fitrava.services.error.ValidationException;
import mx.com.metlife.tom.fitrava.services.model.customer.AuxCustomerRepository;
import mx.com.metlife.tom.fitrava.services.model.customer.TProcCustomerRepository;
import mx.com.metlife.tom.fitrava.services.model.entity.TBigFile;
import mx.com.metlife.tom.fitrava.services.model.entity.TClctStts;
import mx.com.metlife.tom.fitrava.services.model.entity.TFlow;
import mx.com.metlife.tom.fitrava.services.model.entity.TProc;
import mx.com.metlife.tom.fitrava.services.model.entity.TProcFile;
import mx.com.metlife.tom.fitrava.services.model.entity.TProcFileErr;
import mx.com.metlife.tom.fitrava.services.model.entity.TProcFileId;
import mx.com.metlife.tom.fitrava.services.model.entity.TProcRec;
import mx.com.metlife.tom.fitrava.services.model.entity.TProcRecSum;
import mx.com.metlife.tom.fitrava.services.model.entity.TUloadExt;
import mx.com.metlife.tom.fitrava.services.model.repository.TBigFileRepository;
import mx.com.metlife.tom.fitrava.services.model.repository.TFlowRepository;
import mx.com.metlife.tom.fitrava.services.model.repository.TLogProcRepository;
import mx.com.metlife.tom.fitrava.services.model.repository.TProcFileErrRepository;
import mx.com.metlife.tom.fitrava.services.model.repository.TProcFileRepository;
import mx.com.metlife.tom.fitrava.services.model.repository.TProcRecRepository;
import mx.com.metlife.tom.fitrava.services.model.repository.TProcRecSumDtlRepository;
import mx.com.metlife.tom.fitrava.services.model.repository.TProcRecSumRepository;
import mx.com.metlife.tom.fitrava.services.model.repository.TProcRepository;
import mx.com.metlife.tom.fitrava.services.model.repository.TUloadExtRepository;
import mx.com.metlife.tom.fitrava.services.service.ProcesoService;
import mx.com.metlife.tom.fitrava.services.utility.Constantes;
import mx.com.metlife.tom.fitrava.services.utility.Util;

@Service
@PropertySource("classpath:${env_var:dev}-fitrava.properties")
public class ProcesoServiceImpl implements ProcesoService {

	private static Logger log = LoggerFactory.getLogger(ProcesoServiceImpl.class);

	@Autowired
	private TProcRepository tProcRepository;

	@Autowired
	private TProcCustomerRepository tProcCustomerRepository;

	@Autowired
	private TProcFileRepository tProcFileRepository;

	@Autowired
	private TProcRecRepository tProcRecRepository;

	@Autowired
	private TProcRecSumRepository tProcRecSumRepository;

	@Autowired
	private TProcRecSumDtlRepository tProcRecSumDtlRepository;

	@Autowired
	private TLogProcRepository tLogProcRepository;

	@Autowired
	private TFlowRepository tFlowRepository;

	@Autowired
	private DozerBeanMapper mapper;

	@Autowired
	private TUloadExtRepository tUloadExtRepository;

	@Autowired
	private AuxCustomerRepository auxCustomerRepository;
	
	@Autowired
	private TProcFileErrRepository tProcFileErrRepository; 
	
	//@Autowired
	private TBigFileRepository tBigFileRepository; 
	

	@Value("${batch.destination.folder}")
	private String batchDestinationFolder;

	@Override
	public ProcesoDTO getProcesoByDcn(String dcn) throws ValidationException, FitravaException {
		log.info("En el getProcesoByDcn(dcn: {})", dcn);
		TProc proc = null;
		List<TProcFile> listTProcFile = null;

		ProcesoDTO proceso = null;
		List<ProcesoFileDTO> listProcesoFile = null;
		try {
			Optional<TProc> optional = tProcRepository.findById(dcn);
			if (optional.isPresent()) {
				proc = optional.get();
			}
		} catch (Exception e) {
			log.error(String.format("Error al obtener el Proceso por el DCN: %1$s", dcn), e);
			throw new FitravaException(
					String.format("Error al obtener el Proceso por el DCN: %1$s, Error: %2$s", dcn, e.getCause()));
		}
		if (proc == null) {
			throw new ValidationException(String.format("No se encuentra ningun Proceso con el DCN: %1$s", dcn));
		}
		try {
			listTProcFile = tProcFileRepository.findByDstnctCtrlNum(dcn);
		} catch (Exception e) {
			log.error(String.format("Error al obtener los ProcesoFile por el DCN: %1$s", dcn), e);
			throw new FitravaException(
					String.format("Error al obtener los ProcesoFile por el DCN: %1$s, Error: %2$s", dcn, e.getCause()));
		}

		proceso = mapper.map(proc, ProcesoDTO.class);
		if (listTProcFile != null && !listTProcFile.isEmpty()) {
			listProcesoFile = new ArrayList<>();
			for (TProcFile t : listTProcFile) {
				listProcesoFile.add(mapper.map(t, ProcesoFileDTO.class));
			}
			proceso.setListProcesoFile(listProcesoFile);
		}
		return proceso;
	}

	@Override
	public List<ProcesoDTO> getAllProcesosByFlujoId(Long flujoId) throws ValidationException, FitravaException {
		log.info("En el getAllProcesosByFlujoId(flujoId: {})", flujoId);
		List<TProc> procesos = null;
		List<ProcesoDTO> procesosDTOs = null;
		try {
			procesos = tProcRepository.findByFlowId(flujoId);
		} catch (Exception e) {
			log.error(String.format("error al obtener el Proceso por el flujoId: %1$s", flujoId), e);
			throw new FitravaException(String.format("error al obtener el Proceso por el flujoId: %1$s, Error: %2$s",
					flujoId, e.getCause()));
		}
		if (procesos == null || procesos.isEmpty()) {
			throw new ValidationException(
					String.format("No se encuentra ningun Proceso con el flujoId: %1$s", flujoId));
		}
		procesosDTOs = new ArrayList<>();
		for (TProc t : procesos) {
			procesosDTOs.add(mapper.map(t, ProcesoDTO.class));
		}
		return procesosDTOs;
	}

	@Override
	public List<ProcesoDTO> getAllProcesosByEaiAndRetainer(String retenedorId, String eaiCd)
			throws ValidationException, FitravaException {
		log.info("En el getAllProcesosByEaiAndRetainer(retenedorId: {}, eaiCd: {})", retenedorId, eaiCd);
		List<TProc> procesos = null;
		List<ProcesoDTO> procesosDTOs = null;
		try {
			procesos = tProcCustomerRepository.findByEaiAndRetainer(retenedorId, eaiCd);
		} catch (FitravaPersistenceException e) {
			log.error(String.format("error al obtener los procesos por el retenedorId: %1$s y el eai: %2$s",
					retenedorId, eaiCd), e);
			throw new FitravaException(Constantes.ERROR_DATA_BASE, e);
		} catch (Exception e) {
			log.error(String.format("error al obtener los Proceso por el retenedor: %1$s y/o eaiCd: %2$s", retenedorId,
					eaiCd), e);
			throw new FitravaException(
					String.format("error al obtener los Procesos por el retenedor: %1$s y/o eaiCd: %2$s, Error: %3$s",
							retenedorId, eaiCd, e.getCause()));
		}
		if (procesos == null || procesos.isEmpty()) {
			throw new ValidationException(String.format(
					"No se encuentra ningun Proceso con el retenedor: %1$s y/o eaiCd: %2$s", retenedorId, eaiCd));
		}
		procesosDTOs = new ArrayList<>();
		for (TProc t : procesos) {
			procesosDTOs.add(mapper.map(t, ProcesoDTO.class));
		}
		return procesosDTOs;
	}

	@Override
	public List<ProcesoDTO> getAllProcesosByUsuarioAndEstatus(String usuario, Integer estatus) throws ValidationException, FitravaException {
		log.info("En el getAllProcesosByUsuarioAndEstatus(usuario: {}, estatus: {})", usuario, estatus);
		List<TProc> procesos = null;
		List<ProcesoDTO> procesosDTOs = null;
		try {
			procesos = tProcCustomerRepository.findByUsuarioAndEstatus(usuario, estatus);
		} catch (FitravaPersistenceException e) {
			log.error(String.format("error al obtener los procesos por el usuario: %1$s y el eai: %2$s", usuario,
					estatus), e);
			throw new FitravaException(Constantes.ERROR_DATA_BASE, e);
		} catch (Exception e) {
			log.error(String.format("error al obtener los Proceso por el usuario: %1$s y/o estatus: %2$s", usuario,
					estatus), e);
			throw new FitravaException(
					String.format("error al obtener los Procesos por el usuario: %1$s y/o estatus: %2$s, Error: %3$s",
							usuario, estatus, e.getCause()));
		}
		if (procesos == null || procesos.isEmpty()) {
			throw new ValidationException(String
					.format("No se encuentra ningun Proceso con el usuario: %1$s y/o estatus: %2$s", usuario, estatus));
		}
		procesosDTOs = new ArrayList<>();
		for (TProc t : procesos) {
			procesosDTOs.add(mapper.map(t, ProcesoDTO.class));
		}
		return procesosDTOs;
	}

	@Transactional
	@Override
	public ProcesoDTO guardaProceso(ProcesoDTO procesoDTO) throws ValidationException, FitravaException {
		log.info("En el guardaProceso(procesoDTO: {})", procesoDTO);
		TProc tProc = null;
		Date hoy = null;
		List<ProcesoFileDTO> listProcesoFile = null;
		try {
			hoy = new Date();
			listProcesoFile = procesoDTO.getListProcesoFile();
			tProc = mapper.map(procesoDTO, TProc.class);
			tProc.setRcptnTs(hoy);
			tProc.setPrtyNum(1);// no se va usar
			tProc = tProcRepository.saveAndFlush(tProc);

			if (listProcesoFile != null && !listProcesoFile.isEmpty()) {
				for (ProcesoFileDTO t : listProcesoFile) {
					tProcFileRepository.saveAndFlush(mapper.map(t, TProcFile.class));
				}
			}
			procesoDTO = mapper.map(tProc, ProcesoDTO.class);
			procesoDTO.setListProcesoFile(listProcesoFile);
			return procesoDTO;
		} catch (Exception e) {
			log.error(String.format("error al guardar el flujo: %1$s", procesoDTO), e);
			throw new FitravaException(
					String.format("error al guardar el Flujo: %1$s, Error: %2$s", procesoDTO, e.getCause()));
		}
	}

	@Transactional
	@Override
	public ProcesoDTO actualizaProceso(ProcesoDTO procesoDTO) throws FitravaException {
		log.info("En el guardaProceso(procesoDTO: {})", procesoDTO);
		TProc tProc = null;
		Date hoy = null;
		List<ProcesoFileDTO> listProcesoFile = null;
		try {
			hoy = new Date();
			listProcesoFile = procesoDTO.getListProcesoFile();
			tProc = mapper.map(procesoDTO, TProc.class);
			tProc.setRcptnTs(hoy);
			tProc.setPrtyNum(1);// no se va usar
			tProc = tProcRepository.save(tProc);

			if (listProcesoFile != null && !listProcesoFile.isEmpty()) {
				tProcFileRepository.deleteByDcn(tProc.getDstnctCtrlNum());
				for (ProcesoFileDTO t : listProcesoFile) {
					tProcFileRepository.save(mapper.map(t, TProcFile.class));
				}
			}
			procesoDTO = mapper.map(tProc, ProcesoDTO.class);
			procesoDTO.setListProcesoFile(listProcesoFile);
			return procesoDTO;
		} catch (Exception e) {
			log.error(String.format("error al guardar el flujo: %1$s", procesoDTO), e);
			throw new FitravaException(
					String.format("error al guardar el Flujo: %1$s, Error: %2$s", procesoDTO, e.getCause()));
		}
	}

	@Transactional
	@Override
	public Boolean actualizaProceso(String dcn, Integer estatus) throws FitravaException {
		log.info("En el actualizaProceso(dcn: {}, estatus: {})", dcn, estatus);
		Boolean resultado = null;
		try {
			resultado = tProcCustomerRepository.mergeEstatus(dcn, estatus);
		} catch (FitravaPersistenceException e) {
			log.error(String.format("error al actualizar el proceso con DCN: %1$s", dcn), e);
			throw new FitravaException(Constantes.ERROR_DATA_BASE, e);
		} catch (Exception e) {
			log.error(String.format("error al actualizar el estatus del proceso con DCN: %1$s", dcn), e);
			throw new FitravaException(String.format(
					"error al actualizar el estatus del proceso con DCN: %1$s, Error: %2$s", dcn, e.getCause()));
		}
		return resultado;
	}

	@Transactional
	@Override
	public void deleteProceso(String dcn) throws FitravaException {
		log.info("En el deleteProceso(dcn: {})", dcn);
		try {
			tProcRecSumDtlRepository.deleteByDcn(dcn);
			tProcRecSumRepository.deleteByDcn(dcn);
			tProcRecRepository.deleteByDcn(dcn);
			tProcFileRepository.deleteByDcn(dcn);
			tLogProcRepository.deleteByDcn(dcn);
			tProcRepository.deleteById(dcn);
		} catch (Exception e) {
			log.error(String.format("error al borrar el proceso con DCN: %1$s", dcn), e);
			throw new FitravaException(
					String.format("error al borrar el proceso por el DCN: %1$s, Error: %2$s", dcn, e.getCause()));
		}
	}

	@Override
	public ProcesoFileDTO getProcesoFileById(String dcn, String archivo) throws ValidationException, FitravaException {
		log.info("En el getProcesoByDcn(dcn: {})", dcn);
		TProcFile tProcFile = null;
		TProcRecSum tProcRecSum = null;
		ProcesoFileDTO procesoFileDTO = null;
		try {
			Optional<TProcFile> optional = tProcFileRepository.findById(new TProcFileId(dcn, archivo));
			if (optional.isPresent()) {
				tProcFile = optional.get();
			}
		} catch (Exception e) {
			log.error(String.format("Error al obtener el Proceso File por el DCN: %1$s y archivo: %2$s", dcn, archivo),
					e);
			throw new FitravaException(
					String.format("Error al obtener el Proceso por el DCN: %1$s y archivo: %2$s, Error: %3$s", dcn,
							archivo, e.getCause()));
		}
		if (tProcFile == null) {
			throw new ValidationException(String
					.format("No se encuentra ningun Proceso Archivo con el DCN: %1$s y archivo: %2$s", dcn, archivo));
		}
		tProcRecSum = tProcRecSumRepository.findByDcnAndArchivo(dcn, archivo);
		procesoFileDTO = mapper.map(tProcFile, ProcesoFileDTO.class);
		if (tProcRecSum != null) {
			procesoFileDTO.setTProcRecSum(mapper.map(tProcRecSum, ProcesoRegistroSumaryDTO.class));
		}
		return procesoFileDTO;
	}

	@Override
	public List<ProcesoFileDTO> getAllProcesoFileByDcn(String dcn) throws ValidationException, FitravaException {
		log.info("En el getProcesoByDcn(dcn: {})", dcn);
		List<TProcFile> listTProcFile = null;
		List<ProcesoFileDTO> listProcesoFile = null;
		try {
			listTProcFile = tProcFileRepository.findByDstnctCtrlNum(dcn);
		} catch (Exception e) {
			log.error(String.format("Error al obtener los Proceso File por el DCN: %1$s", dcn), e);
			throw new FitravaException(String.format("Error al obtener los Procesos File por el DCN: %1$s, Error: %2$s",
					dcn, e.getCause()));
		}
		if (listTProcFile == null || listTProcFile.isEmpty()) {
			throw new ValidationException(
					String.format("No se encuentra ningun Proceso Archivo con el DCN: %1$s", dcn));
		}
		listProcesoFile = new ArrayList<>();
		for (TProcFile t : listTProcFile) {
			listProcesoFile.add(mapper.map(t, ProcesoFileDTO.class));
		}
		return listProcesoFile;
	}

	@Transactional
	@Override
	public void guardaArchivo(UploadFileDTO uploadFileDTO, MultipartFile... files) throws ValidationException, FitravaException {
		log.info("En el guardaArchivo(uploadFileDTO: {}, files: {})", uploadFileDTO, Util.getArrayToString(files));
		// 1ero validamos que no exista el DCN en BD
		log.info("Iniciando");
		Long exist = null;
		try {
			exist = tProcRepository.existDcn(uploadFileDTO.getDcn());
		} catch (Exception e) {
			log.error(String.format("Error al ver si existe el DCN: %1$s", uploadFileDTO.getDcn()), e);
			throw new FitravaException(String.format("Error al ver si existe el DCN: %1$s, Error: %2$s",
					uploadFileDTO.getDcn(), e.getCause()));
		}
		log.info("existe? " + exist);
		if (exist != null && exist > 0) {
			throw new ValidationException("Ya existe un registro con el DCN: " + uploadFileDTO.getDcn());
		}
		List<File> archivos = null;
		Map<String, File> mapArchivos = null;
		try {
			archivos = Util.convertMutipartToFile(new File(Constantes.TEMP_ROOT_DIRECTORY_ORIGEN_TEMP), files);
			mapArchivos = Util.getMapNombresOriginales(archivos);
			
//			for (String nombre: mapArchivos.keySet()) {
//				log.info(Constantes.LOGGER_DOUBLE_BRACET,nombre,mapArchivos.get(nombre)); 
//			}
			
		} catch (Exception e) {
			log.error("Error al obtener los archivos del multipart", e);
			// si existe alguna excepcion, borra los archivos temporales
			Util.deleteFiles(archivos);
			throw e;
		}
		Optional<TFlow> optional = null;
		TFlow tFlow = null;
		try {
			// obtenemos la lista
			 //{{Pieda Solorzano}} Aqui se obtienen los flujos por el flowId
			optional = tFlowRepository.findById(uploadFileDTO.getFlowId());
			if (optional.isPresent()) {
				tFlow = optional.get();
			}
			log.info("tFlow: {} ", tFlow);
		} catch (Exception e) {
			log.error("Error al obtener el Flujo", e);
			Util.deleteFiles(archivos);
			throw new FitravaException(String.format("Error al obtener el Flujo, Error: %1$s", e.getCause()));
		}
		if (tFlow == null) {
			Util.deleteFiles(archivos);
			throw new FitravaException(
					String.format("No se encuentra registrado ningun flujo con el ID: %1$s, por favor corrija",
							uploadFileDTO.getFlowId()));
		}
		TProc tProc = null;
		TProcFile tProcFile = null;
		Date hoy = null;
		int i = 0;
		File archivo = null;
		TProcFileErr tProcFileErr = null;  
		try {
			hoy = new Date();
			tProc = new TProc();
			tProc.setDstnctCtrlNum(uploadFileDTO.getDcn());
			tProc.setFlowId(tFlow.getFlowId());
			tProc.setEntrncLayoutId(tFlow.getDfltEntrncLayoutId()); // aqui ponemos el layout de entrada por omision, en el t_proc_file el que corresponda con el archivo
			tProc.setRcptnTs(hoy);
			tProc.setPrtyNum(0);
			tProc.setCrtUsrId(uploadFileDTO.getCrtUsrId());
			tProc.setClctSttsId(TClctStts.Estatus.PENDIENTE.getId());
			tProc.setRsltDscr("INICIO");// ALGUN OTRO TEXTO, aun no se que va aqui...
			tProcRepository.save(tProc);
			log.info("tProc: " + tProc);

			// {{Pieda Solorzano}} Guardando datos externos
			log.info("...::: Guardando datos externos :::....");
			uploadFileDTO.getLstExternalData()
					.parallelStream()
					.forEach(e -> e.setDstnctCtrlNum(uploadFileDTO.getDcn()));
			TUloadExt tUloadExt = null;
			for (UploadExternalDataDTO uploadExternalDataDTO : uploadFileDTO.getLstExternalData()) {
				log.info("uploadExternalDataDTO: " + uploadExternalDataDTO);
				tUloadExt = mapper.map(uploadExternalDataDTO, TUloadExt.class);
				tUloadExtRepository.save(tUloadExt);
			}
			log.info("tProc: " + tProc);
			for (String nombre : mapArchivos.keySet()) {
				archivo = mapArchivos.get(nombre);
				if (archivo == null || archivo.length() == 0) {// puede pasar??? si pasa que? error???
					tProcFileErr = new TProcFileErr(uploadFileDTO.getDcn(), nombre, 102, hoy, "El Archivo es null, o está vacio");
					tProcFileErrRepository.save(tProcFileErr);
					continue;
				}
				tProcFile = new TProcFile();
				tProcFile.setDstnctCtrlNum(uploadFileDTO.getDcn());
				tProcFile.setFileNm(nombre);// el nombre original
				tProcFile.setFullPathOrigNm(archivo.getName());
				tProcFile.setProcFileOrdNum(i++);
				tProcFile.setEntrncLayoutId(null);// lo voy a buscar y poner hasta el engine, buena sugerencia del pinche bubu
				tProcFile.setClctSttsId(TClctStts.Estatus.PENDIENTE.getId());
				tProcFile.setProcFileStrtTs(hoy);
				tProcFile.setProcFileEndTs(hoy);
				tProcFileRepository.save(tProcFile);
				log.info("tProcFile: " + tProcFile);
				// Util.moveFileInit(Constantes.TEMP_ROOT_DIRECTORY_ORIGEN,
				// uploadFileDTO.getDcn(), archivo);
			}

		} catch (Exception e) {
			log.error("Error al guardar el proceso y/o proceso archivo", e);
			Util.deleteFiles(archivos);
			throw new FitravaException(
					String.format("Error al guardar el proceso y/o el proceso archivo, Error: %1$s", e.getCause()));
		}
	}

	@Transactional
	@Override
	public void procesaArchivo(String dcn) throws ValidationException, FitravaException {
		// Obtener nonmbre de archivos de la base de datos
		List<TProcFile> lstProcFile = tProcFileRepository.findByDcn(dcn);
		if (lstProcFile == null || lstProcFile.isEmpty()) {
			throw new FitravaException("No se encuntran archivos asociados al DCN: " + dcn);
		}

		// Obtener archivos del directorio de origen
		List<File> archivos = lstProcFile.parallelStream()
				.map(e -> new File(Constantes.TEMP_ROOT_DIRECTORY_ORIGEN_TEMP + e.getFullPathOrigNm())) // e.getFileNm
				.collect(Collectors.toList());
		log.info(".....:::::Archivos obtenidos: ");
		archivos.forEach(f -> log.info(f.getName()));
		TProcFileErr tProcFileErr = null; 
		// Moviendo archivos al directorio de procesamiento
		for (File f : archivos) {
			try {
				log.info(".....:::::Moviendo archivos ... ");
				Util.moveFileInit(Constantes.TEMP_ROOT_DIRECTORY_ORIGEN, dcn, f);
				log.info(".....:::::Movidos con exito ");
				auxCustomerRepository.mergeTProcFileStatus(TClctStts.Estatus.EN_PROCESO.getId(), Util.getFileNameOriginal(f));
			} catch (ValidationException e1) {
				log.error("Error al guardar el proceso y/o proceso archivo", e1);
				tProcFileErr = new TProcFileErr(dcn, f.getName(), 103, new Date(), "Error al guardar el proceso y/o proceso archivo, e: " + e1 );
				tProcFileErrRepository.save(tProcFileErr);
				Util.deleteFile(f);
				throw new FitravaException(String.format("Error al guardar el proceso y/o el proceso archivo, Error: %1$s", e1.getCause()));
			} catch (FitravaPersistenceException e1) {
				log.error("Error al actualizar el TprocFile ", e1);
				Util.deleteFile(f);
				throw new FitravaException(String.format("Error al guardar el proceso y/o el proceso archivo, Error: %1$s", e1.getCause()));
			}
		}
	}

	@Override
	public List<ProcesoRegistroDTO> getProcRecByDcnAndFileName(String dcn, String fileName) throws ValidationException, FitravaException {
		log.info("En el getProcRecByDcnAndFileName(dcn: {},fileName: {} )", dcn, fileName);
		List<TProcRec> listTProcRec = null;
		List<ProcesoRegistroDTO> listProcesoRegistro = null;
		try {
			listTProcRec = tProcRecRepository.findByDstnctCtrlNumAndFileNm(dcn, fileName);
		} catch (Exception e) {
			log.error(String.format("Error al obtener los Proceso Registro por el DCN: %1$s", dcn), e);
			throw new FitravaException(
					String.format("Error al obtener los Procesos Registro por el DCN & FileName: %1$s, Error: %2$s",
							dcn, fileName, e.getCause()));
		}
		if (listTProcRec == null || listTProcRec.isEmpty()) {
			throw new ValidationException(String
					.format("No se encuentra ningun Proceso Registro con el DCN & FileName: %1$s", dcn, fileName));
		}
		listProcesoRegistro = new ArrayList<>();
		for (TProcRec t : listTProcRec) {
			listProcesoRegistro.add(mapper.map(t, ProcesoRegistroDTO.class));
		}
		return listProcesoRegistro;
	}

	@Override
	public ProcesoRegistroSumaryDTO getProcRecSumByDcnAndFileName(String dcn, String fileName)
			throws ValidationException, FitravaException {
		log.info("En el getProcRecSumByDcnAndFileName(dcn: {},fileName: {} )", dcn, fileName);
		TProcRecSum tProcRecSum = null;
		ProcesoRegistroSumaryDTO procesoRegistroSumary = null;
		try {
			tProcRecSum = tProcRecSumRepository.findByDstnctCtrlNumAndFileNm(dcn, fileName);
		} catch (Exception e) {
			log.error(String.format("Error al obtener los Proceso Registro Sumary por el DCN: %1$s", dcn), e);
			throw new FitravaException(String.format(
					"Error al obtener los Procesos Registro Sumary por el DCN & FileName: %1$s, Error: %2$s", dcn,
					fileName, e.getCause()));
		}
		if (tProcRecSum == null) {
			throw new ValidationException(String.format(
					"No se encuentra ningun Proceso Registro Sumary con el DCN & FileName: %1$s", dcn, fileName));
		}
		procesoRegistroSumary = new ProcesoRegistroSumaryDTO();

		procesoRegistroSumary = mapper.map(tProcRecSum, ProcesoRegistroSumaryDTO.class);

		return procesoRegistroSumary;
	}

	@Override
	public ProcesoDTO getProcByDcn(String dcn) throws ValidationException, FitravaException {
		log.info("En el getProcByDcn(dcn: {})", dcn);
		TProc proc = null;
		List<TProcFile> listTProcFile = null;

		ProcesoDTO proceso = null;
		List<ProcesoFileDTO> listProcesoFile = null;
		ProcesoFileDTO procesoFile = null;

		List<ProcesoRegistroDTO> listProcesoRegistro = null;
		ProcesoRegistroSumaryDTO procesoRegistroSumary = null;
		try {
			Optional<TProc> optional = tProcRepository.findById(dcn);
			if (optional.isPresent()) {
				proc = optional.get();
			}
		} catch (Exception e) {
			log.error(String.format("Error al obtener el Proceso por el DCN: %1$s", dcn), e);
			throw new FitravaException(
					String.format("Error al obtener el Proceso por el DCN: %1$s, Error: %2$s", dcn, e.getCause()));
		}
		if (proc == null) {
			throw new ValidationException(String.format("No se encuentra ningun Proceso con el DCN: %1$s", dcn));
		}
		try {
			listTProcFile = tProcFileRepository.findByDstnctCtrlNum(dcn);
		} catch (Exception e) {
			log.error(String.format("Error al obtener los ProcesoFile por el DCN: %1$s", dcn), e);
			throw new FitravaException(
					String.format("Error al obtener los ProcesoFile por el DCN: %1$s, Error: %2$s", dcn, e.getCause()));
		}

		proceso = mapper.map(proc, ProcesoDTO.class);
		if (listTProcFile != null && !listTProcFile.isEmpty()) {
			listProcesoFile = new ArrayList<>();
			for (TProcFile t : listTProcFile) {
				procesoFile = mapper.map(t, ProcesoFileDTO.class);
				try {
					// Obteniendo y setteando los registros
					listProcesoRegistro = getProcRecByDcnAndFileName(procesoFile.getDcn(), procesoFile.getFileNm());
					procesoFile.setListProcesoRegistro(listProcesoRegistro);
				} catch (Exception e) {
				}

				try {
					// Obteniendo y setteando el summary
					procesoRegistroSumary = getProcRecSumByDcnAndFileName(procesoFile.getDcn(),
							procesoFile.getFileNm());
					procesoFile.setTProcRecSum(procesoRegistroSumary);
				} catch (Exception e) {
				}

				// Excluyendo layout de entrada
				procesoFile.setLayoutEntrada(null);

				listProcesoFile.add(procesoFile);
			}

			proceso.setListProcesoFile(listProcesoFile);
		}

		// Excluyendo flujo
		proceso.setTFlow(null);
		return proceso;
	}

	@Override
	public File downloadFiles(String dcn, String fileName) throws FitravaException {
		// get files by dcn
		List<TProcFile> lstFiles = tProcFileRepository.findByDstnctCtrlNum(dcn);

		if (lstFiles == null || lstFiles.isEmpty()) {
			log.error(String.format("No hay archivos asociados a el DCN: %1$s", dcn), "Not found");
			throw new FitravaException(
					String.format("No hay archivos asociados a el DCN: %1$s, Error: %2$s", dcn, "Not found"));
		}

		if (fileName != null && !fileName.isEmpty()) {
			lstFiles = lstFiles.parallelStream().filter(e -> e.getFileNm().equalsIgnoreCase(fileName))
					.collect(Collectors.toList());

			if (lstFiles == null || lstFiles.isEmpty()) {
				log.error(String.format("No se encontro el archivo: %1$s  para a el DCN: %2$s", fileName, dcn),
						"Not found");
				throw new FitravaException(String.format("No se encontro el archivo: %1$s  para a el DCN: %2$s",
						fileName, dcn, "Not found"));
			}
		}

		List<String> lstFilNames = lstFiles.parallelStream()
											.map(e -> e.getFileNm())
											.map(e -> batchDestinationFolder + e)
											.collect(Collectors.toList());
		
		//filtrar por los que si existen
		lstFilNames = lstFilNames.parallelStream()
									.filter( Util.existsInFolder())
									.collect(Collectors.toList());

		if (lstFilNames == null || lstFilNames.isEmpty()) {
			log.error(String.format("No se encontro ningun archivo para a el DCN: %1$s", dcn),
					"Not found");
			throw new FitravaException(String.format("No se encontro ningun archivo para a el DCN: %1$s", dcn, "Not found"));
		}

		// Zipping files
		try {
			Util.zipFiles(batchDestinationFolder + dcn, lstFilNames);
		} catch (ValidationException e1) {
			log.error("Error al zppear los archivos: " + fileName);
			throw new FitravaException(String.format("Error al zppear los archivos,  Error: %1$s", e1.getCause()));
		}
		
		//validar existencia de zip de salida
		File zip = new File(batchDestinationFolder + dcn.concat(Constantes.DOT).concat(Constantes.ZIP));
		
		if(!zip.exists()) {
			log.error(String.format("El zip no se encuentra para el DCN: %1$s", dcn), "Not found");
			throw new FitravaException(
					String.format("El zip no se encuentra para el DCN: %1$s, Error: %2$s", dcn, "Not found"));
		}

		return zip;
	}
	
	public void validaRuta(String path) throws ValidationException {
		log.info("En el validaRuta(path: {})", path);
		//buscamos si existe algun archivo con ese nombre relacionado al path
		List<TProcFile> listTProcFile = null;
		try {
			listTProcFile = tProcFileRepository.findAllByFiles(Util.getFilesFromPath(path));
		} catch (Exception e) {
			log.error("Error al buscar los archivos", e);
		}
		if (listTProcFile != null && !listTProcFile.isEmpty()) {
			throw new ValidationException("Los archivos ya se encuentran registrados, y estan siendo procesados, por lo que no se puede borrar/remplazar");
		}
		
	}
	
	public void procesaArchivo(UploadFileDTO uploadFileDTO) throws ValidationException, FitravaException {
		log.info("En el procesaArchivo(uploadFileDTO: {})", uploadFileDTO);
		// 1ero validamos que no exista el DCN en BD
		log.info("Iniciando");
		Long exist = null;
		try {
			exist = tProcRepository.existDcn(uploadFileDTO.getDcn());
		} catch (Exception e) {
			log.error(String.format("Error al ver si existe el DCN: %1$s", uploadFileDTO.getDcn()), e);
			throw new FitravaException(String.format("Error al ver si existe el DCN: %1$s, Error: %2$s",
					uploadFileDTO.getDcn(), e.getCause()));
		}
		log.info("existe? " + exist);
		if (exist != null && exist > 0) {
			throw new ValidationException("Ya existe un registro con el DCN: " + uploadFileDTO.getDcn());
		}
		Map<String, File> mapArchivos = null;
		try {
			mapArchivos = Util.getMapNombresOriginales(uploadFileDTO.getRuta());
			for (String nombre: mapArchivos.keySet()) {
				log.info(Constantes.LOGGER_DOUBLE_BRACET, nombre,mapArchivos.get(nombre)); 
			}
		} catch (Exception e) {
			log.error("Error al obtener los archivos", e);
			// si existe alguna excepcion, borra los archivos temporales
			Util.deleteFiles(uploadFileDTO.getRuta());
			throw e;
		}
		Optional<TFlow> optional = null;
		TFlow tFlow = null;
		try {
			// obtenemos la lista
			 //{{Pieda Solorzano}} Aqui se obtienen los flujos por el flowId
			optional = tFlowRepository.findById(uploadFileDTO.getFlowId());
			if (optional.isPresent()) {
				tFlow = optional.get();
			}
			log.info("tFlow: {} ", tFlow);
		} catch (Exception e) {
			log.error("Error al obtener el Flujo", e);
			Util.deleteFiles(uploadFileDTO.getRuta());
			throw new FitravaException(String.format("Error al obtener el Flujo, Error: %1$s", e.getCause()));
		}
		if (tFlow == null) {
			Util.deleteFiles(uploadFileDTO.getRuta());
			throw new FitravaException(
					String.format("No se encuentra registrado ningun flujo con el ID: %1$s, por favor corrija",
							uploadFileDTO.getFlowId()));
		}
		TProc tProc = null;
		TProcFile tProcFile = null;
		Date hoy = null;
		int i = 0;
		File archivo = null;
		TProcFileErr tProcFileErr = null;  
		try {
			hoy = new Date();
			tProc = new TProc();
			tProc.setDstnctCtrlNum(uploadFileDTO.getDcn());
			tProc.setFlowId(tFlow.getFlowId());
			tProc.setEntrncLayoutId(tFlow.getDfltEntrncLayoutId()); // aqui ponemos el layout de entrada por omision, en el t_proc_file el que corresponda con el archivo
			tProc.setRcptnTs(hoy);
			tProc.setPrtyNum(0);
			tProc.setCrtUsrId(uploadFileDTO.getCrtUsrId());
			tProc.setClctSttsId(TClctStts.Estatus.EN_PROCESO.getId());
			tProc.setRsltDscr("INICIO");// ALGUN OTRO TEXTO, aun no se que va aqui...
			tProcRepository.save(tProc);
			log.info("tProc: " + tProc);

			// {{Pieda Solorzano}} Guardando datos externos
			log.info("...::: Guardando datos externos :::....");
			uploadFileDTO.getLstExternalData()
					.parallelStream()
					.forEach(e -> e.setDstnctCtrlNum(uploadFileDTO.getDcn()));
			TUloadExt tUloadExt = null;
			for (UploadExternalDataDTO uploadExternalDataDTO : uploadFileDTO.getLstExternalData()) {
				log.info("uploadExternalDataDTO: " + uploadExternalDataDTO);
				tUloadExt = mapper.map(uploadExternalDataDTO, TUloadExt.class);
				tUloadExtRepository.save(tUloadExt);
			}
			log.info("tProc: " + tProc);
			for (String nombre : mapArchivos.keySet()) {
				archivo = mapArchivos.get(nombre);
				if (archivo == null || archivo.length() == 0) {// puede pasar??? si pasa que? error???
					tProcFileErr = new TProcFileErr(uploadFileDTO.getDcn(), nombre, 102, hoy, "El Archivo es null, o está vacio");
					tProcFileErrRepository.save(tProcFileErr);
					continue;
				}
				tProcFile = new TProcFile();
				tProcFile.setDstnctCtrlNum(uploadFileDTO.getDcn());
				tProcFile.setFileNm(nombre);// el nombre original
				tProcFile.setFullPathOrigNm(archivo.getName());
				tProcFile.setProcFileOrdNum(i++);
				tProcFile.setEntrncLayoutId(null);// lo voy a buscar y poner hasta el engine, buena sugerencia del pinche bubu
				tProcFile.setClctSttsId(TClctStts.Estatus.EN_PROCESO.getId());
				tProcFile.setProcFileStrtTs(hoy);
				tProcFile.setProcFileEndTs(hoy);
				tProcFileRepository.save(tProcFile);
				log.info("tProcFile: " + tProcFile);
				Util.moveFileInit(Constantes.TEMP_ROOT_DIRECTORY_ORIGEN, uploadFileDTO.getDcn(), archivo);
			}
			Util.deleteFiles(uploadFileDTO.getRuta());

		} catch (Exception e) {
			log.error("Error al guardar el proceso y/o proceso archivo", e);
			Util.deleteFiles(uploadFileDTO.getRuta());
			throw new FitravaException(
					String.format("Error al guardar el proceso y/o el proceso archivo, Error: %1$s", e.getCause()));
		}
	}
	
	public void guardaArchivosGrandes(MultipartFile file, String dcn, String fileName) throws ValidationException, FitravaException {
		log.info("En el guardaArchivosGrandes(files: {})", file);
		String originalFilename = file.getOriginalFilename();
		log.info("File recieved: {}", originalFilename);
		
		TBigFile bigFile = null;
		try {
			if (fileName != null && !fileName.isEmpty()) {
				bigFile = tBigFileRepository.findByDcnAndName(dcn, fileName);
			}
			if (bigFile == null) {
				bigFile = new TBigFile();
			}
			bigFile.setDstnctCtrlNum(dcn);
			bigFile.setBigFileNm(fileName!= null && !fileName.isEmpty()?fileName:file.getOriginalFilename());
			bigFile.setFile(file.getBytes());
			//bigFile.setSizeMB(Double.valueOf(file.getSize())/(1024*1024));
			bigFile.setUloadDt(new Date());
			tBigFileRepository.save(bigFile);
		} catch (IOException e) {
			throw new FitravaException("No se puedo asociar el flujo de bytes al archivo", e);
		} catch (Exception e) {
			throw new FitravaException("No se puedo guardar en BD", e);
		}
	}
	
	public File downloadGrandesArchivos(String dcn, String fileName) throws FitravaException {
		log.info("En el downloadGrandesArchivos(dcn: {}, fileName: {})", dcn, fileName);
		TBigFile bigFile = null;
		try {
			bigFile = tBigFileRepository.findByDcnAndName(dcn, fileName);
		} catch (Exception e) {
			throw new FitravaException("No se pudo obtener el archivo de la BD", e);
		}
		if (bigFile == null || bigFile.getFile() == null || bigFile.getFile().length == 0) {
			throw new FitravaException(String.format("No se encuentra ningun archivo relacionado al dcn: %1$s y al nombre del archivo: %2$s", dcn, fileName));
		}
		File file = null;
		try {
			file = new File(bigFile.getBigFileNm());
			Files.write(file.toPath(), bigFile.getFile());
			return file;
		} catch (IOException e) {
			throw new FitravaException("No se pudo recuperar el archivo", e);
		}
	}
	
	public GranArchivoDTO getGrandesArchivos(String dcn, String fileName) throws FitravaException {
		log.info("En el getGrandesArchivos(dcn: {}, fileName: {})", dcn, fileName);
		TBigFile bigFile = null;
		try {
			bigFile = tBigFileRepository.findByDcnAndName(dcn, fileName);
		} catch (Exception e) {
			throw new FitravaException("No se pudo obtener el archivo de la BD", e);
		}
		if (bigFile == null || bigFile.getFile() == null || bigFile.getFile().length == 0) {
			throw new FitravaException(String.format("No se encuentra ningun archivo relacionado al dcn: %1$s y al nombre del archivo: %2$s", dcn, fileName));
		}
		return mapper.map(bigFile, GranArchivoDTO.class);
	}
}
