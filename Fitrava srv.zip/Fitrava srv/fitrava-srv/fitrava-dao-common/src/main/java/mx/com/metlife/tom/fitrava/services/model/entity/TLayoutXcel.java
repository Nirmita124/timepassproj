package mx.com.metlife.tom.fitrava.services.model.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import lombok.Data;

@SuppressWarnings("serial")
@Data
@Entity
@Table(name = "T_LAYOUT_XCEL")
@IdClass(TLayoutXcelId.class)
public class TLayoutXcel implements java.io.Serializable{

	
	@Id
	@Column(name = "LAYOUT_ID")
	private Long  layoutId= null;
	
	@Id
	@Column(name = "XCEL_SHEET_NM")
	private String  xcelSheetNm= null;
	
}
