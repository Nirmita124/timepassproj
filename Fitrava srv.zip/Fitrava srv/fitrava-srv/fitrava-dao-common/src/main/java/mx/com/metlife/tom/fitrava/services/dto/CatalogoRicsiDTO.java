package mx.com.metlife.tom.fitrava.services.dto;

import java.util.Date;

import org.dozer.Mapping;

import lombok.Data;
import lombok.EqualsAndHashCode;

@EqualsAndHashCode(callSuper=false)
@Data
public class CatalogoRicsiDTO extends CatalogoFitravaDTO {

	@Mapping("polNum")
	private String poliza;
	
	@Mapping("natlId")
	private String rfc;
	
	@Mapping("insFullNm")
	private String nombre;

	private String numRecibo;
	
	@Mapping("polSttsNm")
	private String estatus;
	
	@Mapping("issDt")
	private Date fechaEmision;
	
	@Mapping("rcptDt")
	private Date fechaRecibo;
	
	@Mapping("polEffDt")
	private Date fechaEfectoPoliza;
	
	@Mapping("pyMthdCd")
	private String formaPago;
	
	@Mapping("clctKeyCd")
	private String conductoCobro;
	
	@Mapping("pensionerNum")
	private String numPensionado;
	
	@Mapping("annlPremAmt")
	private Double primaAnual;
	
	@Mapping("rcptSttsCd")
	private String statusRecibo;
	
	@Mapping("clctPremAmt")
	private Double primaCobro;


}
