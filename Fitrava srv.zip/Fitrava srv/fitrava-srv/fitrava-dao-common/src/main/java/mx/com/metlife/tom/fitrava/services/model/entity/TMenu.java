package mx.com.metlife.tom.fitrava.services.model.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import lombok.Data;

@SuppressWarnings("serial")
@Data
@Entity
@Table(name = "T_MENU")
public class TMenu implements java.io.Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "MENU_ID")
	private Integer menuId = null;

	@Column(name = "MENU_NM")
	private String menuNm = null;

	@Column(name = "MENU_DSCR")
	private String menuDscr = null;

	@Column(name = "MENU_LNK_NM")
	private String menuLnkNm = null;

	@Column(name = "MENU_ICON_NM")
	private String menuIconNm = null;

	@Column(name = "MENU_TOOL_Tip_DSCR")
	private String menuToolTipDscr = null;

	@Column(name = "PRNT_MENU_ID")
	private Integer prntMenuId = null;

	@OneToMany(cascade=CascadeType.ALL, fetch=FetchType.EAGER,mappedBy="prntMenuId")
	private List<TMenu> tMenus;
}
