package mx.com.metlife.tom.fitrava.services.model.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import mx.com.metlife.tom.fitrava.services.model.entity.TLayoutHd;

@Repository
public interface TLayoutHdRepository extends JpaRepository<TLayoutHd, Long>{

	List<TLayoutHd> findByLayoutId(Long layoutId);

}
