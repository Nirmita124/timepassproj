package mx.com.metlife.tom.fitrava.services.utility.excel;


import java.util.ArrayList;
import java.util.List;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import mx.com.metlife.tom.fitrava.services.utility.Constantes;

class SAXHandler extends DefaultHandler {

    private List<XmlRow> xmlRowList = new ArrayList<>();
    private XmlRow xmlRow = null;
    private String content = null;
    
    @Override
    public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
        if (qName.equalsIgnoreCase(Constantes.ROW)) {
            xmlRow = new XmlRow();
        }
    }

    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        if (qName.equalsIgnoreCase(Constantes.ROW)) {
                xmlRowList.add(xmlRow);
        } else if (qName.equalsIgnoreCase(Constantes.DATA)) {
                xmlRow.cellList.add(content);
        }
    }

    @Override
    public void characters(char[] ch, int start, int length) throws SAXException {
        content = String.copyValueOf(ch, start, length).trim();
    }
    
	public List<XmlRow> getXmlRowList() {
		return xmlRowList;
	}
	
	public void setXmlRowList(List<XmlRow> xmlRowList) {
		this.xmlRowList = xmlRowList;
	}
}