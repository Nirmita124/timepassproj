package mx.com.metlife.tom.fitrava.services.model.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import mx.com.metlife.tom.fitrava.services.model.entity.TProcFile;
import mx.com.metlife.tom.fitrava.services.model.entity.TProcFileId;

@Repository
public interface TProcFileRepository extends JpaRepository<TProcFile, TProcFileId>{


	List<TProcFile> findByDcn(@Param("dcn") String dstnctCtrlNum);

	@Modifying
	void deleteByDcn(@Param("dcn") String dcn);
	
	List<TProcFile> findByDstnctCtrlNum(String dstnctCtrlNum);

	List<TProcFile> findAllByFiles(@Param("archivos") List<String> archivos);

	
}
