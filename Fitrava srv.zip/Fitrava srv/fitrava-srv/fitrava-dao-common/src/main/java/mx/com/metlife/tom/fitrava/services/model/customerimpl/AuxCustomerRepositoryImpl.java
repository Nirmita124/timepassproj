package mx.com.metlife.tom.fitrava.services.model.customerimpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.sql.DataSource;
import javax.transaction.Transactional;

import org.apache.commons.lang3.time.DateUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.stereotype.Repository;

import mx.com.metlife.tom.fitrava.services.dto.InputDto;
import mx.com.metlife.tom.fitrava.services.error.FitravaPersistenceException;
import mx.com.metlife.tom.fitrava.services.model.customer.AuxCustomerRepository;
import mx.com.metlife.tom.fitrava.services.model.entity.TClctStts;
import mx.com.metlife.tom.fitrava.services.model.entity.TExtCncpt74;
import mx.com.metlife.tom.fitrava.services.model.entity.TExtFone;
import mx.com.metlife.tom.fitrava.services.model.entity.TExtFoneId;
import mx.com.metlife.tom.fitrava.services.model.entity.TExtIssste;
import mx.com.metlife.tom.fitrava.services.model.entity.TExtRicsi;
import mx.com.metlife.tom.fitrava.services.model.entity.TProcRec;
import mx.com.metlife.tom.fitrava.services.utility.Constantes;
import mx.com.metlife.tom.fitrava.services.utility.OperationUtility;
import mx.com.metlife.tom.fitrava.services.utility.UtilCommon;

@Repository
@PropertySource("classpath:otros_queries.properties")
public class AuxCustomerRepositoryImpl implements AuxCustomerRepository {
	
	private static final Logger log = LoggerFactory.getLogger(AuxCustomerRepositoryImpl.class);

	private static final String QUERY_CREATE_BY_DCN_AND_FILE_NAME = "InputDto.createByDcnAndFileName";
	private static final String QUERY_ACTUALIZA_TPROCFILE_ESTATUS = "TProcFile.mergeStatus";
	private static final String QUERY_ACTUALIZA_TPROCRECSUM_ESTATUS = "TProcRecSum.mergeStatus";
	private static final String QUERY_ACTUALIZA_TPROC_ESTATUS = "TProc.mergeStatus";
	private static final String QUERY_ACTUALIZA_TPROC_FILE_LAYOUT = "TProcFile.mergeLayoutEntradaId";
	
	private static final String QUERY_EXIST_MORE_FILES_WITH_DCN = "TProcFile.existMoreFilesWithDcn";
	private static final String QUERY_CONSECUTIVO_T_PROC_REC_SUM_BY_DCN_FILE = "TProcRecSum.getConsecutivo";

	private static final String QUERY_DELETE_ALL_CATALOGO_RISCI = "TExtRicsi.deleteAll";
	private static final String QUERY_DELETE_ALL_CATALOGO_ISSTE = "TExtIssste.deleteAll";
	private static final String QUERY_DELETE_ALL_CATALOGO_FONE  = "TExtFone.deleteAll";
	private static final String QUERY_DELETE_ALL_CONCEPTO_74 = "TExtCncpt74.deleteAll";

	private static final String QUERY_INSERT_CATALOGO_RISCI = "TExtRicsi.insert";
	private static final String QUERY_INSERT_CATALOGO_ISSSTE = "TExtIssste.insert";
	private static final String QUERY_INSERT_CATALOGO_FONE  = "TExtFone.insert";
	private static final String QUERY_INSERT_CONCEPTO_74 = "TExtCncpt74.insert";


    private static final String  QUERY_DELETE_BATCH_STEP_EXECUTION_CONTEXT = "DELETE.BATCH_STEP_EXECUTION_CONTEXT";
    private static final String  QUERY_DELETE_BATCH_STEP_EXECUTION         = "DELETE.BATCH_STEP_EXECUTION";
    private static final String  QUERY_DELETE_BATCH_JOB_EXECUTION_CONTEXT  = "DELETE.BATCH_JOB_EXECUTION_CONTEXT";
    private static final String  QUERY_DELETE_BATCH_JOB_EXECUTION_PARAMS   = "DELETE.BATCH_JOB_EXECUTION_PARAMS";
    private static final String  QUERY_DELETE_BATCH_JOB_EXECUTION          = "DELETE.BATCH_JOB_EXECUTION";
    private static final String  QUERY_DELETE_BATCH_JOB_INSTANCE           = "DELETE.BATCH_JOB_INSTANCE";

    private static final String  QUERY_FIND_FONE_BY_ID_1 = "TExtFone.findById1";
    private static final String  QUERY_FIND_FONE_BY_ID_2 = "TExtFone.findById2";
	

    private static final String  QUERY_FIND_ALL_FILENAME_BY_DCN = "TProcFile.findAllFileNmByDcn";
	
	private static final String ESTATUS = "estatus";
	private static final String DCN = "dcn";
    private static final String NOMBRE_ARCHIVO = "nombreArchivo";
    private static final String ARCHIVO = "archivo";
    private static final String LAYOUT_ENTRADA_ID = "layoutEntradaId";
	
    
	@Value("${TExtRicsi.insert.batch}")
	private String insertRicsiBatch;
    
	@Value("${TExtIssste.insert.batch}")
	private String insertIsssteBatch;
    
	@Value("${TExtFone.insert.batch}")
	private String insertFoneBatch;
    
	@Value("${TExtCncpt74.insert.batch}")
	private String insertConcepto74Batch;
    
	@Value("${TProcRec.insert.batch}")
	private String insertTProcRecBatch;
    
    private static final int MAX_BATCH = 1000;
    
    private static Map<TExtFoneId, TExtFone> mapFone = new HashMap<>();

    @Autowired
	private EntityManager entityManager;
    
    @Autowired
    private DataSource dataSource; 
	
	@Override
	public InputDto createByDcnAndFileName(String dcn, String fileName) throws FitravaPersistenceException {
		log.info("En el createByDcnAndFileName(dcn: {}, fileName: {})", dcn, fileName);
		Query query = null;
		try {
			query = entityManager.createNamedQuery(QUERY_CREATE_BY_DCN_AND_FILE_NAME);
			query.setParameter(DCN, dcn);
			query.setParameter("fileName", fileName);
			query.setMaxResults(1);
			return (InputDto) query.getSingleResult();
		} catch(Exception e) {
			throw new FitravaPersistenceException(String.format("Error en el createByDcnAndFileName(dcn: %1$s, fileName: %2$s), excepcion: %3$s", dcn, fileName, e));
		}	
	}
	
	@Transactional
	public Boolean mergeTProcFileStatus(Integer estatus, String nombreArchivo) throws FitravaPersistenceException {
		Query query = null;
		int actualiza = 0;
		try {
			query = entityManager.createNamedQuery(QUERY_ACTUALIZA_TPROCFILE_ESTATUS);
			query.setParameter(ESTATUS, estatus);
			query.setParameter(NOMBRE_ARCHIVO, nombreArchivo);
			actualiza = query.executeUpdate();
			return actualiza > 0;
		} catch(Exception e) {
			throw new FitravaPersistenceException(String.format("Error en el mergeTProcFileStatus(estatus: %1$s, nombreArchivo: %2$s), excepcion: %3$s", estatus, nombreArchivo, e));
		}	
	}
	
	@Transactional
	public Boolean mergeTProcRecSumStatus(Integer estatus, String nombreArchivo) throws FitravaPersistenceException {
		Query query = null;
		int actualiza = 0;
		try {
			query = entityManager.createNamedQuery(QUERY_ACTUALIZA_TPROCRECSUM_ESTATUS);
			query.setParameter(ESTATUS, estatus);
			query.setParameter(NOMBRE_ARCHIVO, nombreArchivo);
			actualiza = query.executeUpdate();
			return actualiza > 0;
		} catch(Exception e) {
			throw new FitravaPersistenceException(String.format("Error en el mergeTProcRecSumStatus(estatus: %1$s, nombreArchivo: %2$s), excepcion: %3$s", estatus, nombreArchivo, e));
		}	
	}

	@Transactional
	public Boolean mergeTProcStatus(Integer estatus, String dcn) throws FitravaPersistenceException {
		Query query = null;
		int actualiza = 0;
		try {
			query = entityManager.createNamedQuery(QUERY_ACTUALIZA_TPROC_ESTATUS);
			query.setParameter(ESTATUS, estatus);
			query.setParameter(DCN, dcn);
			actualiza = query.executeUpdate();
			return actualiza > 0;
		} catch(Exception e) {
			throw new FitravaPersistenceException(String.format("Error en el mergeTProcStatus(estatus: %1$s, dcn: %2$s), excepcion: %3$s", estatus, dcn, e));
		}	
	}
	
	@Transactional
	@Modifying
	public Boolean mergeTProcFileLayout(String dcn, String fileName, Long layoutEntradaId) throws FitravaPersistenceException {
		log.info("En en mergeTProcFileLayout(dcn: {}, fileName: {}, layoutEntradaId: {})", dcn, fileName, layoutEntradaId);
		Query query = null;
		int actualiza = 0;
		try {
			query = entityManager.createNamedQuery(QUERY_ACTUALIZA_TPROC_FILE_LAYOUT);
			query.setParameter(DCN, dcn);
			query.setParameter(ARCHIVO, fileName);
			query.setParameter(LAYOUT_ENTRADA_ID, layoutEntradaId);
			actualiza = query.executeUpdate();
			return actualiza > 0;
		} catch(Exception e) {
			throw new FitravaPersistenceException(
					String.format("Error en el mergeTProcFileLayout(dcn: %1$s, fileName: %2$s, layoutEntradaId: %3$s), excepcion: %4$s", dcn, fileName, layoutEntradaId, e));
		}	
	}

	public Boolean hasMoreFiles(String dcn) throws FitravaPersistenceException {
		log.info("En el hasMoreFiles(dcn: {})", dcn);
		Query query = null;
		Integer cuenta = null;
		try {
			query = entityManager.createNamedQuery(QUERY_EXIST_MORE_FILES_WITH_DCN);
			query.setParameter(DCN, dcn);
			query.setParameter(ESTATUS, TClctStts.Estatus.FINALIZADO.getId());
			cuenta = (Integer)query.getSingleResult();
			return cuenta != null && cuenta > 0;
		} catch(Exception e) {
			throw new FitravaPersistenceException(String.format("Error en el hasMoreFiles(dcn: %1$s), excepcion: %2$s", dcn, e));
		}	
	}
	
	public Integer getConsecutivoTProcRecSum(String dcn, String archivo) throws FitravaPersistenceException {
		log.info("En el getConsecutivoTProcRecSum(dcn: {}, archivo: {})", dcn, archivo);
		Query query = null;
		Integer cuenta = null;
		try {
			query = entityManager.createNamedQuery(QUERY_CONSECUTIVO_T_PROC_REC_SUM_BY_DCN_FILE);
			query.setParameter(DCN, dcn);
			query.setParameter(ARCHIVO, archivo);
			cuenta = (Integer)query.getSingleResult();
			return cuenta != null?cuenta:0;
		} catch(Exception e) {
			throw new FitravaPersistenceException(String.format("Error en el getConsecutivoTProcRecSum(dcn: %1$s, archivo: %2$s), excepcion: %3$s", dcn, archivo, e));
		}	
	}
	
	@Transactional
	public void deleteAllCatalogoByTipo(Integer tipoCatalgo) throws FitravaPersistenceException {
		log.info("En el deleteAllCatalogoByTipo(tipoCatalgo: {})", tipoCatalgo);
		Query query = null;
		try {
			switch (tipoCatalgo) {
				case Constantes.ID_CATALOGO_RICSI: 
					query = entityManager.createNamedQuery(QUERY_DELETE_ALL_CATALOGO_RISCI); 
					break;
				case Constantes.ID_CATALOGO_FONE: 
					query = entityManager.createNamedQuery(QUERY_DELETE_ALL_CATALOGO_FONE); 
					mapFone = new HashMap<>();
					break;
				case Constantes.ID_CATALOGO_ISSSTE: 
					query = entityManager.createNamedQuery(QUERY_DELETE_ALL_CATALOGO_ISSTE); 
					break;
				case Constantes.ID_CATALOGO_RAMO74: 
					query = entityManager.createNamedQuery(QUERY_DELETE_ALL_CONCEPTO_74); 
					break;
				default:
			}
			if (query != null) {
				query.executeUpdate();
			}
		} catch(Exception e) {
			throw new FitravaPersistenceException(String.format("Error en el deleteAllCatalogoByTipo(tipoCatalgo: %1$s), excepcion: %2$s", tipoCatalgo, e));
		}
	}

	@Transactional
	public void deleteSpringBatchHistory() throws FitravaPersistenceException {
		log.info("En el deleteSpringBatchHistory()");
        Date date = DateUtils.addMonths(new Date(), -6);//menos 6 meses
        DateFormat df = new SimpleDateFormat();
        log.info("Remove the Spring Batch history before the {}", df.format(date));
		Query query = null;
		int borrados = 0;
		String fecha = "fecha";
		try {
			query = entityManager.createNamedQuery(QUERY_DELETE_BATCH_STEP_EXECUTION_CONTEXT); 
			query.setParameter(fecha, date);
			borrados = query.executeUpdate();
			
			query = entityManager.createNamedQuery(QUERY_DELETE_BATCH_STEP_EXECUTION); 
			query.setParameter(fecha, date);
			borrados += query.executeUpdate();
			
			query = entityManager.createNamedQuery(QUERY_DELETE_BATCH_JOB_EXECUTION_CONTEXT); 
			query.setParameter(fecha, date);
			borrados += query.executeUpdate();
			
			query = entityManager.createNamedQuery(QUERY_DELETE_BATCH_JOB_EXECUTION_PARAMS); 
			query.setParameter(fecha, date);
			borrados += query.executeUpdate();
			
			query = entityManager.createNamedQuery(QUERY_DELETE_BATCH_JOB_EXECUTION); 
			query.setParameter(fecha, date);
			borrados += query.executeUpdate();
			
			query = entityManager.createNamedQuery(QUERY_DELETE_BATCH_JOB_INSTANCE); 
			borrados += query.executeUpdate();
			
			log.info("Borrados: {}", borrados);
		} catch(Exception e) {
			throw new FitravaPersistenceException(String.format("Error en el deleteSpringBatchHistory(), excepcion: %1$s", e));
		}
	}
	
	public Boolean saveCatalogoRicsi(TExtRicsi catalogo) throws FitravaPersistenceException {
		Query query = null;
		int i = 0;
		try {
			query = entityManager.createNamedQuery(QUERY_INSERT_CATALOGO_RISCI);
			query.setParameter("polNum", catalogo.getPolNum());
			query.setParameter("natlId", catalogo.getNatlId());
			query.setParameter("insFullNm", catalogo.getInsFullNm());
			query.setParameter("polSttsNm", catalogo.getPolSttsNm());
			query.setParameter("issDt", catalogo.getIssDt());
			query.setParameter("rcptDt", catalogo.getRcptDt());
			query.setParameter("polEffDt", catalogo.getPolEffDt());
			query.setParameter("pyMthdCd", catalogo.getPyMthdCd());
			query.setParameter("clctKeyCd", catalogo.getClctKeyCd());
			query.setParameter("pensionerNum", catalogo.getPensionerNum());
			query.setParameter("annlPremAmt", catalogo.getAnnlPremAmt());
			query.setParameter("rcptSttsCd", catalogo.getRcptSttsCd());
			query.setParameter("clctPremAmt", catalogo.getClctPremAmt());
			i = query.executeUpdate();
			return i > 0;
		} catch(Exception e) {
			throw new FitravaPersistenceException(String.format("Error en el saveCatalogoRicsi(TExtRicsi: %1$s), excepcion: %2$s",catalogo, e));
		}
	}

	public Boolean saveCatalogoFone(TExtFone catalogo) throws FitravaPersistenceException {
		Query query = null;
		int i = 0;
		try {
			query = entityManager.createNamedQuery(QUERY_INSERT_CATALOGO_FONE);
			query.setParameter("foneId", catalogo.getFoneId());
			query.setParameter("origPolNum", catalogo.getOrigPolNum());
			query.setParameter("custNm", catalogo.getCustNm());
			query.setParameter("sbCtgyCd", catalogo.getSbCtgyCd());
			query.setParameter("pordCd", catalogo.getPordCd());
			query.setParameter("sbGrpNum", catalogo.getSbGrpNum());
			query.setParameter("sbGrpNm", catalogo.getSbGrpNm());
			query.setParameter("rcptNm", catalogo.getRcptNm());
			query.setParameter("stCd", catalogo.getStCd());
			query.setParameter("pyrlDiscPct", catalogo.getPyrlDiscPct());
			query.setParameter("insCnt", catalogo.getInsCnt());
			query.setParameter("prevYrInsCnt", catalogo.getPrevYrInsCnt());
			query.setParameter("moPyrlAmt", catalogo.getMoPyrlAmt());
			query.setParameter("intSumAmt", catalogo.getIntSumAmt());
			query.setParameter("insAvgSumAmt", catalogo.getInsAvgSumAmt());
			query.setParameter("annlPremAmt", catalogo.getAnnlPremAmt());
			query.setParameter("moPremAmt", catalogo.getMoPremAmt());
			i = query.executeUpdate();
			return i > 0;
		} catch(Exception e) {
			throw new FitravaPersistenceException(String.format("Error en el saveCatalogoFone(TExtFone: %1$s), excepcion: %2$s",catalogo, e));
		}
	}
	
	public Boolean saveCatalogoIssste(TExtIssste catalogo) throws FitravaPersistenceException {
		Query query = null;
		int i = 0;
		try {
			query = entityManager.createNamedQuery(QUERY_INSERT_CATALOGO_ISSSTE);
			query.setParameter("rtnrCd", catalogo.getRtnrCd());
			query.setParameter("ramo", catalogo.getRamo());
			query.setParameter("custNm", catalogo.getCustNm());
			query.setParameter("origPolNum", catalogo.getOrigPolNum());
			query.setParameter("pordCd", catalogo.getPordCd());
			query.setParameter("sbGrpNum", catalogo.getSbGrpNum());
			query.setParameter("sbGrpNm", catalogo.getSbGrpNm());
			i = query.executeUpdate();
			return i > 0;
		} catch(Exception e) {
			throw new FitravaPersistenceException(String.format("Error en el saveCatalogoIssste(TExtIssste: %1$s), excepcion: %2$s",catalogo, e));
		}
	}
	
	public Boolean saveCatalogoConcepto74(TExtCncpt74 catalogo) throws FitravaPersistenceException {
		Query query = null;
		int i = 0;
		try {
			query = entityManager.createNamedQuery(QUERY_INSERT_CONCEPTO_74);
			query.setParameter("fullNm", catalogo.getFullNm());
			query.setParameter("natlId", catalogo.getNatlId());
			query.setParameter("penNum", catalogo.getPenNum());
			query.setParameter("polNum", catalogo.getPolNum());
			i = query.executeUpdate();
			return i > 0;
		} catch(Exception e) {
			throw new FitravaPersistenceException(String.format("Error en el saveCatalogoConcepto74(TExtCncpt74: %1$s), excepcion: %2$s", catalogo, e));
		}
	}
	
	
	public TExtFone findFoneBy(String foneId, String operacionName) throws FitravaPersistenceException {
//		log.info("En el findFoneBy(foneId: {}, operacionName: {})", foneId, operacionName);
		Query query = null;
		String producto = null;
		Integer aportacion = null;
		TExtFoneId tExtFoneId = null;
		TExtFone tExtFone = null;
		try {
			if (OperationUtility.isFoneVida(operacionName)) {
				producto = "VIDA";
			} else if ( OperationUtility.isFoneRetencion(operacionName)) {
				producto = "RETIRO";
				aportacion = 1;
			} else if ( OperationUtility.isFoneAportacion(operacionName)) {
				producto = "RETIRO";
				aportacion = 2;
			}  
			tExtFoneId = new TExtFoneId(foneId, producto, aportacion);
			tExtFone = mapFone.get(tExtFoneId);
			if (tExtFone != null) {
				return tExtFone;
			}
			//log.info("foneId: {}, producto: {}, aportacion: {}", foneId, producto, aportacion);
			if (aportacion == null) {
				query = entityManager.createNamedQuery(QUERY_FIND_FONE_BY_ID_1);
				query.setParameter("producto", producto);
			} else {
				query = entityManager.createNamedQuery(QUERY_FIND_FONE_BY_ID_2);
				query.setParameter("producto", producto);
				query.setParameter("aportacion", aportacion);
			}
			query.setParameter("foneId", foneId);
			tExtFone = (TExtFone)query.getSingleResult();
			mapFone.put(tExtFoneId, tExtFone);
			return tExtFone;
		} catch(Exception e) {
			throw new FitravaPersistenceException(String.format("Error en el findFoneBy(foneId: %1$s, operacionName: %2$s), excepcion: %3$s", foneId, operacionName, e));
		}
	}
	
	
	public List<String> saveAllRicsi(List<TExtRicsi> catalogos) throws FitravaPersistenceException {
		List<String> excepciones = new ArrayList<>();
		int i = 1;
		for (TExtRicsi catalogo: catalogos) {
			i++;
			try {
				saveCatalogoRicsi(catalogo);
			} catch(Exception e) {
				excepciones.add(String.format("No se pudo insertar el registro: %1$s, a causa de: %2$s", i, e));
			}
		}
		return excepciones;
	}

	public List<String> saveAllFone(List<TExtFone> catalogos) throws FitravaPersistenceException {
		List<String> excepciones = new ArrayList<>();
		int i = 1;
		for (TExtFone catalogo: catalogos) {
			i++;
			try {
				saveCatalogoFone(catalogo);
			} catch(Exception e) {
				excepciones.add(String.format("No se pudo insertar el registro: %1$s, a causa de: %2$s", i, e));
			}
		}
		return excepciones;
	}

	public List<String> saveAllIssste(List<TExtIssste> catalogos) throws FitravaPersistenceException {
		List<String> excepciones = new ArrayList<>();
		int i = 1;
		for (TExtIssste catalogo: catalogos) {
			i++;
			try {
				saveCatalogoIssste(catalogo);
			} catch(Exception e) {
				excepciones.add(String.format("No se pudo insertar el registro: %1$s, a causa de: %2$s", i, e));
			}
		}
		return excepciones;
	}
	
	public List<String> saveAllConcepto74(List<TExtCncpt74>  catalogos) throws FitravaPersistenceException {
		List<String> excepciones = new ArrayList<>();
		int i = 1;
		for (TExtCncpt74 catalogo: catalogos) {
			i++;
			try {
				saveCatalogoConcepto74(catalogo);
			} catch(Exception e) {
				excepciones.add(String.format("No se pudo insertar el registro: %1$s, a causa de: %2$s", i, e));
			}
		}
		return excepciones;
	}
	
	
	public void saveAllRicsiBatch(List<TExtRicsi> catalogos) throws FitravaPersistenceException {
		int cuenta = 0;
		Connection connection = null;
		PreparedStatement ps = null;
		try {
			connection = dataSource.getConnection();
			ps = connection.prepareStatement(insertRicsiBatch);
			for (TExtRicsi catalogo:catalogos) {
				ps.setString(1,  catalogo.getPolNum());
				ps.setString(2,  catalogo.getNatlId());
				ps.setString(3,  catalogo.getInsFullNm());
				ps.setString(4,  catalogo.getPolSttsNm());
				ps.setDate  (5,  UtilCommon.getDBDate(catalogo.getIssDt()));
				ps.setDate  (6,  UtilCommon.getDBDate(catalogo.getRcptDt()));
				ps.setDate  (7,  UtilCommon.getDBDate(catalogo.getPolEffDt()));
				ps.setString(8,  catalogo.getPyMthdCd());
				ps.setString(9,  catalogo.getClctKeyCd());
				ps.setString(10, catalogo.getPensionerNum());
				ps.setDouble(11, catalogo.getAnnlPremAmt()!=null?catalogo.getAnnlPremAmt().doubleValue():0.0);
				ps.setString(12, catalogo.getRcptSttsCd());
				ps.setDouble(13, catalogo.getClctPremAmt()!=null?catalogo.getClctPremAmt().doubleValue():0.0);
				
				ps.addBatch();
				if (cuenta > 0 && (cuenta%MAX_BATCH == 0 || cuenta == catalogos.size()-1)) {
					try {
						ps.executeBatch();
					} catch (Exception e) {
						log.error("No se pudo ejecutar este bloque", e);
					}
				}
				cuenta++;
			}
		} catch (Exception e) {
			throw new FitravaPersistenceException("No se pudo efectuar el insert batch", e);
		} finally {
			if (ps != null) {
				try {
					ps.close();
				} catch (SQLException e) {}
			}
			if (connection != null) {
				try {
					connection.close();
				} catch (SQLException e) {}
			}
		}
	}
	
	public void saveAllIsssteBatch(List<TExtIssste> catalogos) throws FitravaPersistenceException {
		int cuenta = 0;
		Connection connection = null;
		PreparedStatement ps = null;
		try {
			connection = dataSource.getConnection();
			ps = connection.prepareStatement(insertIsssteBatch);
			for (TExtIssste catalogo: catalogos) {
				ps.setString(1, catalogo.getRtnrCd());
				ps.setString(2, catalogo.getRamo());
				ps.setString(3, catalogo.getCustNm());
				ps.setString(4, catalogo.getOrigPolNum());
				ps.setString(5, catalogo.getPordCd());
				ps.setString(6, catalogo.getSbGrpNum());
				ps.setString(7, catalogo.getSbGrpNm());
				
				ps.addBatch();
				if (cuenta > 0 && (cuenta%MAX_BATCH == 0 || cuenta == catalogos.size()-1)) {
					try {
						ps.executeBatch();
					} catch (Exception e) {
						log.error("No se pudo ejecutar este bloque", e);
					}
				}
				cuenta++;
			}
		} catch (Exception e) {
			throw new FitravaPersistenceException("No se pudo efectuar el insert batch", e);
		} finally {
			if (ps != null) {
				try {
					ps.close();
				} catch (SQLException e) {}
			}
			if (connection != null) {
				try {
					connection.close();
				} catch (SQLException e) {}
			}
		}
	}

	public void saveAllFoneBatch(List<TExtFone> catalogos) throws FitravaPersistenceException {
		int cuenta = 0;
		Connection connection = null;
		PreparedStatement ps = null;
		try {
			connection = dataSource.getConnection();
			ps = connection.prepareStatement(insertFoneBatch);
			for (TExtFone catalogo: catalogos) {
				ps.setString(1,  catalogo.getFoneId());
				ps.setString(2,  catalogo.getOrigPolNum());
				ps.setString(3,  catalogo.getCustNm());
				ps.setString(4,  catalogo.getSbCtgyCd());
				ps.setString(5,  catalogo.getPordCd());
				ps.setInt   (6,  catalogo.getSbGrpNum()!=null?catalogo.getSbGrpNum().intValue():0);
				ps.setString(7,  catalogo.getSbGrpNm());
				ps.setString(8,  catalogo.getRcptNm());
				ps.setString(9,  catalogo.getStCd());
				ps.setDouble(10, catalogo.getPyrlDiscPct()!=null?catalogo.getPyrlDiscPct().doubleValue():0.0);
				ps.setInt   (11, catalogo.getInsCnt()!=null?catalogo.getInsCnt().intValue():0);
				ps.setInt   (12, catalogo.getPrevYrInsCnt()!=null?catalogo.getPrevYrInsCnt().intValue():0);
				ps.setDouble(13, catalogo.getMoPyrlAmt()!=null?catalogo.getMoPyrlAmt().doubleValue():0.0);
				ps.setDouble(14, catalogo.getIntSumAmt()!=null?catalogo.getIntSumAmt().doubleValue():0.0);
				ps.setDouble(15, catalogo.getInsAvgSumAmt()!=null?catalogo.getInsAvgSumAmt().doubleValue():0.0);
				ps.setDouble(16, catalogo.getAnnlPremAmt()!=null?catalogo.getAnnlPremAmt().doubleValue():0.0);
				ps.setDouble(17, catalogo.getMoPremAmt()!=null?catalogo.getMoPremAmt().doubleValue():0.0);

				ps.addBatch();
				if (cuenta > 0 && (cuenta%MAX_BATCH == 0 || cuenta == catalogos.size()-1)) {
					try {
						ps.executeBatch();
					} catch (Exception e) {
						log.error("No se pudo ejecutar este bloque", e);
					}
				}
				cuenta++;
			}
		} catch (Exception e) {
			throw new FitravaPersistenceException("No se pudo efectuar el insert batch", e);
		} finally {
			if (ps != null) {
				try {
					ps.close();
				} catch (SQLException e) {}
			}
			if (connection != null) {
				try {
					connection.close();
				} catch (SQLException e) {}
			}
		}
	}
	
	public void saveAllConcepto74Batch(List<TExtCncpt74> catalogos) throws FitravaPersistenceException {
		int cuenta = 0;
		Connection connection = null;
		PreparedStatement ps = null;
		try {
			connection = dataSource.getConnection();
			ps = connection.prepareStatement(insertConcepto74Batch);
			for (TExtCncpt74 catalogo: catalogos) {
				ps.setString(1, catalogo.getFullNm());
				ps.setString(2, catalogo.getNatlId());
				ps.setString(3, catalogo.getPenNum());
				ps.setString(4, catalogo.getPolNum());
				
				ps.addBatch();
				if (cuenta > 0 && (cuenta%MAX_BATCH == 0 || cuenta == catalogos.size()-1)) {
					try {
						ps.executeBatch();
					} catch (Exception e) {
						log.error("No se pudo ejecutar este bloque", e);
					}
				}
				cuenta++;
			}
		} catch (Exception e) {
			throw new FitravaPersistenceException("No se pudo efectuar el insert batch", e);
		} finally {
			if (ps != null) {
				try {
					ps.close();
				} catch (SQLException e) {}
			}
			if (connection != null) {
				try {
					connection.close();
				} catch (SQLException e) {}
			}
		}
	}
	
	
	public void saveAllTProcRecBatch(List<TProcRec> lista) throws FitravaPersistenceException {
		int cuenta = 0;
		Connection connection = null;
		PreparedStatement ps = null;
		try {
			connection = dataSource.getConnection();
			ps = connection.prepareStatement(insertTProcRecBatch);
			for (TProcRec tProcRec: lista) {
				ps.setString (1, tProcRec.getDstnctCtrlNum());
				ps.setLong   (2, tProcRec.getRecNum()!=null?tProcRec.getRecNum():0L);
				ps.setLong   (3, tProcRec.getLayoutFldId()!=null?tProcRec.getLayoutFldId().longValue():0L);
				ps.setString (4, tProcRec.getOrigVal()!=null?tProcRec.getOrigVal():Constantes.BLANK);
				ps.setString (5, tProcRec.getNewVal()!=null?tProcRec.getNewVal():Constantes.BLANK);
				ps.setBoolean(6, tProcRec.getBadRsltInd()!=null?tProcRec.getBadRsltInd().booleanValue():false);
				ps.setString (7, tProcRec.getMsgTxt());
				ps.setInt    (8, tProcRec.getRowNum());
				ps.setInt    (9, tProcRec.getColNum());
				ps.setString(10, tProcRec.getFileNm());
				ps.setString(11, tProcRec.getXcelSheetNm());
				
				ps.addBatch();
				if (cuenta > 0 && (cuenta%MAX_BATCH == 0 || cuenta == lista.size()-1)) {
					try {
						ps.executeBatch();
					} catch (Exception e) {
						log.error("No se pudo ejecutar este bloque", e);
					}
				}
				cuenta++;
			}
		} catch (Exception e) {
			throw new FitravaPersistenceException("No se pudo efectuar el insert batch", e);
		} finally {
			if (ps != null) {
				try {
					ps.close();
				} catch (SQLException e) {}
			}
			if (connection != null) {
				try {
					connection.close();
				} catch (SQLException e) {}
			}
		}
	}
	
	@SuppressWarnings("unchecked")
	public List<String> findFileNamesByDcn(String dcn) throws FitravaPersistenceException {
		log.info("En el findFileNamesByDcn(dcn: {})", dcn);
		Query query = null;
		try {
			query = entityManager.createNamedQuery(QUERY_FIND_ALL_FILENAME_BY_DCN);
			query.setParameter(DCN, dcn);
			query.setParameter(ESTATUS, TClctStts.Estatus.FINALIZADO.getId());
			
			return (List<String>) query.getResultList();
		} catch(Exception e) {
			throw new FitravaPersistenceException(String.format("Error en el findFileNamesByDcn(dcn: %1$s), excepcion: %2$s", dcn, e));
		}
	}

}
