package mx.com.metlife.tom.fitrava.services.model.entity;

import java.util.Date;

import lombok.Data;

@Data
public class TExtRicsiId implements java.io.Serializable{

	private static final long serialVersionUID = -543291867468569537L;

	private String  polNum= null;
	private String  natlId= null;
	private String  insFullNm= null;
	private String  polSttsNm= null;
	private Date  issDt= null;
	private Date  rcptDt= null;
	private Date  polEffDt= null;
	private Date  pyMthdCd= null;
	private String  clctKeyCd= null;
	private String  pensionerNum= null;
	private Double  annlPremAmt= null;
	private String  rcptSttsCd= null;
	private Double  clctPremAmt= null;


}
