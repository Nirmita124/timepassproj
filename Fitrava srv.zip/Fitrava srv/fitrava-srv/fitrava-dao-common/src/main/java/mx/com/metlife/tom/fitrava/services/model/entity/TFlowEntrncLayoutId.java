package mx.com.metlife.tom.fitrava.services.model.entity;

import lombok.Data;

@Data
public class TFlowEntrncLayoutId implements java.io.Serializable {

	private static final long serialVersionUID = 1L;

	private Long flowId = null;
	private Long layoutId = null;

	public TFlowEntrncLayoutId() {
	}

	public TFlowEntrncLayoutId(Long flowId, Long layoutId) {
		super();
		this.flowId = flowId;
		this.layoutId = layoutId;
	}
	
	
}
