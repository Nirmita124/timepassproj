package mx.com.metlife.tom.fitrava.services.model.entity;

import lombok.Data;

@Data
public class TProcFileId implements java.io.Serializable{

	private static final long serialVersionUID = 1L;

	private String dstnctCtrlNum = null;
	private String fileNm = null;

	public TProcFileId () {
	}

	public TProcFileId(String dstnctCtrlNum, String fileNm) {
		super();
		this.dstnctCtrlNum = dstnctCtrlNum;
		this.fileNm = fileNm;
	}
	
	
}
