package mx.com.metlife.tom.fitrava.services.model.entity;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import lombok.Data;

@SuppressWarnings("serial")
@Data
@Entity(name = "TLayout")
@Table(name = "T_LAYOUT")
public class TLayout implements java.io.Serializable{

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "LAYOUT_ID")
	private Long layoutId = null;

	@Column(name = "EAI_CD")
	private String eaiCd = null;

	@Column(name = "LAYOUT_ACT_IND")
	private Boolean layoutActInd = null;

	@Column(name = "LAYOUT_NM")
	private String layoutNm = null;

	@Column(name = "LAYOUT_DSCR")
	private String layoutDscr = null;

	@Column(name = "XPCT_REC_LNTH_NUM")
	private Integer xpctRecLnthNum = null;

	@Column(name = "HD_IND")
	private Boolean hdInd = null;

	@Column(name = "FTR_IND")
	private Boolean ftrInd = null;

	@Column(name = "EXT_CD")
	private String extCd = null;

	@Column(name = "DLMT_IND")
	private Boolean dlmtInd = null;

	@Column(name = "DLMT_CHAR_CD")
	private String dlmtChar = null;

	@Column(name = "OMIT_INIT_REC_CNT")
	private Integer omitInitRecCnt = null;

	@Column(name = "CRT_USR_ID")
	private String crtUsrId = null;

	@Column(name = "CRT_TS")
	private Date crtTs = null;

	@Column(name = "UPDT_USR_ID")
	private String updtUsrId = null;

	@Column(name = "UPDT_TS")
	private Date updtTs = null;
	
	@Column(name="COL_CNT")
	private Integer numColumns = null;
	
//	@Column(name="ERR_ALLW_PCT")
//	private Float errorUmbral = null;
	
	@OneToMany(cascade=CascadeType.ALL, fetch=FetchType.EAGER, mappedBy="layoutId")
	private List<TLayoutXcel> lstTLayoutXcel = null;
}
