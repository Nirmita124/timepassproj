package mx.com.metlife.tom.fitrava.services.model.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import lombok.Data;

@SuppressWarnings("serial")
@Data
@Entity
@Table(name = "T_PROC_REC_SUM_DTL")
@IdClass(TProcRecSumDtlId.class)
public class TProcRecSumDtl implements java.io.Serializable{

	@Id
	@Column(name = "DSTNCT_CTRL_NUM")
	private String dstnctCtrlNum = null;

	@Id
	@Column(name = "FILE_NM")
	private String fileNm = null;

	@Id
	@Column(name = "LAYOUT_FLD_ID")
	private Long layoutFldId = null;

	@Column(name = "REC_SUM_VAL")
	private String recSumVal = null;

	@Column(name = "RSLT_MSG_TXT")
	private String rsltMsgTxt = null;


}
