package mx.com.metlife.tom.fitrava.services.model.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import mx.com.metlife.tom.fitrava.services.model.entity.TProc;

@Repository
public interface TProcRepository extends JpaRepository<TProc, String>{

	List<TProc> findByFlowId(Long flowId);

	Long existDcn(@Param("dcn")String dcn);
			
}
