package mx.com.metlife.tom.fitrava.services.dto;

import org.dozer.Mapping;

import lombok.Data;
import lombok.EqualsAndHashCode;

@EqualsAndHashCode(callSuper=false)
@Data
public class CatalogoFoneDTO  extends CatalogoFitravaDTO { 

	@Mapping("foneId")
	private String id;

	@Mapping("origPolNum")
	private String polizaOriginal;
	
	@Mapping("custNm")
	private String contratante;

	@Mapping("sbCtgyCd")
	private Integer ramoSubramo;
	
	@Mapping("pordCd")
	private String producto;
	
	@Mapping("sbGrpNum")
	private Integer subgrupoAplicacion;
	
	@Mapping("sbGrpNm")
	private String descripcionSubgrupo;
	
	@Mapping("rcptNm")
	private String reciboFiscalCartaRecibo;
	
	//no se que sea
	private String stCd = null;
	
	@Mapping("pyrlDiscPct")
	private Double primaSueldoMet;
	
	@Mapping("insCnt")
	private Integer numAsegurados;
	
	@Mapping("prevYrInsCnt")
	private Integer prevYrInsCnt = null;
	
	@Mapping("moPyrlAmt")
	private Double nominaMensual;
	
	@Mapping("intSumAmt")
	private Double sumaAsegurada;
	
	@Mapping("insAvgSumAmt")
	private Double sumaAseguradaPromedio;
	
	@Mapping("annlPremAmt")
	private Double primaAnual;
	
	@Mapping("moPremAmt")
	private Double primaMensual;

}
