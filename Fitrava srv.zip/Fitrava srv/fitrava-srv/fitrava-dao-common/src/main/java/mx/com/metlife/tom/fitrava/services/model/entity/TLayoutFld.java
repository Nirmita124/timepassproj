package mx.com.metlife.tom.fitrava.services.model.entity;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.Table;

import lombok.Data;

@SuppressWarnings("serial")
@Data
@Entity(name = "TLayoutFld")
@Table(name = "T_LAYOUT_FLD")
public class TLayoutFld implements java.io.Serializable{

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "LAYOUT_FLD_ID")
	private Long layoutFldId = null;

	@Column(name = "LAYOUT_ID")
	private Long layoutId = null;

	@Column(name = "LAYOUT_FLD_NM")
	private String layoutFldNm = null;

	@Column(name = "LAYOUT_FLD_DSCR")
	private String layoutFldDscr = null;

	@Column(name = "DATATYP_ID")
	private Integer datatypId = null;

	@Column(name = "MNDT_LAYOUT_FLD_IND")
	private Boolean mndtLayoutFldInd = null;

	@Column(name = "LAYOUT_FLD_LNTH_NUM")
	private Integer layoutFldLnthNum = null;

	@Column(name = "SEPRTR_DEC_VAL")
	private String seprtrDecVal = null;

	@Column(name = "DEC_PSTN_CNT")
	private Integer decPstnCnt = null;

	@Column(name = "INIT_PSTN_NUM")
	private Integer initPstnNum = null;

	@Column(name = "FNL_PSTN_NUM")
	private Integer fnlPstnNum = null;

	@Column(name = "CIFRA_CTRL_IND")
	private Boolean cifraCtrlInd = null;

	@Column(name = "LAYOUT_FLD_LBL_NM")
	private String layoutFldLblNm = null;

	@Column(name = "OPER_ID")
	private Integer operId = null;

	@Column(name="HDN_IND")
	private Character hdnInd = null;
	
	@OneToMany(cascade=CascadeType.ALL, fetch=FetchType.EAGER, mappedBy="layoutFldId")
	@OrderBy("layoutFldOrdNum")
	private Set<TLayoutFldAtrb> listTLayoutFldAtrb;

    @ManyToOne
    @JoinColumn(name = "OPER_ID", nullable = true, insertable = false, updatable = false)
    private TOper tOper;

    @ManyToOne
    @JoinColumn(name = "DATATYP_ID", nullable = false, insertable = false, updatable = false)
    private TDatatyp tDatatyp;

    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER, mappedBy = "fldTformId")
	@OrderBy("fldTformId")
	private Set<TFldTform> listTFldTform;

}
