package mx.com.metlife.tom.fitrava.services.model.entity;

import java.util.Date;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.Table;

import lombok.Data;

@SuppressWarnings("serial")
@Data
@Entity
@Table(name = "T_FILE_PROC")
public class TProc implements java.io.Serializable{

	@Id
	@Column(name = "DSTNCT_CTRL_NUM")
	private String dstnctCtrlNum = null;

	@Column(name = "FLOW_ID")
	private Long flowId = null;

	@Column(name = "RCPTN_TS")
	private Date rcptnTs = null;
	
	@Column(name = "ENTRNC_LAYOUT_ID")
	private Long entrncLayoutId = null;
	
	@Column(name = "PRTY_NUM")
	private Integer prtyNum = null;

	@Column(name = "CRT_USR_ID")
	private String crtUsrId = null;

	@Column(name = "CLCT_STTS_ID")
	private Integer clctSttsId = null;

	@Column(name = "RSLT_DSCR")
	private String rsltDscr = null;
	
	@ManyToOne
    @JoinColumn(name = "FLOW_ID", nullable = false, insertable = false, updatable = false)
    private TFlow tFlow;
	
	@OneToMany(cascade=CascadeType.ALL, mappedBy="dstnctCtrlNum")
	@OrderBy("uloadExternalDataId")
	private Set<TUloadExt> lstTUloadExt = null;

}
