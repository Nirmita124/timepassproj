package mx.com.metlife.tom.fitrava.services.model.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import mx.com.metlife.tom.fitrava.services.model.entity.TFlow;

@Repository
public interface TFlowRepository extends JpaRepository<TFlow, Long>{

	void mergeLayoutSalida(@Param("flujoId") Long flujoId, @Param("layoutId") Long layoutId);

	//List<TFlow> findByEaiRetainerLayout(@Param("eaiCd") String eaiCd, @Param("retainerId") String retainerId, @Param("layoutId") Long layoutId);
	
	List<TFlow> findByLayout(@Param("layoutId") Long layoutId);
	
	List<TFlow> findFlowsByEaiAndExt(@Param("eaiCd") String eaiCd, @Param("ext") String ext);
	
	TFlow findByName (@Param ("name") String name);
}
