package mx.com.metlife.tom.fitrava.services.model.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import mx.com.metlife.tom.fitrava.services.model.entity.TLayoutXcel;
import mx.com.metlife.tom.fitrava.services.model.entity.TLayoutXcelId;

@Repository
public interface TLayoutXcelRepository extends JpaRepository<TLayoutXcel, TLayoutXcelId>{ 

	@Transactional
	void deleteByLayoutId(Long  layoutId);
}
