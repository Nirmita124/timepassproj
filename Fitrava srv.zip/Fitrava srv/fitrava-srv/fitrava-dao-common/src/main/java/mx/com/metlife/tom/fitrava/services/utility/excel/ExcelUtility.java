package mx.com.metlife.tom.fitrava.services.utility.excel;

import java.io.File;
import java.io.InputStream;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Sheet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import mx.com.metlife.tom.fitrava.services.error.FitravaException;
import mx.com.metlife.tom.fitrava.services.utility.UtilCommon;

public abstract class ExcelUtility {
	
	protected static final Logger log = LoggerFactory.getLogger(ExcelUtility.class);


	protected List<CellType> columnTypes = null;
	protected Integer numColumnas = null;
	protected Integer columnaInicial;
	protected Integer columnaFinal;
	protected Integer renglonesAOmitir;
	protected Integer numHojas = null;
	protected String[] hojasOmitir = null;
	protected Boolean isForNumber = null;
	protected File excelFile = null;
	protected InputStream is = null;
	
	public ExcelUtility(File excelFile, Integer renglonesAOmitir, String...hojasOmitir) throws FitravaException  {
		this.excelFile = excelFile;
		this.renglonesAOmitir = renglonesAOmitir;
		this.hojasOmitir = hojasOmitir;
	}
	
	public Integer getNumColumnas() {
		return numColumnas;
	}

	public Integer getColumnaInicial() {
		return columnaInicial;
	}

	public Integer getColumnaFinal() {
		return columnaFinal;
	}
	
	public void setRenglonesAOmitir(Integer renglonesAOmitir) {
		this.renglonesAOmitir = renglonesAOmitir;
	}
	
	protected void initIsForNumber() {
		if (hojasOmitir != null && hojasOmitir.length > 0) {
			isForNumber = UtilCommon.hasOnlyIntegers(hojasOmitir);
		}
	}
	
	protected Boolean validateHojaNumero(int i) {
		Integer h = null;
		for (String hoja:hojasOmitir) {
			h = Integer.parseInt(hoja);
			if (h.equals(i)) {
				return true;
			}
		}
		return false;
	}
	
	protected Boolean validateHojaNombre(String nombre) {
		for (String hoja:hojasOmitir) {
			if (nombre.equals(hoja)) {
				return true;
			}
		}
		return false;
	}

	public int getNumeroHojas() {
		return numHojas;
	}

	
	public String[] getRow(int hoja, int num) {
		String[] row = new String[getColumnTypes().size()];
		for(int i = 0; i < row.length; i++) {
			row[i] = getCellString(hoja, num, i);
		}
		return row;
	}
	
	protected String getCellString(int hoja, int rownum, int cellnumber) {
		rownum = rownum + renglonesAOmitir;
		if (hoja <0 || hoja > getNumeroHojas()) {
			return null;
		}
		if (rownum < 0 || rownum > getHoja(hoja).getLastRowNum()) {
			return null;
		}
		Cell cell = getHoja(hoja).getRow(rownum).getCell(cellnumber);
		return UtilCommon.getCellValueAsString(cell);
	}
	
	public Integer getLastRowNum(int sheetNum) {
		int i = getHoja(sheetNum).getLastRowNum();
		return i-renglonesAOmitir;
	}

	protected abstract void init() throws FitravaException;

	public abstract void initAllHojas();

	public abstract List<CellType> getColumnTypes();

	public abstract Sheet getHoja(int sheet);

	public abstract void close();
}
