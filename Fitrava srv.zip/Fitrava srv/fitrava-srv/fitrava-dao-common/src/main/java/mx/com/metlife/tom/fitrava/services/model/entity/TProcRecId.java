package mx.com.metlife.tom.fitrava.services.model.entity;

import java.io.Serializable;

import lombok.Data;

@Data
public class TProcRecId implements Serializable {

	private static final long serialVersionUID = -6097360882448046861L;

	private String dstnctCtrlNum = null;
	private Long recNum = null;
	private Long layoutFldId = null;
	private String fileNm = null;

	public TProcRecId() {}

	public TProcRecId(String dstnctCtrlNum, Long recNum, Long layoutFldId, String fileNm) {
		super();
		this.dstnctCtrlNum = dstnctCtrlNum;
		this.recNum = recNum;
		this.layoutFldId = layoutFldId;
		this.fileNm = fileNm;
	}

	
	
}
