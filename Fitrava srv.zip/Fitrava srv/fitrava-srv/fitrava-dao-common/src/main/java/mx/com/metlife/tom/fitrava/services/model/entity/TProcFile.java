package mx.com.metlife.tom.fitrava.services.model.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.Data;

@SuppressWarnings("serial")
@Data
@Entity
@Table(name = "T_PROC_FILE")
@IdClass(TProcFileId.class)
public class TProcFile implements java.io.Serializable {

	@Id
	@Column(name = "DSTNCT_CTRL_NUM")
	private String dstnctCtrlNum = null;

	@Id
	@Column(name = "FILE_NM")
	private String fileNm = null;

	@Column(name = "PROC_FILE_ORD_NUM")
	private Integer procFileOrdNum = null;

	@Column(name = "ENTRNC_LAYOUT_ID")
	private Long entrncLayoutId = null;

	@Column(name = "CLCT_STTS_ID")
	private Integer clctSttsId = null;

	@Column(name = "PROC_FILE_STRT_TS")
	private Date procFileStrtTs = null;

	@Column(name = "PROC_FILE_END_TS")
	private Date procFileEndTs = null;
	
	@Column(name = "FULL_PATH_ORIG_NM")
	private String fullPathOrigNm = null;
	
	@ManyToOne
    @JoinColumn(name = "ENTRNC_LAYOUT_ID", nullable = true, insertable = false, updatable = false)
    private TLayout layoutEntrada = null;

}
