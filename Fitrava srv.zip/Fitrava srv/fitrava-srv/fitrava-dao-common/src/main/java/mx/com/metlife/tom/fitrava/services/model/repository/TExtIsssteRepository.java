package mx.com.metlife.tom.fitrava.services.model.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import mx.com.metlife.tom.fitrava.services.model.entity.TExtIssste;
import mx.com.metlife.tom.fitrava.services.model.entity.TExtIsssteId;

@Repository
public interface TExtIsssteRepository extends JpaRepository<TExtIssste, TExtIsssteId>{

	List<TExtIssste> findByConceptoAndRamo(@Param("concepto")Integer concepto, @Param("ramo")Integer ramo);
	
	List<TExtIssste> findByConceptoAndRamoAndNumeroPoliza(@Param("concepto")Integer concepto, @Param("ramo")Integer ramo, @Param("polNum")String polNum);
}
