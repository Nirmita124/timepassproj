package mx.com.metlife.tom.fitrava.services.model.entity;

import lombok.Data;

@Data
public class TExtIsssteId implements java.io.Serializable{

	private static final long serialVersionUID = 378629973770646525L;

	private String rtnrCd = null;
	private String ramo = null;
	private String custNm = null;
	private String origPolNum = null;
	private String pordCd = null;
	private String  sbGrpNum= null;
	private String  sbGrpNm= null;

}
