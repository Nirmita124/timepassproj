package mx.com.metlife.tom.fitrava.services.model.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import mx.com.metlife.tom.fitrava.services.model.entity.TFlowMappingDtl;
import mx.com.metlife.tom.fitrava.services.model.entity.TFlowMappingDtlId;

@Repository
public interface TFlowMappingDtlRepository extends JpaRepository<TFlowMappingDtl, TFlowMappingDtlId>{

	@Modifying
	void deleteByFlowMappingId(@Param("flowMappingId") Long flowMappingId);

}
