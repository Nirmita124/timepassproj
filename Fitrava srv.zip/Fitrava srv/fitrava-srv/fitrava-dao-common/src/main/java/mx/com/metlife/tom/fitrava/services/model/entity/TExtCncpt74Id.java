package mx.com.metlife.tom.fitrava.services.model.entity;

import lombok.Data;

@Data
public class TExtCncpt74Id implements java.io.Serializable{

	private static final long serialVersionUID = 6338878094726508806L;

	private String penNum = null;
	private String natlId = null;
	private String fullNm = null;
	private String polNum = null;

	public TExtCncpt74Id() {}
	
	public TExtCncpt74Id(String penNum, String natlId, String fullNm, String polNum) {
		super();
		this.penNum = penNum;
		this.natlId = natlId;
		this.fullNm = fullNm;
		this.polNum = polNum;
	}
	
}
