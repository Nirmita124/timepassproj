package mx.com.metlife.tom.fitrava.services.model.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Data;

@SuppressWarnings("serial")
@Data
@Entity
@Table(name = "T_CLCT_STTS")
public class TClctStts implements java.io.Serializable{

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "CLCT_STTS_ID")
	private Integer clctSttsId = null;

	@Column(name = "CLCT_STTS_NM")
	private String clctSttsNm = null;

	public enum Estatus {
		INHABILITADO 			(0, "INHABILITADO"),
		PENDIENTE 				(1, "PENDIENTE"),
		EN_PROCESO 				(2, "EN PROCESO"),
		LAYOUT_TRANSFORMADO 	(3, "LAYOUT TRANSFORMADO"),
		ENVIADO_A_LEGADO 		(4, "ENVIADO A LEGADO"),
		RESPUESTA_DE_LEGADO 	(5, "RESPUESTA DE LEGADO"),
		FINALIZADO				(6, "FINALIZADO");
		
		private Integer id;
		private String descripcion;
		
		private  Estatus(Integer id, String descripcion) {
			this.id  = id;
			this.descripcion = descripcion;
		}

		public Integer getId() {
			return id;
		}

		public String getDescripcion() {
			return descripcion;
		}

	}
}
