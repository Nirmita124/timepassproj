package mx.com.metlife.tom.fitrava.services.model.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import lombok.Data;
import lombok.ToString;


@SuppressWarnings("serial")
@ToString(exclude = {"tmenus"})
@Data
@Entity
@Table(name = "T_ROLE")
public class TRole implements java.io.Serializable {

	@Id
	@Column(name = "ROLE_ID")
	private Integer roleId = null;

	@Column(name = "ROLE_NM")
	private String roleNm = null;

	@Column(name = "ROLE_DSCR")
	private String roleDscr = null;

	@Column(name = "ROLE_ACT_IND")
	private Integer roleActInd = null;

	@JoinTable(name = "T_ROLE_MENU", 
			joinColumns = @JoinColumn(name = "ROLE_ID", nullable = false, insertable = false, updatable = false ), 
			inverseJoinColumns = @JoinColumn(name = "MENU_ID", nullable = false, insertable = false, updatable = false))
	@ManyToMany(fetch = FetchType.EAGER,cascade = CascadeType.ALL)
	private List<TMenu> tmenus;
}
