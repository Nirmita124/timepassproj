package mx.com.metlife.tom.fitrava.services.model.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.Table;

import lombok.Data;

@SuppressWarnings("serial")
@Data
@Entity(name= "TFldTform")
@Table(name = "T_FLD_TFORM")
public class TFldTform implements java.io.Serializable{

	@Id
	@Column(name = "FLD_TFORM_ID")
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long fldTformId = null;

	@Column(name = "LAYOUT_FLD_ID")
	private Long layoutFldId = null;

	@Column(name = "FLD_OPER_ID")
	private Long fldOperId = null;

	@Column(name = "CNST_VAL")
	private String cnstVal = null;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER, mappedBy = "fldTformId")
	@OrderBy("fldTformParmOrdNum")
	private List<TFldTformParm> listTFldTformParm;


}
