package mx.com.metlife.tom.fitrava.services.model.entity;

import lombok.Data;

@Data
public class TExtFoneId implements java.io.Serializable{

	private static final long serialVersionUID = -2114874591218923205L;

	private String foneId = null;
	private String pordCd = null;
	private Integer sbGrpNum = null;

	public TExtFoneId() {}
	
	public TExtFoneId(String foneId, String pordCd, Integer sbGrpNum) {
		super();
		this.foneId = foneId;
		this.pordCd = pordCd;
		this.sbGrpNum = sbGrpNum;
	}
	
}
