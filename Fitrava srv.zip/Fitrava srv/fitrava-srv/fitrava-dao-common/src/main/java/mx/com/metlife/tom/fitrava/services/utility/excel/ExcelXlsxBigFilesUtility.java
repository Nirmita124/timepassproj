package mx.com.metlife.tom.fitrava.services.utility.excel;

import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.util.Assert;

import com.monitorjbl.xlsx.StreamingReader;

import mx.com.metlife.tom.fitrava.services.error.FitravaException;
import mx.com.metlife.tom.fitrava.services.utility.UtilCommon;

public class ExcelXlsxBigFilesUtility extends ExcelUtility {

	private Workbook book = null;
	private List<Sheet> allSheet = null;
	private List<String[]> rows = null;
	private Integer hojaActual = 0;
	
	public ExcelXlsxBigFilesUtility(File excelFile, Integer renglonesAOmitir, String...hojasOmitir) throws FitravaException  {
		super(excelFile, renglonesAOmitir, hojasOmitir);
		init();
		initAllHojas();
		initAllRows(hojaActual);
	}
	
	public void init() throws FitravaException {
		try {
			is = new FileInputStream(excelFile);
			this.book = StreamingReader.builder()
				.rowCacheSize(50)//100
		        .bufferSize(2048)//4096   
		        .open(is);     
		} catch (Exception e) {
			throw new FitravaException("el archivo esta malformado", e);
		}
	}
	
	public void initAllHojas() {
		System.out.println("dentro");
		this.allSheet = new ArrayList<>();
		initIsForNumber();
		System.out.println("book.getNumberOfSheets(): " + book.getNumberOfSheets());
		for (int i = 0; i < book.getNumberOfSheets(); i++) {
			System.out.println("i: " + i);
			if (isForNumber != null) {
				if (isForNumber) {
					if (validateHojaNumero(i)) {
						continue;
					}
				} else {
					if(validateHojaNombre(book.getSheetAt(i).getSheetName())) {
						continue;
					}
				}
			}
			System.out.println("----->>>" + i);
			allSheet.add(book.getSheetAt(i));
		}
		this.numHojas = allSheet.size();
	}
	
	public List<CellType> getColumnTypes() {
		return columnTypes;
	}
	
	private void initColumnTypes(Row row) {
		columnTypes = new ArrayList<>();
		for (Cell cell: row) {
			if (cell.getCellType().equals(CellType._NONE) 
					|| cell.getCellType().equals(CellType.BLANK)
					|| cell.getCellType().equals(CellType.ERROR)) 
			{
				continue;
			}
			if (columnaInicial == null) {
				columnaInicial = cell.getColumnIndex();
			}
			columnTypes.add(cell.getCellType());
			columnaFinal = cell.getColumnIndex();
		}
		numColumnas = columnTypes.size();
	}
	
	public void initAllRows(int hoja){
		Assert.notNull(renglonesAOmitir, "Es necesario que indique el numero de renglones a omitir");
		rows = new ArrayList<>();
		int i = 0;
		int j = 0;
		String[] arr = null;
		for (Row row :getHoja(hoja)) {
			if (i < renglonesAOmitir) {
				i++;
				continue;
			}
			if (j == 5) {
				break;
			}
			if (getColumnTypes() == null) {
				initColumnTypes(row);
			}
			arr = getRowAsStringArray(row);
			if (UtilCommon.isNull(arr)) {
				j++;
				continue;
			}
			rows.add(arr);
		}
	}
	
	private String[] getRowAsStringArray(Row row) {
		List<String> array = new ArrayList<>();
		int i = 0;
		for(Cell cell: row) {
			if (i < getColumnaInicial()) {
				i++;
				continue;
			}
			if (i > getColumnaFinal()) {
				break;
			}
			array.add(cell.getStringCellValue());
			i++;
		}
		return array.toArray(new String[array.size()]);
	}
	
	@Override
	public String[] getRow(int hoja, int num) {
		if (hoja != hojaActual) {
			hojaActual = hoja;
			initAllRows(hoja);
		}
		if (num >= 0) {
			return rows.get(num);
		}
		return null;
	}
	
	
	public Sheet getHoja(int sheet) {
		if (sheet >=0 && sheet<allSheet.size()) {
			return allSheet.get(sheet);
		}
		return null;
	}

	@Override
	public Integer getLastRowNum(int hoja) {
		if (hoja != hojaActual) {
			hojaActual = hoja;
			initAllRows(hoja);
		}
		return rows!=null?rows.size():0;
	}
	

	public void close() {
		if (is != null) {
			try {
				is.close();
			} catch (Exception e) {}
		}
		if (book != null) {
			try {
				book.close();
			} catch (Exception e) {}
		}
	}
	
	
	public static void main(String[] args) throws FitravaException {
		String archivo = "C:\\Users\\icarball\\Documents\\asignacion\\0_LAYOUTS\\capgeminy\\colectivos\\FONE\\ENERO\\RETIRO RETENCION\\CONSOLIDACIÓN1_COLECTIVIDAD 77y77A CLC_QNA02.xlsx";
		ExcelUtility excel = new ExcelXlsxBigFilesUtility(new File(archivo), 1, "0");
		Integer num = excel.getNumeroHojas();
		System.out.println("num: " + num);
		for (int i = 0; i < num; i++) {
			String nombre = excel.getHoja(i).getSheetName();
			System.out.println("nombre: " + nombre);
			int max = excel.getLastRowNum(i);
			System.out.println("max: " + max);
			for (int j = 0; j < max; j++) {
				System.out.println(j + " --->"+ UtilCommon.getArrayToString(excel.getRow(i, j)) + "<---");
			}
		}
		List<CellType> cels = excel.getColumnTypes();
		cels.forEach(x -> System.out.println("--"+x));
	}
	
}
