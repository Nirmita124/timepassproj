package mx.com.metlife.tom.fitrava.services.model.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Data;

@SuppressWarnings("serial")
@Data
@Entity(name = "TOper")
@Table(name = "T_OPER")
public class TOper implements java.io.Serializable{

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "OPER_ID")
	private Integer operId = null;

	@Column(name = "OPER_NM")
	private String operNm = null;

	@Column(name = "OPER_DSCR")
	private String operDscr = null;

	@Column(name = "OPER_CLASS_NM")
	private String operClassNm = null;

	@Column(name = "OPER_MTHD_DSCR")
	private String operMthdDscr = null;


}
