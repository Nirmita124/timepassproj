package mx.com.metlife.tom.fitrava.services.model.entity;


import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "T_BIG_FILE")
public class TBigFile implements Serializable {

	private static final long serialVersionUID = -2919570219374926409L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "FILE_GEN_ID")
	private Integer fileId;

	@Column(name = "BIG_FILE_TXT")
	@Lob
	private byte[] file;
	
//	@Column(name = "BIG_FILE_TXT")
//	private Double sizeMB;
	
	@Column(name = "BIG_FILE_NM")
	private String bigFileNm;
	
	@Column(name = "DSTNCT_CTRL_NUM")
	private String dstnctCtrlNum;
	
	@Column(name = "ULOAD_DT")
	private Date uloadDt;

	@Column(name = "CRT_USR_ID")
	private String crtUsrId;
	
}