package mx.com.metlife.tom.fitrava.services.error;

/**
 * Exception class to handle custom validation related exceptions.
 * 
 * @author Capgemini
 * @since 03/15/2019
 */
public class ValidationException extends Exception {

	private static final long serialVersionUID = 7733209621979119558L;

	public ValidationException() {
		super();
	}

	public ValidationException(String message) {
		super(message);
	}

	public ValidationException(String message, Throwable cause) {
		super(message, cause);
	}

}
