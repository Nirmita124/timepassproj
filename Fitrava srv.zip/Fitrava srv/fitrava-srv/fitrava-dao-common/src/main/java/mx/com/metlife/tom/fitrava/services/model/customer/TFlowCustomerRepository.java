package mx.com.metlife.tom.fitrava.services.model.customer;

import java.util.List;

import mx.com.metlife.tom.fitrava.services.error.FitravaPersistenceException;
import mx.com.metlife.tom.fitrava.services.model.entity.TFlow;

public interface TFlowCustomerRepository {

	List<TFlow> findAllBy(String retenedorId, String eaiCd) throws FitravaPersistenceException;
	
	Boolean mergeEstatus(Long flowId, Integer estatus) throws FitravaPersistenceException;
}
