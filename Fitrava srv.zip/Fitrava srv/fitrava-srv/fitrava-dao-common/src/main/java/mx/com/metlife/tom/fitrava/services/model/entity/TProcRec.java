package mx.com.metlife.tom.fitrava.services.model.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import lombok.Data;

@SuppressWarnings("serial")
@Data
@Entity
@Table(name = "T_PROC_REC")
@IdClass(TProcRecId.class)
public class TProcRec implements java.io.Serializable{

	@Id
	@Column(name = "DSTNCT_CTRL_NUM")
	private String dstnctCtrlNum = null;

	@Id
	@Column(name = "REC_NUM")
	private Long recNum = null;

	@Id
	@Column(name = "FILE_NM")
	private String fileNm = null;

	@Id
	@Column(name = "LAYOUT_FLD_ID")
	private Long layoutFldId = null;

	@Column(name="ROW_NUM")
	private Integer rowNum = null;

	@Column(name="COL_NUM")
	private Integer colNum = null;
	
	@Column(name = "ORIG_VAL")
	private String origVal = null;

	@Column(name = "NEW_VAL")
	private String newVal = null;

	@Column(name = "BAD_RSLT_CD")
	private Boolean badRsltInd = null;

	@Column(name = "MSG_TXT")
	private String msgTxt = null;
	
	@Column(name="XCEL_SHEET_NM")
	private String xcelSheetNm = null;
	
}
