package mx.com.metlife.tom.fitrava.services.model.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@SuppressWarnings("serial")
@Data
@Entity
@Table(name = "T_APP")
public class TApp implements java.io.Serializable{

	@Id
	@Column(name = "EAI_CD")
	private String eaiCd = null;

	@Column(name = "EAI_DSCR")
	private String eaiDscr = null;

	@Column(name = "DIR_ORIG_DSCR")
	private String dirOrigDscr = null;

	@Column(name = "DIR_DEST_DSCR")
	private String dirDestDscr = null;

}
