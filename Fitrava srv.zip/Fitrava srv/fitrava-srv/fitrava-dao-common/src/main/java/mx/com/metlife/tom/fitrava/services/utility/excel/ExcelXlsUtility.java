package mx.com.metlife.tom.fitrava.services.utility.excel;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.springframework.util.Assert;

import mx.com.metlife.tom.fitrava.services.error.FitravaException;

public class ExcelXlsUtility extends ExcelUtility {

	private HSSFWorkbook book = null;
	private List<HSSFSheet> allSheet = null;
	private POIFSFileSystem fs = null;
	
	public ExcelXlsUtility(File excelFile, Integer renglonesAOmitir, String...hojasOmitir) throws FitravaException  {
		super(excelFile, renglonesAOmitir, hojasOmitir);
		init();
		initAllHojas();
		getColumnTypes();
	}
	
	public void init() throws FitravaException {
		try {
	    	fs = new POIFSFileSystem(excelFile);
			this.book = new HSSFWorkbook(fs.getRoot(), true);
		} catch (IOException e) {
			throw new FitravaException("el archivo esta malformado", e);
		}
		
	}
	
	public void initAllHojas() {
		//System.out.println("dentro");
		this.allSheet = new ArrayList<>();
		initIsForNumber();
		//System.out.println("book.getNumberOfSheets(): " + book.getNumberOfSheets());
		for (int i = 0; i < book.getNumberOfSheets(); i++) {
			//System.out.println("i: " + i);
			if (isForNumber != null) {
				if (isForNumber) {
					if (validateHojaNumero(i)) {
						continue;
					}
				} else {
					if(validateHojaNombre(book.getSheetAt(i).getSheetName())) {
						continue;
					}
				}
			}
			allSheet.add(book.getSheetAt(i));
		}
		this.numHojas = allSheet.size();
	}
	
	public List<CellType> getColumnTypes() {
		Assert.notNull(renglonesAOmitir, "Es necesario que indique el numero de renglones a omitir");
		if (columnTypes == null) {
			columnTypes = new ArrayList<>();
			int i = 0;
			for (Row row :getHoja(0)) {
				if (i < renglonesAOmitir) {
					i++;
					continue;
				}
				for (Cell cell: row) {
					if (cell.getCellType().equals(CellType._NONE) 
							|| cell.getCellType().equals(CellType.BLANK)
							|| cell.getCellType().equals(CellType.ERROR)) 
					{
						continue;
					}
					if (columnaInicial == null) {
						columnaInicial = cell.getColumnIndex();
					}
					columnTypes.add(cell.getCellType());
					columnaFinal = cell.getColumnIndex();
				}
				break;
			}
			numColumnas = columnTypes.size();
		}
		return columnTypes;
	}

	public Sheet getHoja(int sheet) {
		if (sheet >=0 && sheet<allSheet.size()) {
			return allSheet.get(sheet);
		}
		return null;
	}


	public void close() {
		if (book != null) {
			try {
				book.close();
			} catch (Exception e) {}
		}
		if (is != null) {
			try {
				is.close();
			} catch (Exception e) {}
		}
		if (fs != null) {
			try {
				fs.close();
			} catch (Exception e) {}
		}
	}
	
	
}
