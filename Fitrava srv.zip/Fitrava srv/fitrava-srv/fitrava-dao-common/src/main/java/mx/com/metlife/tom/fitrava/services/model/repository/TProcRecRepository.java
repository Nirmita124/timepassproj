package mx.com.metlife.tom.fitrava.services.model.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import mx.com.metlife.tom.fitrava.services.model.entity.TProcRec;
import mx.com.metlife.tom.fitrava.services.model.entity.TProcRecId;

@Repository
public interface TProcRecRepository extends JpaRepository<TProcRec, TProcRecId>{

	List<TProcRec> findByDstnctCtrlNum(String dstnctCtrlNum);

	@Modifying
	void deleteByDcn(@Param("dcn") String dcn);
	
	List<TProcRec> findByDstnctCtrlNumAndFileNm(String dstnctCtrlNum,String fileNm);
}
