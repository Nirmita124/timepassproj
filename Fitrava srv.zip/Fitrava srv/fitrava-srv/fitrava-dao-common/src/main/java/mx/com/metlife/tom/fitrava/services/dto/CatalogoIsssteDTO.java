package mx.com.metlife.tom.fitrava.services.dto;

import org.dozer.Mapping;

import lombok.Data;
import lombok.EqualsAndHashCode;

@EqualsAndHashCode(callSuper=false)
@Data
public class CatalogoIsssteDTO extends CatalogoFitravaDTO { 

	@Mapping("rtnrCd")
	private String concepto;

	@Mapping("ramo")
	private String ramoIssste;
	
	@Mapping("custNm")
	private String nombreOrganismo;
	
	@Mapping("origPolNum")
	private String poliza;
	
	@Mapping("pordCd")
	private String ramoSubramo;
	
	@Mapping("sbGrpNum")
	private String subgrupo;
	
	@Mapping("sbGrpNm")
	private String clasificacion;
	
	private String aseguradoUnico;

}
