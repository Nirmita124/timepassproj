package mx.com.metlife.tom.fitrava.services.model.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import mx.com.metlife.tom.fitrava.services.model.entity.TLayoutHdDtl;

@Repository
public interface TLayoutHdDtlRepository extends JpaRepository<TLayoutHdDtl, Long>{

	@Modifying
	void deleteByLayoutHdId(@Param("layoutHdId")Long layoutHdId);

}
