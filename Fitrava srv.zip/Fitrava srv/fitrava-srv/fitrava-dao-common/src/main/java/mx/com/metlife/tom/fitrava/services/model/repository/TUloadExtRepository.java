package mx.com.metlife.tom.fitrava.services.model.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import mx.com.metlife.tom.fitrava.services.model.entity.TUloadExt;

@Repository
public interface TUloadExtRepository  extends JpaRepository<TUloadExt, Long>{

	
	List<TUloadExt> findAllByDstnctCtrlNum(String dstnctCtrlNum);
	
	TUloadExt findByDstnctCtrlNumAndKey(String dstnctCtrlNum, String key);

}
