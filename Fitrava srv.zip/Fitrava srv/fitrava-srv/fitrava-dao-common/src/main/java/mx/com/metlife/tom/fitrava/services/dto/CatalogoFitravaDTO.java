package mx.com.metlife.tom.fitrava.services.dto;

import lombok.Data;

@Data
public class CatalogoFitravaDTO {
	
	private int linea;
	private String error;

	public CatalogoFitravaDTO() {}

	public CatalogoFitravaDTO(int linea, String error) {
		super();
		this.linea = linea;
		this.error = error;
	}
	
}
