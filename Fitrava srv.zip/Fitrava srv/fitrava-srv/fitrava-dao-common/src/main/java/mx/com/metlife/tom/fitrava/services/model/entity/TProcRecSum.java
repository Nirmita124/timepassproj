
package mx.com.metlife.tom.fitrava.services.model.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

import lombok.Data;

@Data
@Entity
@Table(name = "T_PROC_REC_SUM")
@IdClass(TProcRecSumId.class)
public class TProcRecSum implements java.io.Serializable{

	private static final long serialVersionUID = 8930347617887403645L;

	public TProcRecSum() {
		super();
	}

	public TProcRecSum(String dstnctCtrlNum, String fileNm, String extCd, Integer clctSttsId, int totRecCnt, int totErrRecCnt) {
		super();
		this.dstnctCtrlNum = dstnctCtrlNum;
		this.fileNm = fileNm;
		this.extCd = extCd;
		this.clctSttsId = clctSttsId;
		this.totRecCnt = (long)totRecCnt;
		this.totErrRecCnt = (long)totErrRecCnt;
	}

	@Id
	@Column(name = "DSTNCT_CTRL_NUM")
	private String dstnctCtrlNum = null;

	@Id
	@Column(name = "FILE_NM")
	private String fileNm = null;

	@Column(name = "EXT_CD")
	private String extCd = null;

	@Column(name = "CLCT_STTS_ID")
	private Integer clctSttsId = null;

	@Column(name = "TOT_REC_CNT")
	private Long totRecCnt = null;

	@Column(name = "TOT_ERR_REC_CNT")
	private Long totErrRecCnt = null;

	@OneToMany(cascade=CascadeType.ALL, fetch=FetchType.EAGER)
	@JoinColumns({
	    @JoinColumn(name="DSTNCT_CTRL_NUM", referencedColumnName = "DSTNCT_CTRL_NUM", insertable = false, updatable = false ),
	    @JoinColumn(name="FILE_NM", referencedColumnName = "FILE_NM", insertable = false, updatable = false)
	})
	private List<TProcRecSumDtl> listTProcRecSumDtl = null;
	
	@Transient
	public Double getPorcentajeErrores() {
		if (totRecCnt == null || totRecCnt == 0 || totErrRecCnt == null || totErrRecCnt == 0) {
			return null;
		}
		return (double)totRecCnt/totErrRecCnt;
	}
}
