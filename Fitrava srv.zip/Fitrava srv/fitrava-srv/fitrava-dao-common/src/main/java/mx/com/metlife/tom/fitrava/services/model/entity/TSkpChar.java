package mx.com.metlife.tom.fitrava.services.model.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "T_SKP_CHAR")
public class TSkpChar implements java.io.Serializable{

	private static final long serialVersionUID = -5475206143098139973L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="SKP_CHAR_ID")
	private Long skpCharId = null;
	
	@Column(name="LAYOUT_ID")
	private Long layoutId = null;
	
	@Column(name="CHAR_VAL")
	private String charVal = null;

	@Column(name="CHAR_CD")
	private String charCd = null;
	
}
