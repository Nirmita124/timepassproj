package mx.com.metlife.tom.fitrava.services.model.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@SuppressWarnings("serial")
@Data
@Entity
@Table(name = "T_USR")
public class TUsr implements java.io.Serializable{
	@Id
	@Column(name = "USR_KEY_ID")
	private String userCve = null;
	
	@Column(name = "USR_ID")
	private String userIdentifier = null;

	@Column(name = "USR_NM")
	private String userNm = null;

	@Column(name = "USR_PTRNL_LST_NM")
	private String userApePat = null;

	@Column(name = "USR_MTRNL_LST_NM")
	private String userApeMat = null;

	@Column(name = "USR_EMAIL_ADR_TXT")
	private String userEmail = null;

	@Column(name = "USR_TEL_NUM")
	private String userTel = null;

	@Column(name = "USR_TEL_EXT_NUM")
	private String userTelExt = null;

	@Column(name = "USR_ACT_IND")
	private Integer userActInd = null;

	@Column(name = "ROLE_ID")
	private Integer roleId = null;
	
//	@ManyToOne
//	@JoinColumn(name = "ROLE_ID", nullable = false, insertable = false, updatable = false)
//	private TRole tRole;
}
