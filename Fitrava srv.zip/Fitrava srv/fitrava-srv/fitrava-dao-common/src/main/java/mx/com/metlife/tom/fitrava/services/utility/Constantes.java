package mx.com.metlife.tom.fitrava.services.utility;

/**
 * Class to keep constants.
 * 
 * @author Capgemini
 * @since 26/03/2019
 */
public class Constantes {

	private Constantes() {
		throw new IllegalStateException("Constantes class");
	}
	
	//-- [App-related]
	public static final String 	TOM_APP_NAME = "[App Name = TOM] ";	
	public static final String 	SEARCH_TOM_METHOD = "searchTOM ";
	//-- [Symbols]
	public static final char 	CHAR_ZERO = '0';
	public static final Integer ESTATUS_INACTIVO = 0;
	public static final Integer ESTATUS_ACTIVO = 1;
	public static final String 	DOT = ".";
	public static final String 	BLANK = "";
	public static final String 	NULL = "NULL";//para los campos que no acetan vacios, y no hacer cambios con kaminski
	
	public static final String 	SPACE = " ";	
	public static final char 	CHAR_SPCAE = ' ';	
	public static final String 	OPENING_BRACET = " [ ";
	public static final String 	CLOSING_BRACKET = " ] ";
	public static final String 	EQUAL_SIGN = " = ";	
	public static final String 	LOGGER_DOUBLE_BRACET = "{} {}";	
	public static final String 	LOGGER_TRIPLE_BRACET = "{} {} {}";	

	public static final String 	DATE_FORMAT = "MM/dd/yyyy";
	public static final String 	DATE_FORMAT_DD_MM_YYYY = "dd/MM/yyyy";	

	//-- [Code-errors]
	public static final String 	ERROR_CODE_500 = "500";	
	public static final String 	ERROR_CODE_401 = "401";
	public static final String 	ERROR_CODE_400 = "400";
	public static final String 	ERROR_CODE_202 = "202";
	public static final String 	SUCCESS_CODE_200 = "200";
	public static final String 	ERROR_MESSAGE_500 = "Internal error";
	
	public static final String 	TYPE_GKY = "0GKY";
	public static final String 	PRODUCT_REF_SSIN = "SSIN";
	public static final String 	PRODUCT_REF_GMMC = "GMMC";
	public static final String 	PRODUCT_REF_PREM = "PREM";	
	public static final String 	REGEX_FORMAT_PRN_IND = "%15s";
	public static final String 	REGEX_FORMAT_PRN_RAMO = "%5s";
	public static final String 	REGEX_FORMAT_PRN_POLICY = "%10s";
	
	//-- [File-related]
	public static final String 	TXT = "txt";
	public static final String 	XLS = "xls";
	public static final String 	XLSX = "xlsx";
	public static final String 	DAT = "dat";
	public static final String 	CSV = "csv";	
	public static final String 	ZIP = "zip";
	public static final String 	TEMP = "temp";
	public static final String 	ENCODE_UTF_8 = "UTF-8";	
	
	//el nombre del archivo debe quedar: //INPUT_{{DCN}}_NOMBRE_ORIGINAL.EXT
	public static final String 	INICIO_NOMBRE_ARCHIVO_ENTRADA = "INPUT_";
	public static final String 	NOMBRE_ARCHIVO_ENTRADA = INICIO_NOMBRE_ARCHIVO_ENTRADA + "%1$s_%2$s";
	
	public static final String 	FINAL_NOMBRE_ARCHIVO_ENTRADA = ".txt";
	public static final String 	NOMBRE_ARCHIVO_SALIDA = "%1$s" + FINAL_NOMBRE_ARCHIVO_ENTRADA;	
	
	//-- [messages]
	public static final String ERROR_DATA_BASE = "Error al acceder a la BD";
	public static final String LOG_MSG_EXECUTING = "Execution STARTED of service - ";
	public static final String LOG_MSG_EXECUTED = " Execution ENDED of service - ";
	public static final String LOG_MSG_ERROR_EXECUTING = " ERROR executing service - ";
	public static final String LOG_MSG_EXECUTING_CLASS = "Executing class: ";
	public static final String LOG_MSG_EXECUTING_METHOD = "Started executing method: ";
	public static final String LOG_MSG_EXECUTED_METHOD = "Executed method: ";
	public static final String LOG_MSG_SERVICE_START_TIME = "Start time of execution: ";
	public static final String LOG_MSG_SERVICE_EXECUTION_TIME = "Execution time in Seconds: ";
	
	public static final String TRANSFORMATION = "Transformacion";
	public static final String MASKING_ERROR = "El campo no cumple con el patron especificado";
	public static final String LENGTH_ERROR = "El campo no cumple la longitud especificada";

	public static final String BUSINESS_RULE = "BusinessRule";
	public static final String CONODITION_MANDATOTY_ERROR = "El valor del campo no es permitido";
	public static final String TEXT_TRUE = "true";
	public static final String TEXT_FALSE = "false";
	public static final String DCN_ERROR = "El DCN no se encuentra registrado en el sistema";
	public static final String TRANMSSN_CMPLTE = "Transformatiion completed";
	public static final String TRANMSSN_NOT_CMPLTE = "Transformation has not been completed";
	public static final String TIPO_DATO_ERROR = "El tipo de dato esperado, no es correcto";
	public static final String MANDATORY_FIELD = "El campo es obligatorio";
	public static final String INVALID_COL = "El layout no cumple con el estándar";
	public static final String WRONG_FILE_TYPE = "Wrong File type";
	public static final String MAX_2_FILES = "Maximum two files Allowed";
	public static final String JSON_FILE_RQRD = "Json File required for processing";
	public static final String NOT_ALLOWED = " is not allowed for String parameter 'isMassive'";
	public static final String NOT_ALLOWED_FILE_TYPE = " is not allowed fileType";

	public static final String FORMATO_FECHA_DESCONOCIDO = " el formato de la fecha no es valido";
	
	public static final String NO_DATA_FOUND = "No data found";
	public static final String UN_AUTHORIZED_USER = "Unauthorized User";
	public static final String RESULT_SET_EMPTY = "Result set is empty.";
	public static final String INTERNAL_ERROR = "Error in Search";
	public static final String SEARCH_CRITERIA_NOT_ENOUGH = "Not enough inforamation to Perform Search";

	public static final String TEMP_ROOT_DIRECTORY= "resources/";

	public static final String TEMP_ROOT_DIRECTORY_ORIGEN = TEMP_ROOT_DIRECTORY + "origen/";
	public static final String TEMP_ROOT_DIRECTORY_ORIGEN_TEMP = TEMP_ROOT_DIRECTORY + "origen-temp/";
	public static final String TEMP_ROOT_DIRECTORY_DESTINO = TEMP_ROOT_DIRECTORY +"destino/";
	public static final String TEMP_ROOT_DIRECTORY_DESTINO_TEMP = TEMP_ROOT_DIRECTORY +"destino-temp/";
	public static final String TEMP_ROOT_DIRECTORY_DELETE = TEMP_ROOT_DIRECTORY +"delete/";

	public static final String TEMP_ROOT_DIRECTORY_CATALOGOS = TEMP_ROOT_DIRECTORY + "catalogos/";
	public static final String TEMP_ROOT_DIRECTORY_CATALOGOS_TEMP = TEMP_ROOT_DIRECTORY + "catalogos-temp/";
	public static final Integer DCN_LENGTH = 20;
	
	public static final String[] CATALOGO_RICSI_CAMPOS = {
			"poliza", "rfc", "nombre", "numRecibo", "estatus", "fechaEmision", "fechaRecibo", "fechaEfectoPoliza", 
			"formaPago", "conductoCobro", "numPensionado", "primaAnual", "statusRecibo", "primaCobro"
	};
	
	public static final String[] CATALOGO_FONE_CAMPOS = {
			"id", "polizaOriginal", "contratante", "ramoSubramo", "producto", "subgrupoAplicacion",
			"descripcionSubgrupo", "reciboFiscalCartaRecibo", "primaSueldoMet", "numAsegurados", "nominaMensual",
			"sumaAsegurada", "sumaAseguradaPromedio", "primaAnual", "primaMensual"	
	};
	
	public static final String[] CATALOGO_ISSSTE_CAMPOS = {
			"concepto", "ramoIssste", "nombreOrganismo", "poliza", "ramoSubramo", "subgrupo", "clasificacion", "aseguradoUnico"	
	};

	public static final String[] CATALOGO_RAMO74_CAMPOS = {
			"numeroPension", "rfc", "nombreCompleto", "poliza"
	};
	
	public static final int ID_CATALOGO_RICSI  = 1;
	public static final int ID_CATALOGO_FONE   = 2;
	public static final int ID_CATALOGO_ISSSTE = 3;
	public static final int ID_CATALOGO_RAMO74 = 4;
	
	public static final String PREF_NOMBRE_CATALOGO_RICSI  = "catRicsi";
	public static final String PREF_NOMBRE_CATALOGO_FONE   = "catFone";
	public static final String PREF_NOMBRE_CATALOGO_ISSSTE = "catIssste";
	public static final String PREF_NOMBRE_CATALOGO_RAMO74 = "catRamo74";

	public static final String FILE_PATH_RECIBE_ARCHIVOS = "file_path";
	public static final String FILE_CATALOGO_PATH_RECIBE_CATALOGOS = "catalog_file_path";
	
	public static final String CONCEPTO_77 = "77";
	public static final String CONCEPTO_77A = "77A";
	public static final String CONCEPTO_37 = "37";


	public static final String PARAM_NAME_ANIO = "ANIO";
	public static final String PARAM_NAME_MES = "MES";
	public static final String PARAM_NAME_QUINCENA = "QUINCENA";
	public static final String PARAM_NAME_FILE_POST_PARAM = "FILE_POST_PARAM";

	public static final String ROW = "Row";
	public static final String DATA = "Data";

	public static final String CONCEPTO = "CONCEPTO";
	public static final String RAMO = "RAMO";
	public static final String NUM_PENSION = "NUM_PENSION";
	
	public static final String POTENCIACION = "POTENCIACION";
	public static final String NO_ENCONTRADO = "NO ENCONTRADO";

	public static final Character HIDDEN = 'H';
	public static final Character SHOW = 'S';

}

