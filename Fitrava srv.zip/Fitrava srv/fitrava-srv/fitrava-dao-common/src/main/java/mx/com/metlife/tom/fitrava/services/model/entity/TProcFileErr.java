package mx.com.metlife.tom.fitrava.services.model.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import lombok.Data;


@SuppressWarnings("serial")
@Data
@Entity
@Table(name = "T_PROC_FILE_ERR")
@IdClass(TProcFileId.class)
public class TProcFileErr implements java.io.Serializable {

	@Id
	@Column(name = "DSTNCT_CTRL_NUM")
	private String dstnctCtrlNum = null;

	@Id
	@Column(name = "FILE_NM")
	private String fileNm = null;
	
	@Column(name = "ERR_CD")
	private Integer errCd = null;

	@Column(name = "ERR_TS")
	private Date errTs = null;

	@Column(name = "ERR_DSCR")
	private String errDscr = null;

	public TProcFileErr() {}
	
	
	public TProcFileErr(String dstnctCtrlNum, String fileNm, Integer errCd, Date errTs, String errDscr) {
		super();
		this.dstnctCtrlNum = dstnctCtrlNum;
		this.fileNm = fileNm;
		this.errCd = errCd;
		this.errTs = errTs;
		this.errDscr = errDscr;
	}

}
