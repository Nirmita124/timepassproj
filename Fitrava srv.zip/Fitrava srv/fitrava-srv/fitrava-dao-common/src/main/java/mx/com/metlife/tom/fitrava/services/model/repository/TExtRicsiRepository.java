package mx.com.metlife.tom.fitrava.services.model.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import mx.com.metlife.tom.fitrava.services.model.entity.TExtRicsi;
import mx.com.metlife.tom.fitrava.services.model.entity.TExtRicsiId;

@Repository
public interface TExtRicsiRepository extends JpaRepository<TExtRicsi, TExtRicsiId>{

	List<TExtRicsi> findByNumeroPension(@Param("numPension") String numPension);
	
}
