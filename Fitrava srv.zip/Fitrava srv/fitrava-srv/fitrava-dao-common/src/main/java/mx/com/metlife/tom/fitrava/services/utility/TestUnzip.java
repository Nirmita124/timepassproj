package mx.com.metlife.tom.fitrava.services.utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import mx.com.metlife.tom.fitrava.services.error.FitravaException;

public class TestUnzip extends UtilCommon {
	
	public static List<File> getFilesFromZip(File directorioBase, File zip, String name) throws FitravaException {
		ZipInputStream zis = null;
        ZipEntry zipEntry = null;
        File fileZip = null;
        List<File> files = null;
        File nuevo = null;
		try {
			createDirectory(directorioBase);
			files = new ArrayList<>();
			fileZip = new File(directorioBase, zip.getName());
			//System.out.println("fileZip: " + fileZip.getName());
	        zis = new ZipInputStream(new FileInputStream(fileZip));
	        while ((zipEntry = zis.getNextEntry())!= null) {
	        	nuevo = newFile(directorioBase, zipEntry, zis, zip.getName());
	        	//System.out.println("nuevo: " + nuevo.getName());
	        	if (nuevo.getName().toLowerCase().endsWith(Constantes.ZIP)) {
	        		files.addAll(getFilesFromZip(directorioBase, nuevo, nuevo.getName()));
	        	}
	        	files.add(nuevo);
	        }
	        return files;
		} catch (Exception e) {
			throw new FitravaException(String.format("No se pudo descomprimir el archivo: %1$s", zip), e);
		} finally {
	        try {
	        	if (zis != null) {
	        		zis.closeEntry();
	        	}
			} catch (IOException e) {}
	        try {
	        	if (zis != null) {
		        	zis.close();
	        	}
			} catch (IOException e) {}
		}
	}
	
	public static File newFile(File directorioBase, ZipEntry zipEntry, ZipInputStream zis, String zipName) throws FitravaException {
		//System.out.println(String.format("en el newFile(directorioBase: %1$s, zipEntry: %2$s, zis: %3$s, name: %4$s", directorioBase, zipEntry, zis, zipName));
		File destFile = null;
		FileOutputStream fos = null;
		int len = 0;
		byte[] buffer = null;
		String nombre = zipName!=null? zipName+"_"+zipEntry.getName():zipEntry.getName();
		//System.out.println("nombre: " + nombre);
		try {
			destFile = new File(directorioBase, nombre);
			buffer = new byte[1024];
			fos = new FileOutputStream(destFile);
			while ((len = zis.read(buffer)) > 0) {
				fos.write(buffer, 0, len);
			}
			destFile.deleteOnExit();
			return destFile;
		} catch (Exception e) {
			throw new FitravaException(String.format("Error al descomprimir el archivo: %1$s", zipEntry), e);
		} finally {
			try {
				if (fos != null) {
					fos.close();
				}
			} catch (IOException e) {
			}
		}
	}

	public static final List<File> removeFiles(List<File> archivos) {
		List<File> files = null;
		if (archivos != null && !archivos.isEmpty()) {
			files = new ArrayList<>();
			for (File f:archivos) {
				if (!validaExtensionesPermitidas(f)) {
					continue;
				}
				files.add(f);
			}
		}
		return files;
	}

	public static void main(String[] args) throws FitravaException {
		String archivo = "C:\\test\\test\\test.zip";
		File zip = new File(archivo);
		
		List<File> files = getFilesFromZip(new File("c://test//test"), zip, null);
		files = removeFiles(files);
		files.add(new File("uno.xlsx"));
		String nombreArchivo = null;
		String last = ".zip_";
		for (File f: files) {
			nombreArchivo = f.getName();
			nombreArchivo = nombreArchivo.indexOf(last)>0? nombreArchivo.substring(nombreArchivo.lastIndexOf(last)+last.length()): nombreArchivo;
			System.out.println("-->" + f.getName() + "<-- -->" + nombreArchivo);
		}
		
	}

}
