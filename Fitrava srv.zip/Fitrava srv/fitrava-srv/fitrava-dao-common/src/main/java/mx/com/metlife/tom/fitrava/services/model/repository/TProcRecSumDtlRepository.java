package mx.com.metlife.tom.fitrava.services.model.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import mx.com.metlife.tom.fitrava.services.model.entity.TProcRecSumDtl;
import mx.com.metlife.tom.fitrava.services.model.entity.TProcRecSumDtlId;

@Repository
public interface TProcRecSumDtlRepository extends JpaRepository<TProcRecSumDtl, TProcRecSumDtlId>{


	List<TProcRecSumDtl> findByDstnctCtrlNum(String dstnctCtrlNum);

	@Modifying
	void deleteByDcn(@Param("dcn") String dcn);
}
