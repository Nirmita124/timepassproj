package mx.com.metlife.tom.fitrava.services.model.entity;

import java.io.Serializable;

import lombok.Data;

@Data
public class TFlowMappingDtlId implements Serializable {

	private static final long serialVersionUID = -4723226499519109086L;

	private Long flowMappingId = null;
	private Long flowId = null;
	private Long outLayoutFldId = null;
	
	public TFlowMappingDtlId() {}

	public TFlowMappingDtlId(Long flowMappingId, Long flowId, Long outLayoutFldId) {
		super();
		this.flowMappingId = flowMappingId;
		this.flowId = flowId;
		this.outLayoutFldId = outLayoutFldId;
	}

}
