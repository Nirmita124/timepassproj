package mx.com.metlife.tom.fitrava.services.model.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import lombok.Data;

@SuppressWarnings("serial")
@Data
@Entity
@Table(name = "T_FLOW_ENTRNC_LAYOUT")
@IdClass(TFlowEntrncLayoutId.class)
public class TFlowEntrncLayout implements java.io.Serializable{

	@Id
	@Column(name = "FLOW_ID")
	private Long flowId = null;
	
	@Id
	@Column(name = "LAYOUT_ID")
	private Long layoutId = null;

	@Column(name = "FLOW_ENTRNC_LAYOUT_ORD_NUM")
	private Integer flowEntrncLayoutOrdNum = null;

	public TFlowEntrncLayout() {}

	public TFlowEntrncLayout(Long flowId, Long layoutId, Integer flowEntrncLayoutOrdNum) {
		super();
		this.flowId = flowId;
		this.layoutId = layoutId;
		this.flowEntrncLayoutOrdNum = flowEntrncLayoutOrdNum;
	}
	

}
