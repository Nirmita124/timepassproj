package mx.com.metlife.tom.fitrava.services.model.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "T_LAYOUT_HD")
public class TLayoutHd implements java.io.Serializable{

	private static final long serialVersionUID = 1796401627448848421L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "LAYOUT_HD_ID")
	private Long layoutHdId = null;

	@Column(name = "LAYOUT_ID")
	private Long layoutId = null;

	@Column(name = "FTR_IND")
	private Boolean ftrInd = null;

	@OneToMany(cascade=CascadeType.ALL, fetch=FetchType.EAGER, mappedBy="layoutHdId")
	@OrderBy("fldOrdNum")
	private List<TLayoutHdDtl> listTLayoutHdDtl = null;

}
