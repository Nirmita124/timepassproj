package mx.com.metlife.tom.fitrava.services.utility.excel;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;

import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Sheet;
import org.xml.sax.SAXException;

import mx.com.metlife.tom.fitrava.services.error.FitravaException;
import mx.com.metlife.tom.fitrava.services.utility.Constantes;
import mx.com.metlife.tom.fitrava.services.utility.UtilCommon;

public class ExcelXmlUtility extends ExcelUtility {

	private SAXHandler handler = null;
	private List<String[]> renglones = null;
	private SAXParser parser;

	private FileInputStream fis = null;
    private XMLStreamReader xmlStreamReader = null;
    
    private static final String TABLE = "Table";
    private static final String ROW = "Row";
    private static final String CELL= "Cell";
    private static final String ATTRIBUTE_INDEX = "Index";
	

	
	public ExcelXmlUtility(File excelFile, Integer renglonesAOmitir, String[] hojasOmitir) throws FitravaException {
		super(excelFile, renglonesAOmitir, hojasOmitir);
		init();
		initAllHojas();
	}

	protected void init2() throws FitravaException {
		SAXParserFactory parserFactor = null;
		try {
			parserFactor =  SAXParserFactory.newInstance();
			parser = parserFactor.newSAXParser();
			handler = new SAXHandler();
			parser.parse(excelFile, handler);
		} catch (ParserConfigurationException | SAXException | IOException e) {
			throw new FitravaException("Error al iniciar el parseo de XML", e);
		}
	}
	
	public void initAllHojas2() {
		if (handler != null && handler.getXmlRowList() != null) {
			renglones = new ArrayList<>();
			int i = 0;
			String[] arr = null;
			for (XmlRow row: handler.getXmlRowList()) {
				if (i < renglonesAOmitir) {
					i++;
					continue;
				}
				arr = row.cellList.toArray(new String[row.cellList.size()]);
				 //System.out.println("--->" + UtilCommon.getArrayToString(arr) + "<---");
				renglones.add(arr);
				if (numColumnas == null) {
					numColumnas = arr.length;
					this.columnaInicial = 0;
					this.columnaFinal = numColumnas-1;
				}
			}
		}
		this.numHojas = 1;
		try {
			if (handler != null) {
				handler.endDocument();
			}
			if (parser != null) {
				parser.reset();
			}
		} catch (SAXException e) {
			log.error("Error al finalizar el documento", e);
		}
	}

	@Override
	protected void init() throws FitravaException {
		XMLInputFactory factory = null;
		try {
			factory = XMLInputFactory.newInstance();
			factory.setProperty(XMLInputFactory.IS_SUPPORTING_EXTERNAL_ENTITIES, Boolean.FALSE);
			factory.setProperty(XMLInputFactory.SUPPORT_DTD, Boolean.FALSE);
			fis = new FileInputStream(excelFile);
		    xmlStreamReader = factory.createXMLStreamReader(fis);
		    renglones = new ArrayList<>();
		    readDocument(xmlStreamReader);
		} catch (Exception e) {
			throw new FitravaException("Error al iniciar el parseo de XML", e);
		} finally {
			close();
		}
	}
	
	@Override
	public void initAllHojas() {
		if (renglones != null) {
			 for(int i = 0; i < renglonesAOmitir; i++) {
				renglones.remove(i);
			 }
		}
		if (numColumnas == null) {
			numColumnas = renglones!= null && !renglones.isEmpty()?renglones.get(0).length:0;
			this.columnaInicial = 0;
			this.columnaFinal = numColumnas-1;
		}
		this.numHojas = 1;
	}

	private void readDocument(XMLStreamReader reader) throws XMLStreamException {
        while (reader.hasNext()) {
            int eventType = reader.next();
            switch (eventType) {
                case XMLStreamReader.START_ELEMENT:
                    String elementName = reader.getLocalName();
                    if (elementName.equalsIgnoreCase(TABLE))
                        readLines(reader);
                    break;
                case XMLStreamReader.END_ELEMENT:
                    break;
            }
        }
    }
 
    private void readLines(XMLStreamReader reader) throws XMLStreamException {
    	while (reader.hasNext()) {
    		//System.out.println("en readLines");
            int eventType = reader.next();
            switch (eventType) {
                case XMLStreamReader.START_ELEMENT:
                    String elementName = reader.getLocalName();
                    //System.out.println("En el readLines, elementName: " + elementName);
                    if (elementName.equalsIgnoreCase(ROW)) {
                    	readLine(reader);
                    }
                    break;
                case XMLStreamReader.END_ELEMENT:
                    break;
            }
        }
    }
 
    private void readLine(XMLStreamReader reader) throws XMLStreamException {
    	//System.out.println("en el readLine");
    	List<String> list = new ArrayList<>();
    	int numColumn = 0;
    	int valorIndex = 0;
    	while (reader.hasNext()) {
    		int eventType = reader.next();
            String elementName = null;
            switch (eventType) {
                case XMLStreamReader.START_ELEMENT:
                	for(int i = 0; i < reader.getAttributeCount(); i++) {
                		if (reader.getAttributeLocalName(i).equalsIgnoreCase(ATTRIBUTE_INDEX)) {
	                    	valorIndex = Integer.parseInt(reader.getAttributeValue(i));
	                    	for (int j = numColumn; j < valorIndex; j++) {
	                    		list.add(Constantes.BLANK);
	                    	}
	                    }
                	}
                	elementName = reader.getLocalName();
                    //System.out.println("en el readLine, elementName: " + elementName);
                	if (elementName.equalsIgnoreCase(CELL)) {
                		list.add(readCharacters(reader));
                    }
                	numColumn++;
                    break;
                case XMLStreamReader.END_ELEMENT:
                	elementName = reader.getLocalName();
                    if (elementName.equalsIgnoreCase(ROW)) {
                         renglones.add(list.toArray(new String[list.size()]));
                     	list = new ArrayList<>();
                     	numColumn = 0;
                     }
                    break;
            }
        }
    }
 
    private String readCharacters(XMLStreamReader reader) throws XMLStreamException {
        StringBuilder result = new StringBuilder();
        String temp = null;
        while (reader.hasNext()) {
            int eventType = reader.next();
            //System.out.println("readCharacters() eventType: " + eventType);
            switch (eventType) {
                case XMLStreamReader.CHARACTERS:
                case XMLStreamReader.CDATA:
                	temp = reader.getText();
                	//System.out.println("temp: " + temp);
                    result.append(temp!=null?temp:Constantes.BLANK);
                    break;
                case XMLStreamReader.END_ELEMENT:
                    return result.toString();
            }
        }
        throw new XMLStreamException("Premature end of file");
    }
 
	
	@Override
	public Integer getNumColumnas() {
		return numColumnas;
	}
	
	
	public Integer getNumeroRows() {
		if (renglones != null) {
			return renglones.size();
		}
		return 0;
	}

	public String[] getRow(int rowNumber) {
		if (renglones != null && rowNumber >=0 && rowNumber < renglones.size()) {
			return renglones.get(rowNumber);
		}
		return null;
	}

	@Override
	public List<CellType> getColumnTypes() {
		return null;
	}

	@Override
	public Sheet getHoja(int sheet) {
		return null;
	}

	@Override
	public void close() {
		if (fis != null) {
			try { 
				fis.close();
			} catch (IOException e) {}
		}
		if (xmlStreamReader != null) {
			try { 
				xmlStreamReader.close();
			} catch (XMLStreamException e) {}
		}
	}
	
	public static void main(String[] args) throws FitravaException {
		String archivo = "C:\\Users\\icarball\\Documents\\asignacion\\0_LAYOUTS\\capgeminy\\colectivos\\FONE\\ENERO\\SEGURO DE VIDA-ENERO-2019.zip\\SEGURO DE VIDA-20190215T024522Z-001\\Detalle_SEG_VIDA_R01_01_2019-2.xls";
		//archivo = "C:\\Users\\icarball\\Documents\\asignacion\\0_LAYOUTS\\capgeminy\\colectivos\\FONE\\ENERO\\SECORE-20190215T025330Z-001\\Detalle_SECORE_R03_01_2019-2.xls";
		ExcelXmlUtility excel = new ExcelXmlUtility(new File(archivo), 1, null);
		System.out.println("excel.getNumeroHojas(): " + excel.getNumeroHojas() + ", excel.getNumeroRows(): " + excel.getNumeroRows());
		System.out.println(String.format("excel.getColumnaInicial(): %1$s, excel.getColumnaFinal(): %2$s, excel.getNumColumnas(): %3$s", excel.getColumnaInicial(), excel.getColumnaFinal(), excel.getNumColumnas()));
		for (int i = 0; i < excel.getNumeroHojas(); i ++) {
			for (int j = 0 ; j < excel.getNumeroRows(); j++) {
				System.out.println("excel.getRow("+j+"): " + excel.getRow(j).length);
				System.out.println("--->" + UtilCommon.getArrayToString(excel.getRow(j)) + "<---");
			}
		}
	}


}
