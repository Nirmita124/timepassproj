package mx.com.metlife.tom.fitrava.services.utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.Instant;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.DateUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import mx.com.metlife.tom.fitrava.services.error.FitravaException;
import mx.com.metlife.tom.fitrava.services.error.ValidationException;
import mx.com.metlife.tom.fitrava.services.model.entity.TLayoutXcel;

public class UtilCommon {

	private static final Logger log = LoggerFactory.getLogger(UtilCommon.class);

	protected static final String PATH_DEFAULT = String.format("%1$svar%1$stemp%1$s", File.separator);
	protected static final String[] EXTENSIONES_PERMITIDAS = { "txt", "xls", "xlsx", "dat", "csv" };
	protected static final String[] EXTENSIONES_IMAGES = { "jpg", "jpeg", "gif", "png", "tif", "tiff", "thumbnails" };
	protected static String[] POTENCIACION_IDS = {"101-11", "102-11", "103-11","104-11","105-11","75-11","76-11","77-11","78-11","79-11"};


	protected UtilCommon() {
	}

	public static String getArrayToString(String... arr) {
		if (arr == null || arr.length == 0) {
			return null;
		}
		StringBuilder sb = new StringBuilder("[");
		for (String s : arr) {
			sb.append(s);
			sb.append(", ");
		}
		String toReturn = sb.toString().trim();
		return toReturn.substring(0, toReturn.length() - 1) + "]";
	}

	public static String getArrayToString(Object[] arr) {
		if (arr == null || arr.length == 0) {
			return null;
		}
		StringBuilder sb = new StringBuilder("[");
		for (Object o : arr) {
			sb.append(o);
			sb.append(", ");
		}
		String toReturn = sb.toString().trim();
		return toReturn.substring(0, toReturn.length() - 1) + "]";
	}

	public static String dateToString(Date d) {
		if (d == null) {
			return Constantes.BLANK;
		}
		return new SimpleDateFormat("dd/MMM/yyyy hh:mm:ss", new Locale("es_MX")).format(d);
	}

	public static String date2StringDB(Date d) {
		if (d == null) {
			return Constantes.BLANK;
		}
		return new SimpleDateFormat("yyyy-MM-dd", new Locale("es_MX")).format(d);
	}

	public static final Boolean validaExtensionesPermitidas(String ext) {
		if (ext != null && ext.trim().length() > 0) {
			for (String e : EXTENSIONES_PERMITIDAS) {
				if (ext.equalsIgnoreCase(e)) {
					return Boolean.TRUE;
				}
			}
		}
		return Boolean.FALSE;
	}

	public static final Boolean validaExtensionesImagenes(String ext) {
		if (ext != null && ext.trim().length() > 0) {
			for (String e : EXTENSIONES_IMAGES) {
				if (ext.equalsIgnoreCase(e)) {
					return Boolean.TRUE;
				}
			}
		}
		return Boolean.FALSE;
	}

	public static final Boolean validaExtensionesPermitidas(File file) {
		if (file == null)
			return false;
		String extension = getExtension(file);
		return validaExtensionesPermitidas(extension);
	}

	public static final Boolean validaExtensionesImagenes(File file) {
		if (file == null)
			return false;
		String extension = getExtension(file);
		return validaExtensionesImagenes(extension);
	}

	public static final String getExtension(File file) {
		if (file == null)
			return null;
		String extension = file.getName();
		extension = extension.substring(extension.lastIndexOf(Constantes.DOT) + 1);
		return extension;
	}

	public static final String getExtension(String path) {
		if (path == null)
			return null;
		path = path.substring(path.lastIndexOf(Constantes.DOT) + 1);
		return path;
	}

	public static void validaArchivos(List<File> files) throws ValidationException {
		if (files != null && !files.isEmpty()) {
			for (File f : files) {
				if (!validaExtensionesPermitidas(f)) {
					throw new ValidationException(
							String.format("La extension del archivo: %1$s no esta permitida", f.getName()));
				}
				if (f.length() == 0) {
					throw new ValidationException(String.format("El archivo %1$s, esta vacio", f.getName()));
				}
			}
		}
	}

	public static String getExtension(List<File> archivos) throws ValidationException {
		String ext = null;
		String ext1 = null;
		for (File f : archivos) {
			if (ext == null) {
				ext = getExtension(f);
			}
			ext1 = getExtension(f);
			if (ext != null && ext1 != null && !ext.equalsIgnoreCase(ext1)) {
				throw new ValidationException("Deben ser la misma extension de archivo para todos los archivos");
			}
		}
		return ext;
	}

	public static void deleteFiles(List<File> archivos){
		if (archivos != null && !archivos.isEmpty()) {
			for (File f : archivos) {
				try {
					Files.delete(f.toPath());
				} catch (IOException e) {
					log.error("No se pudo borrar el archivo: " + f, e);
				}
			}
		}
	}

	public static void deleteFiles(String directorio) throws FitravaException {
		File dir = new File(directorio);
		if (dir.exists() && dir.isDirectory()) {
			try {
				Files.delete(dir.toPath());
			} catch (IOException e) {
				throw new FitravaException("No se pudo Borrar el directorio", e);
			}
		}
	}

	public static void deleteFile(File archivo){
		if (archivo != null ) {
			try {
				Files.delete(archivo.toPath());
			} catch (IOException e) {
				log.error("No se pudo borrar el archivo: " + archivo, e);
			}
		}
	}
	
	public static String moveFileInit(String ruta, String dcn, File archivo) throws ValidationException {
		// el nombre del archivo debe quedar: //INPUT_{{DCN}}_NOMBRE_ORIGINAL.EXT
		String nombreNuevoArchivo = String.format(Constantes.NOMBRE_ARCHIVO_ENTRADA, dcn, archivo.getName());
		return moveFile(ruta, nombreNuevoArchivo, archivo);
	}

	public static String moveFile(String ruta, String nombreNuevoArchivo, File archivo) throws ValidationException {
		if (archivo == null || ruta == null || nombreNuevoArchivo == null) {
			throw new ValidationException("Parametros para mover el archivo invalidos");
		}
		File nuevo = null;
		try {
			nuevo = new File(ruta, nombreNuevoArchivo);
			Files.move(archivo.toPath(), nuevo.toPath(), StandardCopyOption.REPLACE_EXISTING);
			return nombreNuevoArchivo;
		} catch (Exception e) {
			throw new ValidationException("No se pudo mover el archivo: " + archivo.getName(), e);
		}
	}
	
	public static void move(File origen, File destino) throws FitravaException {
		FileInputStream fis = null;
		FileOutputStream fos = null;
		int len = 0;
		byte[] buffer = null;
		try {
			buffer = new byte[1024];
			fis = new FileInputStream(origen);
			fos = new FileOutputStream(destino);
			while ((len = fis.read(buffer)) > 0) {
				fos.write(buffer, 0, len);
			}
			origen.deleteOnExit();
		} catch (Exception e) {
			throw new FitravaException(String.format("No se pudo mover el archivo origena: %1$s, al destino: %2$s", origen, destino), e);
		} finally {
			try {
				if (fos != null) {
					fos.flush();
					fos.close();
				}
			} catch (IOException e) {
			}
			try {
				if (fis != null) {
					fis.close();
				}
			} catch (IOException e) {
			}
		}
	}

	public static final Boolean isNull(String cadena) {
		return cadena == null || cadena.trim().isEmpty();
	}

	public static final Boolean isNull(String[] cadenas) {
		if (cadenas == null || cadenas.length == 0) {
			return true;
		}
		for (String cadena: cadenas) {
			if (cadena != null && cadena.trim().length()>0) {
				return false;
			}
		}
		return true;
	}

	public static final String getFileByPath(String filePath) {
		if (filePath == null || filePath.trim().isEmpty()) {
			return null;
		}
		return filePath.substring(filePath.lastIndexOf(File.separator) + 1);		
	}

	public static final String getDcnByFileName(String fileName) {
		if (fileName == null || fileName.trim().isEmpty()) {
			return null;
		}
		return fileName.substring(Constantes.INICIO_NOMBRE_ARCHIVO_ENTRADA.length(),
				Constantes.DCN_LENGTH + Constantes.INICIO_NOMBRE_ARCHIVO_ENTRADA.length());
	}

	public static final String getFileOriginalNameByFileName(String fileName) {
		if (fileName == null || fileName.trim().isEmpty()) {
			return null;
		}
		return fileName.substring(Constantes.INICIO_NOMBRE_ARCHIVO_ENTRADA.length() + Constantes.DCN_LENGTH + 1);
	}

	public static final String getFileNameSalidaByFileName(String fileName) {
		if (fileName == null || fileName.trim().isEmpty()) {
			return null;
		}
		String temp = getFileOriginalNameByFileName(fileName);
		if (temp == null) {
			return null;
		}
		temp = temp.substring(0, temp.lastIndexOf(Constantes.DOT));
		return String.format(Constantes.NOMBRE_ARCHIVO_SALIDA, temp);
	}

	public static final Boolean exist(String fileName) {
		return (new File(fileName)).exists();
	}

	public static final void createDirectory(File directory) throws FitravaException {
		if (!directory.exists() && !directory.mkdirs()) {
			throw new FitravaException("No se puede crear el directorio: " + directory);
		}
	}

	public static String getCellValueAsString(Cell cell) {
		if (cell != null) {
			if (cell instanceof com.monitorjbl.xlsx.impl.StreamingCell) {
				return ((com.monitorjbl.xlsx.impl.StreamingCell)cell).getStringCellValue();
			}
			if (cell.getCellType().equals(CellType.STRING)) {
				return cell.toString();
			} else if (cell.getCellType().equals(CellType.NUMERIC)) {
				if (DateUtil.isCellDateFormatted(cell)) {
					SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
					return dateFormat.format(cell.getDateCellValue());
				}
				Double value = cell.getNumericCellValue();
				Long longValue = value.longValue();
				return longValue.toString();
			} else if (cell.getCellType().equals(CellType.BOOLEAN)) {
				return Boolean.toString(cell.getBooleanCellValue());
			} else if (cell.getCellType().equals(CellType.BLANK)) {
				return Constantes.BLANK;
			}
		}
		return Constantes.BLANK;
	}

	public static Date parseDate(String ddMMyyyy) {
		if (ddMMyyyy == null || ddMMyyyy.trim().isEmpty()) {
			return null;
		}
		try {
			return (new SimpleDateFormat("dd/MM/yyyy")).parse(ddMMyyyy);
		} catch (ParseException e) {
			return null;
		}
	}

	public static Integer getTipoCatalgoByFileName(String nombreArchivo) {
		if (nombreArchivo.startsWith(Constantes.PREF_NOMBRE_CATALOGO_RICSI)) {
			return Constantes.ID_CATALOGO_RICSI;
		} else if (nombreArchivo.startsWith(Constantes.PREF_NOMBRE_CATALOGO_FONE)) {
			return Constantes.ID_CATALOGO_FONE;
		} else if (nombreArchivo.startsWith(Constantes.PREF_NOMBRE_CATALOGO_ISSSTE)) {
			return Constantes.ID_CATALOGO_ISSSTE;
		} else if (nombreArchivo.startsWith(Constantes.PREF_NOMBRE_CATALOGO_RAMO74)) {
			return Constantes.ID_CATALOGO_RAMO74;
		}
		return null;
	}

	public static Boolean hasOnlyIntegers(String... args) {
		Pattern patternInteger = Pattern.compile("^-?\\d+$");
		Matcher matcher = null;
		if (args != null && args.length > 0) {
			for (String arg : args) {
				matcher = patternInteger.matcher(arg);
				if (!matcher.matches()) {
					return false;
				}
			}
			return true;
		}
		return false;
	}

	public static String[] getHojas(List<TLayoutXcel> hojas) {
		if (hojas == null || hojas.isEmpty()) {
			return null;
		}
		String[] args = new String[hojas.size()];
		int i = 0;
		for (TLayoutXcel hoja : hojas) {
			args[i] = hoja.getXcelSheetNm();
			i++;
		}
		return args;
	}

	public static Double getDouble(String tDouble) {
		if (tDouble == null || tDouble.trim().length() == 0) {
			return 0.0;
		}
		tDouble = tDouble.replace("$", Constantes.BLANK).replace("%", Constantes.BLANK).replace(",", Constantes.BLANK);
		try {
			return Double.parseDouble(tDouble.trim());
		} catch (NumberFormatException e) {
			return 0.0;
		}
	}

	public static Integer getInteger(String tInteger) {
		if (tInteger == null || tInteger.trim().length() == 0) {
			return 0;
		}
		try {
			return Integer.parseInt(tInteger.trim());
		} catch (NumberFormatException e) {
			return 0;
		}
	}

	public static String getNameFileErrors(int tipo) {
		String name = "errores_%1$s_%2$s.txt";
		String uno = null;
		switch (tipo) {
			case Constantes.ID_CATALOGO_FONE: uno = "FONE"; break;
			case Constantes.ID_CATALOGO_ISSSTE: uno = "ISSSTE"; break;
			case Constantes.ID_CATALOGO_RICSI: uno = "RICSI"; break;
			case Constantes.ID_CATALOGO_RAMO74: uno = "RAMO74"; break;
			default: uno = Constantes.BLANK;
		}
		String dos = (new SimpleDateFormat("ddMMyyyy_HHmm")).format(new Date());
		return String.format(name, uno, dos);
	}

	/*
	 * recibe una fecha así yyyyy/qq donde qq es quincena
	 */
	public static final String getAnioMesByQuincenas(String yyyyqq) {
		if (yyyyqq == null || yyyyqq.trim().isEmpty()) {
			return null;
		}
		int anio = Integer.parseInt(yyyyqq.substring(0, 4));
		int quincena = Integer.parseInt(yyyyqq.substring(5), 10);
		Calendar c = Calendar.getInstance();
		c.set(Calendar.YEAR, anio);
		c.set(Calendar.WEEK_OF_YEAR, quincena * 2);
		int mes = c.get(Calendar.MONTH) + 1;
		return String.format("%1$s/%2$s", anio, mes < 10 ? "0" + mes : mes);

	}
	
	public static String getFileNameOriginal(File f) {
		return getFileNameOriginal(f.getName());
	}

	public static String getFileNameOriginal(String nombreArchivo) {
		String last = ".zip_";
		nombreArchivo = nombreArchivo.indexOf(last)>0? nombreArchivo.substring(nombreArchivo.lastIndexOf(last)+last.length()): nombreArchivo;
		return nombreArchivo;
	}
	
	public static Boolean isPotenciacion(Integer concepto, Integer ramo) {
		String id = String.format("%1$s-%2$s", concepto, ramo);
		for (String p:POTENCIACION_IDS) {
			if (p.equals(id)) {
				return true;
			}
		}
		return false;
	}
	
	public static String getValidRfc(String rfc) {
		if (isNull(rfc)) {
			return Constantes.BLANK;
		}
		return rfc.replaceAll("-", "");
	}
	
	public static java.sql.Date getDBDate(Date fecha) {
		if (fecha == null) {
			return null;
		}
		return new java.sql.Date(fecha.getTime());
	}
	
	public static long getDiferencesMinutes(Date fechaInicial, Date fechaFinal) {
		if (fechaInicial == null || fechaFinal == null) {
			return 0l;
		}
		Instant start = fechaInicial.toInstant();
		Instant end = fechaFinal.toInstant();
		Duration dur = Duration.between(start, end);
		return dur.toMinutes();
	}
	

}