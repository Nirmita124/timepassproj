package mx.com.metlife.tom.fitrava.services.dto;

import lombok.Data;

@Data
public class InputDto {

	private String dcn = null;
	private Long flowId = null;
	private String fileNm = null;
	private Long entradaLayoutId = null;
	private Long salidaLayoutId = null;
	private String nombreHoja = null;

	private ColumnaDto[] renglon = null;

	public InputDto() {
		
	}

	public InputDto(String dcn, Long flowId, String fileNm, Long entradaLayoutId, Long salidaLayoutId) {
		super();
		this.dcn = dcn;
		this.flowId = flowId;
		this.fileNm = fileNm;
		this.entradaLayoutId = entradaLayoutId;
		this.salidaLayoutId = salidaLayoutId;
	}
	
}
