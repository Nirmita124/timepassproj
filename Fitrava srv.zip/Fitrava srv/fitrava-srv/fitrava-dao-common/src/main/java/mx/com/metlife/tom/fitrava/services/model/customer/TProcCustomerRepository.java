package mx.com.metlife.tom.fitrava.services.model.customer;

import java.util.List;

import mx.com.metlife.tom.fitrava.services.error.FitravaPersistenceException;
import mx.com.metlife.tom.fitrava.services.model.entity.TProc;

public interface TProcCustomerRepository {

	List<TProc> findByEaiAndRetainer(String retenedorId, String eaiCd) throws FitravaPersistenceException;

	List<TProc> findByUsuarioAndEstatus(String usuario, Integer estatus)throws FitravaPersistenceException;
	
	Boolean mergeEstatus(String dcn, Integer estatus) throws FitravaPersistenceException;
}
