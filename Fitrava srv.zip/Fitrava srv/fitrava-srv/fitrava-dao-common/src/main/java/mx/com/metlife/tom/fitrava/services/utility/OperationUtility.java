package mx.com.metlife.tom.fitrava.services.utility;

import static mx.com.metlife.tom.fitrava.services.utility.Constantes.BLANK;
import static mx.com.metlife.tom.fitrava.services.utility.Constantes.SPACE;
import static mx.com.metlife.tom.fitrava.services.utility.UtilCommon.isNull;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.Normalizer;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;

import mx.com.metlife.tom.fitrava.services.error.ValidationException;
import mx.com.metlife.tom.fitrava.services.model.entity.TDatatyp;
import mx.com.metlife.tom.fitrava.services.model.entity.TSkpChar;

public final class OperationUtility {

	private static Locale mexico = null;
	private static String regexDecimal = "^-?\\d*\\.\\d+$";
	private static String regexInteger = "^-?\\d+$";
	private static String regexDouble = regexDecimal + "|" + regexInteger;
	private static String regexLetras = "[a-zA-Z .,]+";
	private static String regexLetrasNumeros = "[^A-Za-z0-9., ]";
	private static String regexAlfanumeric = "(?=.*\\S)[a-zA-Z0-9\\s-]*";
	private static String regexAlfanumericWithSpace = "^[a-zA-Z0-9]+$";

	private static Pattern patternDecimal = null;
	private static Pattern patternInteger = null;
	private static Pattern patternDouble = null;
	private static Pattern patternLetras = null;
	private static Pattern patternLetrasNumeros = null;
	private static Pattern patternAlfanumericWithSpace  = null;
	
	private static DecimalFormat decimalFormat = null;

	static {
		mexico = new Locale("es", "MX");
		patternDecimal = Pattern.compile(regexDecimal);
		patternInteger = Pattern.compile(regexInteger);
		patternDouble = Pattern.compile(regexDouble);
		patternLetras = Pattern.compile(regexLetras);
		patternLetrasNumeros = Pattern.compile(regexLetrasNumeros);
		patternAlfanumericWithSpace = Pattern.compile(regexAlfanumericWithSpace);
		
		decimalFormat = new DecimalFormat("#,###,###,###.##", new DecimalFormatSymbols(mexico));
		
	}
	
	public enum OPERATION_IDS {
		REPLACE("REPLACE"),
		CAMELCASE("CAMELCASE"),
		UPPERCASE("UPPERCASE"),
		LOWERCASE("LOWERCASE"),
		TRIM("TRIM"),
		CONCAT("CONCAT"),
		LTRIM("LTRIM"),
		RTRIM("RTRIM"),
		FILL_SPACE_LEFT("FILL_SPACE_LEFT"),
		FILL_SPACE_RIGTH("FILL_SPACE_RIGTH"),
		FILL_CERO_LEFT("FILL_CERO_LEFT"),
		FILL_CERO_RIGTH("FILL_CERO_RIGTH"),
		FORMAT_DATE("FORMAT_DATE"),
		FORMAT_DECIMAL("FORMAT_DECIMAL"),
		NORMALIZE_SPACE("NORMALIZE_SPACE"),
		VALIDACION_CONCEPTO_FONE("VALIDACION_CONCEPTO_FONE"),
		
		OBTENER_POLIZA_ORIGINAL_FONE_VIDA("OBTENER_POLIZA_ORIGINAL_FONE_VIDA"),
		OBTENER_POLIZA_ORIGINAL_FONE_RETIRO_RETENCION("OBTENER_POLIZA_ORIGINAL_FONE_RETIRO_RETENCION"),
		OBTENER_POLIZA_ORIGINAL_FONE_RETIRO_APORTACION("OBTENER_POLIZA_ORIGINAL_FONE_RETIRO_APORTACION"),
		
		OBTENER_RAMO_SUBRAMO_FONE_VIDA("OBTENER_RAMO_SUBRAMO_FONE_VIDA"),
		OBTENER_RAMO_SUBRAMO_FONE_RETIRO_RETENCION("OBTENER_RAMO_SUBRAMO_FONE_RETIRO_RETENCION"),
		OBTENER_RAMO_SUBRAMO_FONE_RETIRO_APORTACION("OBTENER_RAMO_SUBRAMO_FONE_RETIRO_APORTACION"),
		
		OBTENER_SUBGRUPO_APLICACION_FONE_VIDA("OBTENER_SUBGRUPO_APLICACION_FONE_VIDA"),
		OBTENER_SUBGRUPO_APLICACION_FONE_RETIRO_RETENCION("OBTENER_SUBGRUPO_APLICACION_FONE_RETIRO_RETENCION"),
		OBTENER_SUBGRUPO_APLICACION_FONE_RETIRO_APORTACION("OBTENER_SUBGRUPO_APLICACION_FONE_RETIRO_APORTACION"),
		
		VALIDA_ANIO_QUINCENA_FONE_RETENCION("VALIDA_ANIO_QUINCENA_FONE_RETENCION"),
		NO_NULO_MAYOR_CERO("NO_NULO_MAYOR_CERO"),
		ARCHIVO_ORIGINARIO("ARCHIVO_ORIGINARIO"),
		OBTEN_PARAMETER_VALUE("OBTEN_PARAMETER_VALUE"),
		
		OBTENER_POLIZA_ISSSTE("OBTENER_POLIZA_ISSSTE"),
		OBTENER_NOMBRE_CLIENTE_ISSSTE("OBTENER_NOMBRE_CLIENTE_ISSSTE"),
		OBTENER_SUBGRUPO_ISSSTE("OBTENER_SUBGRUPO_ISSSTE"),
		VALIDA_RFC("VALIDA_RFC"),
		VALIDA_CURP("VALIDA_CURP"),
		PUNTO_FICTICIO("PUNTO_FICTICIO");
		
		private String  name = null;
		
		private OPERATION_IDS(String name) {
			this.name = name;
		}
		
		public String getName() {
			return this.name;
		}
	}
	
	private static final String ERROR_PARAMETROS_INSUFICIENTES = "Parametros insuficientes";
	
	private OperationUtility() {
		
	}
	
	public static final String transformAndFormat(String code, Object...params) throws ValidationException {
		//las validaciones las pongo por separado, por si se desean agregar m�s sea 1) mas facil de entender y 2) se pueda mandar diferentes excepciones
		if (code == null) {
			throw new ValidationException(ERROR_PARAMETROS_INSUFICIENTES);
		}
		if (params == null || params.length == 0) {
			throw new ValidationException(ERROR_PARAMETROS_INSUFICIENTES);
		}
		if ((code.equals(OPERATION_IDS.REPLACE.name) ||
				code.equals(OPERATION_IDS.VALIDA_ANIO_QUINCENA_FONE_RETENCION.name)) 
				&& params.length < 3 ) {
			throw new ValidationException(ERROR_PARAMETROS_INSUFICIENTES);
		}
		if ((code.equals(OPERATION_IDS.CONCAT.name) 
				|| code.equals(OPERATION_IDS.FILL_SPACE_LEFT.name)
				|| code.equals(OPERATION_IDS.FILL_SPACE_RIGTH.name)
				|| code.equals(OPERATION_IDS.FILL_CERO_LEFT.name)
				|| code.equals(OPERATION_IDS.FILL_CERO_RIGTH.name)
				|| code.equals(OPERATION_IDS.FORMAT_DATE.name)
				|| code.equals(OPERATION_IDS.NO_NULO_MAYOR_CERO.name))
				&& params.length < 2) 
		{
			throw new ValidationException(ERROR_PARAMETROS_INSUFICIENTES);
		}
		try {
			if (code.equals(OPERATION_IDS.REPLACE.name)) {
				return replace((String)params[0], (String)params[1], (String)params[2]); 
			} else if (code.equals(OPERATION_IDS.CAMELCASE.name)) {
				return camelCase((String)params[0]);   
			} else if (code.equals(OPERATION_IDS.UPPERCASE.name)) {
				return toUpperCase((String)params[0]);   
			} else if (code.equals(OPERATION_IDS.LOWERCASE.name)) {
				return toLowerCase((String)params[0]);   
			} else if (code.equals(OPERATION_IDS.TRIM.name)) {
				return trim((String)params[0]);   
			} else if (code.equals(OPERATION_IDS.CONCAT.name)) {
				return null;   
			} else if (code.equals(OPERATION_IDS.LTRIM.name)) {
				return ltrim((String)params[0]);   
			} else if (code.equals(OPERATION_IDS.RTRIM.name)) {
				return rtrim((String)params[0]);   
			} else if (code.equals(OPERATION_IDS.FILL_SPACE_LEFT.name)) {
				return fillSpaceLeft((String)params[0], (Integer)params[1]);  
			} else if (code.equals(OPERATION_IDS.FILL_SPACE_RIGTH.name)) {
				return fillSpaceRigth((String)params[0], (Integer)params[1]);  
			} else if (code.equals(OPERATION_IDS.FILL_CERO_LEFT.name)) {
				return fillCeroLeft((String)params[0], (Integer)params[1]);  
			} else if (code.equals(OPERATION_IDS.FILL_CERO_RIGTH.name)) {
				return fillCeroRigth((String)params[0], (Integer)params[1]);  
			} else if (code.equals(OPERATION_IDS.FORMAT_DATE.name)) {
				return formatDate((Date)params[0], (String)params[1]);  
			} else if (code.equals(OPERATION_IDS.FORMAT_DECIMAL.name)) {
				return formatNumber((Number)params[0]);   
			} else if (code.equals(OPERATION_IDS.NORMALIZE_SPACE.name)) {
				return normalizeSpace((String)params[0]);   
			} else if (code.equals(OPERATION_IDS.VALIDACION_CONCEPTO_FONE.name)) {
				return validacionCondeptoFone((String)params[0]); 
			} else if (code.equals(OPERATION_IDS.VALIDA_ANIO_QUINCENA_FONE_RETENCION.name)) {
				return validacionAnioQuincenaFoneRetencion((String)params[0], (String)params[1], (String)params[2]);     
			} else if (code.equals(OPERATION_IDS.NO_NULO_MAYOR_CERO.name)) {
				return notNullMayorCero((String)params[0]);  
			
			} else if (code.equals(OPERATION_IDS.VALIDA_RFC.name)) {
				return validaRfc((String)params[0]);  
			} else if (code.equals(OPERATION_IDS.VALIDA_CURP.name)) {
				return validaCurp((String)params[0]);  
			} else if (code.equals(OPERATION_IDS.PUNTO_FICTICIO.name)) {
				return getPuntoFicticio((String)params[0]);  
				
			} else {
				return (String)params[0];
			}
		} catch (Exception e) {
			throw new ValidationException(String.format("No se pudo ejecutar la operacion con el id: %1$s", code), e);
		}
	}
	

	public static final Double cifrasControl(Integer code, Object...params) throws ValidationException {
		//las validaciones las pongo por separado, por si se desean agregar m�s sea 1) mas facil de entender y 2) se pueda mandar diferentes excepciones
		if (code == null) {
			throw new ValidationException(ERROR_PARAMETROS_INSUFICIENTES);
		}
		if (params == null || params.length == 0) {
			throw new ValidationException(ERROR_PARAMETROS_INSUFICIENTES);
		}
		try {
			switch (code) {
				case 1:  return suma(params);
				case 2:  return avg(params);
				default :
					throw new ValidationException("Codigo de cifrasControl invalido");
			}
		} catch (ValidationException e) {
			throw e;
		} catch (Exception e) {
			throw new ValidationException(String.format("No se pudo ejecutar la operacion con el id: %1$s", code), e);
		}
	}
	
	public static final Double suma(Object...params) {
		Double total = 0.0;
		Double valor = null;
		for (Object o:params) {
			valor = null;
			if(o instanceof Double) {
				valor = (Double)o;
			} else if(o instanceof String) {
				try {
					valor = Double.parseDouble((String)o);
				} catch(NumberFormatException e) {
					continue;
				}
			}  
			if (valor != null) {
				total+=valor;
			}
		}
		return total;
	}
	
	public static final Double avg(Object...params) {
		Double total = 0.0;
		int cantidad = 0;
		Double valor = null;
		for (Object o:params) {
			valor = null;
			if(o instanceof Double) {
				valor = (Double)o;
			} else if(o instanceof String) {
				try {
					valor = Double.parseDouble((String)o);
				} catch(NumberFormatException e) {
					continue;
				}
			}  
			if (valor != null) {
				total+=valor;
				cantidad++;
			}
		}
		return cantidad>0?total/cantidad:0;
	}
	
	
	public static final String replace(String cadena, String cadena1, String cadena2) {
		if (isNull(cadena)) {
			return BLANK;
		}
		if (isNull(cadena1) || isNull(cadena2)) {
			return cadena;
		}
		return cadena.replaceAll(cadena1, cadena2);
	}
	
	public static final String camelCase(String cadena) {
		if (isNull(cadena)) {
			return BLANK;
		}
		StringBuilder builder = new StringBuilder();
	    for (String string:cadena.split(" ")) {
	        if (!string.isEmpty()) {
	            builder.append(Character.toUpperCase(string.charAt(0)));
	            builder.append(string.substring(1).toLowerCase());
	        }
	    }
	    return builder.toString();
	}
	
	public static final String toUpperCase(String cadena) {
		if (isNull(cadena)) {
			return BLANK;
		}
		return cadena.toUpperCase();
	}
	
	public static final String toLowerCase(String cadena) {
		if (isNull(cadena)) {
			return BLANK;
		}
		return cadena.toLowerCase();
	}
	
	public static final String trim(String cadena) {
		if (isNull(cadena)) {
			return BLANK;
		}
		return cadena.trim();
	}
	
	public static final String concat(String constantValue, Object...objs) {
		StringBuilder builder = new StringBuilder();
		if (constantValue.equals("NINGUNO")) {
			constantValue = BLANK;
		} else if (constantValue.equals("ESPACIO")) {
			constantValue = SPACE;
		} else {
			constantValue = "-";
		}
		for (Object o:objs) {
			if (o instanceof String) {
				builder.append(((String)o).trim());
				builder.append(constantValue);
			}
		}
		String temp = builder.toString();
		return temp.substring(0, temp.length()-constantValue.length());
	}
	
	public static final String ltrim(String cadena) {
		if (isNull(cadena)) {
			return BLANK;
		}
		return StringUtils.stripStart(cadena,null);
	}
	
	public static final String rtrim(String cadena) {
		if (isNull(cadena)) {
			return BLANK;
		}
	    return StringUtils.stripEnd(cadena,null);
	}
	
	public static final String fillSpaceLeft(String cadena, Integer tamanio) {
		return fillLeft(cadena, Constantes.CHAR_SPCAE, tamanio);
	}
	
	public static final String fillSpaceRigth(String cadena, Integer tamanio){
		return fillRigt(cadena, Constantes.CHAR_SPCAE, tamanio);
	}
	
	public static final String fillCeroLeft(String cadena, Integer tamanio){
		return fillLeft(cadena, Constantes.CHAR_ZERO, tamanio);
	}

	public static final String fillCeroRigth(String cadena, Integer tamanio){
		return fillRigt(cadena, Constantes.CHAR_ZERO, tamanio);
	}
	
	public static final String fillLeft(String cadena, Character caracter,  Integer tamanio) {
		if (isNull(cadena)) {
			return BLANK;
		}
		String temp = cadena.length()>tamanio?cadena.substring(0,tamanio):StringUtils.leftPad(cadena, tamanio).replace(Constantes.CHAR_SPCAE, caracter);
		if (temp.indexOf("-") > 0 && caracter == Constantes.CHAR_ZERO) {
			return formatNumerAca(temp);
		}
		return temp;
	}

	public static final String fillRigt(String cadena, Character caracter,  Integer tamanio) {
		if (isNull(cadena)) {
			return BLANK;
		}
		return cadena.length()>tamanio?cadena.substring(0,tamanio):StringUtils.rightPad(cadena, tamanio).replace(Constantes.CHAR_SPCAE, caracter);
	}
		
	
	public static final String formatDate(Date fecha, String pattern) {
		if (fecha == null) {
			return BLANK;
		}
		if (isNull(pattern)) {
			return BLANK;
		}
		return new SimpleDateFormat(pattern).format(fecha);
	}

	public static final String formatNumber(Number decimal){
		if (decimal == null) {
			return BLANK;
		}
		return decimalFormat.format(decimal);
	}
	
	public static final String normalizeSpace(String cadena) {
		if (isNull(cadena)) {
			return BLANK;
		}
		return StringUtils.normalizeSpace(cadena);
	}
	
	
	public static final String validacionCondeptoFone(String cadena) {
		if (isNull(cadena)) {
			return Constantes.TEXT_FALSE;
		}
		return (cadena.equals(Constantes.CONCEPTO_77) || cadena.equals(Constantes.CONCEPTO_77A) || cadena.equals(Constantes.CONCEPTO_37))?Constantes.TEXT_TRUE:Constantes.TEXT_FALSE;
	}
	
	//recibe 
	public static final String validacionAnioQuincenaFoneRetencion(String yyyyqq, String anio, String mes) {
		if (isNull(yyyyqq) || isNull(anio) || isNull(mes) ) {
			return Constantes.TEXT_FALSE;
		}
		String anioMes = UtilCommon.getAnioMesByQuincenas(yyyyqq);
		int m = Integer.parseInt(mes,10);
		return String.format("%1$s/%2$s", anio.trim(), m<10?"0"+m:m).equals(anioMes)?Constantes.TEXT_TRUE:Constantes.TEXT_FALSE;
	}

	public static final String notNullMayorCero(String cadena) {
		if (isNull(cadena)) {
			return Constantes.TEXT_FALSE;
		}
		Double d = null;
		try {
			d = Double.parseDouble(cadena.trim());
			return d > 0?Constantes.TEXT_TRUE:Constantes.TEXT_FALSE;
		} catch (Exception e) {
			return Constantes.TEXT_FALSE;
		}
	}
	
	public static final Boolean isNumeric(String cadena) {
		if (isNull(cadena)) {
			return Boolean.FALSE;
		}
		cadena = remove(cadena);
		Matcher matcher = patternDouble.matcher(cadena.trim());
		return matcher.matches();

	}

	public static Boolean isAlphaNumericNumeric(String cadena) {
		if (isNull(cadena)) {
			return Boolean.FALSE;
		}
		return cadena.matches(regexAlfanumeric);
	}

	public static Boolean isAlphaNumericNumericWithSpace(String cadena) {
		if (isNull(cadena)) {
			return Boolean.FALSE;
		}
		Matcher matcher = patternAlfanumericWithSpace.matcher(cadena);
		return matcher.matches();
	}

	public static Boolean isDecimal(String cadena) {
		if (isNull(cadena)) {
			return Boolean.FALSE;
		}
		Matcher matcher = patternDecimal.matcher(cadena);
		return matcher.matches();
	}

	public static Boolean isInteger(String cadena) {
		if (isNull(cadena)) {
			return Boolean.FALSE;
		}
		Matcher matcher = patternInteger.matcher(cadena);
		return matcher.matches();
	}

	public static Boolean isOnlyLetters(String cadena) {
		if (isNull(cadena)) {
			return Boolean.FALSE;
		}
		Matcher matcher = patternLetras.matcher(cadena);
		return matcher.matches();
	}

	public static Boolean isLettersAndNumbers(String cadena) {
		if (isNull(cadena)) {
			return Boolean.FALSE;
		}
		Matcher matcher = patternLetrasNumeros.matcher(cadena);
		return matcher.matches();
	}
	
	
	public static String capitalize(String cadena) {
		if (isNull(cadena)) {
			return BLANK;
		}
		StringBuilder builder = new StringBuilder();
	    for (String string : cadena.split(" ")) {
	        if (!string.isEmpty()) {
	            builder.append(Character.toUpperCase(string.charAt(0)));
	            builder.append(string.substring(1).toLowerCase());
	            builder.append(" ");
	        }
	    }
	    return builder.toString().trim();
	}
	
	public static String flattenToAscii(String cadena) {
		char[] out = new char[cadena.length()];
		cadena = Normalizer.normalize(cadena, Normalizer.Form.NFD);
		int j = 0;
		for (int i = 0, n = cadena.length(); i < n; ++i) {
			char c = cadena.charAt(i);
			if (c <= '\u007F')
				out[j++] = c;
		}
		return new String(out);
	}
	
	public static String getValueByDatatypId(String textoOriginal, Integer datatypId) {
		System.out.println(String.format("getValueByDatatypId(textoOriginal: %1$s, datatypId: %2$s", textoOriginal, datatypId));
		if ( datatypId.equals(TDatatyp.TIPO_DATO.NUMERICO.getId())) { //NUMERICO
			textoOriginal =  textoOriginal.replaceAll(",", ".");
		} else if ( datatypId.equals(TDatatyp.TIPO_DATO.ALFANUMERICO.getId())) { //ALFANUMERICO
			textoOriginal = flattenToAscii(textoOriginal).toUpperCase();
			textoOriginal = StringUtils.remove(textoOriginal, "*");
			textoOriginal = StringUtils.remove(textoOriginal, "-");
			textoOriginal = StringUtils.remove(textoOriginal, "[^\\p{ASCII}]");
			textoOriginal = normalizeSpace(textoOriginal);
		} else if ( datatypId.equals(TDatatyp.TIPO_DATO.ALFABETICO.getId())) { //ALFABETICO
			textoOriginal = flattenToAscii(textoOriginal).toUpperCase();
			textoOriginal = normalizeSpace(textoOriginal);
		}			
		return textoOriginal;
	}
	
	public static Boolean isDataTypeCorrectByDatatypId(String textoOriginal, Integer datatypId) {
		if ( datatypId.equals(TDatatyp.TIPO_DATO.NUMERICO.getId()) 
				|| datatypId.equals(TDatatyp.TIPO_DATO.ENTERO.getId()) 
				|| datatypId.equals(TDatatyp.TIPO_DATO.DECIMAL.getId()) ) 
		{ //NUMERICO
			return isNumeric(textoOriginal);
		} else if ( datatypId.equals(TDatatyp.TIPO_DATO.ALFANUMERICO.getId()) 
				|| datatypId.equals(TDatatyp.TIPO_DATO.FECHA.getId()) 
				|| datatypId.equals(TDatatyp.TIPO_DATO.STRING.getId()) 
				|| datatypId.equals(TDatatyp.TIPO_DATO.BOOLEAN.getId()) ) 
		{ //ALFANUMERICO
			return true;// isAlphaNumericNumericWithSpace(textoOriginal);
		} else if ( datatypId.equals(TDatatyp.TIPO_DATO.ALFABETICO.getId())) { //ALFABETICO
			return isOnlyLetters(textoOriginal);
		}			
		return Boolean.FALSE;
	}
	
	public static String formatNumber(String temp, String separador, int numDecimales) throws ValidationException {
		//System.out.println(String.format("formatNumber(temp: %1$s, separador: %2$s, numDecimales: %3$s", temp, separador, numDecimales));
		Double d = null;
		try {
			if (temp == null || temp.trim().length() == 0) {
				temp = "0.0";
			} 
			temp = remove(temp);
			d = Double.parseDouble(temp.trim());
			String t = formatNumber(d, separador, numDecimales);
			//System.out.println("...::: " + t);
			return t;
		} catch (Exception e) {
			throw new ValidationException("no se pudo dar formato al numero");
		}
	}
	
	public static String formatNumber(Double d, String separador, int numDecimales) {
		DecimalFormat numberFormat =  new DecimalFormat("0.00");
		numberFormat.setMinimumFractionDigits(numDecimales);
		numberFormat.setMaximumFractionDigits(numDecimales);
		if (separador != null && separador.trim().length() == 1) {
			DecimalFormatSymbols simbolos = new DecimalFormatSymbols();
			simbolos.setDecimalSeparator(separador.trim().charAt(0));
			numberFormat.setDecimalFormatSymbols(simbolos);
		}
		return numberFormat.format(d);
	}
	
	public static String getPuntoFicticio(String numero) {
		if (isNull(numero) || !isNumeric(numero)) {
			return BLANK;
		}
		Double d = Double.parseDouble(numero);
		d = d/100;
		return formatNumber(d, ".", 2);
	}

	public static Boolean validaFormatoFecha(String expresionRegular, String fecha) {
		if (isNull(fecha) || isNull(expresionRegular)) {
			return false;
		}
		Date date = null;
		String dd = null;
		try {
			date = new SimpleDateFormat(expresionRegular, mexico).parse(fecha);
			dd = new SimpleDateFormat(expresionRegular, mexico).format(date);
			return dd.equals(fecha);
		} catch(Exception e) {
			return false;
		}
	}
	
	public static String validaRfc(String rfc) {
		if (isNull(rfc) && rfc.trim().length() < 10 && rfc.trim().length() > 13) {
			return Constantes.TEXT_FALSE;
		}
		return validarRfc(rfc)?Constantes.TEXT_TRUE:Constantes.TEXT_FALSE;
	}

	public static String validaCurp(String curp) {
		if (isNull(curp) || curp.trim().length() != 18) {
			return Constantes.TEXT_FALSE;
		}
		return validarCurp(curp)?Constantes.TEXT_TRUE:Constantes.TEXT_FALSE;
	}

	public static boolean validarCurp(String curp) {
		curp = curp.toUpperCase().trim();
		return curp.matches("[A-Z]{4}[0-9]{6}[H,M][A-Z]{5}[0-9]{2}");
	}

	public static boolean validarNumCreden(String numCrede) {
		numCrede = numCrede.toUpperCase().trim();
		return numCrede.matches("[A-Za-z]{6}[0-9]{8}[H,M][0-9]{3}");
	}
	
	public static boolean validarRfc(String rfc) {
		rfc = rfc.toUpperCase().trim();
		return rfc.matches("[A-Z]{4}[0-9]{6}[A-Z0-9]{3}");
	}


	public static boolean validarText(String cadena) {
		String texto = "";
		texto = cadena.trim();
		texto = texto.replace(" ", "a");
		texto = texto.replace("ñ", "a");
		if (!texto.matches("[a-zA-Z]*\\D{3}")) {
			return true;
		}
		return false;
	}
	
	
	public static String remove(String temp) {
		if (isNull(temp)) {
			return BLANK;
		}
		if (temp.contains("$") || temp.contains("%")) {
			temp = temp.replace('$', ' ').replace('%', ' ');
		}
		return temp.trim();
	}
	
	public static Boolean isFoneOperation(String name) {
		if (isFoneVida(name) || isFoneRetencion(name) || isFoneAportacion(name)){
			return true;
		}
		return false;
	}
	
	public static Boolean isFoneVida(String name) {
		if(name.equals(OPERATION_IDS.OBTENER_POLIZA_ORIGINAL_FONE_VIDA.name) || 
				name.equals(OPERATION_IDS.OBTENER_RAMO_SUBRAMO_FONE_VIDA.name) || 
				name.equals(OPERATION_IDS.OBTENER_SUBGRUPO_APLICACION_FONE_VIDA.name) )
		{
			return true;
		}
		return false;
	}

	public static Boolean isFoneRetencion(String name) {
		if(name.equals(OPERATION_IDS.OBTENER_POLIZA_ORIGINAL_FONE_RETIRO_RETENCION.name) || 
				name.equals(OPERATION_IDS.OBTENER_RAMO_SUBRAMO_FONE_RETIRO_RETENCION.name) || 
				name.equals(OPERATION_IDS.OBTENER_SUBGRUPO_APLICACION_FONE_RETIRO_RETENCION.name) )
		{
			return true;
		}
		return false;
	}
	
	public static Boolean isFoneAportacion(String name) {
		if(name.equals(OPERATION_IDS.OBTENER_POLIZA_ORIGINAL_FONE_RETIRO_APORTACION.name) || 
				name.equals(OPERATION_IDS.OBTENER_RAMO_SUBRAMO_FONE_RETIRO_APORTACION.name) || 
				name.equals(OPERATION_IDS.OBTENER_SUBGRUPO_APLICACION_FONE_RETIRO_APORTACION.name) ) 
		{
			return true;
		}
		return false;
	}
	
	public static Boolean isFonePolizaOriginal(String name) {
		if(name.equals(OPERATION_IDS.OBTENER_POLIZA_ORIGINAL_FONE_VIDA.name) || 
				name.equals(OPERATION_IDS.OBTENER_POLIZA_ORIGINAL_FONE_RETIRO_RETENCION.name) || 
				name.equals(OPERATION_IDS.OBTENER_POLIZA_ORIGINAL_FONE_RETIRO_APORTACION.name) )
				 
		{
			return true;
		}
		return false;
	}
	
	public static Boolean isFoneRamoSubRamo(String name) {
		if(name.equals(OPERATION_IDS.OBTENER_RAMO_SUBRAMO_FONE_VIDA.name) || 
				name.equals(OPERATION_IDS.OBTENER_RAMO_SUBRAMO_FONE_RETIRO_RETENCION.name) || 
				name.equals(OPERATION_IDS.OBTENER_RAMO_SUBRAMO_FONE_RETIRO_APORTACION.name)) 
		{
			return true;
		}
		return false;
	}
	
	public static Boolean isFoneSubGrupo(String name) {
		if(name.equals(OPERATION_IDS.OBTENER_SUBGRUPO_APLICACION_FONE_VIDA.name) || 
				name.equals(OPERATION_IDS.OBTENER_SUBGRUPO_APLICACION_FONE_RETIRO_RETENCION.name) || 
				name.equals(OPERATION_IDS.OBTENER_SUBGRUPO_APLICACION_FONE_RETIRO_APORTACION.name) ) 
		{
			return true;
		}
		return false;
	}

	public static Boolean isIsssteOperation(String name) {
		if(name.equals(OPERATION_IDS.OBTENER_POLIZA_ISSSTE.name) || 
				name.equals(OPERATION_IDS.OBTENER_NOMBRE_CLIENTE_ISSSTE.name) || 
				name.equals(OPERATION_IDS.OBTENER_SUBGRUPO_ISSSTE.name) ) 
		{
			return true;
		}
		return false;
	}

	private static String formatNumerAca(String cadena) {
		cadena = cadena.replace('-', '0');
		cadena = cadena.replaceFirst("0", "-");
		return cadena;
	}
	
	public static String removeCarateresExcluir(String cadena, List<TSkpChar> listaCaracteresOmitir) {
		if (listaCaracteresOmitir == null || listaCaracteresOmitir.isEmpty()) {
			return cadena;
		}
		List<String> caracteres = listaCaracteresOmitir.parallelStream().map(e -> e.getCharVal()).collect(Collectors.toList());
		for(String caracter: caracteres) {
			cadena = cadena.replaceAll(caracter, "");
		}
		return cadena;
	}
	
	/**
	 * 1 -> replace(cadena,cadena,cadena)
	 * 2 -> camelCase(cadena)
	 * 3 -> toUpperCase(cadena)
	 * 4 -> toLowerCase(cadena)
	 * 5 -> trim(cadena)
	 * 6 -> concat(cadena,cadena)
	 * 7 -> ltrim(cadena)
	 * 8 -> rtrim(cadena)
	 * 9 -> fillSpaceLeft(cadena,tamanio)
	 * 10 -> fillSpaceRigth(cadena,tamanio)
	 * 11 -> fillCeroLeft(cadena,tamanio)
	 * 12 -> fillCeroRigth(cadena,tamanio)
	 * 13 -> formatDate(fecha, pattern)
	 * 14 -> formatNumber(decimal)
	 * 15 -> normalizeSpace(cadena)
	 * 
	 * @param args
	 * @throws ValidationException 
	 */
	public static void main(String[] args) throws ValidationException {
		
		//System.out.println("------>" + getPuntoFicticio("0007180500"));

//		System.out.println("--->" + isDataTypeCorrectByDatatypId("7C", 6));
//		System.out.println(fillLeft("-50.25", '0', 10));
		
//		System.out.println("--" + formatNumber(" $3.95  ", ",", 2));
//		System.out.println("-------->" + isOnlyLetters("Ma. lupitas"));
//		
//		System.out.println("---------->>>" + formatNumber("$3.95", null, 2));
//		System.out.println("-------->" + isNumeric("$3.95"));
//		System.out.println("-------->" + isNumeric("12.45%"));
		
//		String[] patterns = new String[] {
//				"yyyy/MM","MM/yyyy","yyyy-MM","MM/yyyy","yyyy-MM-dd","yyyy/MM/dd","MM/dd/yyyy","MM-dd-yyyy","dd-MM-yyyy","dd/MM/yyyy"
//		};
//		
//		for (String pattern: patterns) {
//			System.out.println("--->" + validaFormatoFecha(pattern, "2001-01"));
//		}
//		
//		
//		
//		
//		System.out.println("1  -> replace(cadena,cadena,cadena) -->" + transformAndFormat(1, "cadena cadena cadena", "cad", "123") + "<--");
//		System.out.println("2  -> camelCase(cadena)             -->" + transformAndFormat(2, "Hola    mundo como te va") + "<--");
//		System.out.println("3  -> toUpperCase(cadena)           -->" + transformAndFormat(3, "Hola mundo como te va") + "<--");
//		System.out.println("4  -> toLowerCase(cadena)           -->" + transformAndFormat(4, "Hola mundo como te va") + "<--");
//		System.out.println("5  -> trim(cadena)                  -->" + transformAndFormat(5, " 		espacios     ") + "<--");
//		//System.out.println("6  -> concat(cadena,cadena)         -->" + transformAndFormat(6,  "una", "dos") + "<--");
//		System.out.println("7  -> ltrim(cadena)                 -->" + transformAndFormat(7, " 		espacios     ") + "<--");
//		System.out.println("8  -> rtrim(cadena)                 -->" + transformAndFormat(8, " 		espacios     ") + "<--");
//		System.out.println("9  -> fillSpaceLeft(cadena,tamanio) -->" + transformAndFormat(9, "12345678901234567", 20) + "<--");
//		System.out.println("10 -> fillSpaceRigth(cadena,tamanio)-->" + transformAndFormat(10, "dos", 12) + "<--");
//		System.out.println("11 -> fillCeroLeft(cadena,tamanio)  -->" + transformAndFormat(11, "tres", 12) + "<--");
//		System.out.println("12 -> fillCeroRigth(cadena,tamanio) -->" + transformAndFormat(12, "cuatro",12) + "<--");
//		System.out.println("13 -> formatDate(fecha, pattern)    -->" + transformAndFormat(13, new Date(), "dd/MMM/yyyy") + "<--");
//		System.out.println("14 -> formatNumber(decimal)         -->" + transformAndFormat(14, 1234567.12342) + "<--");
//		System.out.println("15 -> normalizeSpace(cadena)        -->" + transformAndFormat(15, "vamos     a    ver   como funciona     esto") + "<--");
//		
//		System.out.println("\nflattenToAscii: " + flattenToAscii("sdasd$#%&/“º”"));
//		
//		String[] constantValues = new String[] {"NINGUNO", "ESPACIO", "-"};
//		Object[] obs = new Object[] {"uno", "dos", "tres","cuatro", "5"};
//		for (String constantValue: constantValues) {
//			System.out.println(String.format("concat(->%1$s<-): -->>%2$s<<--", constantValue, concat(constantValue, obs)));
//		}
//
//		
//		
//		//se puede usar encadenadas
//		String test = "uno   dos    tres    cuatro     cinco";
//		String cadena = transformAndFormat(OPERATION_IDS.UPPERCASE.name,
//							transformAndFormat(OPERATION_IDS.FILL_SPACE_RIGTH.name, 
//									transformAndFormat(OPERATION_IDS.NORMALIZE_SPACE.name, test), 50));
//
//		System.out.println("-->" + cadena + "<--");
//		String[] temp = new String [] {"123456", "1234.56", "123456dasdsaASDASDASD#$%$%#$", "adsasdasda", "12323asdasdas", "ASDASDASDASD", "ASDASDA SDASD"};
//		Integer[] dataType = new Integer[] {1,2,3};
//		for (String a:temp) {
//			for (Integer i: dataType) {
//				System.out.println(String.format("isDataTypeCorrectByDatatypId(textoOriginal: %1$s, datatypId: %2$s): %3$s", a, i, isDataTypeCorrectByDatatypId(a, i)));
//			}
//		}
//		cadena = "sdasdasd#$#%&@*-.,asasas";
//		
//		for (Integer i: dataType) {
//			System.out.println(String.format("getValueByDatatypId(textoOriginal: %1$s, datatypId: %2$s): %3$s", cadena, i, getValueByDatatypId(cadena, i)));
//		}

//		System.out.println("formatNumber: " + formatNumber("37243.65354353", ",", 2));
//		System.out.println("formatNumber: " + formatNumber("37243.65354353", ".", 0));
//		System.out.println("formatNumber: " + formatNumber("37243", null, 0));
		
	}
	
}
