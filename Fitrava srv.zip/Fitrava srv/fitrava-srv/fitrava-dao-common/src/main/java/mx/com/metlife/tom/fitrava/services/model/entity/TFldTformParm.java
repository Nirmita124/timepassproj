package mx.com.metlife.tom.fitrava.services.model.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Data;

@SuppressWarnings("serial")
@Data
@Entity(name = "TFldTformParm")
@Table(name = "T_FLD_TFORM_PARM")
public class TFldTformParm implements java.io.Serializable{

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "FLD_TFORM_PARM_ID")
	private Long fldTformParmId = null;

	@Column(name = "FLD_TFORM_ID")
	private Long fldTformId = null;

	@Column(name = "PARM_NM")
	private String parmNm = null;

	@Column(name = "FLD_TFORM_PARM_ORD_NUM")
	private Integer fldTformParmOrdNum = null;

	@Column(name = "FLD_TFORM_PARM_VAL")
	private String fldTformParmVal = null;

	@Column(name = "LAYOUT_FLD_ID")
	private Long layoutFldId = null;


}
