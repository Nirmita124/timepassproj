package mx.com.metlife.tom.fitrava.services.model.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@SuppressWarnings("serial")
@Data
@Entity
@Table(name = "T_ULOAD_EXT")
public class TUloadExt implements java.io.Serializable{

	@Id
	@Column(name = "ULOAD_EXT_ID")
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long uloadExternalDataId;
	
	@Column(name = "DSTNCT_CTRL_NUM")
	private String dstnctCtrlNum;
	
	@Column(name = "ULOAD_EXT_KEY_ID")
	private String key;
	
	@Column(name = "ULOAD_EXT_VAL")
	private String value;
	
}
