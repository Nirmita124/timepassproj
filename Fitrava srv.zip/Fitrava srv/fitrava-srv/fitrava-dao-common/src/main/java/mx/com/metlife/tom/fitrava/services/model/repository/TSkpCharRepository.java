package mx.com.metlife.tom.fitrava.services.model.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import mx.com.metlife.tom.fitrava.services.model.entity.TSkpChar;

@Repository
public interface TSkpCharRepository extends JpaRepository<TSkpChar, Long>{
	
	@Transactional
	void deleteByLayoutId(Long layoutId);
	
	List<TSkpChar> findByLayoutId(Long layoutId);


	List<TSkpChar> findAllByLayoutId(Long layoutId);
}
