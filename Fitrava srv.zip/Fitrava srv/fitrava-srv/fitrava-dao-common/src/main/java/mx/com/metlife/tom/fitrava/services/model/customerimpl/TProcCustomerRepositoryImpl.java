package mx.com.metlife.tom.fitrava.services.model.customerimpl;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import mx.com.metlife.tom.fitrava.services.error.FitravaPersistenceException;
import mx.com.metlife.tom.fitrava.services.model.customer.TProcCustomerRepository;
import mx.com.metlife.tom.fitrava.services.model.entity.TFlow;
import mx.com.metlife.tom.fitrava.services.model.entity.TProc;

@Repository
public class TProcCustomerRepositoryImpl implements TProcCustomerRepository {

	private static final String QUERY_ACTUALIZA_TPROC_ESTATUS = "TProcCustomerRepositoryImpl.mergeEstatus";

	
	@Autowired
	private EntityManager entityManager;
	
	
	@Override
	public List<TProc> findByEaiAndRetainer(String retenedorId, String eaiCd) throws FitravaPersistenceException {
		CriteriaBuilder builder = null;
		CriteriaQuery<TProc> query = null;
		Root<TProc> root = null;
		Join<TProc, TFlow> join = null;
		List<Predicate> list = null;
		try {
			list = new ArrayList<>();
			builder = entityManager.getCriteriaBuilder();
			query = builder.createQuery(TProc.class);
			root = query.from(TProc.class);
			join = root.join("tFlow");
		    
			if(retenedorId != null && retenedorId.trim().length() > 0) {
		    	list.add(builder.equal(join.get("retainerId"), retenedorId));
			}
			if(eaiCd != null && eaiCd.trim().length() > 0) {
		    	list.add(builder.equal(join.get("eaiCd"), eaiCd));
			}
		    query.select(root).distinct(true).where(list.toArray(new Predicate[list.size()]));
		    
		    return entityManager.createQuery(query).getResultList();
			
		} catch(Exception e) {
			throw new FitravaPersistenceException(String.format("Error en el findByEaiAndRetainer(retenedorId: %1$s, eaiCd: %2$s), excepcion: %3$s", retenedorId, eaiCd, e));
		}
	}
	
	@Override
	public List<TProc> findByUsuarioAndEstatus(String usuario, Integer estatus) throws FitravaPersistenceException {
		CriteriaBuilder builder = null;
		CriteriaQuery<TProc> query = null;
		Root<TProc> root = null;
		List<Predicate> list = null;
		try {
			list = new ArrayList<>();
			builder = entityManager.getCriteriaBuilder();
			query = builder.createQuery(TProc.class);
			root = query.from(TProc.class);
		    
			if(usuario != null && usuario.trim().length() > 0) {
		    	list.add(builder.equal(root.get("crtUsrId"), usuario));
			}
			if(estatus != null && estatus > 0) {
		    	list.add(builder.equal(root.get("clctSttsId"), estatus));
			}
		    query.select(root).where(list.toArray(new Predicate[list.size()]));
		    
		    return entityManager.createQuery(query).getResultList();
			
		} catch(Exception e) {
			throw new FitravaPersistenceException(String.format("Error en el findByUsuarioAndEstatus(usuario: %1$s, estatus: %2$s), excepcion: %3$s", usuario, estatus, e));
		}
	}
	
	@Override
	public Boolean mergeEstatus(String dcn, Integer estatus) throws FitravaPersistenceException {
		Query query = null;
		int actualiza = 0;
		try {
			query = entityManager.createNamedQuery(QUERY_ACTUALIZA_TPROC_ESTATUS);
			query.setParameter("dcn", dcn);
			query.setParameter("estatus", estatus);
			actualiza = query.executeUpdate();
			return actualiza > 0;
		} catch(Exception e) {
			throw new FitravaPersistenceException(String.format("Error en el mergeEstatus(dcn: %1$s, estatus: %2$s), excepcion: %3$s", dcn, estatus, e));
		}	
	}

}
