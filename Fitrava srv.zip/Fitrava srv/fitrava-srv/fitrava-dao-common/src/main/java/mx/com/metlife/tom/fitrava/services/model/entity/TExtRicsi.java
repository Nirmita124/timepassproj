package mx.com.metlife.tom.fitrava.services.model.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import lombok.Data;

@SuppressWarnings("serial")
@Data
@Entity
@Table(name="T_EXT_RICSI")
@IdClass(TExtRicsiId.class)
public class TExtRicsi implements java.io.Serializable{
	
	
	@Id
	@Column(name="POL_NUM")
	private String polNum = null;

	@Id
	@Column(name="NATL_ID")
	private String natlId = null;
	
	@Id
	@Column(name="INS_FULL_NM")
	private String  insFullNm = null;
	
	@Id
	@Column(name="POL_STTS_NM")
	private String  polSttsNm = null;
	
	@Id
	@Column(name="ISS_DT")
	private Date issDt = null;
	
	@Id
	@Column(name="RCPT_DT")
	private Date  rcptDt = null;
	
	@Id
	@Column(name="POL_EFF_DT")
	private Date  polEffDt = null;
	
	@Id
	@Column(name="PY_MTHD_CD")
	private String pyMthdCd = null;
	
	@Id
	@Column(name="CLCT_KEY_CD")
	private String  clctKeyCd = null;
	
	@Id
	@Column(name="PENR_NUM")
	private String  pensionerNum = null;
	
	@Id
	@Column(name="ANNL_PREM_AMT")
	private Double  annlPremAmt = null;
	
	@Id
	@Column(name="RCPT_STTS_CD")
	private String  rcptSttsCd = null;
	
	@Id
	@Column(name="CLCT_PREM_AMT")
	private Double  clctPremAmt = null;


}
