package mx.com.metlife.tom.fitrava.services.model.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@SuppressWarnings("serial")
@Data
@Entity
@Table(name = "T_USER")
public class TUser implements java.io.Serializable{
	@Id
	@Column(name = "USER_CVE")
	private String userCve = null;
	
	@Column(name = "USER_IDENTIFIER")
	private String userIdentifier = null;

	@Column(name = "USER_NM")
	private String userNm = null;

	@Column(name = "USER_APE_PAT")
	private String userApePat = null;

	@Column(name = "USER_APE_MAT")
	private String userApeMat = null;

	@Column(name = "USER_EMAIL")
	private String userEmail = null;

	@Column(name = "USER_TEL")
	private String userTel = null;

	@Column(name = "USER_TEL_EXT")
	private String userTelExt = null;

	@Column(name = "USER_ACT_IND")
	private Integer userActInd = null;

	@Column(name = "ROLE_ID")
	private Integer roleId = null;
	
//	@ManyToOne
//	@JoinColumn(name = "ROLE_ID", nullable = false, insertable = false, updatable = false)
//	private TRole tRole;
}
