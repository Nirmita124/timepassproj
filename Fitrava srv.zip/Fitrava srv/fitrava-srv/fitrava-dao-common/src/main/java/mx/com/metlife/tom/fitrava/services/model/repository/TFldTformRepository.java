package mx.com.metlife.tom.fitrava.services.model.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import mx.com.metlife.tom.fitrava.services.model.entity.TFldTform;

@Repository
public interface TFldTformRepository extends JpaRepository<TFldTform, Long>{


	List<TFldTform> findByLayoutFldId(Long layoutFldId);


	List<TFldTform> findAllByLayoutId (@Param("layoutId") Long layoutEntradaId);
	
	@Transactional
	void deleteByLayoutFldId(Long layoutFldId);

}
