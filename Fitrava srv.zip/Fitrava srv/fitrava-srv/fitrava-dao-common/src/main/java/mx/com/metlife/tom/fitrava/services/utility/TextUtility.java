package mx.com.metlife.tom.fitrava.services.utility;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.apache.commons.lang3.StringUtils;

import mx.com.metlife.tom.fitrava.services.error.FitravaException;

public class TextUtility {

	private File archivoTexto = null;
	private Path path = null;

	private Integer numColumnas = null;
	private Integer longitudRenglon = null;
	private String primeraLinea = null;
	private String[] primerasColumnas = null;

	
	public TextUtility(File archivoTexto) throws FitravaException {
		this.archivoTexto = archivoTexto;
		path = Paths.get(archivoTexto.getAbsolutePath());
		initPrimeraLinea();
	}
	
	
	private void initPrimeraLinea() throws FitravaException {
		try (BufferedReader reader = Files.newBufferedReader(path, StandardCharsets.UTF_8)) {
		     primeraLinea = reader.readLine();
		     longitudRenglon = primeraLinea.length();
		} catch (IOException e) {
			throw new FitravaException("Error al leer la 1er linea del archivo");
		}
	}

	public Integer getLongitudRenglon() {
		return longitudRenglon;
	}
	
	public Boolean contieneSeparador(String separador) {
		return primeraLinea.contains(separador);
	}

	
	public File getArchivoTexto() {
		return archivoTexto;
	}

	public Path getPath() {
		return path;
	}

	public Integer getNumColumnas(String separador) {
		if (numColumnas == null) {
			primerasColumnas = StringUtils.splitPreserveAllTokens(primeraLinea,separador);
			if (primerasColumnas != null && primerasColumnas.length > 0) {
				numColumnas = primerasColumnas.length;
			}
		}
		return numColumnas;
	}
	public String[] getPrimerasColumnas(String separador) {
		if (numColumnas == null) {
			getNumColumnas(separador);
		}
		return primerasColumnas;
	}

	public String getPrimeraLinea() {
		return primeraLinea;
	}


}
