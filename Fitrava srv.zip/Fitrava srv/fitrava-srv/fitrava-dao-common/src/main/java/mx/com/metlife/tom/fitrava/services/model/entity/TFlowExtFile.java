package mx.com.metlife.tom.fitrava.services.model.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@SuppressWarnings("serial")
@Data
@Entity
@Table(name = "T_FLOW_EXT_FILE")
public class TFlowExtFile implements java.io.Serializable{

	public TFlowExtFile() {}
	
	public TFlowExtFile(Long flowId, String flowExtFileNm, String flowExtFileRteNm) {
		super();
		this.flowId = flowId;
		this.flowExtFileNm = flowExtFileNm;
		this.flowExtFileRteNm = flowExtFileRteNm;
	}

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "FLOW_EXT_FILE_ID")
	private Integer flowExtFileId = null;

	@Column(name = "FLOW_ID")
	private Long flowId = null;

	@Column(name = "FLOW_EXT_FILE_NM")
	private String flowExtFileNm = null;

	@Column(name = "FLOW_EXT_FILE_RTE_NM")
	private String flowExtFileRteNm = null;


}
