package mx.com.metlife.tom.fitrava.services.dto;

import lombok.Data;

@Data
public class ColumnaDto {

	private Long id;
	private String texto;

	public ColumnaDto() {}

	public ColumnaDto(Long id, String texto) {
		super();
		this.id = id;
		this.texto = texto;
	}
	
}
