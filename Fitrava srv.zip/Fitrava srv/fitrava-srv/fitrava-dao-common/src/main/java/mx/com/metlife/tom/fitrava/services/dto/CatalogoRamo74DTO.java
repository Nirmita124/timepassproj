package mx.com.metlife.tom.fitrava.services.dto;

import org.dozer.Mapping;

import lombok.Data;
import lombok.EqualsAndHashCode;

@EqualsAndHashCode(callSuper=false)
@Data
public class CatalogoRamo74DTO  extends CatalogoFitravaDTO { 

	@Mapping("penNum")
	private String numeroPension; 
	
	@Mapping("natlId")
	private String rfc; 
	
	@Mapping("fullNm")
	private String nombreCompleto; 
	
	@Mapping("polNum")
	private String poliza; 

}
