package mx.com.metlife.tom.fitrava.services.model.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Data;

@SuppressWarnings("serial")
@Data
@Entity
@Table(name = "T_FLD_OPER")
public class TFldOper implements java.io.Serializable{

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "FLD_OPER_ID")
	private Long fldOperId = null;

	@Column(name = "FLD_OPER_NM")
	private String fldOperNm = null;

	@Column(name = "FLD_OPER_DSCR")
	private String fldOperDscr = null;

	@Column(name = "FLD_OPER_CLASS_NM")
	private String fldOperClassNm = null;

	@Column(name = "FLD_OPER_MTHD_NM")
	private String fldOperMthdNm = null;

	@Column(name="MTHD_DFN_PARM_CNT")
	private Integer mthdDfnParmCnt = null;

}
