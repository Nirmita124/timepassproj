package mx.com.metlife.tom.fitrava.services.model.customerimpl;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import mx.com.metlife.tom.fitrava.services.error.FitravaPersistenceException;
import mx.com.metlife.tom.fitrava.services.model.customer.TFlowCustomerRepository;
import mx.com.metlife.tom.fitrava.services.model.entity.TFlow;

@Repository
public class TFlowCustomerRepositoryImpl implements TFlowCustomerRepository {

	private static final String QUERY_ACTUALIZA_TFLOW_ESTATUS = "TFlowCustomerRepositoryImpl.mergeEstatus";

	
	@Autowired
	private EntityManager entityManager;
	
	@Override
	public List<TFlow> findAllBy(String retenedorId, String eaiCd) throws FitravaPersistenceException {
		CriteriaBuilder builder = null;
		CriteriaQuery<TFlow> query = null;
		Root<TFlow> root = null;
		List<Predicate> list = null;
		try {
			list = new ArrayList<>();
			builder = entityManager.getCriteriaBuilder();
			query = builder.createQuery(TFlow.class);
			root = query.from(TFlow.class);
		    
			if(retenedorId != null && retenedorId.trim().length() > 0) {
		    	list.add(builder.equal(root.get("retainerId"), retenedorId));
			}
			if(eaiCd != null && eaiCd.trim().length() > 0) {
		    	list.add(builder.equal(root.get("eaiCd"), eaiCd));
			}
		    query.select(root).where(list.toArray(new Predicate[list.size()]));
		    
		    return entityManager.createQuery(query).getResultList();
			
		} catch(Exception e) {
			throw new FitravaPersistenceException(String.format("Error en el Error en el findAllBy(retenedorId: %1$s, eaiCd: %2$s), excepcion: %3$s", retenedorId, eaiCd, e));
		}
	}
	
	public Boolean mergeEstatus(Long flowId, Integer estatus) throws FitravaPersistenceException {
		Query query = null;
		int actualiza = 0;
		try {
			query = entityManager.createNamedQuery(QUERY_ACTUALIZA_TFLOW_ESTATUS);
			query.setParameter("flowId", flowId);
			query.setParameter("estatus", estatus);
			actualiza = query.executeUpdate();
			return actualiza > 0;
		} catch(Exception e) {
			throw new FitravaPersistenceException(String.format("Error en el mergeActiva(flowId: %1$s, estatus: %2$s), excepcion: %3$s", flowId, estatus, e));
		}	
	}

}
