package mx.com.metlife.tom.fitrava.services.utility;


import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@SuppressWarnings("rawtypes")
public class UtilRest<T> {
	
	private Method[] metodos = null;
	private Method[] metodosOriginal = null;
	
	public T clona(Object original, Class<T> copia) throws Exception {
		Method[] metodosGetters = original.getClass().getMethods();
		T objetoCopia = copia.newInstance();
		String atributo = null;
		Method setter = null;
		Object valor = null;
		List<?> list = null;
		for(Method getter: metodosGetters) {
			if(getter.getName().startsWith("get")){
				atributo = getter.getName().substring(3);
				String setterName = null;
				try {
					setterName = "set"+atributo;
					setter = getMetodoByName(copia, setterName);
					valor = getter.invoke(original, (Object[])null); 
					if (setter == null || valor == null) {
						continue;
					}
					if (valor instanceof List) {
						list = clonaList((List)valor, copia);
						setter.invoke(objetoCopia, list);
					}
					setter.invoke(objetoCopia, valor);
				} catch(Exception e) {}
			}
		}
		return objetoCopia;
	}
	
	/**
	 * 
	 * @param original
	 * @param copia
	 * @param map es una relacion de getter del original, con el setter de la copia
	 * @return
	 * @throws Exception
	 */
	public T clona(Object original, Class<T> copia, Map<String, String> map) throws Exception {
		T objetoCopia = copia.newInstance();
		Method setter = null;
		Method getter = null;
		Object valor = null;
		String setterName = null;
		String getterName = null;
		for(String atributo: map.keySet()) {
			getterName = "get" + atributo;
			setterName = "set" + map.get(atributo);
			getter = getMetodoBisByName(original.getClass(), getterName);
			setter = getMetodoByName(copia, setterName);
			if (getter != null && setter != null) {
				try {
					valor = getter.invoke(original, (Object[])null); 
					if (valor == null) {
						continue;
					}
					setter.invoke(objetoCopia, valor);
				} catch(Exception e) {}
			}
		}
		return objetoCopia;
	}

	public List<T> clonaList(List<?> listOriginal, Class<T> copia) throws Exception {
		List<T> list = null;
		if (listOriginal != null && !listOriginal.isEmpty()) {
			list = new ArrayList<>();
			T objectCopia = null;
			for(Object original: listOriginal) {
				objectCopia = clona(original, copia);
				list.add(objectCopia);
			}
		}
		return list;
	}
	
	Class getPrimitiveClass(Class clazz) {
		if(clazz.toString().endsWith("Integer")){
			return int.class;
		} else if(clazz.toString().endsWith("int")){
			return Integer.class;
		} else if(clazz.toString().endsWith("Boolean")){
			return boolean.class;
		} else if(clazz.toString().endsWith("boolean")){
			return Boolean.class;
		} else if(clazz.toString().endsWith("Float")){
			return float.class;
		} else if(clazz.toString().endsWith("float")){
			return Float.class;
		} else if(clazz.toString().endsWith("Double")){
			return double.class;
		} else if(clazz.toString().endsWith("double")){
			return Double.class;
		} else if(clazz.toString().endsWith("Long")){
			return long.class;
		} else if(clazz.toString().endsWith("long")){
			return Long.class;
		}
		return clazz;
	}
	
	private Method getMetodoByName(Class<T> clazz, String method) {
		if (metodos == null) {
			metodos = clazz.getMethods();
		}
		for (Method metodo: metodos) {
			if (metodo.getName().equalsIgnoreCase(method)){
				return metodo;
			}
		}
		return null;
	}
	
	private Method getMetodoBisByName(Class<?> clazz, String method) {
		if (metodosOriginal == null) {
			metodosOriginal = clazz.getMethods();
		}
		for (Method metodo: metodosOriginal) {
			if (metodo.getName().equalsIgnoreCase(method)){
				return metodo;
			}
		}
		return null;
	}
	
	
	
}
