package mx.com.metlife.tom.fitrava.services.model.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import lombok.Data;

@SuppressWarnings("serial")
@Data
@Entity
@Table(name = "T_EXT_FONE")
@IdClass(TExtFoneId.class)
public class TExtFone implements java.io.Serializable{

	@Id
	@Column(name = "FONE_ID")
	private String foneId = null;

	@Column(name = "ORIG_POL_NUM")
	private String origPolNum = null;

	@Column(name = "CUST_NM")
	private String custNm = null;

	@Column(name = "SB_CTGY_CD")
	private String sbCtgyCd = null;

	@Id
	@Column(name = "PROD_CD")
	private String pordCd = null;

	@Id
	@Column(name = "SB_GRP_NUM")
	private Integer sbGrpNum = null;
	
	@Column(name = "SB_GRP_NM")
	private String  sbGrpNm = null;
	
	@Column(name = "RCPT_NM")
	private String  rcptNm = null;
	
	@Column(name = "ST_CD")
	private String  stCd = null;
	
	@Column(name = "PYRL_DISC_PCT")
	private Double  pyrlDiscPct = 0.0;
	
	@Column(name = "INS_CNT")
	private Integer  insCnt =  0;
	
	@Column(name = "PREV_YR_INS_CNT")
	private Integer  prevYrInsCnt =  0;
	
	@Column(name = "MO_PYRL_AMT")
	private Double  moPyrlAmt =  0.0;
	
	@Column(name = "INS_SUM_AMT")
	private Double  intSumAmt =  0.0;
	
	@Column(name = "INS_AVG_SUM_AMT")
	private Double  insAvgSumAmt =  0.0;
	
	@Column(name = "ANNL_PREM_AMT")
	private Double  annlPremAmt =  0.0;
	
	@Column(name = "MO_PREM_AMT")
	private Double  moPremAmt =  0.0;
}
