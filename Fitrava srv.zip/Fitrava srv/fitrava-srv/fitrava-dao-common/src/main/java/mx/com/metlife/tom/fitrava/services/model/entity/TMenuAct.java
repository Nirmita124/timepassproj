package mx.com.metlife.tom.fitrava.services.model.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Data;

@SuppressWarnings("serial")
@Data
@Entity
@Table(name = "T_MENU_ACT")
public class TMenuAct implements java.io.Serializable{

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "MENU_ACT_ID")
	private Integer menuActId = null;

	@Column(name = "MENU_ID")
	private Integer menuId = null;

	@Column(name = "MENU_ACT_DSCR")
	private String menuActDscr = null;


}
