package mx.com.metlife.tom.fitrava.services.model.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import lombok.Data;

@SuppressWarnings("serial")
@Data
@Entity
@Table(name = "T_EXT_ISSSTE")
@IdClass(TExtIsssteId.class)
public class TExtIssste implements java.io.Serializable{


	@Id
	@Column(name = "RTNR_CD")
	private String rtnrCd = null;

	@Id
	@Column(name = "BR_NUM")
	private String ramo = null;

	@Id
	@Column(name = "INST_NM")
	private String custNm = null;

	@Id
	@Column(name = "POL_NUM")
	private String origPolNum = null;

	@Id
	@Column(name = "SB_CTGY_CD")
	private String pordCd = null;
	
	@Id
	@Column(name = "SB_GRP_CD")
	private String  sbGrpNum = null;
	
	@Id
	@Column(name = "CLASS_NM")
	private String  sbGrpNm = null;
	
}
