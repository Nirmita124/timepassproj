package mx.com.metlife.tom.fitrava.services.model.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import mx.com.metlife.tom.fitrava.services.model.entity.TOper;

@Repository
public interface TOperRepository extends JpaRepository<TOper, Integer>{


}
