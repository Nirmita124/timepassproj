package mx.com.metlife.tom.fitrava.services.model.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import mx.com.metlife.tom.fitrava.services.model.entity.TFlowExtFile;

@Repository
public interface TFlowExtFileRepository extends JpaRepository<TFlowExtFile, Integer>{

	List<TFlowExtFile> findByFlowId(Long flowId);

	@Modifying
	void deleteByFlowId(@Param("flujoId") Long flujoId);


}
