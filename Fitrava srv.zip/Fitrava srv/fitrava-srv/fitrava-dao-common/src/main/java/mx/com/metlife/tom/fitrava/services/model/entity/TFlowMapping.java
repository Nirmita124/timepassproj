package mx.com.metlife.tom.fitrava.services.model.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import lombok.Data;
import lombok.ToString;

@ToString(exclude = {"listTFlowMappingDtl"})
@Data
@Entity
@Table(name = "T_FLOW_MAP")
public class TFlowMapping implements java.io.Serializable {

	private static final long serialVersionUID = 9035340346358252666L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="FLOW_MAP_ID")
	private Long flowMappingId = null;
	
	@Column(name="FLOW_ID")
	private Long flowId = null;

	@Column(name="ENTRNC_LAYOUT_ID")
	private Long entrncLayoutId = null;

	@OneToMany(cascade=CascadeType.ALL, fetch=FetchType.EAGER)
	@JoinColumns({
		@JoinColumn(name = "FLOW_MAP_ID", referencedColumnName = "FLOW_MAP_ID", insertable = false, updatable = false ),
		@JoinColumn(name = "FLOW_ID", referencedColumnName = "FLOW_ID", insertable = false, updatable = false )})
	private List<TFlowMappingDtl> listTFlowMappingDtl = null;

}
