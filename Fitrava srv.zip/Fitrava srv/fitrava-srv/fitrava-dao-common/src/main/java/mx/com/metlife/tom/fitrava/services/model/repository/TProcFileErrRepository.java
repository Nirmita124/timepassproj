package mx.com.metlife.tom.fitrava.services.model.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import mx.com.metlife.tom.fitrava.services.model.entity.TProcFileErr;
import mx.com.metlife.tom.fitrava.services.model.entity.TProcFileId;

@Repository
public interface TProcFileErrRepository extends JpaRepository<TProcFileErr, TProcFileId>{


	List<TProcFileErr> findByDstnctCtrlNum(@Param("dcn") String dstnctCtrlNum);

}
