package mx.com.metlife.tom.fitrava.services.model.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Data;

@SuppressWarnings("serial")
@Data
@Entity(name = "TDatatyp")
@Table(name = "T_DATATYP")
public class TDatatyp implements java.io.Serializable{
	
	public enum TIPO_DATO {
		ENTERO 			(1, "Entero"),
		FECHA			(2, "Fecha"),
		STRING			(3, "String"),
		DECIMAL			(4, "Decimal"),
		BOOLEAN			(5, "Boolean"),
		NUMERICO 		(6, "NUMERICO"),
		ALFANUMERICO	(7, "ALFANUMERICO"),
		ALFABETICO		(8, "ALFABETICO");
		
		private Integer id;
		private String descripcion;
		
		private  TIPO_DATO(Integer id, String descripcion) {
			this.id  = id;
			this.descripcion = descripcion;
		}

		public Integer getId() {
			return id;
		}

		public String getDescripcion() {
			return descripcion;
		}

	}

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "DATATYP_ID")
	private Integer datatypId = null;

	@Column(name = "DATATYP_NM")
	private String datatypNm = null;

	@Column(name = "DATATYP_DSCR")
	private String datatypDscr = null;


}
