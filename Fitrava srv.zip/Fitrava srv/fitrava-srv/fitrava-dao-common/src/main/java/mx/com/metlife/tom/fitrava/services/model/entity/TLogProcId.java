package mx.com.metlife.tom.fitrava.services.model.entity;

import java.io.Serializable;
import java.util.Date;

import lombok.Data;

@Data
public class TLogProcId implements Serializable {

	private static final long serialVersionUID = -5807509379995026158L;

	private String dstnctCtrlNum = null;
	private Integer clctSttsId = null;
	private Date logProcStrtTs = null;
	private Date logProcEndTs = null;
	
	public TLogProcId() {}

	public TLogProcId(String dstnctCtrlNum, Integer clctSttsId, Date logProcStrtTs, Date logProcEndTs) {
		super();
		this.dstnctCtrlNum = dstnctCtrlNum;
		this.clctSttsId = clctSttsId;
		this.logProcStrtTs = logProcStrtTs;
		this.logProcEndTs = logProcEndTs;
	}
	
}
