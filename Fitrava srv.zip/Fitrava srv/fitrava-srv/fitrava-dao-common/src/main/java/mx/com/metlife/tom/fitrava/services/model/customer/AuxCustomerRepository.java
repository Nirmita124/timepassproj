package mx.com.metlife.tom.fitrava.services.model.customer;

import java.util.List;

import mx.com.metlife.tom.fitrava.services.dto.InputDto;
import mx.com.metlife.tom.fitrava.services.error.FitravaPersistenceException;
import mx.com.metlife.tom.fitrava.services.model.entity.TExtCncpt74;
import mx.com.metlife.tom.fitrava.services.model.entity.TExtFone;
import mx.com.metlife.tom.fitrava.services.model.entity.TExtIssste;
import mx.com.metlife.tom.fitrava.services.model.entity.TExtRicsi;
import mx.com.metlife.tom.fitrava.services.model.entity.TProcRec;

public interface AuxCustomerRepository {

	InputDto createByDcnAndFileName(String dcn, String fileName) throws FitravaPersistenceException;

	Boolean mergeTProcFileStatus(Integer estatus, String nombreArchivo) throws FitravaPersistenceException;

	Boolean mergeTProcRecSumStatus(Integer estatus, String nombreArchivo) throws FitravaPersistenceException;

	Boolean mergeTProcStatus(Integer estatus, String nombreArchivo) throws FitravaPersistenceException;

	Boolean mergeTProcFileLayout(String dcn, String fileName, Long layoutEntradaId) throws FitravaPersistenceException;
	
	
	Boolean hasMoreFiles(String dcn) throws FitravaPersistenceException;

	Integer getConsecutivoTProcRecSum(String dcn, String archivo) throws FitravaPersistenceException;
	
	void deleteAllCatalogoByTipo(Integer tipoCatalgo) throws FitravaPersistenceException;
	
	void deleteSpringBatchHistory() throws FitravaPersistenceException;
	
	Boolean saveCatalogoRicsi(TExtRicsi catalogo) throws FitravaPersistenceException;
	
	Boolean saveCatalogoFone(TExtFone catalogo) throws FitravaPersistenceException;
	
	Boolean saveCatalogoIssste(TExtIssste catalogo) throws FitravaPersistenceException;
	
	Boolean saveCatalogoConcepto74(TExtCncpt74 catalogo) throws FitravaPersistenceException;
	
	TExtFone findFoneBy(String foneId, String operacionName) throws FitravaPersistenceException;
	
	List<String> saveAllRicsi(List<TExtRicsi> catalogos) throws FitravaPersistenceException;
	
	List<String> saveAllFone(List<TExtFone> catalogos) throws FitravaPersistenceException;
	
	List<String> saveAllIssste(List<TExtIssste> catalogos) throws FitravaPersistenceException;

	List<String> saveAllConcepto74(List<TExtCncpt74> catalogos) throws FitravaPersistenceException;


	void saveAllRicsiBatch(List<TExtRicsi> catalogos) throws FitravaPersistenceException;
	
	void saveAllFoneBatch(List<TExtFone> catalogos) throws FitravaPersistenceException;
	
	void saveAllIsssteBatch(List<TExtIssste> catalogos) throws FitravaPersistenceException;

	void saveAllConcepto74Batch(List<TExtCncpt74> catalogos) throws FitravaPersistenceException;


	void saveAllTProcRecBatch(List<TProcRec> lista) throws FitravaPersistenceException;
	
	List<String> findFileNamesByDcn(String dcn) throws FitravaPersistenceException;


}
