package mx.com.metlife.tom.fitrava.services.model.entity;

import java.io.Serializable;

import lombok.Data;

@Data
public class TProcRecSumId implements Serializable {

	private static final long serialVersionUID = 9079413760676214276L;

	private String dstnctCtrlNum = null;
	private String fileNm = null;

	public TProcRecSumId() {}

	public TProcRecSumId(String dstnctCtrlNum, String fileNm) {
		super();
		this.dstnctCtrlNum = dstnctCtrlNum;
		this.fileNm = fileNm;
	}

}
