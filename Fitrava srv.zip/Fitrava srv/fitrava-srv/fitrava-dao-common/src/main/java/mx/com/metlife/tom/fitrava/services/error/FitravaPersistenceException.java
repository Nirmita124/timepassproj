package mx.com.metlife.tom.fitrava.services.error;

public class FitravaPersistenceException extends Exception {

	private static final long serialVersionUID = 1L;

	public FitravaPersistenceException() {
		super();
	}

	public FitravaPersistenceException(String message) {
		super(message);
	}

	public FitravaPersistenceException(String message, Throwable cause) {
		super(message, cause);
	}

}
