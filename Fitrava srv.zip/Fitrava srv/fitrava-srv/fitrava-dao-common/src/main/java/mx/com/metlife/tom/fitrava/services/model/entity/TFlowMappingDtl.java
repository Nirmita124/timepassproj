package mx.com.metlife.tom.fitrava.services.model.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "T_FLOW_MAP_DTL")
@IdClass(TFlowMappingDtlId.class)
public class TFlowMappingDtl implements java.io.Serializable {


	private static final long serialVersionUID = 6981642977332620432L;

	@Id
	@Column(name="FLOW_MAP_ID")
	private Long flowMappingId = null;
	
	@Id
	@Column(name="FLOW_ID")
	private Long flowId = null;

	@Id
	@Column(name="OUT_LAYOUT_FLD_ID")
	private Long outLayoutFldId = null;

	@Column(name="ENTRNC_LAYOUT_FLD_ID")
	private Long entrncLayoutFldId = null;
	
	
}
