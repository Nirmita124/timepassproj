package mx.com.metlife.tom.fitrava.services.utility.excel;

import java.io.File;
import java.util.List;

import org.apache.poi.ss.usermodel.CellType;

import mx.com.metlife.tom.fitrava.services.error.FitravaException;
import mx.com.metlife.tom.fitrava.services.model.entity.TDatatyp;
import mx.com.metlife.tom.fitrava.services.utility.Constantes;

public class ValidatorExcel {

	private ValidatorExcel() {}

	public static Integer getNumeroColumnas (File excelFile, String ext, Integer renglonesAOmitir, String...hojasOmitir) throws FitravaException {
		if (excelFile == null || ext == null || renglonesAOmitir == null) {
			return null;
		}
		ExcelUtility excelUtility = null;
		try {
			if (ext.trim().equalsIgnoreCase(Constantes.XLSX)) {
				excelUtility = new ExcelXlsxBigFilesUtility(excelFile, renglonesAOmitir, hojasOmitir);
				return excelUtility.getNumColumnas();
			} else {
				try {
					excelUtility = new ExcelXlsUtility(excelFile, renglonesAOmitir, hojasOmitir);
					return excelUtility .getNumColumnas();
				} catch (Exception e) {
					excelUtility  = new ExcelXmlUtility(excelFile, renglonesAOmitir, null);
					return excelUtility .getNumColumnas();
				}
			}
		} catch (Exception e) {
			return null;
		} finally {
			if (excelUtility != null) {
				excelUtility.close();
			}
		}
	}
	
	
	public static Boolean validaTipos(List<TDatatyp> tipos, File excelFile, Integer renglonesAOmitir, String...hojasOmitir) throws FitravaException {
		ExcelUtility excelUtility = null;
		try {
			if (excelFile.getName().toLowerCase().endsWith(Constantes.XLSX)) {
				excelUtility = new ExcelXlsxBigFilesUtility(excelFile, renglonesAOmitir, hojasOmitir);
				return validaColumnas(excelUtility.getColumnTypes(), tipos);
			} else {
				try {
					excelUtility = new ExcelXlsUtility(excelFile, renglonesAOmitir, hojasOmitir);
					return validaColumnas(excelUtility.getColumnTypes(), tipos);
				} catch (Exception e) {
					excelUtility  = new ExcelXmlUtility(excelFile, renglonesAOmitir, null);
					return validaColumnas(excelUtility.getColumnTypes(), tipos);
				}
			}
		} finally {
			if (excelUtility != null) {
				excelUtility.close();
			}
		}
	}
	
	private static Boolean validaColumnas(List<CellType> celltypes, List<TDatatyp> tipos) {
		CellType celltype = null;
		TDatatyp tipo = null;
		for (int i = 0; i < celltypes.size(); i++) {
			celltype = celltypes.get(i);
			tipo = tipos.get(i);
			if (!equals(celltype, tipo)) {
				return false;
			}
		}
		return true;
	}
	
	//TODO
	private static Boolean equals(CellType celltype, TDatatyp tipo) {
		return true;
	}
}
