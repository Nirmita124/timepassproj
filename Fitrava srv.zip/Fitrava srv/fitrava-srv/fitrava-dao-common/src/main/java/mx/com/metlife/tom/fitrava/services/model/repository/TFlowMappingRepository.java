package mx.com.metlife.tom.fitrava.services.model.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import mx.com.metlife.tom.fitrava.services.model.entity.TFlowMapping;

@Repository
public interface TFlowMappingRepository extends JpaRepository<TFlowMapping, Long>{


	List<TFlowMapping> findByFlowIdAndLayoutEntradaId(@Param("flujoId") Long flujoId, @Param("layoutEntradaId") Long layoutEntradaId);
	
}
