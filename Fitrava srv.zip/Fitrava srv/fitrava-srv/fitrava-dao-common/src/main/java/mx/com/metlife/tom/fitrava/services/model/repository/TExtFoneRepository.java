package mx.com.metlife.tom.fitrava.services.model.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import mx.com.metlife.tom.fitrava.services.model.entity.TExtFone;
import mx.com.metlife.tom.fitrava.services.model.entity.TExtFoneId;

@Repository
public interface TExtFoneRepository extends JpaRepository<TExtFone, TExtFoneId>{


}
