package mx.com.metlife.tom.fitrava.services.model.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "T_CNCPT_74")
@IdClass(TExtCncpt74Id.class)
public class TExtCncpt74 implements java.io.Serializable{

	private static final long serialVersionUID = -1478587738298868946L;
	
	@Id
	@Column(name="PEN_NUM")
	private String penNum = null;
	
	@Id
	@Column(name="NATL_ID")
	private String natlId = null;
	
	@Id
	@Column(name="FULL_NM")
	private String fullNm = null;
	
	@Id
	@Column(name="POL_NUM")
	private String polNum = null;
	
}
