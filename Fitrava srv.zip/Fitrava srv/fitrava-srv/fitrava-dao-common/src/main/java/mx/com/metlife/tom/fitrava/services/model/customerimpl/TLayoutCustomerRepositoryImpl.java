package mx.com.metlife.tom.fitrava.services.model.customerimpl;

import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import mx.com.metlife.tom.fitrava.services.error.FitravaPersistenceException;
import mx.com.metlife.tom.fitrava.services.model.customer.TLayoutCustomerRepository;
import mx.com.metlife.tom.fitrava.services.model.entity.TLayout;

@Repository
public class TLayoutCustomerRepositoryImpl implements TLayoutCustomerRepository {
	
	private static Logger log = LoggerFactory.getLogger(TLayoutCustomerRepositoryImpl.class);

	private static final String QUERY_CONSULTA_ALL_LAYOUTS_BY_EAID = "TLayoutCustomerRepository.findAllByEaid";
	private static final String QUERY_ACTUALIZA_LAYOUT_ESTATUS = "TLayoutCustomerRepository.mergeEstatus";
	
	@Autowired
	private EntityManager entityManager;
	
	@SuppressWarnings("unchecked")
	@Override
	public List<TLayout> findAllByEaid(String eaid) throws FitravaPersistenceException {
		Query query = null;
		try {
			query = entityManager.createNamedQuery(QUERY_CONSULTA_ALL_LAYOUTS_BY_EAID);
			query.setParameter("eaid", eaid);
			return (List<TLayout>) query.getResultList();
		} catch(Exception e) {
			log.error(String.format("Error en el findAllByEaid(eaid: %1$s)", eaid), e);
			throw new FitravaPersistenceException(String.format("Error en el findAllByEaid(eaid: %1$s), excepcion: %2$s", eaid, e));
		}	
	}
	
	public Boolean mergeActiva(Long layoutId, Boolean activo) throws FitravaPersistenceException {
		Query query = null;
		int actualiza = 0;
		try {
			query = entityManager.createNamedQuery(QUERY_ACTUALIZA_LAYOUT_ESTATUS);
			query.setParameter("layoutId", layoutId);
			query.setParameter("activo", activo);
			actualiza = query.executeUpdate();
			return actualiza > 0;
		} catch(Exception e) {
			log.error(String.format("Error en el mergeActiva(layoutId: %1$s, activo: %2$s)", layoutId, activo), e);
			throw new FitravaPersistenceException(String.format("Error en el mergeActiva(layoutId: %1$s, activo: %2$s), excepcion: %3$s", layoutId, activo, e));
		}	
	}


	@Override
	public Date getDate() throws FitravaPersistenceException {
		Query query = null;
		try {
			query = entityManager.createNamedQuery("getDate");
			return (Date) query.getSingleResult();
		} catch(Exception e) {
			log.error("Error en el getDate()", e);
			throw new FitravaPersistenceException("Error en el getDate(), excepcion: %1$s", e);
		}	
	}
	
}
