package mx.com.metlife.tom.fitrava.services.model.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import mx.com.metlife.tom.fitrava.services.model.entity.TFlowEntrncLayout;
import mx.com.metlife.tom.fitrava.services.model.entity.TFlowEntrncLayoutId;
import mx.com.metlife.tom.fitrava.services.model.entity.TLayout;

@Repository
public interface TFlowEntrncLayoutRepository extends JpaRepository<TFlowEntrncLayout, TFlowEntrncLayoutId>{

	@Modifying
	void deleteByFlowId(@Param("flujoId") Long flujoId);

	@Modifying
	void deleteByLayoutId(@Param("layoutId") Long layoutId);

	@Modifying
	void deleteById(@Param("flujoId") Long flujoId, @Param("layoutId") Long layoutId);

	List<TLayout> findAllLayoutsByFlowId(@Param("flujoId") Long flujoId);
	
	Long countBy(@Param("flujoId") Long flujoId, @Param("layoutId") Long layoutId);
}
