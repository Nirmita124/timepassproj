package mx.com.metlife.tom.fitrava.services.config;


import javax.naming.NamingException;
import javax.sql.DataSource;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.dao.annotation.PersistenceExceptionTranslationPostProcessor;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jndi.JndiTemplate;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;


@Configuration
@EnableTransactionManagement
@ComponentScan(JPAConfig.JPA_PACKAGE_COMPONENT_SCAN)
@EnableJpaRepositories(JPAConfig.JPA_PACKAGE_COMPONENT_SCAN)
@PropertySource(value = {JPAConfig.APPLICATION_PROPERTIES})
public class JPAConfig {
	
	//JPA CONFIG
	public static final String JPA_PACKAGE_COMPONENT_SCAN							= "mx.com.metlife.tom.fitrava.services.model";
	public static final String APPLICATION_PROPERTIES								= "classpath:application.properties";
	public static final String DATA_SOURCE											= "dataSource";
	public static final String ENTITY_MANAGER_FACTORY								= "entityManagerFactory";
	public static final String JNDI_NAME											= "jndi/fitravasrv";
	public static final String ORM_FILE												= "orm.xml";

	@Bean(name = DATA_SOURCE)
	public DataSource dataSource() throws NamingException {
		return (DataSource) new JndiTemplate().lookup(JNDI_NAME);
	}
	
	@Bean(name = ENTITY_MANAGER_FACTORY)
	public LocalContainerEntityManagerFactoryBean entityManagerFactoryBean() throws NamingException {
		LocalContainerEntityManagerFactoryBean factoryBean = new LocalContainerEntityManagerFactoryBean();
		factoryBean.setDataSource(dataSource());
		factoryBean.setPackagesToScan(JPA_PACKAGE_COMPONENT_SCAN);
		HibernateJpaVendorAdapter vendorAdapter = new HibernateJpaVendorAdapter();
		vendorAdapter.setShowSql(true);
		factoryBean.setJpaVendorAdapter(vendorAdapter);
		factoryBean.setMappingResources(ORM_FILE);
		factoryBean.afterPropertiesSet();
		return factoryBean;
	}
	
	@Bean
	public PlatformTransactionManager transactionManager() throws NamingException {
		JpaTransactionManager transactionManager = new JpaTransactionManager();
		transactionManager.setEntityManagerFactory(entityManagerFactoryBean().getObject());
		return transactionManager;
	}
	
	@Bean
	public PersistenceExceptionTranslationPostProcessor exceptionTranslation() {
		return new PersistenceExceptionTranslationPostProcessor();
	}
	
}
