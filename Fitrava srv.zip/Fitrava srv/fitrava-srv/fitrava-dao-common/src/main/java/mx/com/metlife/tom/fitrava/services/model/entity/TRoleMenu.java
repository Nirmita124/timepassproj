package mx.com.metlife.tom.fitrava.services.model.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@SuppressWarnings("serial")
@Data
@Entity(name = "TRoleMenu")
@Table(name = "T_ROLE_MENU")
public class TRoleMenu implements java.io.Serializable{

	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "ROLE_MENU_ID")
	private Long roleMenuId = null;
	
	@Column(name = "ROLE_ID")
	private Integer roleId = null;
	
	@Column(name = "MENU_ID")
	private Integer menuId = null;
}
