package mx.com.metlife.tom.fitrava.services.model.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import mx.com.metlife.tom.fitrava.services.model.entity.TLayout;

@Repository
public interface TLayoutRepository extends JpaRepository<TLayout, Long>{ 

	List<TLayout> findByEaiCd(String eaiCd);
	
	TLayout findById(@Param("id") Long id);

	TLayout findByLayoutNm(String name);

	List<TLayout> findByEaiRetainerExt (@Param("eaiCd") String eaiCd, @Param("retainerId") String retainerId, @Param("ext") String ext);
	
	List<TLayout> findAllIntoFlowsByEai(@Param("eaiCd") String eaiCd, @Param("ext") String ext);
	
	String findDescOfOutputLayoutByFlow(@Param("dcn") String dcn);
	
	List<TLayout> findByFlowId(@Param("flowId") Long flowId);
	
	
}
