package mx.com.metlife.tom.fitrava.services.model.entity;

import lombok.Data;

@Data
public class TLayoutXcelId implements java.io.Serializable{

	private static final long serialVersionUID = 9079413760676214276L;
	
	private Long  layoutId= null;
	
	private String  xcelSheetNm= null;
	
	public TLayoutXcelId() {
	}

	public TLayoutXcelId(Long layoutId, String xcelSheetNm) {
		super();
		this.layoutId = layoutId;
		this.xcelSheetNm = xcelSheetNm;
	}
	
	
	
	
}
