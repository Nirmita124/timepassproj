package mx.com.metlife.tom.fitrava.services.model.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@SuppressWarnings("serial")
@Data
@Entity
@Table(name = "T_MENU_GRP")
public class TMenuGrp implements java.io.Serializable{

	@Id
	@Column(name = "MENU_GRP_ID")
	private Long menuGrpId = null;

	@Column(name = "MENU_GRP_NM")
	private String menuGrpNm = null;

	@Column(name = "MENU_ID")
	private Integer menuId = null;

	@Column(name = "MENU_GRP_VSBL_IND")
	private Boolean menuGrpVsblInd = null;


}
