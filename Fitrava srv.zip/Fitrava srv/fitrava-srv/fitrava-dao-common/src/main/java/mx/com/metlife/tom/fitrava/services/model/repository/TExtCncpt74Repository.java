package mx.com.metlife.tom.fitrava.services.model.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import mx.com.metlife.tom.fitrava.services.model.entity.TExtCncpt74;
import mx.com.metlife.tom.fitrava.services.model.entity.TExtCncpt74Id;

@Repository
public interface TExtCncpt74Repository extends JpaRepository<TExtCncpt74, TExtCncpt74Id>{

	List<TExtCncpt74> findByNumeroPension(@Param("numPension") String numPension);
}
