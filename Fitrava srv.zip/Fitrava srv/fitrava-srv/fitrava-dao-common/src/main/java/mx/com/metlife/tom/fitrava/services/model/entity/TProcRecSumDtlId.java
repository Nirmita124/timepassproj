package mx.com.metlife.tom.fitrava.services.model.entity;

import java.io.Serializable;

import lombok.Data;

@Data
public class TProcRecSumDtlId implements Serializable {

	private static final long serialVersionUID = 2627355350876313321L;

	private String dstnctCtrlNum = null;
	private String fileNm = null;
	private Long layoutFldId = null;

	public TProcRecSumDtlId() {}

	public TProcRecSumDtlId(String dstnctCtrlNum, String fileNm, Long layoutFldId) {
		super();
		this.dstnctCtrlNum = dstnctCtrlNum;
		this.fileNm = fileNm;
		this.layoutFldId = layoutFldId;
	}
	
	
	
}
