package mx.com.metlife.tom.fitrava.services.model.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@SuppressWarnings("serial")
@Data
@Entity(name= "TLayoutFldAtrb")
@Table(name = "T_LAYOUT_FLD_ATRB")
public class TLayoutFldAtrb implements java.io.Serializable{

	@Id
	@Column(name = "LAYOUT_FLD_ATRB_ID")
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long layoutFldAtrbId = null;

	@Column(name = "LAYOUT_FLD_ID")
	private Long layoutFldId = null;

	@Column(name = "LAYOUT_FLD_ORD_NUM")
	private Integer layoutFldOrdNum = null;

	@Column(name = "MIN_LNTH_NUM")
	private Integer minLnthNum = null;

	@Column(name = "MAX_LNTH_NUM")
	private Integer maxLnthNum = null;

	@Column(name = "FIX_LNTH_NUM")
	private Integer fixLnthNum = null;

	@Column(name = "LEFT_TRIM_IND")
	private Boolean leftTrimInd = null;

	@Column(name = "RGHT_TRIM_IND")
	private Boolean rghtTrimInd = null;

	@Column(name = "LEFT_FILL_CHAR_VAL")
	private String leftFillCharVal = null;

	@Column(name = "RGHT_FILL_CHAR_VAL")
	private String rghtFillCharVal = null;

	@Column(name = "LEFT_ALGN_IND")
	private Boolean leftAlgnInd = null;

	@Column(name = "RGHT_ALGN_IND")
	private Boolean rghtAlgnInd = null;
	
	@Column(name = "REG_XPRSN_TXT")
	private String regXprsnTxt = null;


}
