package mx.com.metlife.tom.fitrava.services.model.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "T_LAYOUT_HD_DTL")
public class TLayoutHdDtl implements java.io.Serializable {

	private static final long serialVersionUID = -2257287385176245453L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "LAYOUT_HD_DTL_ID")
	private Long layoutHdDtlId = null;

	@Column(name = "LAYOUT_HD_ID")
	private Long layoutHdId = null;

	@Column(name = "FLD_ORD_NUM")
	private Integer fldOrdNum = null;

	@Column(name = "LBL_DSCR")
	private String lblDscr = null;

	@Column(name = "HD_LNTH_NUM")
	private Integer hdLnthNum = null;


}
