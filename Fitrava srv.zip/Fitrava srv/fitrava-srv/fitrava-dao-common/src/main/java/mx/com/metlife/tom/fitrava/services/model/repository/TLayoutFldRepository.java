package mx.com.metlife.tom.fitrava.services.model.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import mx.com.metlife.tom.fitrava.services.model.entity.TLayoutFld;

@Repository
public interface TLayoutFldRepository extends JpaRepository<TLayoutFld, Long>{

	List<TLayoutFld> findByLayoutId(Long layoutId);

	List<TLayoutFld> findAllWithoutSpecialOperations(@Param("layoutId")Long layoutId, @Param("lstExcludeOperations")List<Long> lstExcludeOperations);
	
}
