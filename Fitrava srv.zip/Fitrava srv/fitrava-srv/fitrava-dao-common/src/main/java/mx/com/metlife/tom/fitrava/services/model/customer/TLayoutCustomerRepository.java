package mx.com.metlife.tom.fitrava.services.model.customer;

import java.util.Date;
import java.util.List;

import mx.com.metlife.tom.fitrava.services.error.FitravaPersistenceException;
import mx.com.metlife.tom.fitrava.services.model.entity.TLayout;

public interface TLayoutCustomerRepository {
	
	List<TLayout> findAllByEaid(String eaid) throws FitravaPersistenceException;

	Boolean mergeActiva(Long layoutId, Boolean activa) throws FitravaPersistenceException;
	
	Date getDate() throws FitravaPersistenceException;
}
