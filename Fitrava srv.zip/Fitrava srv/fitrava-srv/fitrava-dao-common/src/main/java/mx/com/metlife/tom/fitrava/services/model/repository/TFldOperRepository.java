package mx.com.metlife.tom.fitrava.services.model.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import mx.com.metlife.tom.fitrava.services.model.entity.TFldOper;

@Repository
public interface TFldOperRepository extends JpaRepository<TFldOper, Long>{


}
