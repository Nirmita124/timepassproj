package mx.com.metlife.tom.fitrava.endorsement.services.model.entity;

import java.io.Serializable;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.Size;

import lombok.Data;

@Cacheable(false)
@Entity
@Table(name = "T_ENDRS_BENE")
@Data
public class TEndrsBene implements Serializable {
    private static final long serialVersionUID = 1L;
    
    @EmbeddedId
    protected TEndrsBenePK tEndrsBenePK;
    
    @Size(max = 100)
    @Column(name = "BENE_NM")
    private String beneficiaryName;
    
    @Size(max = 50)
    @Column(name = "BENE_REL_NM")
    private String realtionship;
    
    @Column(name = "BENE_PCT")
    private Short percentage;
    
    @JoinColumn(name = "ENDRS_ID", referencedColumnName = "ENDRS_ID", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private TEndrs endorsement;

}
