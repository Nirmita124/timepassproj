package mx.com.metlife.tom.fitrava.endorsement.services.service.dto;

import lombok.Data;
import static mx.com.metlife.tom.fitrava.endorsement.services.utility.ConstantUtility.EMPTY_STRING;

@Data
public class TProcRecDTO {

	String dcn;
	
	Long recordNumber;
	
	Long layoutID;
	
	String originalValue;
	
	String newValue;
	
	boolean errorIndicator;
	
	String msgText = EMPTY_STRING;
	
	String fileNm = EMPTY_STRING;
}
