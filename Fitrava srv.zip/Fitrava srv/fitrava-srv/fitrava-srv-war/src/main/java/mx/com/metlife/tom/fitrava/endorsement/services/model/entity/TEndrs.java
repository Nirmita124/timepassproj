package mx.com.metlife.tom.fitrava.endorsement.services.model.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;

import lombok.Data;

@Cacheable(false)
@Entity
@Table(name = "T_ENDRS")
@Data
public class TEndrs implements Serializable {
    private static final long serialVersionUID = 1L;
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ENDRS_ID")
	private Long idEndorsement;
    
    @Column(name = "AGNT_ID")
    private String keyAgent;
    
    @Column(name = "SB_BR_NM")
    private String subbranch;
    
    @Column(name = "POL_NUM")
    private String policyNumber;
    
    @Column(name = "SB_GRP_NUM")
    private Integer subgroupNumber;
    
    @Column(name = "SB_GRP_NM")
    private String subgroupName;
    
    @Column(name = "CTGY_NUM")
    private Long categoryNumber;
    
    @Column(name = "INS_NUM")
    private String insuredNumber;
    
    @Column(name = "INS_FRST_NM")
    private String insuredName;
    
    @Column(name = "INS_LST_NM")
    private String lastName;
    
    @Column(name = "INS_MID_NM")
    private String middleName;
    
    @Column(name = "INS_BRTH_DT")
    @Temporal(TemporalType.TIMESTAMP)
    private Date birthDate;
    
    @Column(name = "INS_SEX_CD")
    private String gender;
    
    @Column(name = "INS_REL_CD")
    private Short relationShip;
    
    @Column(name = "INS_SAL_AMT")
    private BigDecimal salary;
    
    @Column(name = "POL_STRT_DT")
    @Temporal(TemporalType.TIMESTAMP)
    private Date startDate;
    
    @Column(name = "POL_END_DT")
    @Temporal(TemporalType.TIMESTAMP)
    private Date endDate;
    
    @Column(name = "EMPE_INCM_DT")
    @Temporal(TemporalType.TIMESTAMP)
    private Date incomeDateEmployee;
    
    @Column(name = "AGE_FR_DT")
    @Temporal(TemporalType.TIMESTAMP)
    private Date antiqueDate;
    
    @Column(name = "INS_FR_DT")
    @Temporal(TemporalType.TIMESTAMP)
    private Date sinceInsuranceDate;
    
    @Column(name = "INS_AGE_IN_YR")
    private String years;
    
    @Column(name = "INS_PER_ID")
    private String insPerId;
    
    @Column(name = "INS_NATL_ID")
    private String insNatlId;
    
    @Column(name = "INS_JOB_LVL_NM")
    private String insJobLvlNm;
    
    @Column(name = "INS_WRK_CNTR_NM")
    private String centerWork;
    
    @Column(name = "EMPR_NUM")
    private String employeeNumber;
    
    @Column(name = "RTNR_ID")
    private String retainerKey;
    
    @Column(name = "PY_UNIT_CD")
    private String pyUnitCd;
    
    @Column(name = "IND_COL_DUC")
    private Short indColDuc;
    
    @Column(name = "IND_PY_FORM")
    private String indPyForm;
    
    @Column(name = "IND_BNK_KEY")
    private String indBnkKey;
    
    @Column(name = "BRDR_AREA_ZIP_CD")
    private String brdrAreaZipCd;
    
    @Column(name = "INS_ADR_ST_NM")
    private String street;
    
    @Column(name = "INS_ADR_EXTR_NUM")
    private String extNum;
    
    @Column(name = "INS_ADR_INT_NUM")
    private String intNum;

    @Column(name = "INS_ADR_SBURB_NM")
    private String suburb;

    @Column(name = "INS_ADR_TWP_NM")
    private String town;
    
    @Column(name = "INS_PST_CD")
    private String postalCode;

    @Column(name = "INS_EMAIL_ADR_TXT")
    private String email;

    @Column(name = "INS_TEL_NUM")
    private String phone;
    
    @Column(name = "PLAZA_TYP_CD")
    private Short plazaType;

    @Column(name = "INS_TREAT_NM")
    private String teratment;

    @Column(name = "INS_JOB_NM")
    private String job;

    @Column(name = "INS_CNCPT_DSCR")
    private String describedConcept;

    @Column(name = "POL_ASCRPTN_ID")
    private String ascription;

    @Column(name = "GCAYE_ENDRS_PG_NM")
    private String endorsementGcayeFolio;
   
    @Column(name = "GCAYE_RSPN_DT")
    @Temporal(TemporalType.TIMESTAMP)
    private Date responseDateGcaye;
   
    @Column(name = "GCAYE_ACT_IND")
    private Character activeGcaye;
   
    @Column(name = "TOT_GCAYE_FILE_CNT")
    private Short totalFilesGcaye;
    
    @Column(name = "TOT_PDF_FILE_CNT")
    private Short totalFilesPdf;
    
    @Column(name = "TOT_XCEL_FILE_CNT")
    private Short totalFilesXls;
    
    @Column(name = "DLOAD_ACT_IND")
    private Character downloadActive;
    
    @Column(name = "CRT_TS")
    @Temporal(TemporalType.TIMESTAMP)
    private Date creationDate;
    
    @Basic(optional = false)
    @NotNull
    @Column(name = "PRN_RQR_IND")
    private Character prnRqrInd;
    
    @Column(name = "PHYS_DLV_RQR_IND")
    private Character delivery;
    
    @Column(name = "MOVE_KEY")
    private String moveKey;
    
    @JoinColumn(name = "MOVE_TYP_CD", referencedColumnName = "MOVE_TYP_CD")
    @ManyToOne(optional = false)
    private TMoveTyp moveType;
    
    @JoinColumn(name = "WRK_ORD_ID", referencedColumnName = "WRK_ORD_ID")
    @ManyToOne(optional = false)
    private TWrkOrd workOrder;

}