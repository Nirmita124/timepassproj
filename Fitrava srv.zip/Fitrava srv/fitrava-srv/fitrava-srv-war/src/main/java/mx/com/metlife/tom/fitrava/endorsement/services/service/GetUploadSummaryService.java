package mx.com.metlife.tom.fitrava.endorsement.services.service;

import mx.com.metlife.tom.fitrava.endorsement.services.error.FitravaException;
import mx.com.metlife.tom.fitrava.endorsement.services.service.dto.UploadRejectResponse;
import mx.com.metlife.tom.fitrava.endorsement.services.service.dto.UploadSummaryResponseDTO;

public interface GetUploadSummaryService {
	
	UploadRejectResponse getUploadRejec(String dcn);
	
	UploadSummaryResponseDTO getUploadSummaryMovement(String dcn)  throws FitravaException;
	

}
