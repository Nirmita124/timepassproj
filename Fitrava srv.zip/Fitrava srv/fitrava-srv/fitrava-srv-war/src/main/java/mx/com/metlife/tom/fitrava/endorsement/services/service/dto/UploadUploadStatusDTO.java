package mx.com.metlife.tom.fitrava.endorsement.services.service.dto;

import java.util.List;

import lombok.Data;

@Data
public class UploadUploadStatusDTO {
	
	private Integer registrys = 0;
	private Integer success = 0;
	private Integer failure = 0;
	private List<UploadSummaryDTO> details;
	
}
