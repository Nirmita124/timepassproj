package mx.com.metlife.tom.fitrava.endorsement.services.service;

import static org.slf4j.LoggerFactory.getLogger;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Service;

import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;

import mx.com.metlife.tom.fitrava.endorsement.services.error.FitravaException;
import mx.com.metlife.tom.fitrava.endorsement.services.utility.ConstantUtility;
import mx.com.metlife.tom.fitrava.endorsement.services.utility.EncriptionUtils;

@Service
@PropertySource("classpath:${ftv_env:dev}-endpoint.properties")
public class SendFileTransferSFTP {

	private static final Logger logger = getLogger(SendFileTransferSFTP.class);

	@Value("${sftp.host.name}")
	private String remoteHost;

	private String username;
	private String password;
	
	@Value("${sftp.userpassword}")
	private String userPassword;

	@Value("${sftp.host.port}")
	private int port;

	@Value("${sftp.folder.name}")
	private String remoteDirectoryName;

	@Value("${update.workflow.bpm}")
	private String bpmEndpointUrl;

	public static boolean setupJsch() {
		return true;
	}

	@SuppressWarnings("static-access")
	public String transferFile(StringBuilder builder, String fileName)
			throws JSchException, SftpException, IOException {
		JSch jsch = null;
		String result = ConstantUtility.IN_TRANSFER;
		try (ByteArrayInputStream bais = new ByteArrayInputStream(builder.toString().getBytes())) {
			
			logger.info(ConstantUtility.HYPHENS, getUsername(), ConstantUtility.HYPHEN_1, remoteHost, ConstantUtility.SPACE, port, ConstantUtility.SPACE, getPassword());
			jsch = new JSch();
			java.util.Properties config = new java.util.Properties();
			config.put(ConstantUtility.STRICT_HOST_KEY_CHECKING, ConstantUtility.NO);
			jsch.setConfig(config);
			Session session = jsch.getSession(getUsername(), remoteHost, port);
			session.setPassword(getPassword());
			logger.info(ConstantUtility.ESTABLISHING_CONNECTION);
			session.connect();
			logger.info(ConstantUtility.CONNECTION_ESTABLISHED);
			logger.info(ConstantUtility.CREATING_SFTP_CHANNEL);
			ChannelSftp sftpChannel = (ChannelSftp) session.openChannel(ConstantUtility.SFTP);
			sftpChannel.connect();
			logger.info(ConstantUtility.SFTP_CHANNEL_CREATED, ConstantUtility.HYPHEN_1, fileName);
			// Upload file
			sftpChannel.put(bais, remoteDirectoryName.concat(fileName));
			logger.info(ConstantUtility.FILE_TRANSFER_COMPLETED);

			sftpChannel.disconnect();
			session.disconnect();

		} catch (JSchException e) {
			logger.error(ConstantUtility.ERROR_IN_FILE_TRANSFER, e);
			logger.error(ConstantUtility.ERROR_IN_FILE_TRANSFER, e.getMessage());
//			logger.error(ConstantUtility.ERROR_IN_FILE_TRANSFER, e.getStackTrace());
			logger.error(ConstantUtility.ERROR_IN_FILE_TRANSFER, e.getLocalizedMessage());
			result = e.getLocalizedMessage();
			return result;
		}
		return remoteDirectoryName.concat(fileName);

	}

	@SuppressWarnings("static-access")
	public boolean transferFileLocal(StringBuilder builder, String fileName) throws JSchException, SftpException, FitravaException {
		boolean deleteFile = false;
		File file = new File("workarea/".concat(fileName));
		if (file.exists()) {
			deleteFile = file.delete();
			try {
				deleteFile = file.createNewFile();
			} catch (IOException e) {
				throw new FitravaException(e.getLocalizedMessage().concat(fileName));
			}
		}
		logger.info(ConstantUtility.BPM_ENDPOINT_URL, deleteFile);
		try (FileWriter fileWriter = new FileWriter(file);) {
			fileWriter.write(builder.toString());
		} catch (IOException e) {
			logger.error(ConstantUtility.ERROR, e.getLocalizedMessage());
		}
		
		JSch jsch = null;
		try {

			logger.info(ConstantUtility.HYPHENS, getUsername(), ConstantUtility.HYPHEN_1, remoteHost, ConstantUtility.SPACE, port, ConstantUtility.SPACE, getPassword());
			jsch = new JSch();
			java.util.Properties config = new java.util.Properties();
			config.put(ConstantUtility.STRICT_HOST_KEY_CHECKING, ConstantUtility.NO);
			jsch.setConfig(config);
			Session session = jsch.getSession(getUsername(), remoteHost, port);
			session.setPassword(getPassword());
			logger.info(ConstantUtility.ESTABLISHING_CONNECTION);
			session.connect();
			logger.info(ConstantUtility.CONNECTION_ESTABLISHED);
			logger.info(ConstantUtility.CREATING_SFTP_CHANNEL);
			ChannelSftp sftpChannel = (ChannelSftp) session.openChannel(ConstantUtility.SFTP);
			sftpChannel.connect();
			logger.info(ConstantUtility.SFTP_CHANNEL_CREATED);
			logger.info(ConstantUtility.HYPHEN_1, file.getName(), ConstantUtility.HYPHEN_1, file.getAbsolutePath(), ConstantUtility.HYPHEN_1, file.getName());
			// Upload file
			sftpChannel.put(file.getAbsolutePath(), remoteDirectoryName.concat(file.getName()));
			logger.info(ConstantUtility.FILE_TRANSFER_COMPLETED);

			sftpChannel.disconnect();
			session.disconnect();

		} catch (JSchException e) {
			logger.info(ConstantUtility.ERROR_IN_FILE_TRANSFER2);
			throw e;
		}
		return true;

	}

	@SuppressWarnings("static-access")
	public boolean transferFile_NotinUse(File file) throws JSchException, SftpException {
		JSch jsch = null;
		try {
			
			logger.info(ConstantUtility.HYPHENS, getUsername(), ConstantUtility.HYPHEN_1, remoteHost, ConstantUtility.SPACE, port, ConstantUtility.SPACE, getPassword());
			jsch = new JSch();
			java.util.Properties config = new java.util.Properties();
			config.put(ConstantUtility.STRICT_HOST_KEY_CHECKING, ConstantUtility.NO);
			jsch.setConfig(config);
			Session session = jsch.getSession(getUsername(), remoteHost, port);
			session.setPassword(getPassword());
			logger.info(ConstantUtility.ESTABLISHING_CONNECTION);
			session.connect();
			logger.info(ConstantUtility.CONNECTION_ESTABLISHED);
			logger.info(ConstantUtility.CREATING_SFTP_CHANNEL);
			ChannelSftp sftpChannel = (ChannelSftp) session.openChannel(ConstantUtility.SFTP);
			sftpChannel.connect();
			logger.info(ConstantUtility.SFTP_CHANNEL_CREATED);
			logger.info(ConstantUtility.HYPHEN_1, file.getName(), ConstantUtility.HYPHEN_1, file.getAbsolutePath(), ConstantUtility.HYPHEN_1, file.getName());
			// Upload file
			sftpChannel.put(file.getAbsolutePath(), remoteDirectoryName.concat(file.getName()));
			logger.info(ConstantUtility.FILE_TRANSFER_COMPLETED);

			sftpChannel.disconnect();
			session.disconnect();

		} catch (JSchException e) {
			logger.info(ConstantUtility.ERROR_IN_FILE_TRANSFER2);
			throw e;
		}
		return true;

	}

	public String testConection() throws JSchException, SftpException {
		JSch jsch = null;
		String fileName = ConstantUtility.TEST_FILE_TXT;
		StringBuilder builder = new StringBuilder(ConstantUtility.TEST_FILE);
		
		try {

			logger.info(remoteHost, ConstantUtility.SPACE, remoteDirectoryName, ConstantUtility.SPACE, getUsername(), ConstantUtility.SPACE, port);
			jsch = new JSch();
			java.util.Properties config = new java.util.Properties();
			config.put(ConstantUtility.STRICT_HOST_KEY_CHECKING, ConstantUtility.NO);
			JSch.setConfig(config);
			Session session = jsch.getSession(getUsername(), remoteHost, port);
			session.setPassword(getPassword());
			logger.info(ConstantUtility.ESTABLISHING_CONNECTION);
			session.connect();
			logger.info(ConstantUtility.CONNECTION_ESTABLISHED);

			logger.info(ConstantUtility.CREATING_SFTP_CHANNEL);
			ChannelSftp sftpChannel = (ChannelSftp) session.openChannel(ConstantUtility.SFTP);
			sftpChannel.connect();
			logger.info(ConstantUtility.SFTP_CHANNEL_CREATED);
			sftpChannel.put(new ByteArrayInputStream(builder.toString().getBytes()),
					remoteDirectoryName.concat(fileName));
			logger.info(ConstantUtility.FILE_TRANSFER_COMPLETED);

			sftpChannel.disconnect();
			session.disconnect();
		} catch (JSchException e) {
			logger.info(ConstantUtility.ERROR_IN_FILE_TRANSFER2);
			throw e;
		}
		return ConstantUtility.SUCCESS;

	}

	@SuppressWarnings("static-access")
	public String transferFileTest(StringBuilder builder, String fileName) throws JSchException, SftpException {
		JSch jsch = null;
		String result = ConstantUtility.IN_TRANSFER;
		try {
			logger.info(ConstantUtility.HYPHENS, getUsername(), ConstantUtility.HYPHEN_1, remoteHost, ConstantUtility.SPACE, port, ConstantUtility.SPACE, getPassword());
			jsch = new JSch();
			java.util.Properties config = new java.util.Properties();
			config.put(ConstantUtility.STRICT_HOST_KEY_CHECKING, ConstantUtility.NO);
			jsch.setConfig(config);
			Session session = jsch.getSession(getUsername(), remoteHost, port);
			session.setPassword(getPassword());
			logger.info(ConstantUtility.ESTABLISHING_CONNECTION);
			session.connect();
			logger.info(ConstantUtility.CONNECTION_ESTABLISHED);

			logger.info(ConstantUtility.CREATING_SFTP_CHANNEL);
			ChannelSftp sftpChannel = (ChannelSftp) session.openChannel(ConstantUtility.SFTP);
			sftpChannel.connect();
			logger.info(ConstantUtility.SFTP_CHANNEL_CREATED);

			logger.info(ConstantUtility.HYPHENS, fileName);

			// Upload file
			sftpChannel.put(new ByteArrayInputStream(builder.toString().getBytes()),
					remoteDirectoryName.concat(fileName));
			logger.info(ConstantUtility.FILE_TRANSFER_COMPLETED);

			sftpChannel.disconnect();
			session.disconnect();

		} catch (JSchException e) {
			logger.error(ConstantUtility.ERROR_IN_FILE_TRANSFER2);
			result = e.getLocalizedMessage();
			return result;
		}
		return remoteDirectoryName.concat(fileName);

	}
	
	public String getUsername() {
		if (username == null) {
			init();
		}
		return username;
	}


	public String getPassword() {
		if (password == null) {
			init();
		}
		return password;
	}

	
	private void init() {
		String userPasswordTemp;
		try {
			userPasswordTemp = EncriptionUtils.decrypt(userPassword);
			username = userPasswordTemp.substring(0, userPasswordTemp.indexOf(":"));
			password = userPasswordTemp.substring(userPasswordTemp.indexOf(":")+1);
		} catch (Exception e) {
			logger.error("No se pudo desencriptar");
		}

	}

}
