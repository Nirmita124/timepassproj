package mx.com.metlife.tom.fitrava.endorsement.services.service;

import org.springframework.stereotype.Service;

@Service
public class UploadFileServiceImpl implements UploadFileService {

	@Override
	public String uploadFile(String claimNum) {
		
		
		return null;
	}
}
