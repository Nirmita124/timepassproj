package mx.com.metlife.tom.fitrava.endorsement.services.service.dto;

import javax.validation.constraints.Size;

import lombok.Data;

@Data
public class PaymentReferenceNumberDTO {

	@Size(min = 0, max = 4, message = "Template ID length cannot exceed more than 4.")
	String templateID;
	
	@Size(min = 0, max = 4, message = "retainerID length cannot exceed more than 4.")
	String retainerID;
	
	@Size(min = 0, max = 3, message = "paymentUnit length cannot exceed more than 3.")
	String paymentUnit;
	
	@Size(min = 0, max = 10, message = "policyGKY length cannot exceed more than 10.")
	String policyGKY;
	
	
}
