package mx.com.metlife.tom.fitrava.endorsement.services.model.repository;

import static mx.com.metlife.tom.fitrava.endorsement.services.utility.ConstantUtility.DB_FROM;

import java.io.Serializable;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import org.springframework.orm.jpa.EntityManagerFactoryInfo;
import org.springframework.stereotype.Repository;

import mx.com.metlife.tom.fitrava.endorsement.services.error.FitravaException;

/**
 * It is a base class of all the Repository's and every repository must extends
 * this class.
 * 
 * @param <ENTITY> : It is a entity class
 * @author Capgemini
 * @since 20/12/2018
 */
@Repository
public class BaseRepository<ENTITY> {

	@PersistenceContext(unitName = "fitravaEntityManager")
	private EntityManager entityManagerFactory;

	public EntityManager getEntityManager() {
		return entityManagerFactory;
	}

	public DataSource getDataSource() {
		EntityManagerFactoryInfo info = (EntityManagerFactoryInfo) entityManagerFactory.getEntityManagerFactory();
		return info.getDataSource();
	}

	public Object saveEntity(ENTITY entity) {
		getEntityManager().persist(entity);
		return entity;
	}

	public Object mergeEntity(ENTITY entity) {
		return getEntityManager().merge(entity);
	}

	public void updateEntity(ENTITY entity) {
		getEntityManager().merge(entity);
	}

	public void deleteEntity(ENTITY entity) {
		getEntityManager().remove(entity);
	}

	public ENTITY getEntity(Class<ENTITY> entityClass, Serializable primaryKey) throws FitravaException {
		ENTITY entity = null;
		try {
			entity = getEntityManager().find(entityClass, primaryKey);
		} catch (Exception exception) {
			throw new FitravaException(exception.getMessage());
		}
		return entity;
	}

	@SuppressWarnings("unchecked")
	public List<ENTITY> getAllEntity(Class<ENTITY> entityClass) {
		return getEntityManager().createQuery(DB_FROM + entityClass.getName()).getResultList();
	}
}
