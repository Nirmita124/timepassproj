package mx.com.metlife.tom.fitrava.endorsement.services.utility;

import static org.slf4j.LoggerFactory.getLogger;

import java.io.File;
import java.io.FileInputStream;
import java.net.URI;
import java.net.URL;

import org.slf4j.Logger;

import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;

import mx.com.metlife.tom.fitrava.endorsement.services.web.controller.UploadFitravaFileController;

public class SFTPWithKey {

	final static String YOUR_KEY_FILE_NAME = "src/main/resources/mxsrvsfgmxu.alico.corp.openssh";
	private static final Logger logger = getLogger(UploadFitravaFileController.class);
	
	public void createSFTPConnection() {
		JSch jsch = new JSch();
		Session session = null;
		ChannelSftp channel = null;
		FileInputStream localFileStream = null;

		try {

			if (YOUR_KEY_FILE_NAME != null) {
				URL keyFileURL = this.getClass().getClassLoader().getResource(YOUR_KEY_FILE_NAME);

				if (keyFileURL == null) {
					throw new RuntimeException("Key file " + YOUR_KEY_FILE_NAME + "not found in classpath");
				}
				URI keyFileURI = keyFileURL.toURI();

				jsch.addIdentity(new File(keyFileURI).getAbsolutePath());
				session = jsch.getSession("christian.reyes", "mxsrvsfgmxu.alico.corp", 8119);
			} else if (ConstantUtility.SPACE != null) {
				session = jsch.getSession("christian.reyes", "mxsrvsfgmxu.alico.corp", 8119);
				session.setPassword("Sterling01");
			}

			session = jsch.getSession("AQ119943", "mxsrvsfgmxu.alico.corp", 8119);
			session.setPassword("{xor}EmwrM245bG5m");
			// session = jsch.getSession("christian.reyes", "169.60.157.188", 8119);
			// session.setPassword("Sterling01");
			session.setConfig("StrictHostKeyChecking", "no");
			session.setTimeout(15000);

			session.connect();

			channel = (ChannelSftp) session.openChannel("sftp");
			channel.connect();

			if (ConstantUtility.SPACE  != null) {
				channel.cd("SERVER FILE Directory");
			}

			File localFile = new File(ConstantUtility.EMPTY_STRING + ConstantUtility.EMPTY_STRING);
			if (localFile.exists()) {
				localFileStream = new FileInputStream(localFile);

				channel.put(localFileStream, ConstantUtility.EMPTY_STRING);
			} else {
				
				logger.info("Local file not found ", localFile.getAbsolutePath());

			}
		} catch (Exception e) {
			logger.info(ConstantUtility.IN_GET_ENDORSEMENTS_SUMMARY_MOVEMENT, e.getLocalizedMessage());
		}
	}
}
