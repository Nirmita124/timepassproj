package mx.com.metlife.tom.fitrava.endorsement.services.model.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import mx.com.metlife.tom.fitrava.endorsement.services.model.entity.TFlow;
import mx.com.metlife.tom.fitrava.endorsement.services.utility.ConstantUtility;

public interface TFlowRepository extends JpaRepository<TFlow, Long> {

	@Query("FROM TFlow f WHERE f.flowNm = :flowName")
	public TFlow findByFlowName(@Param(ConstantUtility.FLOW_NAME) String flowName);
	
	
	public TFlow findFirstByflowNm(String flowName);

}
