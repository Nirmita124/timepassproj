package mx.com.metlife.tom.fitrava.endorsement.services.service.dto;

import lombok.Data;

@Data
public class DataSortKeyDTO {
	private String agentKey;
	private String ramoSubRamo;
	private String policyNum;
	private String parentesco;
	private String nombre;
	private String naseg;

	public String toString() {
		return new StringBuilder().append(this.agentKey).append(this.ramoSubRamo).append(policyNum).append(naseg)
				.append(parentesco).append(nombre).toString();
	}

	public Long generateKey() {
		return Long.parseLong(new StringBuilder().append(this.agentKey).append(this.ramoSubRamo).append(policyNum).append(naseg)
				.append(parentesco).append(nombre).toString());
	}

	public DataSortKeyDTO(String agentKey2, String ramoSubRamo2, String policyNum2, String parentesco2,
			String nombre2, String naseg2) {
		this.agentKey = agentKey2;
		this.ramoSubRamo = ramoSubRamo2;
		this.policyNum = policyNum2;
		this.parentesco = parentesco2;
		this.nombre = nombre2;
		this.naseg = naseg2;
	}

}
