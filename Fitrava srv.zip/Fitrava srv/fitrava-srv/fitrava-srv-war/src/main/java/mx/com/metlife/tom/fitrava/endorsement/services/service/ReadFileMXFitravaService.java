package mx.com.metlife.tom.fitrava.endorsement.services.service;

import static mx.com.metlife.tom.fitrava.endorsement.services.utility.ConstantUtility.INVALID_COL;
import static mx.com.metlife.tom.fitrava.endorsement.services.utility.ConstantUtility.MANDATORY_FIELD;
import static mx.com.metlife.tom.fitrava.endorsement.services.utility.ConstantUtility.MSG_TXT;
import static mx.com.metlife.tom.fitrava.endorsement.services.utility.ConstantUtility.WRONG_FILE_TYPE;
import static mx.com.metlife.tom.fitrava.endorsement.services.utility.LayoutValidations.checkDateMasking;
import static mx.com.metlife.tom.fitrava.endorsement.services.utility.LayoutValidations.checkMendatory;
import static mx.com.metlife.tom.fitrava.endorsement.services.utility.LayoutValidations.isColumnLayoutoutMatched;
import static mx.com.metlife.tom.fitrava.endorsement.services.utility.LayoutValidations.validateLength;
import static mx.com.metlife.tom.fitrava.endorsement.services.utility.MethodUtility.flattenToAscii;
import static mx.com.metlife.tom.fitrava.endorsement.services.utility.MethodUtility.isAlphaNumericNumeric;
import static mx.com.metlife.tom.fitrava.endorsement.services.utility.MethodUtility.isNullOrBlank;
import static mx.com.metlife.tom.fitrava.endorsement.services.utility.MethodUtility.isNumeric;
import static mx.com.metlife.tom.fitrava.endorsement.services.utility.ConstantUtility.DOUBLE_LOGGER;
import static org.slf4j.LoggerFactory.getLogger;

import java.io.IOException;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import mx.com.metlife.tom.fitrava.endorsement.services.error.FitravaException;
import mx.com.metlife.tom.fitrava.endorsement.services.model.entity.TLayout;
import mx.com.metlife.tom.fitrava.endorsement.services.model.entity.TLayoutFld;
import mx.com.metlife.tom.fitrava.endorsement.services.model.entity.TProc;
import mx.com.metlife.tom.fitrava.endorsement.services.model.entity.TProcFile;
import mx.com.metlife.tom.fitrava.endorsement.services.model.entity.TProcRec;
import mx.com.metlife.tom.fitrava.endorsement.services.model.repository.CommonFitravaRepository;
import mx.com.metlife.tom.fitrava.endorsement.services.model.repository.TProcRecRepository;
import mx.com.metlife.tom.fitrava.endorsement.services.model.repository.UploadDataRepository;
import mx.com.metlife.tom.fitrava.endorsement.services.service.dto.TProcRecDTO;
import mx.com.metlife.tom.fitrava.endorsement.services.service.dto.UploadDetails;
import mx.com.metlife.tom.fitrava.endorsement.services.service.dto.UploadRequest;
import mx.com.metlife.tom.fitrava.endorsement.services.service.dto.UploadResponse;
import mx.com.metlife.tom.fitrava.endorsement.services.utility.ConstantUtility;
import mx.com.metlife.tom.fitrava.endorsement.services.utility.JsonLayoutDefinition;
import mx.com.metlife.tom.fitrava.endorsement.services.utility.LayoutDefinition;
import mx.com.metlife.tom.fitrava.endorsement.services.utility.MethodUtility;
import mx.com.metlife.tom.fitrava.endorsement.services.utility.StatusDefinition;

@Service
@Qualifier("uploadFileService")
@Configuration
@EnableAsync
public class ReadFileMXFitravaService {

	@Autowired
	UploadDataRepository uploadRepository;

	@Autowired
	FileWriteService fileWriteService;

	@Autowired
	CallBPMProcess bpmServiceUtility;

	@Resource
	TProcRecRepository tProcRecRepository;

	@Autowired
	CommonFitravaRepository commonRepository;

	private static final Logger logger = getLogger(ReadFileMXFitravaService.class);

	public UploadResponse uploadData(List<TProcRecDTO> tprocDtoList, String dcn, String fileName, String source,
			String isMassive) throws FitravaException {
		UploadResponse uploadResponse = new UploadResponse();
		logger.info(DOUBLE_LOGGER,ConstantUtility.IN_UPLOAD_DATA_STEPS, dcn);
		if (uploadRepository.saveorUpdateProc(dcn, tprocDtoList, fileName, source, isMassive)) {
			uploadRepository.updateFileStatus(dcn, StatusDefinition.EN_PROCESO.getStatusCode(), fileName);
			logger.info(DOUBLE_LOGGER,ConstantUtility.DATA_UPLOADED_AND_UPDATED_STATUS, dcn);
			uploadResponse.setCode(0);
			uploadResponse.setMessage(ConstantUtility.SUCCESS_TEXT);
		} else {
			uploadResponse.setCode(1);
			uploadResponse.setMessage(ConstantUtility.TEXT_FILE_ERROR);
		}
		return uploadResponse;
	}

	public List<TProcRecDTO> getDTOListFromJson(UploadRequest endorsementsUploadRequest)
			throws IllegalAccessException, FitravaException {
		List<UploadDetails> listEndoInfo = endorsementsUploadRequest.getEndorsements();
		TProcRecDTO tprocDto = null;
		List<TProcRecDTO> tprocDtoList = new ArrayList<>();
		TLayout tLayout = commonRepository.getLayoutByName(ConstantUtility.ENDOSOS);
		if (null == tLayout) {
			throw new FitravaException(ConstantUtility.LAYOUT_DEFINITION_IS_NOT_PRESENT_FOR_ENDOSOS_LAYOUT
					.concat(endorsementsUploadRequest.getDcn()));
		}

		Map<String, Long> layoutFieldMap = commonRepository.getLayoutFieldId(tLayout.getLayoutId());
		for (int j = 0; j < listEndoInfo.size(); j++) {
			UploadDetails endosmentDetails = listEndoInfo.get(j);
			Class<? extends UploadDetails> aClass = endosmentDetails.getClass();
			Field[] fields = aClass.getDeclaredFields();
			for (int i = 0; i < fields.length; i++) {
				JsonLayoutDefinition field = JsonLayoutDefinition.getLayoutByFieldName(fields[i].getName());
				fields[i].setAccessible(true);
				tprocDto = new TProcRecDTO();
				tprocDto.setDcn(endorsementsUploadRequest.getDcn());
				tprocDto.setFileNm(endorsementsUploadRequest.getFileName());
				tprocDto.setErrorIndicator(true);
				logger.info("-------------------  "+field.getLayoutFieldName());
				logger.info("-------------------  "+layoutFieldMap.values());
				logger.info("-------------------  "+layoutFieldMap);
				logger.info("-------------------  "+layoutFieldMap.get(field.getLayoutFieldName()));
				tprocDto.setLayoutID(layoutFieldMap.get(field.getLayoutFieldName()));
				logger.info(""+tprocDto.getLayoutID());
				Object valueOfField = fields[i].get(endosmentDetails);
				if (null != valueOfField) {
					tprocDto.setNewValue(valueOfField.toString());
					tprocDto.setOriginalValue(valueOfField.toString());
				} else {
					tprocDto.setNewValue(ConstantUtility.BLANK);
					tprocDto.setOriginalValue(ConstantUtility.BLANK);
				}
				tprocDto.setRecordNumber(Long.valueOf(j + 1l));
				tprocDtoList.add(tprocDto);
			}
		}
		return tprocDtoList;
	}

	@Async
	public void applyValidateFileLayoutAsync(String dcn) throws FitravaException {
		List<TProcRecDTO> listTprocDTO = layoutValidate(dcn);
		validateGenTransferFile(listTprocDTO, dcn);
	}

	public List<TProcRecDTO> layoutValidate(String dcn) throws FitravaException {
		logger.info(DOUBLE_LOGGER,ConstantUtility.IN_LAYOUT_VALIDATE, dcn);
		TProc tproc = commonRepository.getTProc(dcn);
		List<TProcRecDTO> listRecDTOs = uploadRepository.getDTOsForDCN(dcn);
		if (listRecDTOs.isEmpty()) {
			throw new FitravaException(ConstantUtility.NO_RECORDS_TO_PROCESS.concat(dcn));
		}

		if (null == tproc.getAdtField() || !tproc.getAdtField().equalsIgnoreCase(ConstantUtility.TEXT_TRUE)) {
			listRecDTOs.forEach(tProcRecDTO -> {
				tProcRecDTO.setNewValue(tProcRecDTO.getOriginalValue());
				tProcRecDTO.setErrorIndicator(true);
			});

			return listRecDTOs;
		}

		List<TProcRecDTO> fileRecList = new ArrayList<>();
		TLayout tLayout = commonRepository.getLayoutByName(ConstantUtility.ENDOSOS);
		Long layoutID = tLayout.getLayoutId();
		Long layoutIDforColumnI = commonRepository.getLayoutFieldId(ConstantUtility.COLUMNI, layoutID);
		Map<Long, TLayoutFld> mapLayoutFields = commonRepository.getLayoutFields(layoutID);
		for (TProcRecDTO recDTO : listRecDTOs) {
			TLayoutFld tLayoutFld = mapLayoutFields.get(recDTO.getLayoutID());
			if (null == tLayoutFld) {
				throw new FitravaException(
						ConstantUtility.LAYOUT_DEFINITION_IS_NOT_PRESENT_FOR_ENDOSOS_LAYOUT.concat(dcn));
			}
			LayoutDefinition column = LayoutDefinition.getLayoutByExcelColumnName(tLayoutFld.getLayoutFldNm());
			TProcRec tProcRecColumnI = commonRepository.getTProcRec(dcn, recDTO.getRecordNumber(), layoutIDforColumnI);
			boolean isNullOrBlank = isNullOrBlank(recDTO.getOriginalValue());
			switch (column.getDataType()) {
			case ConstantUtility.NUMERIC:
				if (!isNullOrBlank) {
					recDTO.setNewValue(recDTO.getOriginalValue().replaceAll(",", "."));
					if (isNumeric(recDTO.getNewValue())) {
						recDTO.setErrorIndicator(true);
					} else {
						recDTO.setErrorIndicator(false);
						recDTO.setMsgText(MSG_TXT);
					}

					recDTO = validateLength(column, recDTO);

				} else {
					recDTO.setNewValue(ConstantUtility.BLANK);
					recDTO = checkMendatory(column, tProcRecColumnI.getOrigVal(), isNullOrBlank, recDTO);
				}
				if (!isNullOrBlank(column.getMask())) {
					recDTO = checkDateMasking(column.getMask(), recDTO);
				}

				break;

			case ConstantUtility.ALPHANUMERIC:
				String newValue = ConstantUtility.BLANK;
				if (!isNullOrBlank) {
					newValue = flattenToAscii(recDTO.getOriginalValue()).toUpperCase();

					if (newValue.contains(ConstantUtility.ASTERISK)) {
						newValue = newValue.replaceAll(ConstantUtility.ASTERISK, ConstantUtility.BLANK);
					}
					if (newValue.contains(ConstantUtility.HYPHEN_SINGLE)) {
						newValue = newValue.replaceAll(ConstantUtility.HYPHEN_SINGLE, ConstantUtility.BLANK);
					}
					if (newValue.contains(ConstantUtility.PATTERN)) {
						newValue = newValue.replaceAll(ConstantUtility.PATTERN, ConstantUtility.BLANK);
					}
					recDTO.setNewValue(newValue);

					if (isAlphaNumericNumeric(recDTO.getNewValue())) {
						recDTO.setErrorIndicator(true);
					} else {
						recDTO.setErrorIndicator(false);
						recDTO.setMsgText(MSG_TXT);
					}
					recDTO = validateLength(column, recDTO);
				} else {
					recDTO.setNewValue(ConstantUtility.BLANK);
					recDTO = checkMendatory(column, tProcRecColumnI.getOrigVal(), isNullOrBlank, recDTO);
				}

				if (!isNullOrBlank(column.getMask()) && !isNullOrBlank) {
					recDTO = checkDateMasking(column.getMask(), recDTO);
					recDTO.setNewValue(newValue);
				}
				break;
			default:
				recDTO.setMsgText(recDTO.getMsgText().concat(MANDATORY_FIELD));
				recDTO.setErrorIndicator(false);
				break;
			}
			fileRecList.add(recDTO);
		}

		return listRecDTOs;
	}

	public UploadResponse validateGenTransferFile(List<TProcRecDTO> tprocDtoList, String dcn) throws FitravaException {
		logger.info(DOUBLE_LOGGER,ConstantUtility.IN_VALIDATE_GEN_TRANSFER_FILE, dcn);
		TProc tproc = commonRepository.getTProc(dcn);
		TProcFile tProcFile = commonRepository.getTProcFile(dcn);
		String fileName = tProcFile.getFileNm();
		UploadResponse uploadResponse = new UploadResponse();
		if (uploadRepository.updateTProcRec(tprocDtoList)) {
			uploadRepository.updateFileStatusNew(dcn, StatusDefinition.TRANSFORMADO.getStatusCode(), fileName);
			if (fileWriteService.generateFile(dcn, tproc.getSourceField(), fileName)) {
				uploadResponse.setCode(0);
				uploadResponse.setMessage(ConstantUtility.SUCCESS_TEXT);
				uploadRepository.updateFileStatusNew(dcn, StatusDefinition.LEGADO.getStatusCode(), fileName);
				logger.info(DOUBLE_LOGGER,ConstantUtility.FILE_CREATED_AND_TRANFERRED_STATUS_UPDATED, dcn);
			} else {
				uploadResponse.setCode(1);
				uploadResponse.setMessage(ConstantUtility.TEXT_FILE_ERROR);
			}
		}
		return uploadResponse;
	}

	public List<TProcRecDTO> getDTOsFromFile(String fname, String dcn, MultipartFile xlsFile)
			throws IOException, FitravaException {
		logger.info(ConstantUtility.DOUBLE_LOGGER, "..::: Method getDTOsFromFile :::..", xlsFile.getOriginalFilename());
		List<TProcRecDTO> fileRecList = new ArrayList<>();
		TProcRecDTO recDTO = null;
		String fileExt = fname.split("\\.")[1];

		if (fileExt.equalsIgnoreCase(ConstantUtility.FILE_TYPE_XLSX)) {

			XSSFWorkbook myWorkBook = new XSSFWorkbook(xlsFile.getInputStream());

			List<String> columnNames = getColumnNames(myWorkBook);
			XSSFSheet mySheet = myWorkBook.getSheetAt(0);

			int rowStart = mySheet.getFirstRowNum();
			int rowEnd = mySheet.getLastRowNum();

			if (isColumnLayoutoutMatched(columnNames)) {
				TLayout tLayout = commonRepository.getLayoutByName(ConstantUtility.ENDOSOS);
				if (null == tLayout) {
					throw new FitravaException(
							ConstantUtility.LAYOUT_DEFINITION_IS_NOT_PRESENT_FOR_ENDOSOS_LAYOUT.concat(dcn));
				}
				Map<String, Long> layoutFieldMap = commonRepository.getLayoutFieldId(tLayout.getLayoutId());
				logger.info("layoutFieldMap -> {}", layoutFieldMap);
				for (int i = rowStart + 1; i < rowEnd + 1; i++) {
					Row row = mySheet.getRow(i);
					if (!MethodUtility.isRowEmpty(row)) {
						for (int j = 0; j < 72; j++) {
							DataFormatter formatter = new DataFormatter();
							String val = formatter.formatCellValue(row.getCell(j));
							LayoutDefinition column = LayoutDefinition.getLayoutBySeqNumber(j + 1);
							logger.info("columName: {}", column.getExcelColumnName());
							recDTO = new TProcRecDTO();
							recDTO.setOriginalValue(val);
							recDTO.setRecordNumber((long) i);
							recDTO.setLayoutID(layoutFieldMap.get(column.getExcelColumnName()));
							recDTO.setDcn(dcn);
							recDTO.setFileNm(fname);
							recDTO.setErrorIndicator(true);
							if (isNullOrBlank(recDTO.getOriginalValue())) {
								recDTO.setOriginalValue(ConstantUtility.BLANK);
								recDTO.setNewValue(ConstantUtility.BLANK);
							} else {
								recDTO.setNewValue(ConstantUtility.BLANK);
							}
							fileRecList.add(recDTO);
						}
					} else {
						break;
					}
				}
			} else {
				bpmServiceUtility.callBPMService(1, dcn);
				throw new FitravaException(INVALID_COL.concat(dcn));

			}
			myWorkBook.close();
		} else {
			throw new FitravaException(WRONG_FILE_TYPE.concat(dcn));
		}
		return fileRecList;

	}

	public List<String> getColumnNames(XSSFWorkbook myWorkBook) throws FitravaException {
		XSSFSheet sheet = myWorkBook.getSheetAt(0);
		Row row = sheet.getRow(0);
		if (null == row) {
			throw new FitravaException(INVALID_COL);
		}
		List<String> columnNames = new ArrayList<>();
		row.forEach(cell -> columnNames.add(cell.getStringCellValue()));
		return columnNames;
	}
}
