package mx.com.metlife.tom.fitrava.endorsement.services.model.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@SuppressWarnings("serial")
@Data
@Entity
@Table(name = "T_PROC_FILE")
@IdClass(TProcFilePk.class)
@NoArgsConstructor
@AllArgsConstructor
public class TProcFile implements java.io.Serializable{

	@Id
	@Column(name="DSTNCT_CTRL_NUM")
	private String dstnctCtrlNum;

	@Id
	@Column(name = "FILE_NM")
	private String fileNm;
	
	@Column(name = "PROC_FILE_ORD_NUM")
	private Integer procFileOrdNum = null;

	@Column(name = "CLCT_STTS_ID")
	private Integer clctSttsId = null;

	@Column(name = "PROC_FILE_STRT_TS")
	private Date procFileStrtTs = null;

	@Column(name = "PROC_FILE_END_TS")
	private Date procFileEndTs = null;
}
