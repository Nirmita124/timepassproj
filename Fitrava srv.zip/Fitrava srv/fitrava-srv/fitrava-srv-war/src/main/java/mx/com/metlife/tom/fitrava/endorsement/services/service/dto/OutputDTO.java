package mx.com.metlife.tom.fitrava.endorsement.services.service.dto;

import org.dozer.Mapping;

import lombok.Data;

@SuppressWarnings("serial")
@Data  
public class OutputDTO implements java.io.Serializable {
                
        @Mapping("AGENTKEY")
        private String agentKey;

        @Mapping("TSOLIC")
        private String tSolic;
        
        @Mapping("FECHA")
        private String fecha;
        
        @Mapping("RAMSUBRAMO")
        private String ramSubRamo;
        
        @Mapping("NPOLIZA")
        private String nPoliza;
        
        @Mapping("NSUBGPO")
        private String nSubGpo;
        
        @Mapping("NCATEG")
        private String nCaTeg;
        
        @Mapping("NFOLIO")
        private String nFolio;
        
        @Mapping("OT")
        private String oT;
        
        @Mapping("IDBROKER")
        private String idBroker;
        
        @Mapping("MOVENDOSO")
        private String movEndosos;
        
        @Mapping("FECEFECT")
        private String fecEfect;
        
        @Mapping("INSTCOBRO")
        private String instcobro;
        
        @Mapping("FMAADMVA")
        private String fmaadmva;
        
        @Mapping("CVNASEG")
        private String cvnaseg;

        
        @Mapping("NASEG")
        private String naseg;
        
        @Mapping("NDEPEND")
        private String ndepend;
        
        @Mapping("CVPARENT")
        private String cvparent;
        
        @Mapping("NUMEMPLDO")
        private String numempldo;
        
        @Mapping("TRAMTO")
        private String tramto;
        
        @Mapping("CVINTBAN")
        private String cvintban;
        
        @Mapping("APPATER")
        private String appater;
        
        @Mapping("APMATER")
        private String apmater;
        
        @Mapping("NOMBRES")
        private String nombres;
        
        @Mapping("FNAC")
        private String fnac;
        
        @Mapping("CVSEXO")
        private String cvsexo;
        
        @Mapping("TIPORFC")
        private String tiporfc; 
                        
        @Mapping("RFC")
        private String rfc;
        
        @Mapping("CURP")
        private String curp;
        
        @Mapping("CVASEG")
        private String cvaseg;
        
        @Mapping("HCVASEG")
        private String hcvaseg;
        
        @Mapping("FSTALTA")
        private String fstalta;
        
        @Mapping("FSTBAJA")
        private String fstbaja;
        
        @Mapping("FINISEG")
        private String finiseg;
        
        @Mapping("CVEDOCIV")
        private String cvedociv;             

        @Mapping("CVNFUMA")
        private String cvnfuma;
        
        @Mapping("STSINIES")
        private String stsinies;
        
        @Mapping("ASEGSINIES")
        private String asegsinies;
        
        @Mapping("CVREAFAC")
        private String cvreafac;
        
        @Mapping("ZONA")
        private String zona;
        
        @Mapping("RIESGOCUP")
        private String riesgocup;
        
        @Mapping("FINGEMP")
        private String fingemp;
        
        @Mapping("SUELDO")
        private String sueldo;
        
        @Mapping("NIVEL")
        private String nivel;
        
        @Mapping("GPONIVEL")
        private String gponivel;
        
        @Mapping("REGION")
        private String region;
        
        @Mapping("CENTROTRAB")
        private String centrotrab;
        
        @Mapping("FASEGDESDE")
        private String fasegdesde;
        
        @Mapping("ANTIG")
        private String anting;
        
        @Mapping("SAMAXSRA")
        private String samaxsra;
        
        @Mapping("CVLIMSA")
        private String cvlimsa;
        
        @Mapping("CARGDEP")
        private String cargdep;
        
        @Mapping("NORDEN")
        private String norden;
        
        @Mapping("NESQFPAGO")
        private String nesqfpago;
        
        @Mapping("FILL-5")
        private String fill5;
        
        
        @Mapping("ORIGEN")
        private String origen;
        
        @Mapping("FILLERUSR")
        private String fillerusr;
                
}

