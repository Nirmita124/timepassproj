package mx.com.metlife.tom.fitrava.endorsement.services.service.dto;

import java.util.Date;

import lombok.Data;

@Data
public class TProcDTO {

	private String dstnctCtrlNum;

	private Integer flowId;

	private Long entrncLayoutId;

	private Date rcptnTs;

	private Integer prtyNum;

	private String crtUsrId;

	private Integer clctStts;

	private String rsltDscr;

}
