package mx.com.metlife.tom.fitrava.endorsement.services.service.dto;

import lombok.Data;

@Data
public class BPMProcessDTO {
	String dcn;
	String fileName;
	int resultCode;
	String resultMessage;
	String numOfSuccessRec;
	String numOfFailureRec;
	int system;
	//{{Pieda Solorzano}} Add field
	int operationType;
	Integer status;
	Integer typNtf;
}
