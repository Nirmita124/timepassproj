package mx.com.metlife.tom.fitrava.endorsement.services.error;

import java.util.List;

import lombok.Data;

/**
 * This class is used to handle error messages.
 * 
 * @author Capgemini
 * @since 03/15/2019
 */
@Data
public class MessagesErrorVO {

	private String code;
	private String description;
	private List<ErrorExtensionVO> errors;

	public MessagesErrorVO() {

	}

	public MessagesErrorVO(String code, String description, List<ErrorExtensionVO> extension) {

		this.code = code;
		this.description = description;
		this.errors = extension;
	}
}
