package mx.com.metlife.tom.fitrava.endorsement.services.model.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import mx.com.metlife.tom.fitrava.endorsement.services.model.entity.TProcFile;

public interface TProcFileRepository extends JpaRepository<TProcFile, String> {
	
	public TProcFile findFirstByDstnctCtrlNum(String dstnctCtrlNum);
	
}
