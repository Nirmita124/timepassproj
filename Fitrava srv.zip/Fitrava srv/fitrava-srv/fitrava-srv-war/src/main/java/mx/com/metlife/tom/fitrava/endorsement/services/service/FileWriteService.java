
package mx.com.metlife.tom.fitrava.endorsement.services.service;

import static org.slf4j.LoggerFactory.getLogger;
import static mx.com.metlife.tom.fitrava.endorsement.services.utility.ConstantUtility.DOUBLE_LOGGER;
import static mx.com.metlife.tom.fitrava.endorsement.services.utility.ConstantUtility.EMPTY_STRING;
import java.util.List;

import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import mx.com.metlife.tom.fitrava.endorsement.services.error.FitravaException;
import mx.com.metlife.tom.fitrava.endorsement.services.model.repository.ProcessDataOutput;
import mx.com.metlife.tom.fitrava.endorsement.services.model.repository.UploadDataRepository;
import mx.com.metlife.tom.fitrava.endorsement.services.service.dto.OutputDTO;
import mx.com.metlife.tom.fitrava.endorsement.services.utility.ConstantUtility;
import mx.com.metlife.tom.fitrava.endorsement.services.utility.StatusDefinition;

@Service
@Qualifier("fileWriteService")
public class FileWriteService {

	private static final Logger logger = getLogger(FileWriteService.class);

	@Autowired
	ProcessDataOutput processOutPutData;

	@Autowired
	SendFileTransferSFTP sendFileTransferSFTP;

	@Autowired
	CallBPMProcess bpmServiceUtility;

	@Autowired
	UploadDataRepository uploadRepository;

	public boolean generateFile(String dcn, String source, String fileName) throws FitravaException {
		logger.info(DOUBLE_LOGGER, ConstantUtility.IN_GENERATE_FILE, dcn);
		List<OutputDTO> finaldataList = processOutPutData.processdata(dcn, source);
		if (finaldataList.isEmpty()) {
			bpmServiceUtility.callBPMService(1, dcn);
			uploadRepository.updateFileStatusNew(dcn, StatusDefinition.FINALIZADO.getStatusCode(), fileName);
			throw new FitravaException(
					ConstantUtility.ALL_THE_ROWS_IN_THE_FILE_HAVE_ERRORS_HENCE_OUTPUT_FILE_IS_EMPTY.concat(dcn));
		}
		String outputFile = EMPTY_STRING;
		boolean result = false;
		try {
			outputFile = writeToTextFile(finaldataList, dcn);
			result = !outputFile.contains(ConstantUtility.EXCEPTION);
		} catch (FitravaException e) {
			result = false;
		}
		return result;
	}

	public String writeToTextFile(List<OutputDTO> finaldataList, String dcn) throws FitravaException {
		String fileName = dcn.concat(ConstantUtility.OUTPUT_TXT);
		String result = EMPTY_STRING;

		StringBuilder builder = new StringBuilder();

		finaldataList.forEach(outputDTO -> 
			builder.append(outputDTO.getTSolic()).append(outputDTO.getFecha()).append(outputDTO.getRamSubRamo())
					.append(outputDTO.getNPoliza()).append(outputDTO.getNSubGpo()).append(outputDTO.getNCaTeg())
					.append(outputDTO.getNFolio()).append(outputDTO.getOT()).append(outputDTO.getIdBroker())
					.append(outputDTO.getMovEndosos()).append(outputDTO.getFecEfect()).append(outputDTO.getInstcobro())
					.append(outputDTO.getFmaadmva()).append(outputDTO.getCvnaseg()).append(outputDTO.getNaseg())
					.append(outputDTO.getNdepend()).append(outputDTO.getCvparent()).append(outputDTO.getNumempldo())
					.append(outputDTO.getTramto()).append(outputDTO.getCvintban()).append(outputDTO.getAppater())
					.append(outputDTO.getApmater()).append(outputDTO.getNombres()).append(outputDTO.getFnac())
					.append(outputDTO.getCvsexo()).append(outputDTO.getTiporfc()).append(outputDTO.getRfc())
					.append(outputDTO.getCurp()).append(outputDTO.getCvaseg()).append(outputDTO.getHcvaseg())
					.append(outputDTO.getFstalta()).append(outputDTO.getFstbaja()).append(outputDTO.getFiniseg())
					.append(outputDTO.getCvedociv()).append(outputDTO.getCvnfuma()).append(outputDTO.getStsinies())
					.append(outputDTO.getAsegsinies()).append(outputDTO.getCvreafac()).append(outputDTO.getZona())
					.append(outputDTO.getRiesgocup()).append(outputDTO.getFingemp()).append(outputDTO.getSueldo())
					.append(outputDTO.getNivel()).append(outputDTO.getGponivel()).append(outputDTO.getRegion())
					.append(outputDTO.getCentrotrab()).append(outputDTO.getFasegdesde()).append(outputDTO.getAnting())
					.append(outputDTO.getSamaxsra()).append(outputDTO.getCvlimsa()).append(outputDTO.getCargdep())
					.append(outputDTO.getNorden()).append(outputDTO.getNesqfpago()).append(outputDTO.getFill5())
					.append(outputDTO.getAgentKey()).append(outputDTO.getOrigen()).append(outputDTO.getFillerusr())
					.append("\n").toString());

		try {
			logger.info(DOUBLE_LOGGER, ConstantUtility.IN_DATA_COLLECTED_STARTING_TRANSFER, dcn);
			result = sendFileTransferSFTP.transferFile(builder, fileName);
			//sendFileTransferSFTP.transferFileLocal(builder, fileName);
			bpmServiceUtility.callBPMService(0, dcn);

		} catch (Exception ex) {
			logger.error(DOUBLE_LOGGER,ConstantUtility.ERROR, ex.getLocalizedMessage());
			bpmServiceUtility.callBPMService(1, dcn);
			throw new FitravaException(ConstantUtility.ERROR_IN_GENERATION_OR_TRANSFER_OF_FILE.concat(dcn)
					.concat(ex.getLocalizedMessage()));
		}
		return result;
	}

	public String writeToTextFileTest() {
		String result = EMPTY_STRING;
		String fileName = ConstantUtility.FILENAME_20170924PPPWP1155081 + ConstantUtility.OUTPUT_TXT;
		List<OutputDTO> finaldataList = processOutPutData.processdata(ConstantUtility.FILENAME_20170924PPPWP1155081,
				ConstantUtility.STRING_S);
		StringBuilder builder = new StringBuilder();
		finaldataList.forEach(outputDTO -> 
			builder.append(outputDTO.getTSolic()).append(outputDTO.getFecha()).append(outputDTO.getRamSubRamo())
					.append(outputDTO.getNPoliza()).append(outputDTO.getNSubGpo()).append(outputDTO.getNCaTeg())
					.append(outputDTO.getNFolio()).append(outputDTO.getOT()).append(outputDTO.getIdBroker())
					.append(outputDTO.getMovEndosos()).append(outputDTO.getFecEfect()).append(outputDTO.getInstcobro())
					.append(outputDTO.getFmaadmva()).append(outputDTO.getCvnaseg()).append(outputDTO.getNaseg())
					.append(outputDTO.getNdepend()).append(outputDTO.getCvparent()).append(outputDTO.getNumempldo())
					.append(outputDTO.getTramto()).append(outputDTO.getCvintban()).append(outputDTO.getAppater())
					.append(outputDTO.getApmater()).append(outputDTO.getNombres()).append(outputDTO.getFnac())
					.append(outputDTO.getCvsexo()).append(outputDTO.getTiporfc()).append(outputDTO.getRfc())
					.append(outputDTO.getCurp()).append(outputDTO.getCvaseg()).append(outputDTO.getHcvaseg())
					.append(outputDTO.getFstalta()).append(outputDTO.getFstbaja()).append(outputDTO.getFiniseg())
					.append(outputDTO.getCvedociv()).append(outputDTO.getCvnfuma()).append(outputDTO.getStsinies())
					.append(outputDTO.getAsegsinies()).append(outputDTO.getCvreafac()).append(outputDTO.getZona())
					.append(outputDTO.getRiesgocup()).append(outputDTO.getFingemp()).append(outputDTO.getSueldo())
					.append(outputDTO.getNivel()).append(outputDTO.getGponivel()).append(outputDTO.getRegion())
					.append(outputDTO.getCentrotrab()).append(outputDTO.getFasegdesde()).append(outputDTO.getAnting())
					.append(outputDTO.getSamaxsra()).append(outputDTO.getCvlimsa()).append(outputDTO.getCargdep())
					.append(outputDTO.getNorden()).append(outputDTO.getNesqfpago()).append(outputDTO.getFill5())
					.append(outputDTO.getAgentKey()).append(outputDTO.getOrigen()).append(outputDTO.getFillerusr())
					.append("\n").toString());

		try {
			result = sendFileTransferSFTP.transferFileTest(builder, fileName);
		} catch (Exception ex) {
			logger.error(DOUBLE_LOGGER,ConstantUtility.ERROR, ex.getLocalizedMessage());
			result = ex.getLocalizedMessage();
			return result;
		}
		return result;
	}

}
