package mx.com.metlife.tom.fitrava.endorsement.services.service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.DependsOn;
import org.springframework.stereotype.Service;

import mx.com.metlife.tom.fitrava.endorsement.services.model.repository.UploadDataRepository;
import mx.com.metlife.tom.fitrava.endorsement.services.service.dto.TProcDTO;
import mx.com.metlife.tom.fitrava.endorsement.services.utility.StatusDefinition;

@Service
@DependsOn("uploadRepository")
@Qualifier("springBatchService")
public class SpringBatchService {

	@Autowired
	ApplicationContext applicationContext;
	
	@Autowired
	@Qualifier("uploadRepository")
	UploadDataRepository uploadRepository;
	
	public List<TProcDTO> statusResponse(){
		return getuploadRepo().getStatusRecords();
	}

	public void updateStatus(String dcn) {
		getuploadRepo().updateStatus(dcn, StatusDefinition.FINALIZADO.getStatusCode());

	}
	
	public UploadDataRepository getuploadRepo() {
		if(null == uploadRepository) {
			uploadRepository = applicationContext.getBean(UploadDataRepository.class);
		}
		return uploadRepository;
	}

}
