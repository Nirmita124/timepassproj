package mx.com.metlife.tom.fitrava.endorsement.services.error;

import java.util.List;

import lombok.Data;

/**
 * This class is created to handle the error message.
 * 
 * @author Capgemini
 * @since 03/15/2019
 *
 */
@Data
public class ErrorExtensionVO {

	private String reason;
	private List<String> fieldList;

	public ErrorExtensionVO() {

	}

	public ErrorExtensionVO(String providerCode, List<String> providerDescription) {

		this.reason = providerCode;
		this.fieldList = providerDescription;
	}

}
