package mx.com.metlife.tom.fitrava.endorsement.services.error;

/**
 * Exception class to handle custom exceptions.
 * 
 * @author Capgemini
 * @since 03/15/2019
 */
public class FitravaException extends Exception {

	private static final long serialVersionUID = -8453192529050470811L;

	public FitravaException() {
		super();
	}

	public FitravaException(String message) {
		super(message);
	}

	public FitravaException(String message, Throwable cause) {
		super(message, cause);
	}
}
