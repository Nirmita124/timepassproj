package mx.com.metlife.tom.fitrava.endorsement.services.web.controller;

import static java.util.Arrays.asList;
import static java.util.stream.Collectors.toList;
import static mx.com.metlife.tom.fitrava.endorsement.services.utility.ConstantUtility.ARROW;
import static mx.com.metlife.tom.fitrava.endorsement.services.utility.ConstantUtility.ERROR_CODE_400;
import static mx.com.metlife.tom.fitrava.endorsement.services.utility.ConstantUtility.ERROR_CODE_401;
import static mx.com.metlife.tom.fitrava.endorsement.services.utility.ConstantUtility.ERROR_CODE_500;
import static org.slf4j.LoggerFactory.getLogger;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import mx.com.metlife.tom.fitrava.endorsement.services.error.AuthorizationException;
import mx.com.metlife.tom.fitrava.endorsement.services.error.ErrorExtensionVO;
import mx.com.metlife.tom.fitrava.endorsement.services.error.FitravaException;
import mx.com.metlife.tom.fitrava.endorsement.services.error.HeaderValidationException;
import mx.com.metlife.tom.fitrava.endorsement.services.error.MessagesErrorVO;
import mx.com.metlife.tom.fitrava.endorsement.services.error.ValidationException;
import mx.com.metlife.tom.fitrava.endorsement.services.utility.ConstantUtility;

/**
 * TomErrorController is the controller which handles the error thrown by the
 * code
 * 
 * @author Capgemini
 * @since 04/30/2019
 */
@RestControllerAdvice
public class FitravaErrorController {
	private static final Logger logger = getLogger(FitravaErrorController.class);

	@ExceptionHandler(value = { ValidationException.class, HeaderValidationException.class })
	public @ResponseBody ResponseEntity<MessagesErrorVO> validationException(ValidationException exception) {
		List<String> errorsList = new ArrayList<>();
		errorsList.add(exception.getMessage());
		ErrorExtensionVO specific = new ErrorExtensionVO(null, errorsList);
		List<ErrorExtensionVO> errors = new ArrayList<>();
		errors.add(specific);
		MessagesErrorVO messagesErrorVO = new MessagesErrorVO(ERROR_CODE_400, exception.getMessage(), errors);
		return new ResponseEntity<>(messagesErrorVO, HttpStatus.BAD_REQUEST);

	}

	@ExceptionHandler(AuthorizationException.class)
	public @ResponseBody ResponseEntity<MessagesErrorVO> authorizationException(AuthorizationException exception) {

		List<String> errorsList = new ArrayList<>();
		errorsList.add(exception.getMessage());
		ErrorExtensionVO specific = new ErrorExtensionVO(null, errorsList);
		List<ErrorExtensionVO> errors = new ArrayList<>();
		errors.add(specific);
		MessagesErrorVO messagesErrorVO = new MessagesErrorVO(ERROR_CODE_401, exception.getMessage(), errors);
		return new ResponseEntity<>(messagesErrorVO, HttpStatus.UNAUTHORIZED);

	}

	@ExceptionHandler(FitravaException.class)
	public @ResponseBody ResponseEntity<MessagesErrorVO> generalPortfolioException(FitravaException exception) {
		List<String> errorsList = new ArrayList<>();
		FitravaErrorController errorController = new FitravaErrorController();
		String errorString = errorController.getErrorTrace(exception);
		errorsList.add(exception.getMessage());
		errorsList.add(errorString);
		ErrorExtensionVO specific = new ErrorExtensionVO(null, errorsList);
		List<ErrorExtensionVO> errors = new ArrayList<>();
		errors.add(specific);
		MessagesErrorVO messagesErrorVO = new MessagesErrorVO(ERROR_CODE_500, exception.getMessage(), errors);
		return new ResponseEntity<>(messagesErrorVO, HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@ExceptionHandler(Exception.class)
	public @ResponseBody ResponseEntity<MessagesErrorVO> generalException(Exception exception) {
		List<String> errorsList = new ArrayList<>();
		errorsList.add(exception.getLocalizedMessage());
		errorsList.add(ERROR_CODE_500);
		ErrorExtensionVO specific = new ErrorExtensionVO(null, errorsList);
		List<ErrorExtensionVO> errors = new ArrayList<>();
		errors.add(specific);
		MessagesErrorVO messagesErrorVO = new MessagesErrorVO(ERROR_CODE_500, exception.getMessage(), errors);
		return new ResponseEntity<>(messagesErrorVO, HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@ExceptionHandler(NullPointerException.class)
	public @ResponseBody ResponseEntity<MessagesErrorVO> nullPointerException(NullPointerException exception) {
		StringWriter er = new StringWriter();
		exception.printStackTrace(new PrintWriter(er));
		logger.error(er.toString());
		FitravaErrorController errorController = new FitravaErrorController();
		String errorString = errorController.getErrorTrace(exception);
		List<String> errorsList = new ArrayList<>();
		errorsList.add(errorString);
		errorsList.add(ERROR_CODE_500);
		ErrorExtensionVO specific = new ErrorExtensionVO(null, errorsList);
		List<ErrorExtensionVO> errors = new ArrayList<>();
		errors.add(specific);
		MessagesErrorVO messagesErrorVO = new MessagesErrorVO(ERROR_CODE_500, exception.getMessage(), errors);
		return new ResponseEntity<>(messagesErrorVO, HttpStatus.INTERNAL_SERVER_ERROR);
	}

	public String getErrorTrace(Exception exception) {
		String topStack = exception.getStackTrace()[0].getClassName().concat(ARROW)
				.concat(exception.getStackTrace()[0].getMethodName()).concat(ARROW)
				.concat(String.valueOf(exception.getStackTrace()[0].getLineNumber()));
		String secondStack = ConstantUtility.EMPTY_STRING;
		List<StackTraceElement> errorStackTrace = asList(exception.getStackTrace()).stream()
				.filter(obj -> obj.getClassName().contains("mx")).collect(toList());

		if (topStack.contains(ConstantUtility.OBJECTS) && errorStackTrace.get(0) != null) {
			secondStack = (errorStackTrace.get(0).getClassName() == null ? ConstantUtility.EMPTY_STRING : errorStackTrace.get(0).getClassName())
					.concat(ARROW)
					.concat(errorStackTrace.get(0).getMethodName() == null ? ConstantUtility.EMPTY_STRING 
							: errorStackTrace.get(0).getMethodName())
					.concat(ARROW).concat(String.valueOf(errorStackTrace.get(0).getLineNumber()));
		}
		return topStack.concat(secondStack);
	}

}
