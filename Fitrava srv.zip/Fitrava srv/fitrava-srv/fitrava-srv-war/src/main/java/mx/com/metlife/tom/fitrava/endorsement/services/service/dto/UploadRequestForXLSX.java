package mx.com.metlife.tom.fitrava.endorsement.services.service.dto;

import lombok.Data;

@Data
public class UploadRequestForXLSX {

	private boolean isMasive;
	private String promotion;
	private String agentName;
	private String agentCode;
	private String dcn;
	private String source;
}
