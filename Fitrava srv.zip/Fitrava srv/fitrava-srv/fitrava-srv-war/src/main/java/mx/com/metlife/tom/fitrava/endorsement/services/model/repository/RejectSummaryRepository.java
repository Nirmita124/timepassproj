package mx.com.metlife.tom.fitrava.endorsement.services.model.repository;

import static mx.com.metlife.tom.fitrava.endorsement.services.utility.ConstantUtility.DCN1;
import static mx.com.metlife.tom.fitrava.endorsement.services.utility.ConstantUtility.DCN2;
import static mx.com.metlife.tom.fitrava.endorsement.services.utility.ConstantUtility.DCN3;
import static mx.com.metlife.tom.fitrava.endorsement.services.utility.ConstantUtility.DCN4;
import static mx.com.metlife.tom.fitrava.endorsement.services.utility.ConstantUtility.GET_QUERY_BOSY;
import static mx.com.metlife.tom.fitrava.endorsement.services.utility.ConstantUtility.GET_QUERY_HEADER_GCAYE;
import static mx.com.metlife.tom.fitrava.endorsement.services.utility.ConstantUtility.GET_QUERY_HEADER_LAYOUT;
import static mx.com.metlife.tom.fitrava.endorsement.services.utility.ConstantUtility.SUCCESS_TEXT;
import static mx.com.metlife.tom.fitrava.endorsement.services.utility.ConstantUtility.TEXT_FAILURE;
import static mx.com.metlife.tom.fitrava.endorsement.services.utility.ConstantUtility.TEXT_REGISTRYS;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import mx.com.metlife.tom.fitrava.endorsement.services.model.entity.TLayoutFld;
import mx.com.metlife.tom.fitrava.endorsement.services.service.dto.UploadRejSummaryQueryResultDTO;
import mx.com.metlife.tom.fitrava.endorsement.services.service.dto.UploadUploadStatusDTO;

@SuppressWarnings("rawtypes")
@Repository
@Qualifier("rejectRepository")
public class RejectSummaryRepository extends BaseRepository {
	@Resource
	TLayoutFldRepository layoutFieldRepo;

	@SuppressWarnings("unchecked")
	public List<UploadRejSummaryQueryResultDTO> getQueryResult(String dcn) {
		Query query = getEntityManager().createNativeQuery(GET_QUERY_BOSY);
		query.setParameter(DCN1, dcn);
		query.setParameter(DCN2, dcn);

		List<Object[]> endormentSummaryList = query.getResultList();
		return getListofObject(endormentSummaryList);

	}

	public List<UploadRejSummaryQueryResultDTO> getListofObject(List<Object[]> summayList) {

		List<UploadRejSummaryQueryResultDTO> objectList = new ArrayList<>();
		UploadRejSummaryQueryResultDTO summaryObject = null;
		for (Object[] object : summayList) {
			TLayoutFld layoutFld = layoutFieldRepo.getOne(Long.parseLong(object[1].toString()));
			
			summaryObject = new UploadRejSummaryQueryResultDTO();
			summaryObject.setRecNum(Integer.parseInt(object[0].toString()));
			summaryObject.setLayoutField(layoutFld.getLayoutFldDscr());
			summaryObject.setDescription(object[2].toString());
			summaryObject.setType(object[3].toString());
			objectList.add(summaryObject);
		}
		return objectList;
	}

	
	 
	@SuppressWarnings("unchecked")
	public UploadUploadStatusDTO getQueryResultHeaders(String dcn, boolean isGcaye) {
		Query query = null;
		if (isGcaye) {
			query = getEntityManager().createNativeQuery(GET_QUERY_HEADER_GCAYE);
		} else {
			query = getEntityManager().createNativeQuery(GET_QUERY_HEADER_LAYOUT);
		}
		query.setParameter(DCN1, dcn);
		query.setParameter(DCN2, dcn);
		query.setParameter(DCN3, dcn);
		query.setParameter(DCN4, dcn);

		List<Object[]> endormentSummaryList = query.getResultList();
		UploadUploadStatusDTO errorStatus = new UploadUploadStatusDTO();
		for (Object[] objects : endormentSummaryList) {
			switch (objects[0].toString()) {
			case TEXT_FAILURE:
				errorStatus.setFailure(Integer.parseInt(objects[1].toString()));
				break;
			case SUCCESS_TEXT:
				errorStatus.setSuccess(Integer.parseInt(objects[1].toString()));
				break;
			case TEXT_REGISTRYS:
				errorStatus.setRegistrys(Integer.parseInt(objects[1].toString()));
				break;
			default:
				break;
			}
		}
		return errorStatus;
	}
}
