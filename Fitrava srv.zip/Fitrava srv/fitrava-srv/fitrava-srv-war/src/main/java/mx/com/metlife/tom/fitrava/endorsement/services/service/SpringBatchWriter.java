package mx.com.metlife.tom.fitrava.endorsement.services.service;

import static org.slf4j.LoggerFactory.getLogger;

import java.util.List;

import org.slf4j.Logger;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import mx.com.metlife.tom.fitrava.endorsement.services.service.dto.TProcDTO;
import mx.com.metlife.tom.fitrava.endorsement.services.utility.ConstantUtility;

@Component
public class SpringBatchWriter implements ItemWriter<List<TProcDTO>> {
	private static final Logger logger = getLogger(SpringBatchWriter.class);
	
	@Autowired
	ApplicationContext applicationContext;
	
	@Autowired
	CallBPMProcess bpmServiceUtility;

	@Override
	public void write(List<? extends List<TProcDTO>> items) throws Exception {

		SpringBatchService springBatchService = applicationContext.getBean(SpringBatchService.class);	

		for (List<TProcDTO> list : items) {
			for (TProcDTO newRcrdList : list) {
				bpmServiceUtility.callBPMService(0, newRcrdList.getDstnctCtrlNum());

				springBatchService.updateStatus(newRcrdList.getDstnctCtrlNum());
			}
		}

		logger.info(ConstantUtility.IN_WRITER);
	}

}
