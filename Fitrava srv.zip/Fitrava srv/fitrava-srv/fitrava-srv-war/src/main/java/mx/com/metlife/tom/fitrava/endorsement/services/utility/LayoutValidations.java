package mx.com.metlife.tom.fitrava.endorsement.services.utility;

import static mx.com.metlife.tom.fitrava.endorsement.services.utility.ConstantUtility.*;
import static mx.com.metlife.tom.fitrava.endorsement.services.utility.MethodUtility.flattenToAscii;
import static mx.com.metlife.tom.fitrava.endorsement.services.utility.MethodUtility.getFileExtension;
import static mx.com.metlife.tom.fitrava.endorsement.services.utility.MethodUtility.isNullOrBlank;
import static org.slf4j.LoggerFactory.getLogger;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.slf4j.Logger;
import org.springframework.web.multipart.MultipartFile;

import mx.com.metlife.tom.fitrava.endorsement.services.service.dto.TProcRecDTO;

public class LayoutValidations {
	private LayoutValidations() {
		
	}
	private static final Logger logger = getLogger(LayoutValidations.class);

	public static boolean validateJsonFilePresent(MultipartFile[] files) {
		boolean isJsonPresent = false;

		for (MultipartFile multipartFile : files) {
			logger.info(ConstantUtility.FITRAVA_SERVICE_FILE_NAME, multipartFile.getOriginalFilename());
			if (getFileExtension(multipartFile.getOriginalFilename())
					.equalsIgnoreCase(ConstantUtility.FILE_TYPE_JSON)) {
				isJsonPresent = true;
			}
		}
		return isJsonPresent;
	}

	public static int validateFiles(MultipartFile[] files) {
		boolean isJsonPresent = false;
		boolean isXlsxPresent = false;
		int returnCode=0;
		for (MultipartFile multipartFile : files) {
			logger.info(ConstantUtility.FITRAVA_SERVICE_FILE_NAME, multipartFile.getOriginalFilename());
			if (getFileExtension(multipartFile.getOriginalFilename())
					.equalsIgnoreCase(ConstantUtility.FILE_TYPE_JSON)) {
				isJsonPresent = true;
			} else if (getFileExtension(multipartFile.getOriginalFilename())
					.equalsIgnoreCase(ConstantUtility.FILE_TYPE_XLSX)) {
				isXlsxPresent = true;
			} else {
				returnCode = 1;
			}
		}
		
		returnCode = isJsonPresent && isXlsxPresent ? 0 : 1;
		return returnCode;
	}

	public static TProcRecDTO validateLength(LayoutDefinition layout, TProcRecDTO dto) {
		if (dto.getNewValue().length() <= layout.getLength()) {
			dto.setErrorIndicator(true);
			dto.setMsgText(ConstantUtility.BLANK);
		} else {
			dto.setMsgText(ConstantUtility.LENGTH_ERROR);
			dto.setErrorIndicator(false);
		}
		return dto;
	}
	public static TProcRecDTO checkMendatory(LayoutDefinition layout, String value, boolean isNullOrBlank,
			TProcRecDTO dto) {
		Boolean isMandatory = layout.getIsMandatory();
		if (null != isMandatory) {
			if (isMandatory && !isNullOrBlank) {
				dto.setErrorIndicator(true);
				dto.setMsgText(ConstantUtility.BLANK);
				return dto;
			}

			if (!isMandatory && isNullOrBlank) {
				dto.setErrorIndicator(true);
				dto.setMsgText(ConstantUtility.BLANK);
				return dto;
			}

			if (!isMandatory && !isNullOrBlank) {
				dto.setErrorIndicator(true);
				dto.setMsgText(ConstantUtility.BLANK);
				return dto;
			}

			if (isMandatory && isNullOrBlank) {
				dto.setErrorIndicator(false);
				dto.setMsgText(ConstantUtility.CONODITION_MANDATOTY_ERROR);
				return dto;
			}

		} else {
			boolean isMandatoryConditional = false;
			if (layout.getExcelColumnName().equals(COLUMNF) || layout.getExcelColumnName().equals(COLUMNI) || layout.getExcelColumnName().equals(COLUMNJ)
					|| layout.getExcelColumnName().equals(COLUMNK) || layout.getExcelColumnName().equals(COLUMNL)  || layout.getExcelColumnName().equals(COLUMNM) 
					|| layout.getExcelColumnName().equals(COLUMNP)) {
				List<String> mandatoryValues = new ArrayList<>(Arrays.asList("1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11","12", "13", "14"));
				isMandatoryConditional = mandatoryValues.contains(value);
				
				if (isMandatoryConditional && !isNullOrBlank) {
					dto.setErrorIndicator(true);
					dto.setMsgText(ConstantUtility.BLANK);
					return dto;
				}
			}

			if (layout.getExcelColumnName().equals(COLUMNO) || layout.getExcelColumnName().equals(COLUMNP)) {
				List<String> mandatoryValues = new ArrayList<>(Arrays.asList("1", "2", "5", "6", "7", "8", "9", "10", "11","12", "13", "14"));
				isMandatoryConditional = mandatoryValues.contains(value);

				if (isMandatoryConditional && !isNullOrBlank) {
					dto.setErrorIndicator(true);
					dto.setMsgText(ConstantUtility.BLANK);
					return dto;
				}
			}
			
			if (layout.getExcelColumnName().equals(COLUMNT)) {
				if (isNullOrBlank) {
					dto.setNewValue(LocalDate.now().format(DateTimeFormatter.BASIC_ISO_DATE));
				}
				dto.setErrorIndicator(true);
				dto.setMsgText(ConstantUtility.BLANK);
				return dto;
			}

			if (layout.getExcelColumnName().equals(COLUMNG)) {
				List<String> mandatoryValues = new ArrayList<>(Arrays.asList("1", "2", "3", "7", "9", "11", "15"));
				isMandatoryConditional = mandatoryValues.contains(value);
				
				if (isMandatoryConditional && !isNullOrBlank) {
					dto.setErrorIndicator(true);
					dto.setMsgText(ConstantUtility.BLANK);
					return dto;
				}
			}

			if (!isMandatoryConditional && isNullOrBlank) {
				dto.setErrorIndicator(true);
				dto.setMsgText(ConstantUtility.BLANK);
				return dto;
			}

			dto.setErrorIndicator(false);
			dto.setMsgText(ConstantUtility.CONODITION_MANDATOTY_ERROR);
			return dto;
		}

		
		return dto;
	}

	public static TProcRecDTO checkDateMasking(String maskType, TProcRecDTO dto) {
		try {
			if (maskType.equalsIgnoreCase(ConstantUtility.YYYYMMDD) && !isNullOrBlank(dto.getOriginalValue()))
				LocalDate.parse(dto.getOriginalValue(), DateTimeFormatter.BASIC_ISO_DATE);
			else if (maskType.equalsIgnoreCase(ConstantUtility.YYYY_MM_DD) && !isNullOrBlank(dto.getOriginalValue()))
				LocalDate.parse(dto.getOriginalValue(), DateTimeFormatter.ISO_DATE);

			return dto;
		} catch (Exception e) {
			dto.setMsgText(dto.getMsgText().concat(ConstantUtility.MASKING_ERROR));
			dto.setErrorIndicator(false);

			return dto;
		}
	}

	public static boolean isColumnLayoutoutMatched(List<String> columnNames) {
		ArrayList<String> colListFromLayoutDef = (ArrayList<String>) LayoutDefinition.getColumnNames();
		boolean isValid = false;
		if (columnNames.size() >= colListFromLayoutDef.size()) {
			for (int i = 0; i < 72; i++) {
				String flattenColValue = flattenToAscii(columnNames.get(i).trim());
				isValid = flattenColValue.equalsIgnoreCase(colListFromLayoutDef.get(i));
			}
		}
		return isValid;
	}
	
}
