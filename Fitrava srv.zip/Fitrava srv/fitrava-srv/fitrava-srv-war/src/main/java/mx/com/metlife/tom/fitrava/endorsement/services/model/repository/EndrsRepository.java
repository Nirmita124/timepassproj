package mx.com.metlife.tom.fitrava.endorsement.services.model.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceUnit;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import lombok.extern.slf4j.Slf4j;
import mx.com.metlife.tom.fitrava.endorsement.services.model.entity.TEndrs;
import mx.com.metlife.tom.fitrava.endorsement.services.model.entity.TEndrsBene;
import mx.com.metlife.tom.fitrava.endorsement.services.model.entity.TWrkOrd;

@Repository
@Slf4j
public class EndrsRepository  {
	
	@PersistenceUnit(unitName = "fitravaEntityManagerPU")
	private EntityManagerFactory entityManagerFactory;
	
	public TEndrs saveTEndrs(TEndrs endrs) {
		log.info("in saveTEndrs : {}", endrs.getIdEndorsement());
		EntityManager em = null;
		try {
			em = entityManagerFactory.createEntityManager();
			em.getTransaction().begin();
			em.persist(endrs);
			em.getTransaction().commit();
			log.info("in saveTEndrs : Success");
			return endrs;
		} catch (Exception e) {
			em.getTransaction().rollback();
			log.error("ERROR saveTEndrs : {}", e.getLocalizedMessage());
		} finally {
			if (null != em) {
				em.close();
			}
		}
		return null;
	}
	
	public TEndrsBene saveBeneficiary(TEndrsBene beneficiary) {
		log.info("in saveBeneficiary : {}", beneficiary.getBeneficiaryName());
		EntityManager em = null;
		try {
			em = entityManagerFactory.createEntityManager();
			em.getTransaction().begin();
			em.persist(beneficiary);
			em.getTransaction().commit();
			log.info("in saveBeneficiary : Success");
			return beneficiary;
		} catch (Exception e) {
			em.getTransaction().rollback();
			log.error("ERROR saveBeneficiary : {}", e.getLocalizedMessage());
		} finally {
			if (null != em) {
				em.close();
			}
		}
		return null;
	}
	
	public TWrkOrd saveWrkOrd(TWrkOrd wo) {
		log.info("in saveWrkOrd : {}", wo.getWorkOrderName());
		EntityManager em = null;
		try {
			em = entityManagerFactory.createEntityManager();
			em.getTransaction().begin();
			em.persist(wo);
			em.getTransaction().commit();
			log.info("in saveWrkOrd : Success");
			return wo;
		} catch (Exception e) {
			em.getTransaction().rollback();
			log.error("ERROR saveWrkOrd : {}", e.getLocalizedMessage());
		} finally {
			if (null != em) {
				em.close();
			}
		}
		return null;
	}
	
	@SuppressWarnings("unchecked")
	public TWrkOrd findTWorkOrder(String dcn, String wo) {
		EntityManager em = entityManagerFactory.createEntityManager();
		Query q = em.createQuery("SELECT C FROM TWrkOrd C WHERE C.procedure.folio = :dcn AND C.workOrderName = :wo ");
		q.setParameter("dcn", dcn);
		q.setParameter("wo", wo);
		List<TWrkOrd> two = q.getResultList();
		em.close();
		if( two.size() > 0) {
			return two.get(0);
		}else {
			return null;
		}
	}
}
