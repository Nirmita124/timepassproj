package mx.com.metlife.tom.fitrava.endorsement.services.model.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@SuppressWarnings("serial")
@Data
@Entity
@Table(name = "T_FILE_PROC")
public class TProc implements java.io.Serializable{

	@Id
	@Column(name = "DSTNCT_CTRL_NUM")
	private String dstnctCtrlNum;

	@Column(name = "FLOW_ID")
	private Long flowId;
	
	@Column(name = "ENTRNC_LAYOUT_ID")
	private Long entrncLayoutId;

	@Column(name = "RCPTN_TS")
	private Date rcptnTs;

	@Column(name = "PRTY_NUM")
	private Integer prtyNum;

	@Column(name = "CRT_USR_ID")
	private String crtUsrId;

	@Column(name = "CLCT_STTS_ID")
	private Integer clctStts;
	
	@Column(name = "RSLT_DSCR")
	private String rsltDscr;
	
	@Column(name = "SRC_FLD_NM") 
	private String sourceField;
	
	@Column(name = "ADDL_FLD_TXT")
	private String adtField;
	
}
