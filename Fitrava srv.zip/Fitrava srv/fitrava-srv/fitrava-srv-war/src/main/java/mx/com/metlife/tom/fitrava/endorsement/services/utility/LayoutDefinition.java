package mx.com.metlife.tom.fitrava.endorsement.services.utility;

import static mx.com.metlife.tom.fitrava.endorsement.services.utility.ConstantUtility.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public enum LayoutDefinition {
	CLAVE_DE_AGENTE		(AGENTE, 5, NUMERIC, false, null, 1, COLUMNA),
	FETCHA_MOVIMIENTO	(MOVIMIENTO, 8, NUMERIC, true, YYYYMMDD, 2, COLUMNB), 
	RAMO_SUB_RAMO		(RAMO, 5, NUMERIC, true, null, 3, COLUMNC),
	NUMERO_DE_POLIZA	(POLIZA, 7, NUMERIC, true, null, 4, COLUMND),
	NUMERO_DE_SUBGRUPO	(SUBGRUPO, 3, NUMERIC, false, null, 5, COLUMNE),
	NUMERO_DE_CATEGORIA	(CATEGORIA, 3, NUMERIC, null, null, 6, COLUMNF),
	NUMERO_DE_ASEGURADO (ASEGURADO, 13, NUMERIC, null, null, 7, COLUMNG),
	NOMBRE_DE_SUBGRUPO	(NOMBRE_SUBGRUPO, 20, ALPHANUMERIC, false, null, 8, COLUMNH),
	TIPO_DE_MOVIMIENTO	(TIPO_MOVIMIENTO, 2, NUMERIC, null, null, 9, COLUMNI),
	ORDEN_DE_TRABAJO	(TRABAJO, 25, ALPHANUMERIC, null, null, 10, COLUMNJ),
	NOMBRE_ASEGURADO	(ASEGURDO, 25, ALPHANUMERIC, null, null, 11, COLUMNK),
	APELLIDO_PATERNO	(PATERNO, 40, ALPHANUMERIC, null, null, 12, COLUMNL),
	APELLIDO_MATERNO	(MATERNO, 40, ALPHANUMERIC, true, null, 13, COLUMNM),
	FECHA_DE_NACIMIENTO	(NACIMIENTO, 8, NUMERIC, null, YYYYMMDD, 14, COLUMNN),
	SEXO				(SEX, 1, NUMERIC, null, null, 15, COLUMNO), 
	PARENTESCO			(PARENTSCO, 1, NUMERIC, null, null, 16, COLUMNP),
	ESTADO_CIVIL		(ESTADO, 2, NUMERIC, false, null, 17, COLUMNQ),
	SUELDO				(SUELDOE, 12, NUMERIC, true, null, 18, COLUMNR), 
	FECHA_ALTA			(ALTA, 8, NUMERIC, false, YYYYMMDD, 19, COLUMNS),
	FECHA_BAJA			(BAJA, 8, NUMERIC, null, YYYYMMDD, 20, COLUMNT),
	FECHA_INGRESO_EMP	(FECHA_INGRESO, 8, NUMERIC, false, YYYYMMDD, 21, COLUMNU),
	FECHA_DE_ANTIGUEDAD	(ANTIGUEDAD, 8, NUMERIC, false, YYYYMMDD, 22, COLUMNV),
	FECHA_ASEGURADO_DESDE(ASEGURADO_DESDE, 8, NUMERIC, false, YYYYMMDD, 23, COLUMNW),
	EDAD				(EDADD, 3, NUMERIC, false, null, 24, COLUMNX), 
	CURP				(CURPP, 20, ALPHANUMERIC, false, null, 25, COLUMNY),
	RFC					(RFCC, 13, ALPHANUMERIC, false, null, 26, COLUMNZ),
	NIVEL				(NIVELL, 5, ALPHANUMERIC, false, null, 27, COLUMNAA),
	CENTRO_DE_TRABAJO	(CENTRO_TRABAJO, 27, ALPHANUMERIC, false, null, 28, COLUMNAB),
	NUMERO_DE_EMPLEADO	(EMPLEADO, 10, ALPHANUMERIC, false, null, 29, COLUMNAC),
	SUMA_AUTO_BASICA_BASE(BASICA_BASE, 13, NUMERIC, false, null, 30, COLUMNAD),
	SUMA_AUTO_BASICA_POT(BASICA_POT, 13, NUMERIC, false, null, 31, COLUMNAE),
	CLAVE_RETENEDOR		(RETENEDOR, 4, NUMERIC, false, null, 32, COLUMNAF),
	UNIDAD_DE_PAGO		(PAGO, 4, NUMERIC, false, null, 33, COLUMNAG),
	CONDUCTO_COBRO_INDIVIDUAL   (INDIVIDUAL, 2, NUMERIC, false, null, 34, COLUMNAH),
	FORMA_DE_PAGO_INDIVIDUAL    (PAGO_INDIVIDUAL, 2, NUMERIC, false, null, 35, COLUMNAI),
	CLAVE_DE_BANCO_INDIVIDUAL   (BANCO_INDIVIDUAL, 1, NUMERIC, false, null, 36, COLUMNAJ),
	NUMERO_DE_CUENTA_DE_BANCO   (CUENTA_DE_BANCO, 18, NUMERIC, false, null, 37, COLUMNAK),
	NUMERO_DE_CUENTA_DE_TARJETA (CUENTA_TARJETA, 16, NUMERIC, false, null, 38, COLUMNAL),
	VENCIMIENTO_TARJETA         (TARJETA, 4, NUMERIC, false, null, 39, COLUMNAM),
	UBICACION_FRONTERIZA        (FRONTERIZA, 1, NUMERIC, false, null, 40, COLUMNAN),
	CALLE                       (CALLEE, 50, ALPHANUMERIC, false, null, 41, COLUMNAO),
	NUMERO_EXTERIOR             (EXTERIOR, 10, ALPHANUMERIC, false, null, 42, COLUMNAP),
	NUMERO_INTERIOR             (INTERIOR, 10, ALPHANUMERIC, false, null, 43, COLUMNAQ),
	COLONIA                     (COLONIAA, 25, ALPHANUMERIC, false, null, 44, COLUMNAR),
	POBLACION                   (POBLACIONN, 25, ALPHANUMERIC, false, null, 45, COLUMNAS),
	CODIGO_POSTAL               (POSTAL, 5, NUMERIC, false, null, 46, COLUMNAT),
	CORREO_ELECTRONICO          (ELECTRONICO, 25, ALPHANUMERIC, false, null, 47, COLUMNAU),
	TELEFONO                    (TELEFON, 13, NUMERIC, false, null, 48, COLUMNAV),

	BENEFICIARIO_1              (BENEFICIARIO1, 53, ALPHANUMERIC, false, null, 49, COLUMNAW),
	PARENTESCO_1                (PARENTESCO1, 15, ALPHANUMERIC, false, null, 50, COLUMNAX),
	PORCENTAJE_1                (PORCENTAJE1, 4, NUMERIC, false, null, 51, COLUMNAY),

	BENEFICIARIO_2              (BENEFICIARIO2, 53, ALPHANUMERIC, false, null, 52, COLUMNAZ),
	PARENTESCO_2                (PARENTESCO2, 15, ALPHANUMERIC, false, null, 53, COLUMNBA),
	PORCENTAJE_2                (PORCENTAJE2, 4, NUMERIC, false, null, 54, COLUMNBB),
	
	BENEFICIARIO_3              (BENEFICIARIO3, 53, ALPHANUMERIC, false, null, 55, COLUMNBC),
	PARENTESCO_3				(PARENTESCO3, 15, ALPHANUMERIC, false, null, 56, COLUMNBD),
	PORCENTAJE_3				(PORCENTAJE3, 4, NUMERIC, false, null, 57, COLUMNBE),
	
	BENEFICIARIO_4				(BENEFICIARIO4, 53, ALPHANUMERIC, false, null, 58, COLUMNBF),
	PARENTESCO_4				(PARENTESCO4, 15, ALPHANUMERIC, false, null, 59, COLUMNBG),
	PORCENTAJE_4				(PORCENTAJE4, 4, NUMERIC, false, null, 60, COLUMNBH),
	
	BENEFICIARIO_5				(BENEFICIARIO5, 53, ALPHANUMERIC, false, null, 61, COLUMNBI),
	PARENTESCO_5				(PARENTESCO5, 15, ALPHANUMERIC, false, null, 62, COLUMNBJ),
	PORCENTAJE_5				(PORCENTAJE5, 4, NUMERIC, false, null, 63, COLUMNBK),
	
	BENEFICIARIO_6				(BENEFICIARIO6, 53, ALPHANUMERIC, false, null, 64, COLUMNBL),
	PARENTESCO_6				(PARENTESCO6, 15, ALPHANUMERIC, false, null, 65, COLUMNBM),
	PORCENTAJE_6				(PORCENTAJE6, 4, NUMERIC, false, null, 66, COLUMNBN),
	
	TIPO_PLAZA					(TIPO_PLAZAA, 1, NUMERIC, false, null, 67, COLUMNBO),
	TRATAMIENTO					(TRATAMINTO, 5, ALPHANUMERIC, false, null, 68, COLUMNBP),
	PUESTO						(PESTO, 10, ALPHANUMERIC, false, null, 69, COLUMNBQ),
	
	CONCEPTO_DESCRITO			(DESCRITO, 3, NUMERIC, false, null, 70, COLUMNBR), //changed from ALPHANUMERIC to NUMERIC
	ADSCRIPCION					(ADSCRIPION, 10, ALPHANUMERIC, false, null, 71, COLUMNBS),
	BT1							(BT, 2, NUMERIC, false, null, 72, COLUMNBT);
	
	public String getFieldName() {
		return fieldName;
	}

	public Integer getLength() {
		return length;
	}

	public String getDataType() {
		return dataType;
	}

	public Boolean getIsMandatory() {
		return isMandatory;
	}

	public String getMask() {
		return mask;
	}

	public String getExcelColumnName() {
		return excelColumnName;
	}

	String fieldName;
	Integer length;
	String dataType;
	Boolean isMandatory;
	String mask;
	Integer seqNumber;
	String excelColumnName;

	private LayoutDefinition(String fieldName, Integer length, String dataType, Boolean inMandatory, String mask,
			Integer seqNumber, String excelColumnName) {
		this.fieldName = fieldName;
		this.length = length;
		this.dataType = dataType;
		this.isMandatory = inMandatory;
		this.mask = mask;
		this.seqNumber = seqNumber;
		this.excelColumnName = excelColumnName;
	}


	public static LayoutDefinition getLayoutBySeqNumber(Integer sequence) {
		List<LayoutDefinition> allColumns = Arrays.asList(LayoutDefinition.values());
		for (LayoutDefinition layoutDefinition : allColumns) {
			if (layoutDefinition.getSeqNumber().equals(sequence)) {
				return layoutDefinition;
			}
		}
		return null;
	}

	public static LayoutDefinition getLayoutByFieldName(Object object) {

		List<LayoutDefinition> allColumns = Arrays.asList(LayoutDefinition.values());
		for (LayoutDefinition layoutDefinition : allColumns) {
			if (layoutDefinition.getFieldName().equalsIgnoreCase((String) object)) {
				return layoutDefinition;
			}
		}
		return null;
	}
	
	public static LayoutDefinition getLayoutByExcelColumnName(String columnName) {
		List<LayoutDefinition> allColumns = Arrays.asList(LayoutDefinition.values());
		for (LayoutDefinition layoutDefinition : allColumns) {
			if (layoutDefinition.getExcelColumnName().equalsIgnoreCase(columnName)) {
				return layoutDefinition;
			}
		}
		return null;
	}

	public static List<String> getColumnNames() {
		List<String> columnNames = new ArrayList<>();

		List<LayoutDefinition> allColumns = Arrays.asList(LayoutDefinition.values());
		for (LayoutDefinition layoutDefinition : allColumns) {
			columnNames.add(layoutDefinition.getFieldName());

		}
		return columnNames;
	}

	public Integer getSeqNumber() {
		return seqNumber;
	}

}
