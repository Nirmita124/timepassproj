package mx.com.metlife.tom.fitrava.endorsement.services.model.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@SuppressWarnings("serial")
@Data
@Entity
@Table(name = "T_FLOW")
public class TFlow implements java.io.Serializable {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "FLOW_ID")
	private Long flowId = null;

	@Column(name = "EAI_CD")
	private String eaiCd = null;

	@Column(name = "FLOW_NM")
	private String flowNm = null;

	@Column(name = "FLOW_DSCR")
	private String flowDscr = null;

	@Column(name = "DFLT_ENTRNC_LAYOUT_ID")
	private Long dfltEntrncLayoutId = null;

	@Column(name = "OUTPUT_LAYOUT_ID")
	private Long outputLayoutId = null;

	@Column(name = "CRT_USR_ID")
	private String crtUsrId = null;

	@Column(name = "ALLW_EXT_TXT")
	private String allwExtTxt = null;

	@Column(name = "OUTPUT_FILE_PTRN_NM")
	private String outputFilePtrnNm = null;

	@Column(name = "CRT_TS")
	private Date crtTs = null;

	@Column(name = "UPDT_TS")
	private Date updtTs = null;

	@Column(name = "LST_MOD_USR_ID")
	private String lstModUsrId = null;

	@Column(name = "FLOW_ACT_IND")
	private Integer flowActInd = null; 
}
