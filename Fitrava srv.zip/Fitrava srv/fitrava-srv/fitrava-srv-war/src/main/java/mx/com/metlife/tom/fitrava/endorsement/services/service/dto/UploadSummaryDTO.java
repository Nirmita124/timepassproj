package mx.com.metlife.tom.fitrava.endorsement.services.service.dto;

import java.util.List;

import lombok.Data;

@Data
public class UploadSummaryDTO {
	Integer registryNumber;
	List<String> errors;

}
