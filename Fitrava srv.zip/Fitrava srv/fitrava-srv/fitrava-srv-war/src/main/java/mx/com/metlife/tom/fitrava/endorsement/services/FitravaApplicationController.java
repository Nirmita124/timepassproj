package mx.com.metlife.tom.fitrava.endorsement.services;

import static mx.com.metlife.tom.fitrava.endorsement.services.utility.ConstantUtility.APP_CONTEXT;

import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.data.jpa.JpaRepositoriesAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;

@EnableBatchProcessing
@EnableScheduling
@SpringBootApplication(exclude = { DataSourceAutoConfiguration.class, HibernateJpaAutoConfiguration.class,JpaRepositoriesAutoConfiguration.class })
public class FitravaApplicationController extends SpringBootServletInitializer {

	 	
	private long maxUploadSizeInMb = 500 * 1024 * 1024l; // 5 MB
	
	public static void main(String[] args) {
	
		ApplicationContext applicationContext = SpringApplication.run(FitravaApplicationController.class, args);
		AutowireCapableBeanFactory factory = applicationContext.getAutowireCapableBeanFactory();
		factory.autowireBean( applicationContext );
		factory.initializeBean( applicationContext, APP_CONTEXT );
	}
	
	@Override
	   protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
	      return application.sources(FitravaApplicationController.class);
	   }
	 
	@Bean(name = "multipartResolver")
	 public CommonsMultipartResolver multipartResolver() {

	        CommonsMultipartResolver cmr = new CommonsMultipartResolver();
	        cmr.setMaxUploadSize(maxUploadSizeInMb * 2l);
	        cmr.setMaxUploadSizePerFile(maxUploadSizeInMb); //bytes
	        return cmr;

	    }

	

}
