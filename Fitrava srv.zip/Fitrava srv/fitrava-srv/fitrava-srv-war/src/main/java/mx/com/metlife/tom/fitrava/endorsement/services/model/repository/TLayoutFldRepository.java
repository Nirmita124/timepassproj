package mx.com.metlife.tom.fitrava.endorsement.services.model.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import mx.com.metlife.tom.fitrava.endorsement.services.model.entity.TLayoutFld;

public interface TLayoutFldRepository extends JpaRepository<TLayoutFld, Long> {
	
	public TLayoutFld findFirstByLayoutFldNmAndLayoutId(String layoutFldNm, Long layoutId);
	
	public TLayoutFld findFirstBylayoutFldId(Long layoutFldId);
	
	public List<TLayoutFld> findBylayoutId(Long layoutId);
	
}
