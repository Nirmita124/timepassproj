package mx.com.metlife.tom.fitrava.endorsement.services.utility;

import static mx.com.metlife.tom.fitrava.endorsement.services.utility.ConstantUtility.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public enum JsonLayoutDefinition {
	AGENT_KEY         (AGENTKEY,73, COLUMNA),
	MOVE_DATA	      (MOVEDATE, 74, COLUMNB),
	BRACH_SUB_BRANCH  (BRACHSUBBRANCH,75, COLUMNC),
	POLICY_NUMBER     (POLICYNUMBER ,76, COLUMND),
	SUB_GROUP_NUMBER  (SUBGROUPNUMBER ,77, COLUMNE),
	CATEGORY_NUMBER   (CATEGORYNUMBER ,78, COLUMNF),
	INSURED_NUMBER    (INSUREDNUMBER ,79, COLUMNG),
	SUB_GROUP_NAME	  (SUBGROUPNAME ,80, COLUMNH),
	MOVE_TYPE         (MOVETYPE ,81, COLUMNI),
	WORK_ORDER        (WORKORDER ,82, COLUMNJ),
	INSURED_NAME      (INSUREDNAME ,83, COLUMNK),
	LAST_NAME         (LASTNAME ,84, COLUMNL),
	MIDDLE_NAME       (MIDDLENAME ,85, COLUMNM),
	BIRTH_DATE        (BIRTHDATE ,86, COLUMNN),
	GENDER            (GEN_DER ,87, COLUMNO),
	RELATIONSHIP      (RELATION_SHIP,88, COLUMNP),
	CIVIL_STATUS      (CIVILSTATUS ,89, COLUMNQ),
	SALARY            (JSON_SALARY ,90, COLUMNR),
	START_DATE        (STARTDATE ,91, COLUMNS),
	END_DATE          (ENDDATE  ,92, COLUMNT),
	INCOME_DATE_EMPLOYEE(INCOMEDATEEMPLOYEE ,93, COLUMNU),
	ANTIQUED_ATE      (ANTIQUEDATE ,94, COLUMNV),
	SINCE_INSURED_DATE(SINCEINSUREDDATE ,95, COLUMNW),
	YEARS             (YEAR ,96, COLUMNX),
	CURP              (CURPP,97, COLUMNY),
	RFC               (RFCC,98, COLUMNZ),
	LEVEL             (LEVELS,99, COLUMNAA),
	CENTER_WORK       (CENTERWORK ,100, COLUMNAB),
	EMPLOYEE_NUMBER   (EMPLOYEENUMBER ,101, COLUMNAC),
	SUMAUTH_BASIC     (SUMAUTHBASIC ,102, COLUMNAD),
	SUM_AUTH_BASIC_POT(SUMAUTHBASICPOT ,103, COLUMNAE),
	RETAINER_KEY      (RETAINERKEY ,104, COLUMNAF),
	PAY_UNIT          (PAYUNIT ,105, COLUMNAG),
	IND_COL_DUCT      (INDCOLDUCT ,106, COLUMNAH),
	IND_PAY_FORM      (INDPAYFORM ,107, COLUMNAI),
	IND_BANK_KEY      (INDBANKKEY ,108, COLUMNAJ),
	BANK_ACC_NUM      (BANKACCNUM ,109, COLUMNAK),
	CARDACCNUM        (CARD_ACCNUM ,110, COLUMNAL),
	EXPIRATION_CARD   (EXPIRATIONCARD ,111, COLUMNAM),
	BORDER_LINE_LOCA  (BORDERLINELOCA ,112, COLUMNAN),
	STREET            (STREETS,113, COLUMNAO),
	EXT_NUM           (EXTNUM ,114, COLUMNAP),
	INT_NUM           (INTNUM,115, COLUMNAQ),
	SUBURB            (SUBURBB ,116, COLUMNAR),
	TOWN              (TOWNS,117, COLUMNAS),
	PC                (P_C,118, COLUMNAT),
	EMAIL             (EMAILS,119, COLUMNAU),
	PHONE             (PHONES,120, COLUMNAV),
	BENEFICIARY1      (BENEFICIARY_1,121, COLUMNAW),
	RELATIONSHIP1     (RELATIONSHIP_1,122, COLUMNAX),
	PERCENTAGE1       (PERCENTAGE_1,123, COLUMNAY),
	BENEFICIARY2      (BENEFICIARY_2,124, COLUMNAZ),
	RELATIONSHIP2     (RELATIONSHIP_2,125, COLUMNBA),
	PERCENTAGE2       (PERCENTAGE_2,126, COLUMNBB),
	BENEFICIARY3      (BENEFICIARY_3,127, COLUMNBC),
	RELATIONSHIP3	  (RELATIONSHIP_3,128, COLUMNBD),
	PERCENTAGE3	 	  (PERCENTAGE_3,129, COLUMNBE),
	BENEFICIARY4 	  (BENEFICIARY_4,130, COLUMNBF),
	RELATIONSHIP4	  (RELATIONSHIP_4,131, COLUMNBG),
	PERCENTAGE4		  (PERCENTAGE_4,132, COLUMNBH),
	BENEFICIARY5	  (BENEFICIARY_5,133, COLUMNBI),
	RELATIONSHIP5     (RELATIONSHIP_5,134, COLUMNBJ),
	PERCENTAGE5       (PERCENTAGE_5,135, COLUMNBK),
	BENEFICIARY6      (BENEFICIARY_6,136, COLUMNBL),
	RELATIONSHIP6	  (RELATIONSHIP_6,137, COLUMNBM),
	PERCENTAGE6		  (PERCENTAGE_6,138, COLUMNBN),
	PLAZATYPE		  (PLAZA_TYPE,139, COLUMNBO),
	TREATMENT		  (TREATMENTS,140, COLUMNBP),
	JOB				  (JOBS,141, COLUMNBQ),
	DESCRIBED_CONCEPT (DESCRIBEDCONCEPT,142, COLUMNBR),
	ASCRIPTION        (ASCRIPTIONS,143, COLUMNBS),
	BT1        (BT,144, COLUMNBT);

	String fieldName;
	Integer seqNumber;
	String layoutFieldName;

	private JsonLayoutDefinition(String fieldName, Integer seqNumber, String layoutFieldName) {
		this.fieldName = fieldName;
		this.seqNumber = seqNumber;
		this.layoutFieldName = layoutFieldName;
	}

	public static JsonLayoutDefinition getLayoutBySeqNumber(Integer sequence) {

		List<JsonLayoutDefinition> allColumns = Arrays.asList(JsonLayoutDefinition.values());
		for (JsonLayoutDefinition layoutDefinition : allColumns) {
			if (layoutDefinition.getSeqNumber().equals(sequence)) {
				return layoutDefinition;
			}
		}
		return null;
	}

	public static Long getLayoutIDByFieldName(String fielString) {

		List<JsonLayoutDefinition> allColumns = Arrays.asList(JsonLayoutDefinition.values());
		for (JsonLayoutDefinition layoutDefinition : allColumns) {
			if (layoutDefinition.getFieldName().equalsIgnoreCase(fielString)) {
				return Long.valueOf(layoutDefinition.getSeqNumber());
			}
		}
		return null;
	}

	public static JsonLayoutDefinition getLayoutByFieldName(String fielString) {

		List<JsonLayoutDefinition> allColumns = Arrays.asList(JsonLayoutDefinition.values());
		for (JsonLayoutDefinition layoutDefinition : allColumns) {
			if (layoutDefinition.getFieldName().equalsIgnoreCase(fielString)) {
				return layoutDefinition;
			}
		}
		return null;
	}

	public static List<String> getColumnNames() {
		List<String> columnNames = new ArrayList<>();

		List<JsonLayoutDefinition> allColumns = Arrays.asList(JsonLayoutDefinition.values());
		for (JsonLayoutDefinition layoutDefinition : allColumns) {
			columnNames.add(layoutDefinition.getFieldName());

		}
		return columnNames;
	}

	public Integer getSeqNumber() {
		return seqNumber;
	}

	public String getFieldName() {
		return fieldName;
	}

	public String getLayoutFieldName() {
		return layoutFieldName;
	}
}
