package mx.com.metlife.tom.fitrava.endorsement.services.service;

public interface UploadFileService {

	public String uploadFile(String claimNum);
}
