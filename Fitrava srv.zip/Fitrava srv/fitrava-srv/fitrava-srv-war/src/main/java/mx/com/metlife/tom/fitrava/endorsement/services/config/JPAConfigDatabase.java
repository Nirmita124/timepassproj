package mx.com.metlife.tom.fitrava.endorsement.services.config;

import static mx.com.metlife.tom.fitrava.endorsement.services.utility.ConstantUtility.JNDI_NAME;
import static mx.com.metlife.tom.fitrava.endorsement.services.utility.ConstantUtility.PACKAGE_SCAN;

import java.util.Properties;

import javax.sql.DataSource;

import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.dao.annotation.PersistenceExceptionTranslationPostProcessor;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.jndi.JndiTemplate;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import mx.com.metlife.tom.fitrava.endorsement.services.error.FitravaException;
import mx.com.metlife.tom.fitrava.endorsement.services.utility.ConstantUtility;

/**
 * This class is created to set up configuration for database, transaction
 * related to fitrava database.
 * 
 * @author Capgemini
 * @since 05/11/2018
 * 
 */
@Configuration
@EnableAutoConfiguration 
@EnableTransactionManagement
@ComponentScan("mx.com.metlife.tom.fitrava.endorsement.services.service")
@EnableJpaRepositories(entityManagerFactoryRef = "fitravaEntityManager", basePackages = {"mx.com.metlife.tom.fitrava.endorsement.services.model.repository" }, transactionManagerRef = "transactionManager")
@PropertySource(value = { "classpath:application.properties" })
public class JPAConfigDatabase {

	/**
	 * This is the method which creates a dataSource connection with Fitrava
	 * database using JNDI configuration.
	 * 
	 * @return DataSource
	 */
	@Bean(name = "fitravadataSource")
	public DataSource dataSource() throws FitravaException {
		DataSource dataSource = null;
		try {
		//	dataSource = getDataSource();
		dataSource = (DataSource) new JndiTemplate().lookup(JNDI_NAME);
		} catch (Exception e) {
			throw new FitravaException(e.getMessage());
		}
		return dataSource;
	}

	public DataSource getDataSource() {
		DriverManagerDataSource dataSource = new DriverManagerDataSource();
		dataSource.setDriverClassName(ConstantUtility.LOCAL_DB_DRIVER);
		dataSource.setUrl(ConstantUtility.LOCAL_DB_URL);
		dataSource.setUsername(ConstantUtility.LOCAL_DB_UN);
		dataSource.setPassword(ConstantUtility.LOCAL_DB_PW);
		return dataSource;
	}

	/**
	 * This method is used to create EntityManagerFactory.
	 * 
	 * @return LocalContainerEntityManagerFactoryBean
	 */
	@Bean(name = "fitravaEntityManager")
	public LocalContainerEntityManagerFactoryBean entityManagerFactoryBean() throws FitravaException {
		LocalContainerEntityManagerFactoryBean factoryBean = new LocalContainerEntityManagerFactoryBean();
		factoryBean.setDataSource(dataSource());
		factoryBean.setPersistenceUnitName("fitravaEntityManagerPU");
		factoryBean.setPackagesToScan(PACKAGE_SCAN);
		HibernateJpaVendorAdapter vendorAdapter = new HibernateJpaVendorAdapter();
		vendorAdapter.setShowSql(true);
		factoryBean.setJpaVendorAdapter(vendorAdapter);
		factoryBean.setJpaProperties(additionalProperties());
		return factoryBean;
	}
	
	public final Properties additionalProperties() {
		Properties hbProp = new Properties();
		hbProp.setProperty("hibernate.dialect", "org.hibernate.dialect.SQLServer2012Dialect");
		hbProp.setProperty("hibernate.show_sql", "true");
		hbProp.setProperty("hibernate.format_sql", "true");
		hbProp.setProperty("hibernate.hbm2ddl.auto", "none");
		return hbProp;
	}

	/**
	 * This method is used create isolated transactions.
	 * 
	 * @return PlatformTransactionManager
	 */
	@Bean(name = "transactionManager")
	public PlatformTransactionManager transactionManager() throws FitravaException {
		JpaTransactionManager transactionManager = new JpaTransactionManager();
		transactionManager.setEntityManagerFactory(entityManagerFactoryBean().getObject());
		return transactionManager;
	}

	/**
	 * 
	 * @return
	 */
	@Bean
	public PersistenceExceptionTranslationPostProcessor exceptionTranslation() {
		return new PersistenceExceptionTranslationPostProcessor();
	}

}
