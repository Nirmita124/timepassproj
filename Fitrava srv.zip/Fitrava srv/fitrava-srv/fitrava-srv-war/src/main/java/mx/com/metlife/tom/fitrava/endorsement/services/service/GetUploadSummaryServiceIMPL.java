package mx.com.metlife.tom.fitrava.endorsement.services.service;

import static mx.com.metlife.tom.fitrava.endorsement.services.utility.ConstantUtility.BUSINESS_RULE;
import static mx.com.metlife.tom.fitrava.endorsement.services.utility.ConstantUtility.DCN_ERROR;
import static mx.com.metlife.tom.fitrava.endorsement.services.utility.ConstantUtility.ERROR_SUMMARY;
import static mx.com.metlife.tom.fitrava.endorsement.services.utility.ConstantUtility.SUCCESS_TEXT;
import static mx.com.metlife.tom.fitrava.endorsement.services.utility.ConstantUtility.SUCEES_SUMMARY;
import static mx.com.metlife.tom.fitrava.endorsement.services.utility.ConstantUtility.TRANSFORMATION;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import mx.com.metlife.tom.fitrava.endorsement.services.error.FitravaException;
import mx.com.metlife.tom.fitrava.endorsement.services.model.repository.CommonFitravaRepository;
import mx.com.metlife.tom.fitrava.endorsement.services.model.repository.RejectSummaryRepository;
import mx.com.metlife.tom.fitrava.endorsement.services.model.repository.SumMoventRepository;
import mx.com.metlife.tom.fitrava.endorsement.services.service.dto.UploadRejSummaryQueryResultDTO;
import mx.com.metlife.tom.fitrava.endorsement.services.service.dto.UploadRejectResponse;
import mx.com.metlife.tom.fitrava.endorsement.services.service.dto.UploadSummaryDTO;
import mx.com.metlife.tom.fitrava.endorsement.services.service.dto.UploadSummaryMomentQueryResultDTO;
import mx.com.metlife.tom.fitrava.endorsement.services.service.dto.UploadSummaryMovDTO;
import mx.com.metlife.tom.fitrava.endorsement.services.service.dto.UploadSummaryResponseDTO;
import mx.com.metlife.tom.fitrava.endorsement.services.service.dto.UploadUploadStatusDTO;
import mx.com.metlife.tom.fitrava.endorsement.services.utility.ConstantUtility;

@Service
@Qualifier("uploadSummaryServiceImpl")
public class GetUploadSummaryServiceIMPL implements GetUploadSummaryService {

	@Autowired
	SumMoventRepository summaryRepository;

	@Autowired
	RejectSummaryRepository rejectRepository;

	@Autowired
	CommonFitravaRepository commonRepository;

	@Override
	public UploadRejectResponse getUploadRejec(String dcn) {
		UploadRejectResponse response = new UploadRejectResponse();
		response.setDcn(dcn);
		String ifDCNExistsOrProcessed = commonRepository.isDCNExistOrProcessed(dcn);
		if (!ifDCNExistsOrProcessed.equalsIgnoreCase(ConstantUtility.SUCCESS_TEXT)) {
			response.setResultCode(1);
			response.setResultDescription(ifDCNExistsOrProcessed);
			response.setSummaryBusiness(new UploadUploadStatusDTO());
			response.setSummaryLayout(new UploadUploadStatusDTO());
			return response;
		}

		List<UploadRejSummaryQueryResultDTO> objectList = rejectRepository.getQueryResult(dcn);
		UploadSummaryDTO errorDetailsDTO = null;
		Map<Integer, UploadSummaryDTO> typeMap = new HashMap<>();
		Map<Integer, UploadSummaryDTO> typeMapTransformation = new HashMap<>();

		for (UploadRejSummaryQueryResultDTO queryResultDTO : objectList) {
			int recNumber = queryResultDTO.getRecNum();
			if (queryResultDTO.getType().equalsIgnoreCase(BUSINESS_RULE)) {
				if (typeMap.containsKey(recNumber)) {
					errorDetailsDTO = typeMap.get(recNumber);
				} else {
					errorDetailsDTO = new UploadSummaryDTO();
					errorDetailsDTO.setRegistryNumber(recNumber);
					errorDetailsDTO.setErrors(new ArrayList<String>());
				}
				List<String> errorList = errorDetailsDTO.getErrors();
				errorList.add(queryResultDTO.getLayoutField().concat(ConstantUtility.SPACE_COLON)
						.concat(queryResultDTO.getDescription()));
				typeMap.put(recNumber, errorDetailsDTO);
			} else if (queryResultDTO.getType().equalsIgnoreCase(TRANSFORMATION)) {
				if (typeMapTransformation.containsKey(recNumber)) {
					errorDetailsDTO = typeMapTransformation.get(recNumber);
				} else {
					errorDetailsDTO = new UploadSummaryDTO();
					errorDetailsDTO.setRegistryNumber(recNumber);
					errorDetailsDTO.setErrors(new ArrayList<String>());
				}
				List<String> errorList = errorDetailsDTO.getErrors();
				errorList.add(queryResultDTO.getLayoutField().concat(ConstantUtility.SPACE_COLON)
						.concat(queryResultDTO.getDescription()));
				typeMapTransformation.put(recNumber, errorDetailsDTO);

			}

		}

		UploadUploadStatusDTO uploadStatusDTOLayout = rejectRepository.getQueryResultHeaders(dcn, false);
		uploadStatusDTOLayout.setDetails(new ArrayList<UploadSummaryDTO>(typeMapTransformation.values()));

		UploadUploadStatusDTO uploadStatusDTOGcaye = rejectRepository.getQueryResultHeaders(dcn, true);
		uploadStatusDTOGcaye.setDetails(new ArrayList<UploadSummaryDTO>(typeMap.values()));

		if (uploadStatusDTOGcaye.getRegistrys() == 0 && uploadStatusDTOLayout.getRegistrys() == 0) {
			response.setResultCode(1);
			response.setResultDescription(DCN_ERROR);
		} else {
			response.setResultCode(0);
			response.setResultDescription(SUCCESS_TEXT);
		}
		response.setSummaryLayout(uploadStatusDTOLayout);
		response.setSummaryBusiness(uploadStatusDTOGcaye);
		return response;
	}

	@Override
	public UploadSummaryResponseDTO getUploadSummaryMovement(String dcn) throws FitravaException {
		UploadSummaryResponseDTO response = new UploadSummaryResponseDTO();
		response.setDcn(dcn);
		String ifDCNExistsOrProcessed = commonRepository.isDCNExistOrProcessed(dcn);
		if (!ifDCNExistsOrProcessed.equalsIgnoreCase(ConstantUtility.SUCCESS_TEXT)) {
			response.setResultCode(1);
			response.setResultDescription(ifDCNExistsOrProcessed);
			response.setSummaryMovements(new ArrayList<UploadSummaryMovDTO>());
			return response;
		}

		List<UploadSummaryMomentQueryResultDTO> objectList = summaryRepository.getQueryResult(dcn);
		UploadSummaryMovDTO summaryDTO = null;

		Map<String, UploadSummaryMovDTO> typeMap = new HashMap<>();
		boolean isAllValueZero = false;
		for (UploadSummaryMomentQueryResultDTO endSummaryMomentQueryResultDTO : objectList) {
			String summaryType = endSummaryMomentQueryResultDTO.getType();
			if (typeMap.containsKey(summaryType)) {
				summaryDTO = typeMap.get(summaryType);
			} else {
				summaryDTO = new UploadSummaryMovDTO();
				summaryDTO.setType(summaryType);
			}

			if (endSummaryMomentQueryResultDTO.getResult().equalsIgnoreCase(SUCEES_SUMMARY)) {
				if (!isAllValueZero) {
					isAllValueZero = endSummaryMomentQueryResultDTO.getTotal() > 0;
				}

				summaryDTO.setSuccess(endSummaryMomentQueryResultDTO.getTotal());
			}

			if (endSummaryMomentQueryResultDTO.getResult().equalsIgnoreCase(ERROR_SUMMARY)) {
				if (!isAllValueZero) {
					isAllValueZero = endSummaryMomentQueryResultDTO.getTotal() > 0;
				}
				summaryDTO.setFailure(endSummaryMomentQueryResultDTO.getTotal());
			}
			typeMap.put(summaryType, summaryDTO);
		}

		Map<String, UploadSummaryMovDTO> sortedMap = new TreeMap<>(typeMap);

		List<UploadSummaryMovDTO> valueList = new ArrayList<>(sortedMap.values());

		response.setSummaryMovements(valueList);
		if (isAllValueZero) {
			response.setResultCode(0);
			response.setResultDescription(SUCCESS_TEXT);
		} else {
			response.setResultCode(1);
			response.setResultDescription(DCN_ERROR);
		}

		return response;
	}
}
