package mx.com.metlife.tom.fitrava.endorsement.services.model.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Table(name = "T_MOVE_TYP")
@Data
public class TMoveTyp implements Serializable {
  private static final long serialVersionUID = 1L;

  @Id
  @Column(name = "MOVE_TYP_CD")
  private Short idTypeMove;

  @Column(name = "MOVE_TYP_DSCR")
  private String description;

}