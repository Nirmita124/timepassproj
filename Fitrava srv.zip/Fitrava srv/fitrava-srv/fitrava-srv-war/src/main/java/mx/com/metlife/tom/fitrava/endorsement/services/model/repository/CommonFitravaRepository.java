package mx.com.metlife.tom.fitrava.endorsement.services.model.repository;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceUnit;

import org.springframework.stereotype.Repository;

import mx.com.metlife.tom.fitrava.endorsement.services.error.FitravaException;
import mx.com.metlife.tom.fitrava.endorsement.services.model.entity.TFlow;
import mx.com.metlife.tom.fitrava.endorsement.services.model.entity.TLayout;
import mx.com.metlife.tom.fitrava.endorsement.services.model.entity.TLayoutFld;
import mx.com.metlife.tom.fitrava.endorsement.services.model.entity.TProc;
import mx.com.metlife.tom.fitrava.endorsement.services.model.entity.TProcFile;
import mx.com.metlife.tom.fitrava.endorsement.services.model.entity.TProcRec;
import mx.com.metlife.tom.fitrava.endorsement.services.utility.ConstantUtility;
import mx.com.metlife.tom.fitrava.endorsement.services.utility.StatusDefinition;

@SuppressWarnings("rawtypes")
@Repository("commonRepository")
public class CommonFitravaRepository extends BaseRepository {

	@PersistenceUnit(unitName = "fitravaEntityManagerPU")
	private EntityManagerFactory entityManagerFactory;

	@Resource
	TProcRecRepository tProcRecRepository;

	@Resource
	TLayoutRepository tLayoutRepository;

	@Resource
	TLayoutFldRepository tLayoutFldRepository;

	@Resource
	TFlowRepository tFlowRepository;

	@Resource
	TProcFileRepository tProcFileRepository;

	@Resource
	TProcRepository tProcRepository;

	TLayout tLayout;

	TFlow tFlow;

	Map<String, Long> layoutFieldValues;

	Map<Long, TLayoutFld> mapLayoutFields;

	public TLayout getLayoutByName(String layoutName) {
		if (null == tLayout) {
			tLayout = tLayoutRepository.findFirstBylayoutNm(layoutName);
		}
		return tLayout;
	}

	public TFlow getFlowByName(String flowName) {
		if (null == tFlow) {
			tFlow = tFlowRepository.findByFlowName(flowName);
		}
		return tFlow;
	}

	public Map<String, Long> getLayoutFieldId(Long layoutId) {
		if (null == layoutFieldValues) {
			List<TLayoutFld> tLayoutFlds = tLayoutFldRepository.findBylayoutId(layoutId);
			layoutFieldValues = new HashMap<>();
			tLayoutFlds.forEach(tLayoutField -> layoutFieldValues.put(tLayoutField.getLayoutFldNm(),
					tLayoutField.getLayoutFldId()));
		}
		return layoutFieldValues;
	}
	
	public Map<Long, String> getLayoutFiel(Long layoutId) {
		Map<Long, String> layoutFieldValuesNM;
		
			List<TLayoutFld> tLayoutFlds = tLayoutFldRepository.findBylayoutId(layoutId);
			layoutFieldValuesNM = new HashMap<>();
			tLayoutFlds.forEach(tLayoutField -> layoutFieldValuesNM.put(tLayoutField.getLayoutFldId(),tLayoutField.getLayoutFldNm()
					));
		
		return layoutFieldValuesNM;
	}

	public Map<Long, TLayoutFld> getLayoutFields(Long layoutId) {
		if (null == mapLayoutFields) {
			List<TLayoutFld> tLayoutFlds = tLayoutFldRepository.findBylayoutId(layoutId);
			mapLayoutFields = new HashMap<>();
			tLayoutFlds.forEach(tLayoutField -> mapLayoutFields.put(tLayoutField.getLayoutFldId(), tLayoutField));
		}
		return mapLayoutFields;
	}

	public Long getLayoutFieldId(String columnName, Long layoutId) throws FitravaException {
		TLayoutFld tLayoutFld = tLayoutFldRepository.findFirstByLayoutFldNmAndLayoutId(columnName, layoutId);
		if (null == tLayoutFld) {
			throw new FitravaException(
					ConstantUtility.LAYOUT_FIELD_DEFINITION_IS_NOT_PRESENT_FOR_COLUMN.concat(columnName));
		}
		return tLayoutFld.getLayoutFldId();
	}

	public TProc getTProc(String dcn) {
		return tProcRepository.findFirstByDstnctCtrlNum(dcn);
	}

	public TProcFile getTProcFile(String dcn) {
		return tProcFileRepository.findFirstByDstnctCtrlNum(dcn);
	}

	public TProcRec getTProcRec(String dcn, Long recNum, Long layoutFldId) {
		return tProcRecRepository.findFirstByDstnctCtrlNumAndRecNumAndLayoutFldId(dcn, recNum,
				layoutFldId);
	}

	public String isDCNExistOrProcessed(String dcn) {
		TProc tProc = tProcRepository.findFirstByDstnctCtrlNum(dcn);
		if (null == tProc || tProc.getDstnctCtrlNum() == null || tProc.getDstnctCtrlNum().isEmpty()) {
			return ConstantUtility.DCN_ERROR;
		} else if (tProc.getClctStts() < StatusDefinition.TRANSFORMADO.getStatusCode()) {
			return ConstantUtility.DCN_NOT_PROCESSED_ERROR;
		}
		return ConstantUtility.SUCCESS_TEXT;
	}

}
