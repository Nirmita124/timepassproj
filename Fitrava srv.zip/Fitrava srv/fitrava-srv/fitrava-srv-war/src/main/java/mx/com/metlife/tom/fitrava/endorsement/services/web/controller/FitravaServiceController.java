package mx.com.metlife.tom.fitrava.endorsement.services.web.controller;

import static java.util.Collections.singletonMap;

import java.util.HashMap;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import lombok.extern.slf4j.Slf4j;
import mx.com.metlife.tom.fitrava.endorsement.services.service.FitravaService;
import mx.com.metlife.tom.fitrava.endorsement.services.service.dto.PaymentReferenceNumberDTO;
import mx.com.metlife.tom.fitrava.endorsement.services.utility.ConstantUtility;

@RestController
@PropertySource("classpath:${ftv_env:dev}-endpoint.properties")
@CrossOrigin
@Slf4j
public class FitravaServiceController {

	@Autowired
	private FitravaService fitravaService;
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@PostMapping(value="${url.file}") 
	public ResponseEntity templateUpload(@Valid @RequestBody PaymentReferenceNumberDTO paymentReferenceNumberDTO,
			@RequestParam("file") CommonsMultipartFile file) {
		String paymentReferenceNumber = fitravaService.getTemplateDetails(paymentReferenceNumberDTO);
		return new ResponseEntity(paymentReferenceNumber, HttpStatus.OK);
	}
	
	@PostMapping(value="${url.processEndorsmentLargeFileWA}") 
	public ResponseEntity<Map<String, Object>> largeFIleUpload(@RequestParam("file") MultipartFile files) {
		
		String originalFilename = files.getOriginalFilename();
		log.debug("File recieved: {}", originalFilename);
		
		Map<String, Object> resp = new HashMap<>();
		
		resp.put(ConstantUtility.FILE_NAME, originalFilename);
		resp.put(ConstantUtility.FILE_SIZE, Double.valueOf(files.getSize())/(1024*1024));
		resp.put(ConstantUtility.SIZE_IN, ConstantUtility.MB);
		String fileExtension = originalFilename.substring(originalFilename.lastIndexOf('.'));
		resp.put(ConstantUtility.FILE_EXTENSION, fileExtension);
		
		return new ResponseEntity<>(resp, HttpStatus.OK);
	}
	
	@GetMapping(value="/readlargeFile/{fileId}") 
	public ResponseEntity<Map<String, Integer>> largeFileRead(@PathVariable("fileId") Integer fileId) {
		
		return new ResponseEntity<>(singletonMap(ConstantUtility.TOTAL_ROWS_READ, 0), HttpStatus.OK);
	}


}
