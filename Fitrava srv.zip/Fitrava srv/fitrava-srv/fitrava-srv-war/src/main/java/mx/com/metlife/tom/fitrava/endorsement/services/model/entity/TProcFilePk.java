package mx.com.metlife.tom.fitrava.endorsement.services.model.entity;

import java.io.Serializable;

@SuppressWarnings("serial")
public class TProcFilePk implements Serializable {
	
	private String fileNm;
	
	private String dstnctCtrlNum;

	public TProcFilePk(String dcn, String fileName) {
		this.dstnctCtrlNum = dcn;
		this.fileNm = fileName;
	}
	
	public TProcFilePk() {
		
	}

	public String getFileNm() {
		return fileNm;
	}

	public void setFileNm(String fileNm) {
		this.fileNm = fileNm;
	}

	public String getDstnctCtrlNum() {
		return dstnctCtrlNum;
	}

	public void setDstnctCtrlNum(String dstnctCtrlNum) {
		this.dstnctCtrlNum = dstnctCtrlNum;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((dstnctCtrlNum == null) ? 0 : dstnctCtrlNum.hashCode());
		result = prime * result + ((fileNm == null) ? 0 : fileNm.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TProcFilePk other = (TProcFilePk) obj;
		if (dstnctCtrlNum == null) {
			if (other.dstnctCtrlNum != null) 
				return false;
		} else if (!dstnctCtrlNum.equals(other.dstnctCtrlNum)) {
			return false;
		}
		if (fileNm == null) {
			if (other.fileNm != null)
				return false;
		} else if (!fileNm.equals(other.fileNm)) {
			return false;
		}
		return true;
	}
}
