package mx.com.metlife.tom.fitrava.endorsement.services.model.entity;

import lombok.Data;

@Data
public class TProcRecPk implements java.io.Serializable {

	private static final long serialVersionUID = 3289075098567781173L;

	private String dstnctCtrlNum;

	private Long recNum;

	private Long layoutFldId;

	public String getDstnctCtrlNum() {
		return dstnctCtrlNum;
	}

	public void setDstnctCtrlNum(String dstnctCtrlNum) {
		this.dstnctCtrlNum = dstnctCtrlNum;
	}

	public Long getRecNum() {
		return recNum;
	}

	public void setRecNum(Long recNum) {
		this.recNum = recNum;
	}

	public Long getLayoutFldId() {
		return layoutFldId;
	}

	public void setLayoutFldId(Long layoutFldId) {
		this.layoutFldId = layoutFldId;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((dstnctCtrlNum == null) ? 0 : dstnctCtrlNum.hashCode());
		result = prime * result + ((layoutFldId == null) ? 0 : layoutFldId.hashCode());
		result = prime * result + ((recNum == null) ? 0 : recNum.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TProcRecPk other = (TProcRecPk) obj;
		if (dstnctCtrlNum == null) {
			if (other.dstnctCtrlNum != null)
				return false;
		} else if (!dstnctCtrlNum.equals(other.dstnctCtrlNum)) {
			return false;
		}
		if (layoutFldId == null) {
			if (other.layoutFldId != null)
				return false;
		} else if (!layoutFldId.equals(other.layoutFldId)) {
			return false;
		}
		if (recNum == null) {
			if (other.recNum != null)
				return false;
		} else if (!recNum.equals(other.recNum)) {
			return false;
		}
		return true;
	}

}
