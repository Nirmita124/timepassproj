package mx.com.metlife.tom.fitrava.endorsement.services.service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import mx.com.metlife.tom.fitrava.endorsement.services.model.repository.UploadDataRepository;
import mx.com.metlife.tom.fitrava.endorsement.services.service.dto.PaymentReferenceNumberDTO;
import mx.com.metlife.tom.fitrava.endorsement.services.utility.ConstantUtility;


@Service
@Qualifier("fitravaService")
public class FitravaServiceImpl implements FitravaService {

	@Autowired
	private UploadDataRepository uploadRepository;

	@Override
	public String getTemplateDetails(PaymentReferenceNumberDTO paymentReferenceNumberDTO) {
		//Logic to be added
		return null;
	}
	
	public String getDate() {
		Date d = uploadRepository.getDate();
		if (d != null) {
			return new SimpleDateFormat(ConstantUtility.DD_MMM_YYYY_HH_MM_SS, new Locale(ConstantUtility.ES_MX)).format(d);
		}
		return ConstantUtility.NO_SE_PUDO_OBTENER_DE_LA_B_D;
	}
	

}
