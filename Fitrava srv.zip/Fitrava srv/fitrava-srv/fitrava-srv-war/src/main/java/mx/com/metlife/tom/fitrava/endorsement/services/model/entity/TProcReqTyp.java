package mx.com.metlife.tom.fitrava.endorsement.services.model.entity;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Size;

import lombok.Data;

@Entity
@Table(name = "T_PROC_REQ_TYP")
@Data
public class TProcReqTyp implements Serializable {

  private static final long serialVersionUID = 1L;

  @Id
  @Basic(optional = false)
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "PROC_REQ_TYP_ID")
  private Integer idTypeRequest;

  @Size(max = 100)
  @Column(name = "PROC_REQ_TYP_DSCR")
  private String description;

}
