package mx.com.metlife.tom.fitrava.endorsement.services.utility;

import static mx.com.metlife.tom.fitrava.endorsement.services.utility.ConstantUtility.ENPROCESO;
import static mx.com.metlife.tom.fitrava.endorsement.services.utility.ConstantUtility.FINALIZADOS;
import static mx.com.metlife.tom.fitrava.endorsement.services.utility.ConstantUtility.GCAYEE;
import static mx.com.metlife.tom.fitrava.endorsement.services.utility.ConstantUtility.LEGADOS;
import static mx.com.metlife.tom.fitrava.endorsement.services.utility.ConstantUtility.PENDIENTES;
import static mx.com.metlife.tom.fitrava.endorsement.services.utility.ConstantUtility.TRANSFRMADO;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public enum StatusDefinition {
	PENDIENTE   (PENDIENTES,1),
	EN_PROCESO	(ENPROCESO, 2),
	TRANSFORMADO(TRANSFRMADO,3),
	LEGADO      (LEGADOS,4),
	GCAYE       (GCAYEE,5),
	FINALIZADO  (FINALIZADOS,6);
	
	String statusName;
	Integer statusCode;

	private StatusDefinition(String fieldName, Integer seqNumber) {
		this.statusName = fieldName;
		this.statusCode = seqNumber;
	}

	public static StatusDefinition getStatusByCode(Integer code) {

		List<StatusDefinition> allColumns = Arrays.asList(StatusDefinition.values());
		for (StatusDefinition layoutDefinition : allColumns) {
			if (layoutDefinition.getStatusCode() == code) {
				return layoutDefinition;
			}
		}
		return null;
	}

	public static List<String> getListOfStatus() {
		List<String> columnNames = new ArrayList<>();

		List<StatusDefinition> allStatuses = Arrays.asList(StatusDefinition.values());
		for (StatusDefinition statusDef : allStatuses) {
			columnNames.add(statusDef.getStatusName());
		}
		return columnNames;
	}

	public String getStatusName() {
		return statusName;
	}

	public Integer getStatusCode() {
		return statusCode;
	}
}
