package mx.com.metlife.tom.fitrava.endorsement.services.model.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import lombok.Data;

@Cacheable(false)
@Entity
@Table(name = "T_PROC")
@Data
public class TProcDCN implements Serializable {

	private static final long serialVersionUID = 1L;

	  @Id
	  @Basic(optional = false)
	  @GeneratedValue(strategy = GenerationType.IDENTITY)
	  @Column(name = "PROC_ID")
	  private Long idProcedure;

	  @Basic(optional = false)
	  @NotNull
	  @Size(min = 1, max = 50)
	  @Column(name = "PG_NM")
	  private String folio;

	  @Basic(optional = false)
	  @NotNull
	  @Column(name = "CRT_TS")
	  @Temporal(TemporalType.TIMESTAMP)
	  private Date creationDate;

	  @Basic(optional = false)
	  @NotNull
	  @Size(min = 1, max = 30)
	  @Column(name = "AGNT_ID")
	  private String agentId;

	  @Basic(optional = false)
	  @NotNull
	  @Size(min = 1, max = 30)
	  @Column(name = "CHNL_NM")
	  private String channel;

	  @Basic(optional = false)
	  @NotNull
	  @Column(name = "MSV_LOAD_IND")
	  private Character masiveLoadInd;

	  @Basic(optional = false)
	  @NotNull
	  @Size(min = 1, max = 20)
	  @Column(name = "LOB_NM")
	  private String lobNum;

	  @JoinColumn(name = "PROC_REQ_TYP_ID", referencedColumnName = "PROC_REQ_TYP_ID")
	  @ManyToOne(optional = false)
	  private TProcReqTyp procReqTypId;

	  @Column(name = "PROMO_OFC_CD")
	  private String promotion;
	  
	  @Column(name = "AGNT_EMAIL_ADR_TXT")
	  private String emailAgent;
	  
	  @Column(name = "AGNT_NM")
	  private String nameAgent;


}
