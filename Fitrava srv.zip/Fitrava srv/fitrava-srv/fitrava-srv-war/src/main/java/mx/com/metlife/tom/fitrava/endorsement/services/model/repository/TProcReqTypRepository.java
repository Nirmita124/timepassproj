package mx.com.metlife.tom.fitrava.endorsement.services.model.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import mx.com.metlife.tom.fitrava.endorsement.services.model.entity.TProcReqTyp;

public interface TProcReqTypRepository extends JpaRepository<TProcReqTyp, Integer> {
	
	public TProcReqTyp findByIdTypeRequest(Integer id);

}
