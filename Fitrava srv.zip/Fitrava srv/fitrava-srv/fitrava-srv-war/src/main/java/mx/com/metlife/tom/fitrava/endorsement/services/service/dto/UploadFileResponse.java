package mx.com.metlife.tom.fitrava.endorsement.services.service.dto;

import lombok.Data;

@Data
public class UploadFileResponse {

	String uploadResult;
	
}
