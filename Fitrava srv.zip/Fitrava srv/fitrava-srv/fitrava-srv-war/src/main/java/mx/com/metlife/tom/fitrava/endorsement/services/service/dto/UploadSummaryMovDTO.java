package mx.com.metlife.tom.fitrava.endorsement.services.service.dto;

import lombok.Data;

@Data
public class UploadSummaryMovDTO {
	String type;
	Integer success;
	Integer failure;

}
