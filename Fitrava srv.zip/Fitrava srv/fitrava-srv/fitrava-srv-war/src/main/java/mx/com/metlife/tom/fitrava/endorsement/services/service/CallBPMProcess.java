package mx.com.metlife.tom.fitrava.endorsement.services.service;

import static org.slf4j.LoggerFactory.getLogger;

import java.nio.charset.Charset;
import java.time.Duration;
import java.time.Instant;
import java.util.Base64;

import org.json.simple.JSONObject;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.ObjectMapper;

import mx.com.metlife.tom.fitrava.endorsement.services.error.FitravaException;
import mx.com.metlife.tom.fitrava.endorsement.services.service.dto.BPMProcessDTO;
import mx.com.metlife.tom.fitrava.endorsement.services.service.dto.BPMProcessResponseDTO;
import mx.com.metlife.tom.fitrava.endorsement.services.utility.ConstantUtility;
import mx.com.metlife.tom.fitrava.endorsement.services.utility.EncriptionUtils;

@Service
@PropertySource("classpath:${ftv_env:dev}-endpoint.properties")
public class CallBPMProcess {

	private static final Logger logger = getLogger(CallBPMProcess.class);

	@Value("${header.accept}")
	String headerValue;

	@Value("${header.clientId}")
	String clientId;

	@Value("${apisecurity.userpassword}")
	private String userPassword;
	
	@Value("${apisecurity.token.url}")
	String authorizationUrl;

	@Value("${update.workflow.bpm}")
	private String bpmEndpointUrl;

	@Value("${update.workflow.bpmMsg0}")
	private String bpmMsg0;

	@Value("${update.workflow.bpmMsg1}")
	private String bpmMsg1;

	private Instant startTime;

	private String authKey;

	public String getToken() {
		logger.info("En el getToken()");
		final HttpHeaders headers = new HttpHeaders();
		try {
			headers.set(ConstantUtility.ACCEPT, headerValue);
			headers.set(ConstantUtility.IBM_CLIENT_ID, clientId);
			String auth = EncriptionUtils.decrypt(userPassword);
			logger.info("{}", auth);
			byte[] encodedAuth = Base64.getEncoder().encode(auth.getBytes(Charset.forName(ConstantUtility.US_ASCII)));
			String authHeader = ConstantUtility.BASIC.concat(new String(encodedAuth));
			headers.set(ConstantUtility.AUTHORIZATION, authHeader);
			final HttpEntity<String> entity = new HttpEntity<>(headers);
			RestTemplate restTemplate = new RestTemplate();
			logger.info(ConstantUtility.ESTABLISHING_CONNECTION);
			final ResponseEntity<JSONObject> response = restTemplate.exchange(authorizationUrl, HttpMethod.GET, entity, JSONObject.class);
			logger.info(ConstantUtility.CONNECTION_ESTABLISHED);
			logger.info("{}", response);
			return getToken(response.getBody());
		} catch (Exception e) {
			logger.error("No se pudo descencriptar", e);
			return null;
		}
	}

	private String getToken(JSONObject json) {
		String accessToken = null;
		String type = null;
		accessToken = json.get(ConstantUtility.ACCESS_TOKEN).toString();
		type = json.get(ConstantUtility.TOKEN_TYPE).toString();
		return type.concat(accessToken);
	}

	public void callBPMService(int responseCode, String dcn) throws FitravaException {
		logger.info(ConstantUtility.CALLING_BPM_SERVICE_IN_CALL_BPM_SERVICE);
		if (null != startTime && null != authKey) {
			long millis = Duration.between(startTime, Instant.now()).toMillis();
			if (millis > 3300000) {
				authKey = getToken();
				startTime = Instant.now();
			}
		} else {
			authKey = getToken();
			startTime = Instant.now();
		}
		BPMProcessDTO bpmProcessDTO = getMessageByCode(responseCode, dcn);
		logger.info(bpmProcessDTO.toString());
		ObjectMapper obj = new ObjectMapper();
		final HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.set(ConstantUtility.AUTHORIZATION, authKey);
		headers.set(ConstantUtility.IBM_CLIENT_ID, clientId);
		logger.info(ConstantUtility.TOKEN, authKey);
		logger.info(ConstantUtility.CLIENT_ID, clientId);
		logger.info(ConstantUtility.BPM_ENDPOINT_URL, bpmEndpointUrl);

		bpmProcessDTO.setOperationType(1);
		bpmProcessDTO.setStatus(2);
		bpmProcessDTO.setTypNtf(1);
		RestTemplate restTemplate = new RestTemplate();
		try {
			logger.info(obj.writeValueAsString(bpmProcessDTO));
			ResponseEntity<BPMProcessResponseDTO> response = restTemplate.exchange(bpmEndpointUrl, HttpMethod.POST,
					new HttpEntity<>(bpmProcessDTO, headers), BPMProcessResponseDTO.class);
			BPMProcessResponseDTO responseDTO = response.getBody();
			logger.info(ConstantUtility.BPM_SUCCESS_1, responseDTO, ConstantUtility.SPACE,
					responseDTO.getSystemMessage());
		} catch (Exception e) {
			logger.error(ConstantUtility.ERROR_IN_CALLING_BPM_1.concat(e.getMessage()));
			if (e.getMessage().equalsIgnoreCase(ConstantUtility.INTERNAL_SERVER_ERROR)) {
				this.callBPM2ndTime(bpmProcessDTO, headers, restTemplate, e);
			} else {
				logger.error(ConstantUtility.ERROR_IN_CALLING_BPM_SERVICE.concat(e.getMessage()));
				throw new FitravaException(ConstantUtility.ERROR_IN_CALLING_BPM_SERVICE + e.getMessage());
			}
		}
	}

	private void callBPM2ndTime(BPMProcessDTO bpmProcessDTO, final HttpHeaders headers, RestTemplate restTemplate,
			Exception e) throws FitravaException {
		try {
			ResponseEntity<BPMProcessResponseDTO> response = restTemplate.exchange(bpmEndpointUrl,
					HttpMethod.POST, new HttpEntity<>(bpmProcessDTO, headers), BPMProcessResponseDTO.class);
			BPMProcessResponseDTO responseDTO = response.getBody();
			logger.info(ConstantUtility.BPM_SUCCESS_2, responseDTO.toString(), ConstantUtility.SPACE,
					responseDTO.getSystemMessage());
		} catch (Exception e2) {
			logger.error(ConstantUtility.ERROR_IN_CALLING_BPM_2.concat(e.getMessage()));
			if (e2.getMessage().equalsIgnoreCase(ConstantUtility.INTERNAL_SERVER_ERROR)) {
				this.callBPM3rdTime(bpmProcessDTO, headers, restTemplate, e2);
			}
		}
	}

	private void callBPM3rdTime(BPMProcessDTO bpmProcessDTO, final HttpHeaders headers, RestTemplate restTemplate,
			Exception e2) throws FitravaException {
		try {
			ResponseEntity<BPMProcessResponseDTO> response = restTemplate.exchange(bpmEndpointUrl,
					HttpMethod.POST, new HttpEntity<>(bpmProcessDTO, headers),
					BPMProcessResponseDTO.class);
			BPMProcessResponseDTO responseDTO = response.getBody();
			logger.info(ConstantUtility.BPM_SUCCESS_3, responseDTO.toString(), ConstantUtility.SPACE,
					responseDTO.getSystemMessage());
		} catch (Exception e3) {
			logger.error(ConstantUtility.ERROR_IN_CALLING_BPM_SERVICE.concat(e3.getMessage()));
			throw new FitravaException(
					ConstantUtility.ERROR_IN_CALLING_BPM_SERVICE.concat(e2.getMessage()));
		}
	}

	public BPMProcessDTO getMessageByCode(int code, String dcn) {
		BPMProcessDTO bpmProcessDTO = new BPMProcessDTO();
		bpmProcessDTO.setResultCode(code);
		bpmProcessDTO.setSystem(ConstantUtility.SYSTEM_CODE);
		bpmProcessDTO.setDcn(dcn);
		switch (code) {
		case 0:
			bpmProcessDTO.setResultMessage(bpmMsg0);
			break;
		case 1:
			bpmProcessDTO.setResultMessage(bpmMsg1);
			break;
		default:
			break;
		}
		return bpmProcessDTO;
	}

}