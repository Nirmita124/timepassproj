package mx.com.metlife.tom.fitrava.endorsement.services.service.dto;

import lombok.Data;

@SuppressWarnings("serial")
@Data
public class UploadDetails implements java.io.Serializable {
	

	private Long agentKey;
	private Long brachSubBranch;
	private Long policyNumber;
	private Long subGroupNumber;
	private String subGroupName;
	private Long categoryNumber;
	private String insuredNumber;
	private Long moveType;
	private String workOrder;
	private String insuredName;
	private String lastName;
	private String middleName;
	private String birthdate;
	private Long gender;
	private Long relationship;
	private String civilStatus;
	private Long salary;
	private String startDate;
	private String endDate;
	private String incomeDateEmployee;
	private String antiqueDate;
	private String sinceInsuredDate;
	private Long years;
	private String curp;
	private String rfc;
	private String level;
	private String centerWork;
	private String employeeNumber;
	private Long sumAuthBasic;
	private Long sumAuthBasicPOT;
	private Long retainerKey;
	private Long payUnit;
	private Long indColDuct;
	private Long indPayForm;
	private Long indBankKey;
	private Long bankAccNum;
	private Long cardAccNum;
	private Long expirationCard;
	private Long borderlineLoca;
	private String street;
	private String extNum;
	private String intNum;
	private String suburb;
	private String town;
	private Long pC;
	private String email;
	private Long phone;
	private String beneficiary1;
	private String relationship1;
	private Long percentage1;
	private String beneficiary2;
	private String relationship2;
	private Long percentage2;
	private String beneficiary3;
	private String relationship3;
	private Long percentage3;
	private String beneficiary4;
	private String relationship4;
	private Long percentage4;
	private String beneficiary5;
	private String relationship5;
	private Long percentage5;
	private String beneficiary6;
	private String relationship6;
	private Long percentage6;
	private Long plazaType;
	private String treatment;
	private String job;
	private Long describedConcept;
	private String ascription;
	private String moveDate;
	private Long filler;
}
