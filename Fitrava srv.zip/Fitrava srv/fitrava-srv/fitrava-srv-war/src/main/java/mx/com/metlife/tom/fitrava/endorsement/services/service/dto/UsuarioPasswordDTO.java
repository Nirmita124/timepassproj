package mx.com.metlife.tom.fitrava.endorsement.services.service.dto;

import lombok.Data;

@Data
public class UsuarioPasswordDTO {

	private String usuarioPassword;

	public UsuarioPasswordDTO() {
		super();
	}

	public UsuarioPasswordDTO(String usuarioPassword) {
		super();
		this.usuarioPassword = usuarioPassword;
	}
	
	
}
