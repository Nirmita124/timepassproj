package mx.com.metlife.tom.fitrava.endorsement.services.model.entity;

import lombok.Data;

@Data
public class Entity {

	private String date;
}
