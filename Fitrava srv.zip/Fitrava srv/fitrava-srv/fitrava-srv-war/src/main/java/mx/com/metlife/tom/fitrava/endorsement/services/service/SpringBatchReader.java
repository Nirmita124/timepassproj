package mx.com.metlife.tom.fitrava.endorsement.services.service;
import static org.slf4j.LoggerFactory.getLogger;

import java.util.List;

import org.slf4j.Logger;
import org.springframework.batch.item.ItemReader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import mx.com.metlife.tom.fitrava.endorsement.services.service.dto.TProcDTO;
import mx.com.metlife.tom.fitrava.endorsement.services.utility.ConstantUtility;

@Component
public class SpringBatchReader implements ItemReader<List<TProcDTO>>{
	private static final Logger logger = getLogger(SpringBatchReader.class);
	
	@Autowired
	ApplicationContext applicationContext;
	
	@Override
	public List<TProcDTO> read() {
	
		logger.info(ConstantUtility.IN_READER);
		SpringBatchService springBatchService = applicationContext.getBean(SpringBatchService.class);	
		List<TProcDTO> list = springBatchService.statusResponse();
		if (!list.isEmpty()) {
			return list;
		} else {
			return null;
		}
		
	}

}
