package mx.com.metlife.tom.fitrava.endorsement.services.service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;
import mx.com.metlife.tom.fitrava.endorsement.services.model.entity.TEndrs;
import mx.com.metlife.tom.fitrava.endorsement.services.model.entity.TEndrsBene;
import mx.com.metlife.tom.fitrava.endorsement.services.model.entity.TEndrsBenePK;
import mx.com.metlife.tom.fitrava.endorsement.services.model.entity.TMoveTyp;
import mx.com.metlife.tom.fitrava.endorsement.services.model.entity.TProcDCN;
import mx.com.metlife.tom.fitrava.endorsement.services.model.entity.TProcRec;
import mx.com.metlife.tom.fitrava.endorsement.services.model.entity.TWrkOrd;
import mx.com.metlife.tom.fitrava.endorsement.services.model.repository.EndrsRepository;
import mx.com.metlife.tom.fitrava.endorsement.services.model.repository.TMoveTypRepository;
import mx.com.metlife.tom.fitrava.endorsement.services.model.repository.TProcDCNRepository;
import mx.com.metlife.tom.fitrava.endorsement.services.utility.ConstantUtility;
import mx.com.metlife.tom.fitrava.endorsement.services.utility.LayoutDefinition;

@Service
@Slf4j
public class EndrsServiceImpl {

	TEndrs endrs;
	TProcDCN procDCN = null;

	TEndrsBene bene1 = null;
	TEndrsBene bene2 = null;
	TEndrsBene bene3 = null;
	TEndrsBene bene4 = null;
	TEndrsBene bene5 = null;
	TEndrsBene bene6 = null;

	@Resource
	TMoveTypRepository tMoveTypRepository;

	@Resource
	TProcDCNRepository procDCNRepository;

	@Autowired
	EndrsRepository endrsRepository;

	public void groupProcRec(List<TProcRec> tprocList, Map<Long, String> layoutMap, String dcn, List<String> uuids) {

		Map<Long, List<TProcRec>> groupList = tprocList.parallelStream()
				.collect(Collectors.groupingBy(p -> (p.getRecNum())));

		try {
			groupList.forEach((id, registro) -> {
				int contador = id.intValue() - 1;
				log.info("Contador: {}", contador);
				saveTEndrs(registro, layoutMap, dcn, uuids.get(contador));
			});
		} catch (Exception e) {
			log.error("ERROR ENDORSMENT : {}", e.getMessage(), e);
		}

	}

	public void saveTEndrs(List<TProcRec> tprocList, Map<Long, String> layoutMap, String dcn, String uuid) {

		endrs = new TEndrs();
		procDCN = new TProcDCN();

		endrs.setActiveGcaye('0');
		endrs.setDownloadActive('0');
		endrs.setPrnRqrInd('1');
		endrs.setMoveKey(uuid);

		procDCN = procDCNRepository.findByFolio(dcn);

		log.info("{}", procDCN);

		tprocList.forEach(pro -> {

			log.info("Valor de recorrido: {}", pro.getLayoutFldId().intValue());

			if (pro.getOrigVal().isEmpty()) {
				return;
			}

			Long fldVal = pro.getLayoutFldId();

			if (layoutMap.get(fldVal).equals(LayoutDefinition.CLAVE_DE_AGENTE.getExcelColumnName())) {
				endrs.setKeyAgent(pro.getOrigVal());
			} else if (layoutMap.get(fldVal).equals(LayoutDefinition.FETCHA_MOVIMIENTO.getExcelColumnName())) {
				endrs.setCreationDate(new Date());
			} else if (layoutMap.get(fldVal).equals(LayoutDefinition.RAMO_SUB_RAMO.getExcelColumnName())) {
				endrs.setSuburb(pro.getOrigVal());
			} else if (layoutMap.get(fldVal).equals(LayoutDefinition.NUMERO_DE_POLIZA.getExcelColumnName())) {
				endrs.setPolicyNumber(pro.getOrigVal());
			} else if (layoutMap.get(fldVal).equals(LayoutDefinition.NUMERO_DE_CATEGORIA.getExcelColumnName())) {
				endrs.setCategoryNumber(Long.parseLong(pro.getOrigVal()));
			} else if (layoutMap.get(fldVal).equals(LayoutDefinition.NUMERO_DE_ASEGURADO.getExcelColumnName())) {
				endrs.setInsuredNumber(pro.getOrigVal());
			} else if (layoutMap.get(fldVal).equals(LayoutDefinition.NUMERO_DE_SUBGRUPO.getExcelColumnName())) {
				endrs.setSubgroupName(pro.getOrigVal());
			} else if (layoutMap.get(fldVal).equals(LayoutDefinition.TIPO_DE_MOVIMIENTO.getExcelColumnName())) {
				TMoveTyp mt;
				if (Short.parseShort(pro.getOrigVal()) > 21  || Short.parseShort(pro.getOrigVal()) < 1 ) {
					mt = tMoveTypRepository.findById((short) 22).orElse(null);
				} else {
					mt = tMoveTypRepository.findById(Short.parseShort(pro.getOrigVal())).orElse(null);
				}
				endrs.setMoveType(mt);

			} else if (layoutMap.get(fldVal).equals(LayoutDefinition.ORDEN_DE_TRABAJO.getExcelColumnName())) {
				TWrkOrd wo = endrsRepository.findTWorkOrder(dcn, pro.getOrigVal());
				log.info("{}", wo);
				if (wo == null) {
					try {
						wo = saveWrkOrd(procDCN, pro.getOrigVal());
					} catch (Exception e) {
						log.error(e.getMessage());
					}
				}
				log.info("{}", wo);
				endrs.setWorkOrder(wo);
			} else if (layoutMap.get(fldVal).equals(LayoutDefinition.NOMBRE_ASEGURADO.getExcelColumnName())) {
				endrs.setInsuredName(pro.getOrigVal());
			} else if (layoutMap.get(fldVal).equals(LayoutDefinition.APELLIDO_PATERNO.getExcelColumnName())) {
				endrs.setLastName(pro.getOrigVal());
			} else if (layoutMap.get(fldVal).equals(LayoutDefinition.APELLIDO_MATERNO.getExcelColumnName())) {
				endrs.setLastName(endrs.getLastName() + " " + pro.getOrigVal());
			} else if (layoutMap.get(fldVal).equals(LayoutDefinition.FECHA_DE_NACIMIENTO.getExcelColumnName())) {
				endrs.setBirthDate(setDate(pro.getOrigVal()));
			} else if (layoutMap.get(fldVal).equals(LayoutDefinition.SEXO.getExcelColumnName())) {
				endrs.setGender(pro.getOrigVal().equals("1") ? "M" : "F");
			} else if (layoutMap.get(fldVal).equals(LayoutDefinition.PARENTESCO.getExcelColumnName())) {
				endrs.setRelationShip(Short.parseShort(pro.getOrigVal()));
			} else if (layoutMap.get(fldVal).equals(LayoutDefinition.ESTADO_CIVIL.getExcelColumnName())) {

			} else if (layoutMap.get(fldVal).equals(LayoutDefinition.SUELDO.getExcelColumnName())) {
				endrs.setSalary(new BigDecimal(pro.getOrigVal()));
			} else if (layoutMap.get(fldVal).equals(LayoutDefinition.FECHA_ALTA.getExcelColumnName())) {
				endrs.setIncomeDateEmployee(setDate(pro.getOrigVal()));
			} else if (layoutMap.get(fldVal).equals(LayoutDefinition.FECHA_BAJA.getExcelColumnName())) {
				endrs.setEndDate(setDate(pro.getOrigVal()));
			} else if (layoutMap.get(fldVal).equals(LayoutDefinition.FECHA_INGRESO_EMP.getExcelColumnName())) {
				endrs.setStartDate(setDate(pro.getOrigVal()));
			} else if (layoutMap.get(fldVal).equals(LayoutDefinition.FECHA_DE_ANTIGUEDAD.getExcelColumnName())) {
				endrs.setAntiqueDate(setDate(pro.getOrigVal()));
			} else if (layoutMap.get(fldVal).equals(LayoutDefinition.FECHA_ASEGURADO_DESDE.getExcelColumnName())) {
				endrs.setSinceInsuranceDate(setDate(pro.getOrigVal()));
			} else if (layoutMap.get(fldVal).equals(LayoutDefinition.EDAD.getExcelColumnName())) {
				endrs.setYears(pro.getOrigVal());
			} else if (layoutMap.get(fldVal).equals(LayoutDefinition.CURP.getExcelColumnName())) {

			} else if (layoutMap.get(fldVal).equals(LayoutDefinition.RFC.getExcelColumnName())) {

			} else if (layoutMap.get(fldVal).equals(LayoutDefinition.NIVEL.getExcelColumnName())) {

			} else if (layoutMap.get(fldVal).equals(LayoutDefinition.CENTRO_DE_TRABAJO.getExcelColumnName())) {
				endrs.setCenterWork(pro.getOrigVal());
			} else if (layoutMap.get(fldVal).equals(LayoutDefinition.NUMERO_DE_EMPLEADO.getExcelColumnName())) {
				endrs.setEmployeeNumber(pro.getOrigVal());
			} else if (layoutMap.get(fldVal).equals(LayoutDefinition.CLAVE_RETENEDOR.getExcelColumnName())) {
				endrs.setRetainerKey(pro.getOrigVal());
			} else if (layoutMap.get(fldVal).equals(LayoutDefinition.UNIDAD_DE_PAGO.getExcelColumnName())) {
				endrs.setPyUnitCd(pro.getOrigVal());
			} else if (layoutMap.get(fldVal).equals(LayoutDefinition.FORMA_DE_PAGO_INDIVIDUAL.getExcelColumnName())) {
				endrs.setIndPyForm(pro.getOrigVal());
			} else if (layoutMap.get(fldVal).equals(LayoutDefinition.CLAVE_DE_BANCO_INDIVIDUAL.getExcelColumnName())) {
				endrs.setIndBnkKey(pro.getOrigVal());
			} else if (layoutMap.get(fldVal).equals(LayoutDefinition.UBICACION_FRONTERIZA.getExcelColumnName())) {
				endrs.setBrdrAreaZipCd(pro.getOrigVal());
			} else if (layoutMap.get(fldVal).equals(LayoutDefinition.CALLE.getExcelColumnName())) {
				endrs.setStreet(pro.getOrigVal());
			} else if (layoutMap.get(fldVal).equals(LayoutDefinition.NUMERO_EXTERIOR.getExcelColumnName())) {
				endrs.setExtNum(pro.getOrigVal());
			} else if (layoutMap.get(fldVal).equals(LayoutDefinition.NUMERO_INTERIOR.getExcelColumnName())) {
				endrs.setIntNum(pro.getOrigVal());
			} else if (layoutMap.get(fldVal).equals(LayoutDefinition.CODIGO_POSTAL.getExcelColumnName())) {
				endrs.setPostalCode(pro.getOrigVal());
			} else if (layoutMap.get(fldVal).equals(LayoutDefinition.CORREO_ELECTRONICO.getExcelColumnName())) {
				endrs.setEmail(pro.getOrigVal());
			} else if (layoutMap.get(fldVal).equals(LayoutDefinition.TELEFONO.getExcelColumnName())) {
				endrs.setPhone(pro.getOrigVal());
			} else if (layoutMap.get(fldVal).equals(LayoutDefinition.TIPO_PLAZA.getExcelColumnName())) {
				endrs.setPlazaType(Short.parseShort(pro.getOrigVal()));
			} else if (layoutMap.get(fldVal).equals(LayoutDefinition.TRATAMIENTO.getExcelColumnName())) {
				endrs.setTeratment(pro.getOrigVal());
			} else if (layoutMap.get(fldVal).equals(LayoutDefinition.PUESTO.getExcelColumnName())) {
				endrs.setJob(pro.getOrigVal());
			} else if (layoutMap.get(fldVal).equals(LayoutDefinition.CONCEPTO_DESCRITO.getExcelColumnName())) {
				endrs.setDescribedConcept(pro.getOrigVal());
			} else if (layoutMap.get(fldVal).equals(LayoutDefinition.ADSCRIPCION.getExcelColumnName())) {
				endrs.setAscription(pro.getOrigVal());
			}
		});

		log.info(" {} ", endrs);

		try {
			endrs = endrsRepository.saveTEndrs(endrs);
			log.info(" {} ", endrs);

			if (endrs != null) {

				saveBene(tprocList, endrs, layoutMap);

			}
		} catch (Exception e) {
			log.error(e.getMessage());
		}

	}

	public TWrkOrd saveWrkOrd(TProcDCN pr, String wo) {
		TWrkOrd tWo = new TWrkOrd();

		tWo.setCreation(new Date());
		tWo.setProcedure(pr);
		tWo.setWorkOrderName(wo);

		return endrsRepository.saveWrkOrd(tWo);
	}

	public void saveBene(List<TProcRec> tprocList, TEndrs endrs, Map<Long, String> layoutMap) {

		TEndrsBenePK pk = new TEndrsBenePK();
		pk.setEndrsId(endrs.getIdEndorsement());

		tprocList.stream().forEach(pro -> {

			if (pro.getOrigVal().isEmpty()) {
				return;
			}

			Long fldVal = pro.getLayoutFldId();

			if (layoutMap.get(fldVal).equals(LayoutDefinition.BENEFICIARIO_1.getExcelColumnName())) {
				bene1 = new TEndrsBene();
				bene1.setBeneficiaryName(pro.getOrigVal());
			} else if (layoutMap.get(fldVal).equals(LayoutDefinition.PARENTESCO_1.getExcelColumnName())) {
				bene1.setRealtionship(pro.getOrigVal());
			} else if (layoutMap.get(fldVal).equals(LayoutDefinition.PORCENTAJE_1.getExcelColumnName())) {
				bene1.setPercentage(Short.valueOf(pro.getOrigVal()));
			}

			else if (layoutMap.get(fldVal).equals(LayoutDefinition.BENEFICIARIO_2.getExcelColumnName())) {
				bene2 = new TEndrsBene();
				bene2.setBeneficiaryName(pro.getOrigVal());
			} else if (layoutMap.get(fldVal).equals(LayoutDefinition.PARENTESCO_2.getExcelColumnName())) {
				bene2.setRealtionship(pro.getOrigVal());
			} else if (layoutMap.get(fldVal).equals(LayoutDefinition.PORCENTAJE_2.getExcelColumnName())) {
				bene2.setPercentage(Short.valueOf(pro.getOrigVal()));
			}

			else if (layoutMap.get(fldVal).equals(LayoutDefinition.BENEFICIARIO_3.getExcelColumnName())) {
				bene3 = new TEndrsBene();
				bene3.setBeneficiaryName(pro.getOrigVal());
			} else if (layoutMap.get(fldVal).equals(LayoutDefinition.PARENTESCO_3.getExcelColumnName())) {
				bene3.setRealtionship(pro.getOrigVal());
			} else if (layoutMap.get(fldVal).equals(LayoutDefinition.PORCENTAJE_3.getExcelColumnName())) {
				bene3.setPercentage(Short.valueOf(pro.getOrigVal()));
			}

			else if (layoutMap.get(fldVal).equals(LayoutDefinition.BENEFICIARIO_4.getExcelColumnName())) {
				bene4 = new TEndrsBene();
				bene4.setBeneficiaryName(pro.getOrigVal());
			} else if (layoutMap.get(fldVal).equals(LayoutDefinition.PARENTESCO_4.getExcelColumnName())) {
				bene4.setRealtionship(pro.getOrigVal());
			} else if (layoutMap.get(fldVal).equals(LayoutDefinition.PORCENTAJE_4.getExcelColumnName())) {
				bene4.setPercentage(Short.valueOf(pro.getOrigVal()));
			}

			else if (layoutMap.get(fldVal).equals(LayoutDefinition.BENEFICIARIO_5.getExcelColumnName())) {
				bene5 = new TEndrsBene();
				bene5.setBeneficiaryName(pro.getOrigVal());
			} else if (layoutMap.get(fldVal).equals(LayoutDefinition.PARENTESCO_5.getExcelColumnName())) {
				bene5.setRealtionship(pro.getOrigVal());
			} else if (layoutMap.get(fldVal).equals(LayoutDefinition.PORCENTAJE_5.getExcelColumnName())) {
				bene5.setPercentage(Short.valueOf(pro.getOrigVal()));
			}

			else if (layoutMap.get(fldVal).equals(LayoutDefinition.BENEFICIARIO_6.getExcelColumnName())) {
				bene6 = new TEndrsBene();
				bene6.setBeneficiaryName(pro.getOrigVal());
			} else if (layoutMap.get(fldVal).equals(LayoutDefinition.PARENTESCO_6.getExcelColumnName())) {
				bene6.setRealtionship(pro.getOrigVal());
			} else if (layoutMap.get(fldVal).equals(LayoutDefinition.PORCENTAJE_6.getExcelColumnName())) {
				bene6.setPercentage(Short.valueOf(pro.getOrigVal()));
			}
		});

		if (bene1 != null) {
			pk.setEndrsBeneSeqNum((short) 1);
			bene1.setEndorsement(endrs);
			bene1.setTEndrsBenePK(pk);

			endrsRepository.saveBeneficiary(bene1);

		}

		if (bene2 != null) {
			pk.setEndrsBeneSeqNum((short) 2);
			bene2.setEndorsement(endrs);
			bene2.setTEndrsBenePK(pk);

			endrsRepository.saveBeneficiary(bene2);
		}

		if (bene3 != null) {
			pk.setEndrsBeneSeqNum((short) 3);
			bene3.setEndorsement(endrs);
			bene3.setTEndrsBenePK(pk);

			endrsRepository.saveBeneficiary(bene3);
		}

		if (bene4 != null) {
			pk.setEndrsBeneSeqNum((short) 4);
			bene4.setEndorsement(endrs);
			bene4.setTEndrsBenePK(pk);

			endrsRepository.saveBeneficiary(bene4);
		}

		if (bene5 != null) {
			pk.setEndrsBeneSeqNum((short) 5);
			bene5.setEndorsement(endrs);
			bene5.setTEndrsBenePK(pk);

			endrsRepository.saveBeneficiary(bene5);
		}

		if (bene6 != null) {
			pk.setEndrsBeneSeqNum((short) 6);
			bene6.setEndorsement(endrs);
			bene6.setTEndrsBenePK(pk);

			endrsRepository.saveBeneficiary(bene6);
		}

		log.info("FIN saveBeneficiary");
	}

	public Date setDate(String dateOrig) {
		Date date = null;
		ZoneId defaultZoneId = ZoneId.systemDefault();
		DateTimeFormatter dateTimeFormatter = null;
		try {
			if (dateOrig.contains(ConstantUtility.FORWARD_SLASH)) {
				dateTimeFormatter = DateTimeFormatter.ofPattern(ConstantUtility.DATE_FORMAT_DD_MM_YYYY);
			} else {
				dateTimeFormatter = DateTimeFormatter.BASIC_ISO_DATE;
			}
			
			LocalDate datesLocal = LocalDate.parse(dateOrig, dateTimeFormatter);
			date = Date.from(datesLocal.atStartOfDay(defaultZoneId).toInstant());
			return date;
		} catch (Exception e) {
			log.error(e.getMessage());
			return null;
		}
	}

	public String generateUID() {
		return UUID.randomUUID().toString().substring(0, 16);
	}
	
	
	/*
	 * public static void main(String[] args) { EndrsServiceImpl esi = new
	 * EndrsServiceImpl();
	 * System.out.println(esi.setDate("20191112"));
	 * System.out.println(esi.setDate("11/12/2019"));
	 * System.out.println(esi.setDate("05/05/2008"));
	 * System.out.println(esi.setDate("35/12/1990"));
	 * System.out.println(esi.setDate("20191532"));}
	 */
	 

}
