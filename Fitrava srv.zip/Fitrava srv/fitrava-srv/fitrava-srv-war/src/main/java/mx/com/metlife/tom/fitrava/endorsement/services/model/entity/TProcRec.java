package mx.com.metlife.tom.fitrava.endorsement.services.model.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import lombok.Data;

@SuppressWarnings("serial")
@Data
@Entity
@Table(name = "T_PROC_REC")
@IdClass(TProcRecPk.class)
public class TProcRec implements java.io.Serializable{

	@Id
	@Column(name="DSTNCT_CTRL_NUM")
	private String dstnctCtrlNum;
	
	@Id
	@Column(name = "REC_NUM")
	private Long recNum;
	
	@Id
	@Column(name = "LAYOUT_FLD_ID")
	private Long layoutFldId;
	
	@Column(name = "ORIG_VAL")
	private String origVal;

	@Column(name = "NEW_VAL")
	private String newVal;

	@Column(name = "BAD_RSLT_CD")
	private Boolean badRsltInd;

	@Column(name = "MSG_TXT")
	private String msgTxt;
}
