package mx.com.metlife.tom.fitrava.endorsement.services.service.dto;

import lombok.Data;

@Data
public class UploadRejectResponse {
	private String dcn;

	private UploadUploadStatusDTO summaryLayout;

	private UploadUploadStatusDTO summaryBusiness;

	Integer resultCode;

	String resultDescription;
}
