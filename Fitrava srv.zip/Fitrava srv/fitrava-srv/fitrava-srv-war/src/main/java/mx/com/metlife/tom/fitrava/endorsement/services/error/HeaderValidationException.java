package mx.com.metlife.tom.fitrava.endorsement.services.error;

/**
 * Exception class to handle custom validation related exceptions related to fields recieved in headers.
 * 
 * @author Capgemini
 * @since 04/02/2019
 */
public class HeaderValidationException extends Exception{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 7078526329861259336L;
	private final String element;

	public HeaderValidationException(String message, String element) {
		super(message);
		this.element = element;
	}
	
	public String getElement() {
		return element;
	}

}
