package mx.com.metlife.tom.fitrava.endorsement.services.model.entity;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Embeddable
@Data
@AllArgsConstructor
@NoArgsConstructor
public class TEndrsBenePK implements Serializable {


  private static final long serialVersionUID = 1L;
  @Basic(optional = false)
  @NotNull
  @Column(name = "ENDRS_ID")
  private long endrsId;
  
  @Basic(optional = false)
  @NotNull
  @Column(name = "ENDRS_BENE_SEQ_NUM")
  private short endrsBeneSeqNum;


}
