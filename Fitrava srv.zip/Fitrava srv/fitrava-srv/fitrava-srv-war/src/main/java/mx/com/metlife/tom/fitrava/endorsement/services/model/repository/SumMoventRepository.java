package mx.com.metlife.tom.fitrava.endorsement.services.model.repository;

import static mx.com.metlife.tom.fitrava.endorsement.services.utility.ConstantUtility.DCN1;
import static mx.com.metlife.tom.fitrava.endorsement.services.utility.ConstantUtility.DCN2;
import static mx.com.metlife.tom.fitrava.endorsement.services.utility.ConstantUtility.DCN3;
import static mx.com.metlife.tom.fitrava.endorsement.services.utility.ConstantUtility.DCN4;
import static mx.com.metlife.tom.fitrava.endorsement.services.utility.ConstantUtility.DCN5;
import static mx.com.metlife.tom.fitrava.endorsement.services.utility.ConstantUtility.GET_QUERY_SUMMARY;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import mx.com.metlife.tom.fitrava.endorsement.services.service.dto.UploadSummaryMomentQueryResultDTO;

@SuppressWarnings("rawtypes")
@Repository
@Qualifier("summaryRepository")
public class SumMoventRepository extends BaseRepository {

	@SuppressWarnings("unchecked")
	public List<UploadSummaryMomentQueryResultDTO> getQueryResult(String dcn) {
		Query query = getEntityManager().createNativeQuery(GET_QUERY_SUMMARY);
		query.setParameter(DCN1, dcn);
		query.setParameter(DCN2, dcn);
		query.setParameter(DCN3, dcn);
		query.setParameter(DCN4, dcn);
		query.setParameter(DCN5, dcn);

		List<Object[]> endormentSummaryList = query.getResultList();
		return getListofObject(endormentSummaryList);

	}

	public List<UploadSummaryMomentQueryResultDTO> getListofObject(List<Object[]> summayList) {

		List<UploadSummaryMomentQueryResultDTO> objectList = new ArrayList<>();
		UploadSummaryMomentQueryResultDTO summaryObject = null;
		for (Object[] object : summayList) {
			summaryObject = new UploadSummaryMomentQueryResultDTO();
			summaryObject.setType(object[0].toString());
			summaryObject.setResult(object[1].toString());
			summaryObject.setTotal(Integer.parseInt(object[2].toString()));
			objectList.add(summaryObject);
		}
		return objectList;
	}

	

}
