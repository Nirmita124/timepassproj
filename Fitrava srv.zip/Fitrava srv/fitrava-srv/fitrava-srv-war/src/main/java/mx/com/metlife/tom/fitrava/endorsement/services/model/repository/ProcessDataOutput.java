package mx.com.metlife.tom.fitrava.endorsement.services.model.repository;

import static mx.com.metlife.tom.fitrava.endorsement.services.utility.ConstantUtility.CHAR_SPCAE;
import static mx.com.metlife.tom.fitrava.endorsement.services.utility.ConstantUtility.EMPTY_STRING;
import static mx.com.metlife.tom.fitrava.endorsement.services.utility.ConstantUtility.CHAR_ZERO;
import static mx.com.metlife.tom.fitrava.endorsement.services.utility.ConstantUtility.FORMAT_15SN;
import static mx.com.metlife.tom.fitrava.endorsement.services.utility.ConstantUtility.FORMAT_1S;
import static mx.com.metlife.tom.fitrava.endorsement.services.utility.ConstantUtility.FORMAT_1SN;
import static mx.com.metlife.tom.fitrava.endorsement.services.utility.ConstantUtility.FORMAT_2S;
import static mx.com.metlife.tom.fitrava.endorsement.services.utility.ConstantUtility.FORMAT_2SN;
import static mx.com.metlife.tom.fitrava.endorsement.services.utility.ConstantUtility.FORMAT_3S;
import static mx.com.metlife.tom.fitrava.endorsement.services.utility.ConstantUtility.FORMAT_6SN;
import static mx.com.metlife.tom.fitrava.endorsement.services.utility.ConstantUtility.FORMAT_8S;
import static mx.com.metlife.tom.fitrava.endorsement.services.utility.ConstantUtility.ONE;
import static mx.com.metlife.tom.fitrava.endorsement.services.utility.ConstantUtility.SPACE;
import static mx.com.metlife.tom.fitrava.endorsement.services.utility.ConstantUtility.ZERO;
import static mx.com.metlife.tom.fitrava.endorsement.services.utility.ConstantUtility.DOUBLE_LOGGER;
import static mx.com.metlife.tom.fitrava.endorsement.services.utility.ConstantUtility.FORWARD_SLASH;
import static mx.com.metlife.tom.fitrava.endorsement.services.utility.ConstantUtility.HYPHEN_SINGLE;
import static mx.com.metlife.tom.fitrava.endorsement.services.utility.ConstantUtility.STRING_S;
import static mx.com.metlife.tom.fitrava.endorsement.services.utility.ConstantUtility.REGEX_HYPHEN_SINGLE;
import static mx.com.metlife.tom.fitrava.endorsement.services.utility.ConstantUtility.REGEX_NO_HYPHEN;
import static mx.com.metlife.tom.fitrava.endorsement.services.utility.ConstantUtility.MOVENDOSO_00;
import static mx.com.metlife.tom.fitrava.endorsement.services.utility.ConstantUtility.MOVENDOSO_50;
import static mx.com.metlife.tom.fitrava.endorsement.services.utility.ConstantUtility.MOVENDOSO_51;
import static mx.com.metlife.tom.fitrava.endorsement.services.utility.ConstantUtility.MOVENDOSO_52;

import static org.slf4j.LoggerFactory.getLogger;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import mx.com.metlife.tom.fitrava.endorsement.services.model.entity.TLayout;
import mx.com.metlife.tom.fitrava.endorsement.services.model.entity.TProcRec;
import mx.com.metlife.tom.fitrava.endorsement.services.service.EndrsServiceImpl;
import mx.com.metlife.tom.fitrava.endorsement.services.service.dto.OutputDTO;
import mx.com.metlife.tom.fitrava.endorsement.services.utility.ConstantUtility;
import mx.com.metlife.tom.fitrava.endorsement.services.utility.LayoutDefinition;

@Repository
@Qualifier("processOutPutData")
public class ProcessDataOutput {

	private static final Logger logger = getLogger(ProcessDataOutput.class);

	@Autowired
	UploadDataRepository uploadRepository;

	@Autowired
	CommonFitravaRepository commonRepository;

	@Autowired
	EndrsServiceImpl endrsService;

	public List<OutputDTO> processdata(String dcn, String source) {
		logger.info(DOUBLE_LOGGER, ConstantUtility.IN_PROCESSDATA, dcn);
		List<TProcRec> tprocList = uploadRepository.getRecordsFileGeneration(dcn);
		List<OutputDTO> finaldataList = new ArrayList<>();
		Map<Long, OutputDTO> typeMap = new HashMap<>();
		TLayout tLayout = commonRepository.getLayoutByName(ConstantUtility.ENDOSOS);
	//	Map<String, Long> layoutFieldMap = commonRepository.getLayoutFieldId(tLayout.getLayoutId());
		Map<Long, String> layoutMap = commonRepository.getLayoutFiel(tLayout.getLayoutId());
		
		for (TProcRec tproc : tprocList) {
			Long fldVal = tproc.getLayoutFldId();
			Long recNumber = tproc.getRecNum();
			OutputDTO getOutputDTO = typeMap.getOrDefault(recNumber, new OutputDTO());
			
			if(layoutMap.get(fldVal).equals(LayoutDefinition.CLAVE_DE_AGENTE.getExcelColumnName())){
				getOutputDTO.setAgentKey(formatOutputData(tproc.getNewVal(), 6, false).replace(CHAR_SPCAE, CHAR_ZERO));
			} else if (layoutMap.get(fldVal).equals(LayoutDefinition.FETCHA_MOVIMIENTO.getExcelColumnName())) {
				getOutputDTO.setFecha(this.setInFecha(tproc));
			} else if (layoutMap.get(fldVal).equals(LayoutDefinition.RAMO_SUB_RAMO.getExcelColumnName())) {
				getOutputDTO
						.setRamSubRamo(formatOutputData(tproc.getNewVal(), 5, false).replace(CHAR_SPCAE, CHAR_ZERO));
			} else if (layoutMap.get(fldVal).equals(LayoutDefinition.NUMERO_DE_POLIZA.getExcelColumnName())) {
				getOutputDTO.setNPoliza(formatOutputData(tproc.getNewVal(), 7, false).replace(CHAR_SPCAE, CHAR_ZERO));
			} else if (layoutMap.get(fldVal).equals(LayoutDefinition.NUMERO_DE_SUBGRUPO.getExcelColumnName())) {
				getOutputDTO.setNSubGpo(formatOutputData(tproc.getNewVal(), 3, false).replace(CHAR_SPCAE, CHAR_ZERO));
			} else if (layoutMap.get(fldVal).equals(LayoutDefinition.NUMERO_DE_CATEGORIA.getExcelColumnName())) {
				getOutputDTO.setNCaTeg(formatOutputData(tproc.getNewVal(), 3, false).replace(CHAR_SPCAE, CHAR_ZERO));
			} else if (layoutMap.get(fldVal).equals(LayoutDefinition.NUMERO_DE_ASEGURADO.getExcelColumnName())) {
				getOutputDTO.setNaseg(formatOutputData(tproc.getNewVal(), 13, false).replace(CHAR_SPCAE, CHAR_ZERO));
			} else if (layoutMap.get(fldVal).equals(LayoutDefinition.TIPO_DE_MOVIMIENTO.getExcelColumnName())) {
				getOutputDTO.setMovEndosos(getMovendoso(tproc.getNewVal()).replace(CHAR_SPCAE, CHAR_ZERO));
				getOutputDTO.setTSolic(formatOutputData(tproc.getNewVal(), 2, false).replace(CHAR_SPCAE, CHAR_ZERO));
			} else if (layoutMap.get(fldVal).equals(LayoutDefinition.ORDEN_DE_TRABAJO.getExcelColumnName())) {
				getOutputDTO.setOT(formatOutputData(tproc.getNewVal(), 25, true));
			} else if (layoutMap.get(fldVal).equals(LayoutDefinition.NUMERO_DE_EMPLEADO.getExcelColumnName())) {
				getOutputDTO.setNumempldo(formatOutputData(tproc.getNewVal(), 10, true));
			} else if (layoutMap.get(fldVal).equals(LayoutDefinition.PARENTESCO.getExcelColumnName())) {
				getOutputDTO.setCvparent(this.setInCvparent(tproc));
			} else if (layoutMap.get(fldVal).equals(LayoutDefinition.TRATAMIENTO.getExcelColumnName())) {
				getOutputDTO.setTramto(formatOutputData(tproc.getNewVal(), 5, true));
			} else if (layoutMap.get(fldVal).equals(LayoutDefinition.CLAVE_DE_BANCO_INDIVIDUAL.getExcelColumnName())) {
				getOutputDTO.setCvintban(formatOutputData(tproc.getNewVal(), 18, true));
			} else if (layoutMap.get(fldVal).equals(LayoutDefinition.APELLIDO_PATERNO.getExcelColumnName())) {
				getOutputDTO.setAppater(formatOutputData(tproc.getNewVal(), 40, true));
			} else if (layoutMap.get(fldVal).equals(LayoutDefinition.APELLIDO_MATERNO.getExcelColumnName())) {
				getOutputDTO.setApmater(formatOutputData(tproc.getNewVal(), 40, true));
			} else if (layoutMap.get(fldVal).equals(LayoutDefinition.NOMBRE_ASEGURADO.getExcelColumnName())) {
				getOutputDTO.setNombres(formatOutputData(tproc.getNewVal(), 40, true));
			} else if (layoutMap.get(fldVal).equals(LayoutDefinition.FECHA_DE_NACIMIENTO.getExcelColumnName())) {
				getOutputDTO.setFnac(this.setDate(tproc));
			} else if (layoutMap.get(fldVal).equals(LayoutDefinition.SEXO.getExcelColumnName())) {
				getOutputDTO.setCvsexo(formatOutputData(tproc.getNewVal(), 1, false).replace(CHAR_SPCAE, CHAR_ZERO));
			} else if (layoutMap.get(fldVal).equals(LayoutDefinition.RFC.getExcelColumnName())) {
				getOutputDTO.setRfc(formatOutputData(tproc.getNewVal(), 13, true));
			} else if (layoutMap.get(fldVal).equals(LayoutDefinition.CURP.getExcelColumnName())) {
				getOutputDTO.setCurp(formatOutputData(tproc.getNewVal(), 18, true));
			} else if (layoutMap.get(fldVal).equals(LayoutDefinition.FECHA_ALTA.getExcelColumnName())) {
				getOutputDTO.setFstalta(this.setDate(tproc));
			} else if (layoutMap.get(fldVal).equals(LayoutDefinition.FECHA_BAJA.getExcelColumnName())) {
				getOutputDTO.setFstbaja(this.setInFstbaja(tproc));
			} else if (layoutMap.get(fldVal).equals(LayoutDefinition.FECHA_INGRESO_EMP.getExcelColumnName())) {
				String toSetInFinisegAndFingemp = this.setDate(tproc);
				getOutputDTO.setFingemp(toSetInFinisegAndFingemp);
				getOutputDTO.setFiniseg(toSetInFinisegAndFingemp);
			} else if (layoutMap.get(fldVal).equals(LayoutDefinition.ESTADO_CIVIL.getExcelColumnName())) {
				getOutputDTO.setCvedociv(formatOutputData(tproc.getNewVal(), 1, false).replace(CHAR_SPCAE, CHAR_ZERO));
			} else if (layoutMap.get(fldVal).equals(LayoutDefinition.SUELDO.getExcelColumnName())) {
				getOutputDTO.setSueldo(formatOutputData(tproc.getNewVal(), 12, false).replace(CHAR_SPCAE, CHAR_ZERO));
			} else if (layoutMap.get(fldVal).equals(LayoutDefinition.NIVEL.getExcelColumnName())) {
				getOutputDTO.setNivel(formatOutputData(tproc.getNewVal(), 5, false).replace(CHAR_SPCAE, CHAR_ZERO));
			} else if (layoutMap.get(fldVal).equals(LayoutDefinition.CENTRO_DE_TRABAJO.getExcelColumnName())) {
				getOutputDTO.setCentrotrab(formatOutputData(tproc.getNewVal(), 27, true));
			} else if (layoutMap.get(fldVal).equals(LayoutDefinition.FECHA_ASEGURADO_DESDE.getExcelColumnName())) {
				getOutputDTO.setFasegdesde(this.setDate(tproc));
			} else if (layoutMap.get(fldVal).equals(LayoutDefinition.SUMA_AUTO_BASICA_BASE.getExcelColumnName())) {
				getOutputDTO.setSamaxsra(formatOutputData(tproc.getNewVal(), 9, false).replace(CHAR_SPCAE, CHAR_ZERO));
			} else if (layoutMap.get(fldVal).equals(LayoutDefinition.BT1.getExcelColumnName())) {
				getOutputDTO.setNdepend(formatOutputData(tproc.getNewVal(), 2, false).replace(CHAR_SPCAE, CHAR_ZERO));
			}
			typeMap.put(recNumber, getOutputDTO);
		}
		List<String> uuids = new ArrayList<>();
		new ArrayList<>(typeMap.values()).forEach(data -> {
			String ui = endrsService.generateUID();
			uuids.add(ui);
			data.setNFolio(ui);
			data.setIdBroker(String.format(FORMAT_6SN, ZERO).replace(CHAR_SPCAE, CHAR_ZERO));
			data.setFecEfect(String.format(FORMAT_8S, ZERO).replace(CHAR_SPCAE, CHAR_ZERO));
			data.setInstcobro(String.format(FORMAT_1S, ONE));
			data.setFmaadmva(String.format(FORMAT_1S, ZERO));
			data.setCvnaseg(String.format(FORMAT_1S, ONE));
			data.setTiporfc(String.format(FORMAT_1S, ONE));
			data.setCvaseg(String.format(FORMAT_6SN, SPACE));
			data.setHcvaseg(String.format(FORMAT_2SN, ZERO).replace(CHAR_SPCAE, CHAR_ZERO));
			data.setCvnfuma(String.format(FORMAT_1SN, ZERO).replace(CHAR_SPCAE, CHAR_ZERO));
			data.setStsinies(String.format(FORMAT_1SN, ZERO).replace(CHAR_SPCAE, CHAR_ZERO));
			data.setAsegsinies(String.format(FORMAT_1SN, ZERO).replace(CHAR_SPCAE, CHAR_ZERO));
			data.setCvreafac(String.format(FORMAT_1SN, ZERO).replace(CHAR_SPCAE, CHAR_ZERO));
			data.setZona(String.format(FORMAT_1SN, ZERO).replace(CHAR_SPCAE, CHAR_ZERO));
			data.setRiesgocup(String.format(FORMAT_1SN, ZERO).replace(CHAR_SPCAE, CHAR_ZERO));
			data.setGponivel(String.format(FORMAT_3S, ZERO).replace(CHAR_SPCAE, CHAR_ZERO));
			data.setRegion(String.format(FORMAT_2S, ZERO).replace(CHAR_SPCAE, CHAR_ZERO));
			data.setAnting(String.format(FORMAT_2S, ZERO).replace(CHAR_SPCAE, CHAR_ZERO));
			data.setCvlimsa(String.format(FORMAT_1S, ZERO).replace(CHAR_SPCAE, CHAR_ZERO));
			data.setCargdep(String.format(FORMAT_1SN, SPACE));
			data.setNorden(String.format(FORMAT_15SN, ZERO).replace(CHAR_SPCAE, CHAR_ZERO));
			data.setNesqfpago(String.format(FORMAT_3S, ZERO).replace(CHAR_SPCAE, CHAR_ZERO));
			data.setFill5(formatOutputData(EMPTY_STRING, 5, false));
			data.setOrigen(formatOutputData(source, 3, false));
			// CHCK THIS FIELD, LONG AND FILL
			data.setFillerusr(formatOutputData(EMPTY_STRING, 107, false));

			finaldataList.add(data);
		});

		endrsService.groupProcRec(tprocList, layoutMap, dcn, uuids);

		return finaldataList;
	}

	private String setInFstbaja(TProcRec tproc) {
		String toSetInFstbaja = null;
		if (null == tproc.getNewVal() || tproc.getNewVal().isEmpty()) {
			String currentDate = LocalDate.now().format(DateTimeFormatter.BASIC_ISO_DATE);
			toSetInFstbaja = formatOutputData(currentDate, 8, false).replace(CHAR_SPCAE, CHAR_ZERO);
		} else {
			if (tproc.getNewVal().contains(FORWARD_SLASH)) {
				String formattedDate = getFormattedDate(tproc.getNewVal());
				toSetInFstbaja = formatOutputData(formattedDate, 8, false).replace(CHAR_SPCAE, CHAR_ZERO);
			} else {
				toSetInFstbaja = formatOutputData(tproc.getNewVal(), 8, false).replace(CHAR_SPCAE, CHAR_ZERO);

			}
		}
		return toSetInFstbaja;
	}

	private String setDate(TProcRec tproc) {
		String toDate = null;
		if (null != tproc.getNewVal() && !tproc.getNewVal().isEmpty() && tproc.getNewVal().contains(FORWARD_SLASH)) {
			String formattedDate = getFormattedDate(tproc.getNewVal());
			toDate = formatOutputData(formattedDate, 8, false).replace(CHAR_SPCAE, CHAR_ZERO);
		} else {
			toDate = formatOutputData(tproc.getNewVal(), 8, false).replace(CHAR_SPCAE, CHAR_ZERO);
		}
		return toDate;
	}

	private String setInCvparent(TProcRec tproc) {
		String toSetInCvparent = null;
		if (null != tproc.getNewVal() && !tproc.getNewVal().isEmpty()) {
			toSetInCvparent = formatOutputData(tproc.getNewVal(), 1, true);
		} else {
			toSetInCvparent = formatOutputData(ZERO, 1, true);
		}
		return toSetInCvparent;
	}

	private String setInFecha(TProcRec tproc) {
		String fecha = tproc.getNewVal();
		if (null == fecha || fecha.isEmpty()) {
			fecha = LocalDate.now().format(DateTimeFormatter.BASIC_ISO_DATE);
		} else if (fecha.contains(HYPHEN_SINGLE)) {
			fecha = fecha.replaceAll(HYPHEN_SINGLE, EMPTY_STRING);
		} else if (fecha.contains(FORWARD_SLASH)) {
			fecha = getFormattedDate(tproc.getNewVal());
		}
		return formatOutputData(fecha, 8, false).replace(CHAR_SPCAE, CHAR_ZERO);
	}

	public String formatOutputData(String value, int width, boolean isRightPadding) {
		String formatExp = EMPTY_STRING;
		if (isRightPadding)
			formatExp = new StringBuilder().append(REGEX_HYPHEN_SINGLE).append(width).append(STRING_S).toString();
		else
			formatExp = new StringBuilder().append(REGEX_NO_HYPHEN).append(width).append(STRING_S).toString();

		return String.format(formatExp, value);
	}

	public String getMovendoso(String value) {
		String returnValue = EMPTY_STRING;
		if (StringUtils.isNotEmpty(value)) {
			Integer movendoso = Integer.parseInt(value);
			switch (movendoso) {
			case 1:
			case 2:
				returnValue = MOVENDOSO_50;
				break;
			case 3:
			case 4:
				returnValue = MOVENDOSO_51;
				break;
			case 5:
			case 6:
			case 7:
			case 8:
			case 9:
			case 10:
			case 11:
			case 12:
			case 13:
			case 14:
				returnValue = MOVENDOSO_52;
				break;
			default:
				returnValue = MOVENDOSO_00;
				break;
			}
		}
		return formatOutputData(returnValue, 2, false);
	}

	public String getFormattedDate(String date) {
		String formattedString = EMPTY_STRING;
		try {
			LocalDate dates = LocalDate.parse(date,
					DateTimeFormatter.ofPattern(ConstantUtility.DATE_FORMAT_DD_MM_YYYY));
			formattedString = dates.format(DateTimeFormatter.BASIC_ISO_DATE);
		} catch (Exception ex) {
			return formattedString;
		}

		return formattedString;
	}

}
