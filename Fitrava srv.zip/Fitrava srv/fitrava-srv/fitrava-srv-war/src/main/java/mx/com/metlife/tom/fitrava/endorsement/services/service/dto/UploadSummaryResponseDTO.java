package mx.com.metlife.tom.fitrava.endorsement.services.service.dto;

import java.util.List;

import lombok.Data;

@Data
public class UploadSummaryResponseDTO {

	
	String dcn;
	
	Integer resultCode;
	
	String resultDescription;
	
	List <UploadSummaryMovDTO> summaryMovements;
	
}
