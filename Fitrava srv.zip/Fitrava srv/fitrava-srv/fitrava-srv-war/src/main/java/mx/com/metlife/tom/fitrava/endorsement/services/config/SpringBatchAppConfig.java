package mx.com.metlife.tom.fitrava.endorsement.services.config;

import java.net.MalformedURLException;
import java.util.Date;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.persistence.EntityManager;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.scheduling.annotation.Scheduled;

import mx.com.metlife.tom.fitrava.endorsement.services.service.SpringBatchReader;
import mx.com.metlife.tom.fitrava.endorsement.services.service.SpringBatchWriter;
import mx.com.metlife.tom.fitrava.endorsement.services.service.dto.TProcDTO;

//@Configuration
@EnableBatchProcessing
public class SpringBatchAppConfig {
	@Autowired
	private JobBuilderFactory jobs;

	@Autowired
	private StepBuilderFactory steps;

	@Autowired
	EntityManager fitravaEntityManager;

	@Autowired
	private JobLauncher jobLauncher;

	@Bean
	public ItemReader<List<TProcDTO>> reader() {
		return new SpringBatchReader();
	}

	public static final String SPRING_BATCH_CRON = "* */10 * * * *";

	public static final String SPRING_START_DATE = "startDate";
	
	public static final String SPRING_START_JOB = "startJob";

	public static final String SPRING_START_JOBGCAYE = "startJobforGcaye";

	@Bean
	public ItemWriter<List<TProcDTO>> writer() {
		return new SpringBatchWriter();
	}

	@Bean(name = "job")
	public Job startJobforGcaye() throws MalformedURLException {
		return jobs.get(SPRING_START_JOBGCAYE).start(startJob()).build();
	}

	@Bean
	public Step startJob() throws MalformedURLException {
		return steps.get(SPRING_START_JOB).<List<TProcDTO>, List<TProcDTO>>chunk(1).reader(reader()).writer(writer()).build();
	}

	@PostConstruct
	@Scheduled(cron = "* */10 * * * *")
	public void perform() throws MalformedURLException, JobExecutionAlreadyRunningException, JobRestartException, JobInstanceAlreadyCompleteException, JobParametersInvalidException {
		Job job = startJobforGcaye();
		JobParameters jobParameters = new JobParametersBuilder().addDate(SPRING_START_DATE, new Date())
				.toJobParameters();
		jobLauncher.run(job, jobParameters);
	}

}
