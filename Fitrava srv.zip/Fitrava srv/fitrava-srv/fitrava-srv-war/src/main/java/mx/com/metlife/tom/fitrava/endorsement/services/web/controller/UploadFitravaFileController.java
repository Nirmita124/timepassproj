package mx.com.metlife.tom.fitrava.endorsement.services.web.controller;

import static mx.com.metlife.tom.fitrava.endorsement.services.utility.ConstantUtility.DOUBLE_LOGGER;
import static mx.com.metlife.tom.fitrava.endorsement.services.utility.ConstantUtility.JSON_FILE_RQRD;
import static mx.com.metlife.tom.fitrava.endorsement.services.utility.ConstantUtility.MAX_2_FILES;
import static mx.com.metlife.tom.fitrava.endorsement.services.utility.ConstantUtility.NOT_ALLOWED;
import static mx.com.metlife.tom.fitrava.endorsement.services.utility.ConstantUtility.NOT_ALLOWED_FILE_TYPE;
import static mx.com.metlife.tom.fitrava.endorsement.services.utility.ConstantUtility.SPACE;
import static mx.com.metlife.tom.fitrava.endorsement.services.utility.ConstantUtility.TEXT_FALSE;
import static mx.com.metlife.tom.fitrava.endorsement.services.utility.ConstantUtility.TEXT_TRUE;
import static org.slf4j.LoggerFactory.getLogger;

import java.io.IOException;
import java.util.List;

import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import mx.com.metlife.tom.fitrava.endorsement.services.error.FitravaException;
import mx.com.metlife.tom.fitrava.endorsement.services.model.repository.UploadDataRepository;
import mx.com.metlife.tom.fitrava.endorsement.services.service.CallBPMProcess;
import mx.com.metlife.tom.fitrava.endorsement.services.service.FileWriteService;
import mx.com.metlife.tom.fitrava.endorsement.services.service.FitravaService;
import mx.com.metlife.tom.fitrava.endorsement.services.service.GetUploadSummaryService;
import mx.com.metlife.tom.fitrava.endorsement.services.service.ReadFileMXFitravaService;
import mx.com.metlife.tom.fitrava.endorsement.services.service.SendFileTransferSFTP;
import mx.com.metlife.tom.fitrava.endorsement.services.service.dto.TProcRecDTO;
import mx.com.metlife.tom.fitrava.endorsement.services.service.dto.UploadRejectResponse;
import mx.com.metlife.tom.fitrava.endorsement.services.service.dto.UploadRequest;
import mx.com.metlife.tom.fitrava.endorsement.services.service.dto.UploadRequestForXLSX;
import mx.com.metlife.tom.fitrava.endorsement.services.service.dto.UploadResponse;
import mx.com.metlife.tom.fitrava.endorsement.services.service.dto.UploadSummaryResponseDTO;
import mx.com.metlife.tom.fitrava.endorsement.services.service.dto.UsuarioPasswordDTO;
import mx.com.metlife.tom.fitrava.endorsement.services.utility.ConstantUtility;
import mx.com.metlife.tom.fitrava.endorsement.services.utility.EncriptionUtils;
import mx.com.metlife.tom.fitrava.endorsement.services.utility.LayoutValidations;
import mx.com.metlife.tom.fitrava.endorsement.services.utility.MethodUtility;

@RestController
@CrossOrigin
@PropertySource("classpath:${ftv_env:dev}-endpoint.properties")
@RequestMapping(value = "${url.contextroot}")
public class UploadFitravaFileController {

	@Autowired
	GetUploadSummaryService uploadSummaryServiceImpl;

	@Autowired
	ReadFileMXFitravaService uploadFileService;

	@Autowired
	UploadDataRepository uploadDataRepository;

	@Autowired
	SendFileTransferSFTP sendFileTransferSFTP;

	@Autowired
	FileWriteService fileWriteService;

	@Autowired
	CallBPMProcess bpmServiceUtility;

	@Autowired
	FitravaService fitravaService;

	private static final Logger logger = getLogger(UploadFitravaFileController.class);

	// JustForTest
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@GetMapping(value = "${url.date}")
	public ResponseEntity getDate() {
		try {
			return new ResponseEntity(fitravaService.getDate(), HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity(e.getMessage(), HttpStatus.BAD_REQUEST);
		}
	}

	@GetMapping(value = "${url.pingurl}")
	public @ResponseBody ResponseEntity<String> hola(@RequestParam("ping") String ping) {
		return new ResponseEntity<>("Hola mundo " + ping, HttpStatus.OK);
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@GetMapping(value = "${url.ping}")
	@CrossOrigin
	public @ResponseBody ResponseEntity pingService() throws FitravaException {
		String result = ConstantUtility.EMPTY_STRING;
		result = fileWriteService.writeToTextFileTest();
		UploadSummaryResponseDTO response = new UploadSummaryResponseDTO();
		response.setResultDescription(result);
		return new ResponseEntity(response, HttpStatus.OK);
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@GetMapping(value = "${url.uploadSummary}")
	public @ResponseBody ResponseEntity getEndorsementsSummaryMovement(@PathVariable(name = "dcn") String dcn)
			throws FitravaException {
		logger.info(DOUBLE_LOGGER, ConstantUtility.IN_GET_ENDORSEMENTS_SUMMARY_MOVEMENT, dcn);
		UploadSummaryResponseDTO response = uploadSummaryServiceImpl.getUploadSummaryMovement(dcn);
		return new ResponseEntity(response, HttpStatus.OK);

	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@GetMapping(value = "callBPMTest")
	public @ResponseBody ResponseEntity getEndorsementsRejecBPM() throws FitravaException {
		bpmServiceUtility.callBPMService(1, ConstantUtility.P20192491CHSP0911255);
		return new ResponseEntity(ConstantUtility.SUCCESS, HttpStatus.OK);
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@GetMapping(value = "${url.uploadReject}")
	public @ResponseBody ResponseEntity getEndorsementsRejec(@PathVariable(name = "dcn") String dcn)
			throws FitravaException {
		logger.info(DOUBLE_LOGGER, ConstantUtility.IN_GET_ENDORSEMENTS_REJEC, dcn);
		UploadRejectResponse response = uploadSummaryServiceImpl.getUploadRejec(dcn);
		return new ResponseEntity(response, HttpStatus.OK);

	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@GetMapping(value = "${url.applyValidation}")
	public @ResponseBody ResponseEntity applyValidateFileLayout(@PathVariable(name = "dcn") String dcn)
			throws FitravaException {
		logger.info(DOUBLE_LOGGER, ConstantUtility.IN_APPLY_VALIDATE_FILE_LAYOUT, dcn);
		UploadResponse uploadResponse = new UploadResponse();
		uploadResponse.setCode(0);
		uploadResponse.setMessage(ConstantUtility.SUCCESS);
		uploadResponse.setSystemMessage(ConstantUtility.SUCCESS);
		uploadFileService.applyValidateFileLayoutAsync(dcn);
		return new ResponseEntity(uploadResponse, HttpStatus.OK);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@PostMapping(value = "${url.uploadFile}")
	public ResponseEntity uploadFile(@RequestParam("files") MultipartFile[] files, @RequestParam String isMassive)
			throws FitravaException, JsonParseException, JsonMappingException, IOException, IllegalAccessException {
		UploadResponse uploadResponse = new UploadResponse();
		boolean dcnExists;
		logger.info(DOUBLE_LOGGER, ConstantUtility.IN_PROCESS_ENDORSMENT_WA_IS_MASSIVE, isMassive);
		if (files.length > ConstantUtility.TWO) {
			throw new FitravaException(MAX_2_FILES);
		}

		if (!LayoutValidations.validateJsonFilePresent(files)) {
			throw new FitravaException(JSON_FILE_RQRD);
		}

		MultipartFile excelFile = null;
		UploadRequest requestDTO = new UploadRequest();
		UploadRequestForXLSX requestDTOExcel = new UploadRequestForXLSX();
		for (MultipartFile multipartFile : files) {
			String getFileExtention = MethodUtility.getFileExtension(multipartFile.getOriginalFilename());
			if (getFileExtention.equalsIgnoreCase(ConstantUtility.FILE_TYPE_JSON)) {
				ObjectMapper mapper = new ObjectMapper();
				mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
				if (isMassive.equalsIgnoreCase(TEXT_TRUE)) {
					requestDTOExcel = mapper.readValue(multipartFile.getInputStream(), UploadRequestForXLSX.class);
				} else if (isMassive.equalsIgnoreCase(TEXT_FALSE)) {
					requestDTO = mapper.readValue(multipartFile.getInputStream(), UploadRequest.class);
				} else {
					throw new FitravaException(isMassive.concat(NOT_ALLOWED));
				}
			} else if (getFileExtention.equalsIgnoreCase(ConstantUtility.FILE_TYPE_XLSX)) {
				excelFile = multipartFile;
			} else {
				throw new FitravaException(getFileExtention.concat(NOT_ALLOWED_FILE_TYPE));
			}
		}
		List<TProcRecDTO> listTprocDTO = null;
		String source = ConstantUtility.EMPTY_STRING;
		String dcn = ConstantUtility.EMPTY_STRING;
		String fileName = ConstantUtility.EMPTY_STRING;
		if (isMassive.equalsIgnoreCase(TEXT_TRUE)) {
			switch (LayoutValidations.validateFiles(files)) {
			case 0:
				dcn = requestDTOExcel.getDcn();
				fileName = excelFile.getOriginalFilename();
				listTprocDTO = uploadFileService.getDTOsFromFile(fileName, dcn, excelFile);
				source = requestDTOExcel.getSource();
				break;
			case 1:
				bpmServiceUtility.callBPMService(1, requestDTOExcel.getDcn());
				break;
			default:
				bpmServiceUtility.callBPMService(1, requestDTOExcel.getDcn());
				break;
			}
		} else if (isMassive.equalsIgnoreCase(TEXT_FALSE)) {
			dcn = requestDTO.getDcn();
			source = requestDTO.getSource();
			fileName = requestDTO.getFileName();
			if (MethodUtility.isNullOrBlank(fileName)) {
				throw new FitravaException(ConstantUtility.JSON_FORMAT_ERROR);
			} else {
				listTprocDTO = uploadFileService.getDTOListFromJson(requestDTO);
			}
		}
		logger.info(DOUBLE_LOGGER, ConstantUtility.IN_PROCESS_ENDORSMENT_WA, dcn);
		dcnExists = uploadDataRepository.getDCNExists(dcn);
		if (dcnExists) {
			bpmServiceUtility.callBPMService(1, dcn);
			uploadResponse.setCode(1);
			uploadResponse.setMessage(ConstantUtility.TEXT_DCN_EXISTS);
			uploadResponse.setSystemMessage(ConstantUtility.TEXT_DCN_EXISTS_SYSTEM);
			return new ResponseEntity(uploadResponse, HttpStatus.OK);
		}
		source = null != source ? source.toUpperCase() : SPACE;
		uploadResponse = uploadFileService.uploadData(listTprocDTO, dcn, fileName, source, isMassive);
		return new ResponseEntity(uploadResponse, HttpStatus.OK);
	}

	@SuppressWarnings({ "rawtypes" })
	@PostMapping(value = "${url.uploadFileAlt}")
	public ResponseEntity uploadFileAlt(@RequestParam("files") MultipartFile[] files, @RequestParam String isMassive)
			throws FitravaException, IllegalAccessException, IOException {
		return uploadFile(files, isMassive);
	}
	

	@PostMapping(value="/users/encodeBase64") 
	public @ResponseBody ResponseEntity<UsuarioPasswordDTO> postEncode(@RequestBody UsuarioPasswordDTO usuarioPasswordDTO) throws Exception {
		return new ResponseEntity<>(new UsuarioPasswordDTO(MethodUtility.getEncoderBase64(usuarioPasswordDTO.getUsuarioPassword())), HttpStatus.OK);
	}
	
	@PostMapping(value="/users/decode") 
	public @ResponseBody ResponseEntity<UsuarioPasswordDTO> postDecode(@RequestBody UsuarioPasswordDTO usuarioPasswordDTO) throws Exception {
		String textoBase64  = MethodUtility.getDecoderBase64(usuarioPasswordDTO.getUsuarioPassword());
		logger.info("texto En Claro: {}", textoBase64);
		return new ResponseEntity<>(new UsuarioPasswordDTO(EncriptionUtils.encrypt(textoBase64)), HttpStatus.OK);
	}


}
