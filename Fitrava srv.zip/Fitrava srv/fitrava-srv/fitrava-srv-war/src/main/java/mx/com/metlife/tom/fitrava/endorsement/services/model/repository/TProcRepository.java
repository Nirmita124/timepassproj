package mx.com.metlife.tom.fitrava.endorsement.services.model.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import mx.com.metlife.tom.fitrava.endorsement.services.model.entity.TProc;
import mx.com.metlife.tom.fitrava.endorsement.services.model.entity.TProcRecPk;

public interface TProcRepository extends JpaRepository<TProc, TProcRecPk> {
	
	public TProc findFirstByDstnctCtrlNum(String dstnctCtrlNum);
	
}
