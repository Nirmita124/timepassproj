package mx.com.metlife.tom.fitrava.endorsement.services.model.repository;

import static org.slf4j.LoggerFactory.getLogger;
import static mx.com.metlife.tom.fitrava.endorsement.services.utility.ConstantUtility.DOUBLE_LOGGER;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceUnit;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import mx.com.metlife.tom.fitrava.endorsement.services.error.FitravaException;
import mx.com.metlife.tom.fitrava.endorsement.services.model.entity.TFlow;
import mx.com.metlife.tom.fitrava.endorsement.services.model.entity.TLayout;
import mx.com.metlife.tom.fitrava.endorsement.services.model.entity.TProc;
import mx.com.metlife.tom.fitrava.endorsement.services.model.entity.TProcFile;
import mx.com.metlife.tom.fitrava.endorsement.services.model.entity.TProcFilePk;
import mx.com.metlife.tom.fitrava.endorsement.services.model.entity.TProcRec;
import mx.com.metlife.tom.fitrava.endorsement.services.service.dto.TProcDTO;
import mx.com.metlife.tom.fitrava.endorsement.services.service.dto.TProcRecDTO;
import mx.com.metlife.tom.fitrava.endorsement.services.utility.ConstantUtility;

@SuppressWarnings("rawtypes")
@Repository("uploadRepository")
public class UploadDataRepository extends BaseRepository {
	private static final Logger logger = getLogger(UploadDataRepository.class);

	@PersistenceUnit(unitName = "fitravaEntityManagerPU")
	private EntityManagerFactory entityManagerFactory;

	@Resource
	TProcRecRepository tProcRecRepository;

	@Autowired
	CommonFitravaRepository commonRepository;

	public Date getDate() {
		EntityManager em = null;
		Query query = null;
		try {
			em = entityManagerFactory.createEntityManager();
			query = em.createNativeQuery("SELECT GETDATE()");
			Date dt = (Date) query.getSingleResult();
			return dt;
		} catch (Exception e) {
			logger.error(ConstantUtility.ERROR.concat(e.getLocalizedMessage()));
		}  finally {
			if (null != em) {
				em.close();
			}
		}
		return null;
	}

	
	
	public boolean updateTProcRec(List<TProcRecDTO> listTprocDTO) throws FitravaException {
		List<TProcRec> popuateDataList = getEntityList(listTprocDTO);
		try {
			EntityManager em = entityManagerFactory.createEntityManager();
			em.getTransaction().begin();
			popuateDataList.stream().forEach((tProcRec) -> em.merge(tProcRec));
			em.getTransaction().commit();
			em.close();
		} catch (Exception e) {
			logger.error(ConstantUtility.ERROR.concat(e.getLocalizedMessage()));
			throw new FitravaException(ConstantUtility.ERROR_IN_SAVING_DATA + e.getMessage());
		}
		return true;
	}
	
	@SuppressWarnings("unchecked")
	@Transactional
	public boolean saveorUpdateProc(String dcn, List<TProcRecDTO> listTprocDTO, String fileName, String source,
			String isMassive) throws FitravaException {
		List<TProcRec> popuateDataList = getEntityList(listTprocDTO);
		TProc tProc = new TProc();
		TFlow tFlow = commonRepository.getFlowByName(ConstantUtility.MAINTENANCE);
		TLayout tLayout = commonRepository.getLayoutByName(ConstantUtility.ENDOSOS);
		if (null == tLayout) {
			throw new FitravaException(ConstantUtility.LAYOUT_DEFINITION_IS_NOT_PRESENT_FOR_ENDOSOS_LAYOUT);
		}

		if (null == tFlow) {
			throw new FitravaException(ConstantUtility.FLOW_DEFINITION_IS_NOT_PRESENT_FOR_MAINTENANCE_FLOW);
		}

		try {
			tProc.setDstnctCtrlNum(dcn);
			tProc.setSourceField(source);
			tProc.setAdtField(isMassive);
			tProc.setFlowId(tFlow.getFlowId());
			tProc.setEntrncLayoutId(tLayout.getLayoutId());
			tProc.setRcptnTs(new Date());
			tProc.setPrtyNum(0);
			tProc.setCrtUsrId(ConstantUtility.TEXT_SYSTEM);
			tProc.setClctStts(1);
			tProc.setRsltDscr(ConstantUtility.SUCCESS_TEXT);
			saveEntity(tProc);
			TProcFile tProcFile = new TProcFile();
			tProcFile.setDstnctCtrlNum(dcn);
			tProcFile.setFileNm(fileName);
			tProcFile.setProcFileOrdNum(1);
			tProcFile.setClctSttsId(1);
			tProcFile.setProcFileStrtTs(new Date());
			tProcFile.setProcFileEndTs(new Date());
			saveEntity(tProcFile);

			tProcRecRepository.saveAll(popuateDataList);

		} catch (Exception e) {
			logger.error(ConstantUtility.ERROR.concat(e.getLocalizedMessage()));
			throw new FitravaException(ConstantUtility.ERROR_IN_SAVING_DATA + e.getMessage());
		}
		return true;
	}

	public List<TProcRec> getEntityList(List<TProcRecDTO> listTprocDTO) {
		List<TProcRec> listTProcRec = new ArrayList<>();
		listTprocDTO.forEach(tProcRecDTO -> {
			TProcRec tProc = new TProcRec();
			tProc.setDstnctCtrlNum(tProcRecDTO.getDcn());
			tProc.setLayoutFldId(tProcRecDTO.getLayoutID());
			tProc.setOrigVal(tProcRecDTO.getOriginalValue());
			tProc.setNewVal(tProcRecDTO.getNewValue());
			tProc.setBadRsltInd(!tProcRecDTO.isErrorIndicator());
			tProc.setRecNum(tProcRecDTO.getRecordNumber());
			tProc.setMsgTxt(tProcRecDTO.getMsgText());
			listTProcRec.add(tProc);
		});

		return listTProcRec;
	}

	public List<TProcRecDTO> getDTOsForDCN(String dcn) {
		List<TProcRec> tprocList = getRecordsForValidation(dcn);
		List<TProcRecDTO> listTprocDTO = new ArrayList<>();
		tprocList.forEach(tProcRec -> {
			TProcRecDTO tProcRecDTO = new TProcRecDTO();
			tProcRecDTO.setDcn(tProcRec.getDstnctCtrlNum());
			tProcRecDTO.setErrorIndicator(tProcRec.getBadRsltInd());
			tProcRecDTO.setLayoutID(tProcRec.getLayoutFldId());
			tProcRecDTO.setMsgText(tProcRec.getMsgTxt());
			tProcRecDTO.setNewValue(tProcRec.getNewVal());
			tProcRecDTO.setOriginalValue(tProcRec.getOrigVal());
			tProcRecDTO.setRecordNumber(tProcRec.getRecNum());
			listTprocDTO.add(tProcRecDTO);
		});
		Integer listSize = listTprocDTO.size();
		logger.info(ConstantUtility.IN_GET_DT_OS_FOR_DCN, listSize);
		return listTprocDTO;
	}

	@SuppressWarnings("unchecked")
	public List<TProcRec> getRecordsForValidation(String dcn) {
		logger.info(DOUBLE_LOGGER, ConstantUtility.IN_GET_RECORDS_FOR_VALIDATION, dcn);
		Query query = getEntityManager().createNativeQuery(ConstantUtility.GET_RECORDS_FILE_VALIDATION, TProcRec.class);
		query.setParameter(ConstantUtility.DCN1, dcn);
		return query.getResultList();
	}

	@SuppressWarnings("unchecked")
	public List<TProcRec> getRecordsFileGeneration(String dcn) {
		Query query = getEntityManager().createNativeQuery(ConstantUtility.GET_RECORDS_FILE_GEN, TProcRec.class);
		query.setParameter(ConstantUtility.DCN1, dcn);
		query.setParameter(ConstantUtility.DCN2, dcn);
		return query.getResultList();
	}

	@Transactional
	public boolean updateFileStatus(String dcn, Integer statusCode, String fileName) {
		TProc tporc = this.getEntityManager().find(TProc.class, dcn);
		if (null != fileName) {
			TProcFilePk tProcFilePk = new TProcFilePk(dcn, fileName);
			TProcFile tproFile = getEntityManager().find(TProcFile.class, tProcFilePk);
			tproFile.setClctSttsId(statusCode);
		}
		tporc.setClctStts(statusCode);
		return true;

	}

	
	public boolean updateFileStatusNew(String dcn, Integer statusCode, String fileName) {
		EntityManager em = null;
		try {
			em = entityManagerFactory.createEntityManager();
			em.getTransaction().begin();
			if (null != fileName) {
				TProcFilePk tProcFilePk = new TProcFilePk(dcn, fileName);
				TProcFile tproFile = em.find(TProcFile.class, tProcFilePk);
				tproFile.setClctSttsId(statusCode);
				em.merge(tproFile);
			}
			TProc tporc = em.find(TProc.class, dcn);
			tporc.setClctStts(statusCode);
			em.merge(tporc);
			em.getTransaction().commit();
		} catch (Exception excp) {
			em.getTransaction().rollback();
			logger.error("updateFileStatusNew --> {} ", excp.getLocalizedMessage());
		} finally {
			if (null != em) {
				em.close();
			}
		}
		return true;
	}

	@SuppressWarnings("unchecked")
	public List<TProcDTO> getStatusRecords() {
		Query query = this.getEntityManager().createNativeQuery(ConstantUtility.GET_RECORDS_STATUS_5);

		List<Object[]> objectList = query.getResultList();
		List<TProcDTO> dtoList = new ArrayList<>();

		objectList.forEach(object -> {
			TProcDTO dto = new TProcDTO();
			dto.setDstnctCtrlNum(object[0].toString());
			dto.setClctStts(Integer.parseInt(object[1].toString()));
			dtoList.add(dto);
		});

		return dtoList;
	}

	public boolean updateStatus(String dcn, Integer statusCode) {
		Query query = this.getEntityManager()
				.createNativeQuery("UPDATE T_FILE_PROC SET CLCT_STTS_ID = :statusCode where DSTNCT_CTRL_NUM = :DCN1");
		query.setParameter(ConstantUtility.STATUS_CODE, statusCode);
		query.setParameter(ConstantUtility.DCN1, dcn);
		this.getEntityManager().joinTransaction();
		query.executeUpdate();
		return true;

	}

	public boolean getDCNExists(String dcn) {
		Query query = this.getEntityManager().createNativeQuery(ConstantUtility.CHECKDCNEXIST);
		query.setParameter(ConstantUtility.DCN1, dcn);
		return ((Number) query.getSingleResult()).intValue() > 0;

	}

	@SuppressWarnings("unchecked")
	public TProc getTProc(String dcn) {
		logger.info(DOUBLE_LOGGER, ConstantUtility.IN_GET_T_PROC, dcn);
		Query query = this.getEntityManager().createQuery(" FROM  TProc tp WHERE tp.dstnctCtrlNum = :dcn ");
		query.setParameter(ConstantUtility.DCN6, dcn);
		List<TProc> tProcs = query.getResultList();
		return tProcs.get(0);
	}

	@SuppressWarnings("unchecked")
	public TProcFile getTProcFile(String dcn) {
		logger.info(DOUBLE_LOGGER, ConstantUtility.IN_GET_T_PROC_FILE, dcn);
		Query query = this.getEntityManager().createQuery(" FROM  TProcFile tpf WHERE tpf.dstnctCtrlNum = :dcn ");
		query.setParameter(ConstantUtility.DCN6, dcn);
		List<TProcFile> tProcFiles = query.getResultList();
		return tProcFiles.get(0);
	}

	@SuppressWarnings("unchecked")
	public TProcRec getTProcRec(String dcn, Long recNum, Long layoutFldId) {
		logger.info(DOUBLE_LOGGER, ConstantUtility.IN_GET_T_PROC_REC, dcn);
		Query query = this.getEntityManager().createQuery(
				"FROM TProcRec tpr WHERE tpr.dstnctCtrlNum = :dstnctCtrlNum AND tpr.recNum = :recNum AND tpr.layoutFldId = :layoutFldId");
		query.setParameter(ConstantUtility.DSTNCT_CTRL_NUM, dcn);
		query.setParameter(ConstantUtility.REC_NUM, recNum);
		query.setParameter(ConstantUtility.LAYOUT_FLD_ID, layoutFldId);
		List<TProcRec> tProcRecs = query.getResultList();
		return tProcRecs.get(0);
	}

}
