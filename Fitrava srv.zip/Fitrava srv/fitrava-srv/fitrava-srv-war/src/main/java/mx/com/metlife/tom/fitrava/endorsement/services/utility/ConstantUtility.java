package mx.com.metlife.tom.fitrava.endorsement.services.utility;

/**
 * Class to keep constants.
 * 
 * @author Capgemini
 * @since 26/03/2019
 */
public final class ConstantUtility {

	public static final String LAYOUT_FIELD_DEFINITION_IS_NOT_PRESENT_FOR_COLUMN = "Layout field definition is not present for Column ";
	public static final String ENDOSOS = "Endosos";
	public static final String FLOW_NAME = "flowName";
	public static final String ERROR_IN_SAVING_DATA = "@@@ Error in Saving Data ";
	public static final String LAYOUT_FLD_ID = "layoutFldId";
	public static final String REC_NUM = "recNum";
	public static final String DSTNCT_CTRL_NUM = "dstnctCtrlNum";
	public static final String STATUS_CODE = "statusCode";
	public static final String FLOW_DEFINITION_IS_NOT_PRESENT_FOR_MAINTENANCE_FLOW = "Flow definition is not present for Maintenance Flow";
	public static final String LAYOUT_DEFINITION_IS_NOT_PRESENT_FOR_ENDOSOS_LAYOUT = "Layout definition is not present for Endosos Layout";
	public static final String MAINTENANCE = "Maintenance";
	public static final String ERROR_IN_CALLING_BPM_SERVICE ="@@@ Error in Calling BPM Service ";
	public static final String INTERNAL_SERVER_ERROR = "500 Internal Server Error";
	public static final String BASIC = "Basic ";
	public static final String US_ASCII = "US-ASCII";
	public static final String FILENAME_20170924PPPWP1155081 = "20170924PPPWP1155081";
	public static final String ERROR_IN_GENERATION_OR_TRANSFER_OF_FILE = "@@@ Error in generation or Transfer of File ";
	public static final String OUTPUT_TXT = "_Output.txt";
	public static final String EXCEPTION = "Exception";
	public static final String ALL_THE_ROWS_IN_THE_FILE_HAVE_ERRORS_HENCE_OUTPUT_FILE_IS_EMPTY = "All the rows in the file have errors, hence output file is empty. ";
	public static final String NO_RECORDS_TO_PROCESS = "No records to process!! ";
	public static final String SUCCESS = "Success";
	public static final String TEST_FILE = "testFile";
	public static final String TEST_FILE_TXT = "testFile.txt";
	public static final String SFTP = "sftp";
	public static final String NO = "no";
	public static final String STRICT_HOST_KEY_CHECKING = "StrictHostKeyChecking";
	public static final String IN_TRANSFER = "inTransfer";
	public static final String TOTAL_ROWS_READ = "totalRowsRead";
	public static final String FILE_EXTENSION = "fileExtension";
	public static final String MB = "MB";
	public static final String SIZE_IN = "sizeIn";
	public static final String FILE_SIZE = "fileSize";
	public static final String FILE_NAME = "fileName";
	public static final String P20192491CHSP0911255 = "P20192491CHSP0911255";
	public static final String DCN6 = "dcn";
	public static final String NO_SE_PUDO_OBTENER_DE_LA_B_D = "NO SE PUDO OBTENER DE LA B.D.";
	public static final String ES_MX = "es_MX";
	public static final String DD_MMM_YYYY_HH_MM_SS = "dd/MMM/yyyy hh:mm:ss";
	public static final String FITRAVA_ENTITY_MANAGER_PU = "fitravaEntityManagerPU";
	public static final String EMPTY_STRING = new String("");
	public static final String IN_PROCESSDATA = "in processdata ";
	public static final String IN_GET_T_PROC_REC = "in getTProcRec ";
	public static final String IN_GET_T_PROC_FILE = "in getTProcFile ";
	public static final String IN_GET_T_PROC = "in getTProc ";
	public static final String IN_GET_RECORDS_FOR_VALIDATION = "in getRecordsForValidation ";
	public static final String IN_GET_DT_OS_FOR_DCN = "in getDTOsForDCN ";
	public static final String BPM_SUCCESS_3 = "BPM SUCCESS 3 ";
	public static final String ERROR_IN_CALLING_BPM_2 = "Error in Calling BPM 2 ";
	public static final String BPM_SUCCESS_2 = "BPM SUCCESS 2 ";
	public static final String ERROR_IN_CALLING_BPM_1 = "Error in Calling BPM 1 ";
	public static final String BPM_SUCCESS_1 = "BPM SUCCESS 1";
	public static final String BPM_ENDPOINT_URL = "bpmEndpointUrl: ";
	public static final String CLIENT_ID = "clientId: ";
	public static final String TOKEN = "token: ";
	public static final String CALLING_BPM_SERVICE_IN_CALL_BPM_SERVICE = "Calling BPM Service in callBPMService";
	public static final String IN_DATA_COLLECTED_STARTING_TRANSFER = "in Data Collected starting Transfer ";
	public static final String IN_GENERATE_FILE = "in generateFile ";
	public static final String FILE_CREATED_AND_TRANFERRED_STATUS_UPDATED = "File Created and Tranferred. Status updated ";
	public static final String IN_VALIDATE_GEN_TRANSFER_FILE = "in validateGenTransferFile ";
	public static final String IN_LAYOUT_VALIDATE = "in layoutValidate ";
	public static final String DATA_UPLOADED_AND_UPDATED_STATUS = "Data uploaded and updated status ";
	public static final String IN_UPLOAD_DATA_STEPS = "in uploadDataSteps ";
	public static final String HYPHEN = "-----";
	public static final String ERROR_IN_FILE_TRANSFER2 = "error in file Transfer";
	public static final String ERROR_IN_FILE_TRANSFER = "error in file Transfer ";
	public static final String FILE_TRANSFER_COMPLETED = "File transfer Completed";
	public static final String SFTP_CHANNEL_CREATED = "SFTP Channel created.";
	public static final String CREATING_SFTP_CHANNEL = "Creating SFTP Channel.";
	public static final String CONNECTION_ESTABLISHED = "Connection established.";
	public static final String ESTABLISHING_CONNECTION = "Establishing Connection...";
	public static final String FITRAVA_SERVICE_FILE_NAME = "Fitrava Service : File Name ";
	public static final String IN_PROCESS_ENDORSMENT_WA = "in processEndorsmentWA ";
	public static final String IN_PROCESS_ENDORSMENT_WA_IS_MASSIVE = "in processEndorsmentWA, isMassive: ";
	public static final String IN_APPLY_VALIDATE_FILE_LAYOUT = "in applyValidateFileLayout ";
	public static final String IN_GET_ENDORSEMENTS_REJEC = "in getEndorsementsRejec ";
	public static final String IN_GET_ENDORSEMENTS_SUMMARY_MOVEMENT = "in getEndorsementsSummaryMovement ";
	public static final String DOUBLE_LOGGER = "{} {}";
	public static final String SPACE_3 = "   ";
	public static final String SPACE = " ";
	public static final String HYPHENS = "------------------";
	public static final String HYPHEN_1 = "  -  ";
	public static final String IN_READER = "in Reader";
	public static final String IN_WRITER = "in writer";
	public static final String ERROR = "ERROR: ";
	private ConstantUtility() {
		throw new IllegalStateException("ConstantUtility class");
	}
	public static final String MASKING_ERROR = "El campo no cumple con el patron especificado";
	public static final String LENGTH_ERROR = "El campo no cumple la longitud especificada";
	public static final String ARROW = "->";
	public static final String JSON_FORMAT_ERROR = "Json format is not valid";
	public static final String DATE_FORMAT = "MM/dd/yyyy";
	public static final String DATE_FORMAT_DD_MM_YYYY = "dd/MM/yyyy";
	public static final String DATE_FORMAT_YYYY_MM = "yyyy/MM";
	public static final String TOM_APP_NAME = "[App Name = TOM] ";
	public static final String LOG_MSG_EXECUTING = "Execution STARTED of service - ";
	public static final String LOG_MSG_EXECUTED = " Execution ENDED of service - ";
	public static final String LOG_MSG_ERROR_EXECUTING = " ERROR executing service - ";
	public static final String LOG_MSG_EXECUTING_CLASS = "Executing class: ";
	public static final String LOG_MSG_EXECUTING_METHOD = "Started executing method: ";
	public static final String LOG_MSG_EXECUTED_METHOD = "Executed method: ";
	public static final String LOG_MSG_SERVICE_START_TIME = "Start time of execution: ";
	public static final String LOG_MSG_SERVICE_EXECUTION_TIME = "Execution time in Seconds: ";
	public static final String SEARCH_TOM_METHOD = "searchTOM ";
	public static final String NO_DATA_FOUND = "No data found";
	public static final String UN_AUTHORIZED_USER = "Unauthorized User";
	public static final String RESULT_SET_EMPTY = "Result set is empty.";
	public static final String INTERNAL_ERROR = "Error in Search";
	public static final String SEARCH_CRITERIA_NOT_ENOUGH = "Not enough inforamation to Perform Search";
	// Error Code Constant
	public static final String ERROR_CODE_500 = "500";
	public static final String ERROR_MESSAGE_500 = "Internal error";
	public static final String ERROR_CODE_401 = "401";
	public static final String ERROR_CODE_400 = "400";
	public static final String ERROR_CODE_202 = "202";
	public static final String SUCCESS_CODE_200 = "200";
	public static final String OPENING_BRACET = " [ ";
	public static final String CLOSING_BRACKET = " ] ";
	public static final String EQUAL_SIGN = " = ";
	public static final String MOVENDOSO_00 = "00";
	public static final String MOVENDOSO_50 = "50";
	public static final String MOVENDOSO_51 = "51";
	public static final String MOVENDOSO_52 = "52";
	
	public static final String SPACE_COLON = ": ";
	public static final String PRODUCT_REF_SSIN = "SSIN";
	public static final String PRODUCT_REF_GMMC = "GMMC";
	public static final String PRODUCT_REF_PREM = "PREM";
	public static final String TYPE_GKY = "0GKY";
	public static final String REGEX_FORMAT_PRN_IND = "%15s";
	public static final String REGEX_FORMAT_PRN_RAMO = "%5s";
	public static final String REGEX_FORMAT_PRN_POLICY = "%10s";
	public static final String REGEX_HYPHEN_SINGLE = "%-";
	public static final String REGEX_NO_HYPHEN = "%";
	public static final String STRING_S = "s";
	public static final char CHAR_SPCAE = ' ';
	public static final char CHAR_ZERO = '0';
	public static final String ZERO = "0";
	public static final String FORWARD_SLASH = "/";
	public static final String HYPHEN_SINGLE = "-";
	public static final String ONE = "1";
	public static final String FORMAT_1S = "%1s";
	public static final String FORMAT_2S = "%2s";
	public static final String FORMAT_2SN = "%-2s";
	public static final String FORMAT_6SN = "%-6s";
	public static final String FORMAT_15SN = "%-15s";
	public static final String FORMAT_5S = "%5s";
	public static final String FORMAT_16SN = "%-16s";  
	public static final String FORMAT_8S = "%8s";
	public static final String FORMAT_3S = "%3s";
	public static final String ORIGEN = "WIN";
	public static final String FORMAT_107S="%107s";
	public static final String FORMAT_1SN = "%-1s";
	public static final String SUCEES_SUMMARY = "Exito";
	public static final String ERROR_SUMMARY = "Error";
	public static final String SUCCESS_TEXT = "Success";
	public static final String BLANK = new String("");
	public static final String DCN1 = "DCN1";
	public static final String DCN2 = "DCN2";
	public static final String DCN3 = "DCN3";
	public static final String DCN4 = "DCN4";
	public static final String DCN5 = "DCN5";
	public static final String TRANSFORMATION = "Transformation";
	public static final String BUSINESS_RULE = "BusinessRule";
	public static final String CONODITION_MANDATOTY_ERROR = "El valor del campo no es permitido";
	public static final String TEXT_TRUE = "true";
	public static final String TEXT_FALSE = "false";
	public static final String DCN_ERROR = "El DCN no se encuentra registrado en el sistema";
	public static final String DCN_NOT_PROCESSED_ERROR = "El DCN no ha sido procesado";
	public static final String TRANMSSN_CMPLTE = "Transformatiion completed";
	public static final String TRANMSSN_NOT_CMPLTE = "Transformation has not been completed";
	public static final String MSG_TXT = "El tipo de dato esperado, no es correcto";
	public static final String MANDATORY_FIELD = "El campo es obligatorio";
	public static final String INVALID_COL = "El layout no cumple con el estándar ";
	public static final String WRONG_FILE_TYPE = "Wrong File type ";
	public static final String MAX_2_FILES = "Maximum two files Allowed";
	public static final String JSON_FILE_RQRD = "Json File required for processing";
	public static final String NOT_ALLOWED = " is not allowed for String parameter 'isMassive'";
	public static final String NOT_ALLOWED_FILE_TYPE = " is not allowed fileType";
	public static final String AGENTE = "Clave de Agente";
	public static final String MOVIMIENTO = "Fecha de Movimiento";
	public static final String RAMO = "Ramo Sub Ramo";
	public static final String POLIZA = "Numero de poliza";
	public static final String SUBGRUPO = "Numero de Subgrupo";
	public static final String CATEGORIA = "Numero de Categoria";
	public static final String ASEGURADO = "Numero de Asegurado";
	public static final String NOMBRE_SUBGRUPO = "Nombre de Subgrupo";
	public static final String TIPO_MOVIMIENTO = "Tipo de Movimiento a Realizar (Altas Bajas o Cambios)";
	public static final String TRABAJO = "Orden de Trabajo";
	public static final String ASEGURDO = "Nombre Asegurado";
	public static final String PATERNO = "Apellido Paterno";
	public static final String MATERNO = "Apellido Materno";
	public static final String NACIMIENTO = "Fecha de Nacimiento";
	public static final String SEX = "Sexo";
	public static final String PARENTSCO = "Parentesco";
	public static final String ESTADO = "Estado Civil";
	public static final String SUELDOE = "Sueldo";
	public static final String ALTA = "Fecha Alta";
	public static final String BAJA = "Fecha Baja";
	public static final String FECHA_INGRESO = "Fecha Ingreso del Empleado";
	public static final String ANTIGUEDAD = "Fecha de Antiguedad";
	public static final String ASEGURADO_DESDE = "Fecha Asegurado Desde";
	public static final String EDADD = "Edad";
	public static final String CURPP = "CURP";
	public static final String RFCC = "RFC";
	public static final String NIVELL = "Nivel";
	public static final String CENTRO_TRABAJO = "Centro de Trabajo";
	public static final String EMPLEADO = "Numero de Empleado";
	public static final String BASICA_BASE = "Suma Autorizada Basica Base";
	public static final String BASICA_POT = "Suma Autorizada Basica POT";
	public static final String RETENEDOR = "Clave Retenedor";
	public static final String PAGO = "Unidad de Pago";
	public static final String INDIVIDUAL = "Conducto Cobro Individual";
	public static final String PAGO_INDIVIDUAL = "Forma de Pago Individual";
	public static final String BANCO_INDIVIDUAL = "Clave de Banco Individual";
	public static final String CUENTA_DE_BANCO = "Numero de Cuenta de Banco";
	public static final String CUENTA_TARJETA = "Numero de Cuenta de Tarjeta";
	public static final String TARJETA = "Vencimiento Tarjeta";
	public static final String FRONTERIZA = "Ubicacion Fronteriza";
	public static final String CALLEE = "Calle";
	public static final String EXTERIOR = "Numero Exterior";
	public static final String INTERIOR = "Numero Interior";
	public static final String COLONIAA = "Colonia";
	public static final String POBLACIONN = "Poblacion";
	public static final String POSTAL = "Codigo Postal";
	public static final String ELECTRONICO = "Correo Electronico";
	public static final String TELEFON = "Telefono";
	public static final String BENEFICIARIO1 = "Beneficiario 1";
	public static final String PARENTESCO1 = "Parentesco 1";
	public static final String PORCENTAJE1 = "Porcentaje 1";
	public static final String BENEFICIARIO2 = "Beneficiario 2";
	public static final String PARENTESCO2 = "Parentesco 2";
	public static final String PORCENTAJE2 = "Porcentaje 2";
	public static final String BENEFICIARIO3 = "Beneficiario 3";
	public static final String PARENTESCO3 = "Parentesco 3";
	public static final String PORCENTAJE3 = "Porcentaje 3";
	public static final String BENEFICIARIO4 = "Beneficiario 4";
	public static final String PARENTESCO4 = "Parentesco 4";
	public static final String PORCENTAJE4 = "Porcentaje 4";
	public static final String BENEFICIARIO5 = "Beneficiario 5";
	public static final String PARENTESCO5 = "Parentesco 5";
	public static final String PORCENTAJE5 = "Porcentaje 5";
	public static final String BENEFICIARIO6 = "Beneficiario 6";
	public static final String PARENTESCO6 = "Parentesco 6";
	public static final String PORCENTAJE6 = "Porcentaje 6";
	public static final String TIPO_PLAZAA = "Tipo Plaza";
	public static final String TRATAMINTO = "Tratamiento";
	public static final String PESTO = "Puesto";
	public static final String DESCRITO = "Concepto Descrito";
	public static final String ADSCRIPION = "Adscripcion";
	public static final String BT = "Filler";
	public static final String YYYYMMDD = "YYYYMMDD";
	public static final String YYYY_MM_DD = "YYYY-MM-DD";
	public static final String AGENTKEY = "agentKey";
	public static final String MOVEDATE = "moveDate";
	public static final String BRACHSUBBRANCH = "brachSubBranch";
	public static final String POLICYNUMBER = "policyNumber";
	public static final String SUBGROUPNUMBER = "subGroupNumber";
	public static final String CATEGORYNUMBER = "categoryNumber";
	public static final String INSUREDNUMBER = "insuredNumber";
	public static final String SUBGROUPNAME = "subGroupName";
	public static final String MOVETYPE = "moveType";
	public static final String WORKORDER = "workOrder";
	public static final String INSUREDNAME = "insuredName";
	public static final String LASTNAME = "lastName";
	public static final String MIDDLENAME = "middleName";
	public static final String BIRTHDATE = "birthdate";
	public static final String GEN_DER = "gender";
	public static final String RELATION_SHIP = "relationship";
	public static final String CIVILSTATUS = "civilStatus";
	public static final String JSON_SALARY = "salary";
	public static final String STARTDATE = "startDate";
	public static final String ENDDATE = "endDate";
	public static final String INCOMEDATEEMPLOYEE = "incomeDateEmployee";
	public static final String ANTIQUEDATE = "antiqueDate";
	public static final String SINCEINSUREDDATE = "sinceInsuredDate";
	public static final String YEAR = "years";
	public static final String LEVELS = "level";
	public static final String CENTERWORK = "centerWork";
	public static final String EMPLOYEENUMBER = "employeeNumber";
	public static final String SUMAUTHBASIC = "sumAuthBasic";
	public static final String SUMAUTHBASICPOT = "sumAuthBasicPOT";
	public static final String RETAINERKEY = "retainerKey";
	public static final String PAYUNIT = "payUnit";
	public static final String INDCOLDUCT = "indColDuct";
	public static final String INDPAYFORM = "indPayForm";
	public static final String INDBANKKEY = "indBankKey";
	public static final String BANKACCNUM = "bankAccNum";
	public static final String CARD_ACCNUM = "cardAccNum";
	public static final String EXPIRATIONCARD = "expirationCard";
	public static final String BORDERLINELOCA = "borderlineLoca";
	public static final String STREETS = "street";
	public static final String EXTNUM = "extNum";
	public static final String INTNUM = "intNum";
	public static final String SUBURBB = "suburb";
	public static final String TOWNS = "town";
	public static final String P_C = "pC";
	public static final String EMAILS = "email";
	public static final String PHONES = "phone";
	public static final String BENEFICIARY_1 = "beneficiary1";
	public static final String RELATIONSHIP_1 = "relationship1";
	public static final String PERCENTAGE_1 = "percentage1";
	public static final String BENEFICIARY_2 = "beneficiary2";
	public static final String RELATIONSHIP_2 = "relationship2";
	public static final String PERCENTAGE_2 = "percentage2";
	public static final String BENEFICIARY_3 = "beneficiary3";
	public static final String RELATIONSHIP_3 = "relationship3";
	public static final String PERCENTAGE_3 = "percentage3";
	public static final String BENEFICIARY_4 = "beneficiary4";
	public static final String RELATIONSHIP_4 = "relationship4";
	public static final String PERCENTAGE_4 = "percentage4";
	public static final String BENEFICIARY_5 = "beneficiary5";
	public static final String RELATIONSHIP_5 = "relationship5";
	public static final String PERCENTAGE_5 = "percentage5";
	public static final String BENEFICIARY_6 = "beneficiary6";
	public static final String RELATIONSHIP_6 = "relationship6";
	public static final String PERCENTAGE_6 = "percentage6";
	public static final String PLAZA_TYPE = "plazaType";
	public static final String TREATMENTS = "treatment";
	public static final String JOBS = "job";
	public static final String DESCRIBEDCONCEPT = "describedConcept";
	public static final String ASCRIPTIONS = "Ascription";
	public static final String PENDIENTES = "PENDIENTE";
	public static final String ENPROCESO = "ENPROCESO";
	public static final String TRANSFRMADO = "TRANSFORMADO";
	public static final String LEGADOS = "LEGADO";
	public static final String GCAYEE = "GCAYE";
	public static final String FINALIZADOS = "FINALIZADO";
	public static final String BUSINESS_RULE_CMPLT = "BusinessRule Completed";
	public static final String APP_CONTEXT = "applicationContext";
	public static final String PACKAGE_SCAN = "mx.com.metlife.tom.fitrava.endorsement.services.model.entity";
	public static final String JNDI_NAME = "jndi/fitravasrv";
	public static final String LOCAL_DB_DRIVER = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
	public static final String LOCAL_DB_URL = "jdbc:sqlserver://localhost;databaseName=MXFITRAVA_DB";
	public static final String LOCAL_DB_UN = "sa";
	public static final String LOCAL_DB_PW = "Nirmita@94";
	public static final String DB_FROM = " FROM ";
	public static final String TEXT_FAILURE = "failure";
	public static final String TEXT_REGISTRYS = "registrys";
	public static final String TEXT_SYSTEM = "system";
	public static final String TEXT_FILENAME_EXT = "_Output.txt";
	public static final String TEXT_FILE_ERROR = "File Write Error";
	public static final String NUMERIC = "Numeric";
	public static final String ALPHANUMERIC = "Alphanumeric";
	public static final String FILE_TYPE_XLSX = "xlsx";
	public static final String FILE_TYPE_JSON = "json";
	public static final String TEXT_DCN_EXISTS = "El DCN recibido, ya existe";
	public static final String FILE_PROCESSED = "Los registros han sido procesados antes";
	public static final String TEXT_DCN_EXISTS_SYSTEM = "DCN Duplicado";
	public static final String ASTERISK = "*";
	public static final String PATTERN = "[^\\\\p{ASCII}]";
	public static final int TWO = 2;
	
	public static final String GET_QUERY_BOSY = new StringBuilder(
			"select A.REC_NUM, A.LAYOUT_FLD_ID, A.MSG_TXT as \"Descripcion\", 'Transformation' as \"Type\" FROM T_PROC_REC A")
					.append(" where A.BAD_RSLT_CD=1 and DSTNCT_CTRL_NUM = :DCN1").append(" union all")
					.append(" select A.REC_NUM, A.LAYOUT_FLD_ID, A.MSG_TXT as \"Descripcion\",'BusinessRule'  FROM T_PROC_REC A")
					.append(" where A.BAD_RSLT_CD=3 and DSTNCT_CTRL_NUM = :DCN2").toString();

	public static final String GET_QUERY_HEADER_LAYOUT = new StringBuilder(
			"select 'failure' as 'result',count(distinct rec_num)  as 'count' from (select REC_NUM, count(distinct rec_num) as num")
			.append(" from T_PROC_REC where DSTNCT_CTRL_NUM=:DCN1 and BAD_RSLT_CD = 1 group by REC_NUM) A union all ")
								.append(" select 'Success',count(distinct rec_num)  as success from (select REC_NUM, count(distinct rec_num) as num")
								.append(" from T_PROC_REC where DSTNCT_CTRL_NUM= :DCN2 and BAD_RSLT_CD = 0")
								.append(" and REC_NUM not in(SELECT distinct REC_NUM FROM T_PROC_REC where DSTNCT_CTRL_NUM = :DCN3 and BAD_RSLT_CD = 1)")
								.append(" group by REC_NUM) A union all ")
								.append(" select 'registrys',count(distinct rec_num)  as success from T_PROC_REC where DSTNCT_CTRL_NUM = :DCN4")
								.toString();

	public static final String GET_QUERY_HEADER_GCAYE = new StringBuilder(
			"select 'failure' as 'result',count(distinct rec_num) as 'count' from T_PROC_REC where DSTNCT_CTRL_NUM=:DCN1")
					.append(" and BAD_RSLT_CD = 3 group by REC_NUM union all")
					.append(" select 'success',count(distinct rec_num)  as success from (select REC_NUM, count(distinct rec_num) as num")
					.append(" from T_PROC_REC where DSTNCT_CTRL_NUM= :DCN2 and BAD_RSLT_CD = 2")
					.append(" and REC_NUM not in(SELECT distinct REC_NUM FROM T_PROC_REC where DSTNCT_CTRL_NUM = :DCN3 and BAD_RSLT_CD = 2)")
					.append(" group by REC_NUM) A union all ")
					.append(" select 'registrys',count(distinct rec_num)  as success from T_PROC_REC where DSTNCT_CTRL_NUM = :DCN4")
					.toString();

	public static final String GET_QUERY_SUMMARY = new StringBuilder(
			"select Type,Resultado, Total from (") 
								.append(" select A2.x as 'Type', 'Exito' as 'Resultado', case when A1.NEW_VAL is null then 0 else count(*) end as \"Total\"") 
								.append(" from (select B.LAYOUT_FLD_NM,T.REC_NUM,t.BAD_RSLT_CD,T.DSTNCT_CTRL_NUM,case when NEW_VAL in(1,2) then 'Alta' when NEW_VAL in(3,4) then 'Baja' when NEW_VAL in(5,6,7,8,9,10,11,12,13,14,15) then 'Cambio' end as NEW_VAL from (") 
								.append(" select DSTNCT_CTRL_NUM, REC_NUM,BAD_RSLT_CD,ROW_NUMBER() OVER(PARTITION BY REC_NUM ORDER BY BAD_RSLT_CD DESC) AS rk ")
								.append(" FROM T_PROC_REC A where A.DSTNCT_CTRL_NUM = :DCN1 group by DSTNCT_CTRL_NUM,REC_NUM, BAD_RSLT_CD ")
								.append(" ) T JOIN T_PROC_REC A ON T.REC_NUM = A.REC_NUM and A.DSTNCT_CTRL_NUM = :DCN2 ")
								.append(" JOIN T_LAYOUT_FLD B on A.LAYOUT_FLD_ID=B.LAYOUT_FLD_ID where B.LAYOUT_FLD_NM = 'I' and T.BAD_RSLT_CD=0 ") 
								.append(" and A.REC_NUM not in ") 
								.append(" (SELECT distinct REC_NUM FROM T_PROC_REC where DSTNCT_CTRL_NUM = :DCN3 and BAD_RSLT_CD = 1)") 
								.append(" ) A1 RIGHT JOIN (SELECT 'Alta' as x union select 'Baja' union select 'Cambio') A2 on A1.NEW_VAL = A2.x ") 
								.append(" group by A1.NEW_VAL,A1.BAD_RSLT_CD,A2.x union all select A2.x as 'Type', 'Error' as 'Resultado', ") 
								.append(" case when A1.NEW_VAL is null then 0 else count(*) end as \"Total\"")  
								.append(" from (select B.LAYOUT_FLD_NM,T.REC_NUM,t.BAD_RSLT_CD,T.DSTNCT_CTRL_NUM,case when NEW_VAL in(1,2) then 'Alta' when NEW_VAL in(3,4) then 'Baja' when NEW_VAL in(5,6,7,8,9,10,11,12,13,14,15) then 'Cambio' end as NEW_VAL from ( ") 
								.append(" select DSTNCT_CTRL_NUM, REC_NUM,BAD_RSLT_CD, ROW_NUMBER() OVER(PARTITION BY REC_NUM ") 
								.append(" ORDER BY BAD_RSLT_CD DESC) AS rk FROM T_PROC_REC A where A.DSTNCT_CTRL_NUM = :DCN4 ") 
								.append(" group by DSTNCT_CTRL_NUM,REC_NUM, BAD_RSLT_CD ) T JOIN T_PROC_REC A ON T.REC_NUM = A.REC_NUM ") 
								.append(" and A.DSTNCT_CTRL_NUM = :DCN5 JOIN T_LAYOUT_FLD B on A.LAYOUT_FLD_ID=B.LAYOUT_FLD_ID ") 
								.append(" where B.LAYOUT_FLD_NM = 'I' and T.BAD_RSLT_CD=1) A1 RIGHT JOIN (SELECT 'Alta' as x union select 'Baja' union select 'Cambio' ") 
								.append(" ) A2 on A1.NEW_VAL = A2.x group by A1.NEW_VAL,A1.BAD_RSLT_CD,A2.x) A order by A.Type")
					.toString();
	
	public static final String GET_RECORDS_FILE_GEN = new StringBuilder()
			.append("select DSTNCT_CTRL_NUM, REC_NUM, LAYOUT_FLD_ID,  ORIG_VAL, NEW_VAL, BAD_RSLT_CD, MSG_TXT ")
			.append("from T_PROC_REC where REC_NUM not in (select distinct REC_NUM from T_PROC_REC ")
			.append("where BAD_RSLT_CD = 1 and DSTNCT_CTRL_NUM = :DCN1) and  DSTNCT_CTRL_NUM = :DCN2").toString();
	
	public static final String GET_RECORDS_FILE_VALIDATION = new StringBuilder()
			.append("select tpr.* from T_PROC_REC tpr, T_FILE_PROC tp where tpr.DSTNCT_CTRL_NUM = tp.DSTNCT_CTRL_NUM")
					.append(" and tp.CLCT_STTS_ID = 2 and  tpr.DSTNCT_CTRL_NUM = :DCN1").toString();

	public static final String GET_RECORDS_STATUS_5 = "select DSTNCT_CTRL_NUM, CLCT_STTS_ID  from T_FILE_PROC where CLCT_STTS_ID=5";
	
	public static final String CHECKDCNEXIST = "select count(*)  from T_FILE_PROC where DSTNCT_CTRL_NUM = :DCN1";
	public static final String COLUMNA = "A";
	public static final String COLUMNB = "B";
	public static final String COLUMNC = "C";
	public static final String COLUMND = "D";
	public static final String COLUMNE = "E";
	public static final String COLUMNF = "F";
	public static final String COLUMNG = "G";
	public static final String COLUMNH = "H";
	public static final String COLUMNI = "I";
	public static final String COLUMNJ = "J";
	public static final String COLUMNK = "K";
	public static final String COLUMNL = "L";
	public static final String COLUMNM = "M";
	public static final String COLUMNN = "N";
	public static final String COLUMNO = "O";
	public static final String COLUMNP = "P";
	public static final String COLUMNQ = "Q";
	public static final String COLUMNR = "R";
	public static final String COLUMNS = "S";
	public static final String COLUMNT = "T";
	public static final String COLUMNU = "U";
	public static final String COLUMNV = "V";
	public static final String COLUMNW = "W";
	public static final String COLUMNX = "X";
	public static final String COLUMNY = "Y";
	public static final String COLUMNZ = "Z";
	public static final String COLUMNAA = "AA";
	public static final String COLUMNAB = "AB";
	public static final String COLUMNAC = "AC";
	public static final String COLUMNAD = "AD";
	public static final String COLUMNAE = "AE";
	public static final String COLUMNAF = "AF";
	public static final String COLUMNAG = "AG";
	public static final String COLUMNAH = "AH";
	public static final String COLUMNAI = "AI";
	public static final String COLUMNAJ = "AJ";
	public static final String COLUMNAK = "AK";
	public static final String COLUMNAL = "AL";
	public static final String COLUMNAM = "AM";
	public static final String COLUMNAN = "AN";
	public static final String COLUMNAO = "AO";
	public static final String COLUMNAP = "AP";
	public static final String COLUMNAQ = "AQ";
	public static final String COLUMNAR = "AR";
	public static final String COLUMNAS = "AS";
	public static final String COLUMNAT = "AT";
	public static final String COLUMNAU = "AU";
	public static final String COLUMNAV = "AV";
	public static final String COLUMNAW = "AW";
	public static final String COLUMNAX = "AX";
	public static final String COLUMNAY = "AY";
	public static final String COLUMNAZ = "AZ";
	public static final String COLUMNBA = "BA";
	public static final String COLUMNBB = "BB";
	public static final String COLUMNBC = "BC";
	public static final String COLUMNBD = "BD";
	public static final String COLUMNBE = "BE";
	public static final String COLUMNBF = "BF";
	public static final String COLUMNBG = "BG";
	public static final String COLUMNBH = "BH";
	public static final String COLUMNBI = "BI";
	public static final String COLUMNBJ = "BJ";
	public static final String COLUMNBK = "BK";
	public static final String COLUMNBL = "BL";
	public static final String COLUMNBM = "BM";
	public static final String COLUMNBN = "BN";
	public static final String COLUMNBO = "BO";
	public static final String COLUMNBP = "BP";
	public static final String COLUMNBQ = "BQ";
	public static final String COLUMNBR = "BR";
	public static final String COLUMNBS = "BS";
	public static final String COLUMNBT = "BT";
	public static final String IBM_CLIENT_ID = "X-IBM-Client-Id";
	public static final String ACCEPT =	"accept";
	public static final String AUTHORIZATION =	"Authorization";
	public static final String ACCESS_TOKEN = "access_token";
	public static final String TOKEN_TYPE = "token_type";
	public static final String DATE_FORMAT_YYYY_MM_DD_HOUR = "yyyy/MM/dd hh:mm:ss a Z";
	public static final int SYSTEM_CODE = 1;
	public static final char UNICODE_DEL = '\u007F';
	public static final char CHAR_DOT= '.';
	public static final String OBJECTS ="Objects";
}
