package mx.com.metlife.tom.fitrava.endorsement.services.service;

import mx.com.metlife.tom.fitrava.endorsement.services.service.dto.PaymentReferenceNumberDTO;

public interface FitravaService {

	String getTemplateDetails(PaymentReferenceNumberDTO paymentReferenceNumberDTO);

	String getDate();
}