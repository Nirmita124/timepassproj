package mx.com.metlife.tom.fitrava.endorsement.services.utility;

import static org.slf4j.LoggerFactory.getLogger;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.Normalizer;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Base64;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.slf4j.Logger;
import org.springframework.context.annotation.PropertySource;

import mx.com.metlife.tom.fitrava.endorsement.services.error.FitravaException;

/**
 * Contains utility methods.
 * 
 * @author Capgemini
 * @since 26/03/2019
 */
@PropertySource(value = { "classpath:application.properties" })
public class MethodUtility {

	private static final Logger logger = getLogger(MethodUtility.class);

	private MethodUtility() {
		throw new IllegalStateException("MethodUtility class");
	}

	static Properties prop;

	public static void loadPropertyFile() {
		try (InputStream input = new FileInputStream(ConstantUtility.BLANK);) {
			prop = new Properties();
			prop.load(input);
		} catch (IOException ex) {
			logger.error(ex.getMessage());
		}
	}

	public static String getPropertyValue(String key) {
		String value = ConstantUtility.EMPTY_STRING;
		if (null == prop)
			loadPropertyFile();

		value = prop.getProperty(key);
		return value;
	}

	public static Date getDateinYYYYMMDDformat(String date) throws FitravaException {
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(ConstantUtility.DATE_FORMAT_DD_MM_YYYY);
		Date givenDate;
		try {
			givenDate = simpleDateFormat.parse(date);
		} catch (ParseException e) {
			throw (new FitravaException(e.getMessage()));
		}
		return givenDate;
	}

	public static String getDateStringDDMMYYYYformat(Date givenDate) {
		String formattedDate = ConstantUtility.EMPTY_STRING;
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(ConstantUtility.DATE_FORMAT_DD_MM_YYYY);
		formattedDate = simpleDateFormat.format(givenDate);
		return formattedDate;
	}

	/**
	 * Get headers parameter from httpServletRequest
	 * 
	 * @param httpServletRequest
	 * @return Map<String, String>
	 */
	public static Map<String, String> getHeaders(HttpServletRequest httpServletRequest) {
		Map<String, String> map = new HashMap<>();
		Enumeration<String> enumeration = httpServletRequest.getHeaderNames();
		while (enumeration.hasMoreElements()) {
			String key = enumeration.nextElement();
			map.put(key, httpServletRequest.getHeader(key));
		}
		return map;
	}

	public static String flattenToAscii(String string) {
		char[] out = new char[string.length()];
		string = Normalizer.normalize(string, Normalizer.Form.NFD);
		int j = 0;
		for (int i = 0, n = string.length(); i < n; ++i) {
			char c = string.charAt(i);
			if (c <= ConstantUtility.UNICODE_DEL)
				out[j++] = c;
		}
		return new String(out);
	}

	public static boolean isNullOrBlank(String string) {
		boolean isNullorBlank = false;
		if (null == string || string.trim().isEmpty())
			isNullorBlank = true;
		else
			isNullorBlank = false;
		return isNullorBlank;
	}

	public static String extractNumber(final String str) {
		if (isNullOrBlank(str))
			return ConstantUtility.EMPTY_STRING;

		StringBuilder sb = new StringBuilder();
		boolean found = false;
		for (char c : str.toCharArray()) {
			if (Character.isDigit(c)) {
				sb.append(c);
				found = true;
			} else if (found) {
				// If we already found a digit before and this char is not a digit, stop looping
				break;
			}
		}

		return sb.toString();
	}

	/**
	 * This function appends all the fields to a string for the elements that
	 * occured in exception
	 * 
	 * @param String: message
	 * @return String
	 */
	public static String getElementForValidation(String message) {
		StringBuilder sb = new StringBuilder();
		sb.append(message);
		return sb.toString();
	}

	public static String getFileExtension(String fileName) {
		if (fileName.lastIndexOf(ConstantUtility.CHAR_DOT) != -1 && fileName.lastIndexOf(ConstantUtility.CHAR_DOT) != 0)
			return fileName.substring(fileName.lastIndexOf('.') + 1);
		else
			return ConstantUtility.EMPTY_STRING;
	}

	public static boolean isNumeric(String inputCellValue) {
		String regexDecimal = "^-?\\d*\\.\\d+$";
		String regexInteger = "^-?\\d+$";
		String regexDouble = regexDecimal + "|" + regexInteger;

		Pattern pattern = Pattern.compile(regexDouble);
		Matcher matcher = pattern.matcher(inputCellValue);
		return matcher.matches();

	}

	public static boolean isAlphaNumericNumeric(String inputCellValue) {
		return inputCellValue.matches("(?=.*\\S)[a-zA-Z0-9\\s-]*");

	}

	public static boolean isAlphaNumericNumericWithSpace(String inputCellValue) {
		// Regex
		String regex = "^[a-zA-Z0-9]+$";

		Pattern pattern = Pattern.compile(regex);
		Matcher matcher = pattern.matcher(inputCellValue);
		return matcher.matches();
	}

	public static boolean isRowEmpty(Row row) {
		if (null != row) {
			for (int cnt = 0; cnt < 72; cnt++) {
				Cell cell = row.getCell(cnt);
				if (cell != null && cell.getCellTypeEnum() != CellType.BLANK) {
					return false;
				}
			}
		}

		return true;
	}

	public static String removeNull(Object value) {
		return value != null ? (String) value : ConstantUtility.EMPTY_STRING;
	}
	
	public static String getEncoderBase64(String text) {
		return new String (Base64.getEncoder().encode(text.getBytes()));
	}
	
	public static String getDecoderBase64(String text) {
		return new String(Base64.getDecoder().decode(text));
	}
	
	public static String dc_decrypt(String str, String key) {
	   StringBuilder sb = new StringBuilder();
	   for(int i = 0; i < str.length(); i++)
	   sb.append((char)(str.charAt(i) ^ key.charAt(i % (key.length()))));
	   return(sb.toString());
	}

	public static void main(String[] args) {
		String t = getEncoderBase64("AQ119985");
		System.out.println("-------------->" + t +"<--");
		t = getDecoderBase64("CDo9Hgw=");
		System.out.println("---->" + t  + "<----");
	
		
	}
	
}