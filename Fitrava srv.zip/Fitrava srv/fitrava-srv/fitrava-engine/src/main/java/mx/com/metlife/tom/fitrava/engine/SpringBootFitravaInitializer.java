package mx.com.metlife.tom.fitrava.engine;

import java.io.File;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.boot.Banner;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.data.jpa.JpaRepositoriesAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Import;
import org.springframework.integration.annotation.IntegrationComponentScan;
import org.springframework.web.WebApplicationInitializer;

import mx.com.metlife.tom.fitrava.services.config.JPAConfig;
import mx.com.metlife.tom.fitrava.services.error.FitravaException;
import mx.com.metlife.tom.fitrava.services.utility.Constantes;
import mx.com.metlife.tom.fitrava.services.utility.UtilCommon;


@EnableBatchProcessing
@IntegrationComponentScan
@SpringBootApplication(exclude = { DataSourceAutoConfiguration.class, HibernateJpaAutoConfiguration.class, JpaRepositoriesAutoConfiguration.class })
@ComponentScan(basePackages = { "mx.com.metlife.tom.fitrava.engine" })
@Import({JPAConfig.class})
public class SpringBootFitravaInitializer extends SpringBootServletInitializer implements WebApplicationInitializer {
	
	static final Logger log = LoggerFactory.getLogger(SpringBootFitravaInitializer.class);

	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder builder) {
		initDirectorios();
		return configureApplication(builder);
	}

	private static SpringApplicationBuilder configureApplication(SpringApplicationBuilder builder) {
		return builder.sources(SpringBootFitravaInitializer.class).bannerMode(Banner.Mode.OFF);
	}
	
	
	private static void initDirectorios() {
		log.info("Inicializando los directorios");
		File directory = null;
		try {
			directory = new File (Constantes.TEMP_ROOT_DIRECTORY_ORIGEN);
			UtilCommon.createDirectory(directory);
			directory = new File (Constantes.TEMP_ROOT_DIRECTORY_DESTINO);
			UtilCommon.createDirectory(directory);
			directory = new File (Constantes.TEMP_ROOT_DIRECTORY_DELETE);
			UtilCommon.createDirectory(directory);
			directory = new File (Constantes.TEMP_ROOT_DIRECTORY_ORIGEN_TEMP);
			UtilCommon.createDirectory(directory);
			directory = new File (Constantes.TEMP_ROOT_DIRECTORY_DESTINO_TEMP);
			UtilCommon.createDirectory(directory);
			directory = new File (Constantes.TEMP_ROOT_DIRECTORY_CATALOGOS);
			UtilCommon.createDirectory(directory);
			directory = new File (Constantes.TEMP_ROOT_DIRECTORY_CATALOGOS_TEMP);
			UtilCommon.createDirectory(directory);
		} catch (FitravaException e) {
			log.error("No se pudo inicializar los directorios");
		}
		//aqui podriamos poner lo de borrar lo de las tablas de BATCH
	}
	
}
