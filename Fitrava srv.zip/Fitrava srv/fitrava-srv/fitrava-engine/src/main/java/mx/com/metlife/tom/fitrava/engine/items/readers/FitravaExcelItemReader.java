package mx.com.metlife.tom.fitrava.engine.items.readers;

import java.util.List;

import org.springframework.batch.item.ExecutionContext;

import mx.com.metlife.tom.fitrava.services.dto.ColumnaDto;
import mx.com.metlife.tom.fitrava.services.dto.InputDto;
import mx.com.metlife.tom.fitrava.services.model.entity.TLayoutXcel;
import mx.com.metlife.tom.fitrava.services.utility.Constantes;
import mx.com.metlife.tom.fitrava.services.utility.UtilCommon;

public class FitravaExcelItemReader extends FitravaItemReader {
	
	private ExcelFitravaReader reader = null;
	private BigExcelFitravaReader readerXlsx = null;
	private Boolean isXlsx = null;
	
	public FitravaExcelItemReader(String filePath) {
		super(filePath);
	}
	
    @Override
	public InputDto read() throws Exception {
    	initAll();
    	initReader();
    	if (isXlsx != null && (readerXlsx != null || reader != null)) {
			String[] line = isXlsx?readerXlsx.read():reader.read();
			String nombreHoja = isXlsx?readerXlsx.getNombreHoja():reader.getNombreHoja();
			//log.info("-->" + UtilCommon.getArrayToString(line) + "<--");
			//log.info("-->" + nombreHoja + "<--");
			if (UtilCommon.isNull(line)) {
				return null;
			}
			return getInputDto(line, nombreHoja);
		}
    	return null;
    }

    private void initReader() throws Exception {
    	if(filePath != null) {
    		isXlsx = filePath.toLowerCase().endsWith(Constantes.XLSX);
    		List<TLayoutXcel> hojas = getLayoutEntrada().getLstTLayoutXcel();
	    	if (isXlsx && readerXlsx == null ) {
				readerXlsx = new BigExcelFitravaReader(filePath, getLayoutEntrada().getOmitInitRecCnt(), UtilCommon.getHojas(hojas));
				readerXlsx.setEndAfterBlankLines(5);
				readerXlsx.doOpen();
			} else if(reader == null ) {
				reader = new ExcelFitravaReader(filePath, getLayoutEntrada().getOmitInitRecCnt(), UtilCommon.getHojas(hojas));
				reader.setEndAfterBlankLines(5);
				reader.open(new ExecutionContext());
			}
    	}
    }
    
    
    private InputDto getInputDto(String[] renglon, String nombreHoja) {
    	InputDto inputDto = getNewInputDto();
    	inputDto.setNombreHoja(nombreHoja);
    	ColumnaDto[] columnasDTO = new ColumnaDto[getLayoutEntrada().getNumColumns()];
		//log.info("renglon.length:{}, getLayoutEntrada().getNumColumns(){}", renglon.length, getLayoutEntrada().getNumColumns());
		for(int i = 0; i < getLayoutEntrada().getNumColumns(); i++) {
			columnasDTO[i] = new ColumnaDto(getCampos().get(i).getLayoutFldId(), renglon[i]);
			//log.info("columnasDTO[{}]: {}", i, columnasDTO[i]);
		}
		inputDto.setRenglon(columnasDTO);
		//log.info("---->{}", inputDto );
		return inputDto;
    }
}
