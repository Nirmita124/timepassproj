package mx.com.metlife.tom.fitrava.engine.items.processors;

import static mx.com.metlife.tom.fitrava.services.utility.UtilCommon.isNull;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections4.map.HashedMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

import mx.com.metlife.tom.fitrava.services.dto.ColumnaDto;
import mx.com.metlife.tom.fitrava.services.dto.InputDto;
import mx.com.metlife.tom.fitrava.services.model.entity.TDatatyp;
import mx.com.metlife.tom.fitrava.services.model.entity.TFldOper;
import mx.com.metlife.tom.fitrava.services.model.entity.TFldTform;
import mx.com.metlife.tom.fitrava.services.model.entity.TLayout;
import mx.com.metlife.tom.fitrava.services.model.entity.TLayoutFld;
import mx.com.metlife.tom.fitrava.services.model.entity.TLayoutFldAtrb;
import mx.com.metlife.tom.fitrava.services.model.entity.TProcRec;
import mx.com.metlife.tom.fitrava.services.model.entity.TSkpChar;
import mx.com.metlife.tom.fitrava.services.model.entity.TUloadExt;
import mx.com.metlife.tom.fitrava.services.model.repository.TFldOperRepository;
import mx.com.metlife.tom.fitrava.services.model.repository.TFldTformRepository;
import mx.com.metlife.tom.fitrava.services.model.repository.TLayoutFldRepository;
import mx.com.metlife.tom.fitrava.services.model.repository.TLayoutRepository;
import mx.com.metlife.tom.fitrava.services.model.repository.TSkpCharRepository;
import mx.com.metlife.tom.fitrava.services.model.repository.TUloadExtRepository;
import mx.com.metlife.tom.fitrava.services.utility.Constantes;
import mx.com.metlife.tom.fitrava.services.utility.OperationUtility;
import mx.com.metlife.tom.fitrava.services.utility.OperationUtility.OPERATION_IDS;

@Scope(value = "step", proxyMode = ScopedProxyMode.INTERFACES)
@Component
public class FitravaItemProcessor implements ItemProcessor<InputDto, List<TProcRec>> {

	static final Logger log = LoggerFactory.getLogger(FitravaItemProcessor.class);

	@Autowired
	private TLayoutRepository tLayoutRepository;
	
	@Autowired
	private TLayoutFldRepository tLayoutFldRepository;

	@Autowired
	private TFldTformRepository tFldTformRepository;

	@Autowired
	private TUloadExtRepository tUloadExtRepository;

	@Autowired
	private TFldOperRepository tFldOperRepository;
	
	@Autowired
	private TSkpCharRepository tSkpCharRepository;
	
	private TLayout layoutEntrada;
	private List<TLayoutFld> camposEntrada;
	private TLayout layoutSalida;
	private List<TLayoutFld> camposSalida;
	private List<TUloadExt> parametros;
	private Map<Long, List<TFldTform>> mapValidacionesPorCampo;
	private List<TFldOper> operaciones;
	private List<TSkpChar> listaCaracteresOmitir;
	
	Long recNum = 0L;
	Integer rowNum = null;
	
	@Override
	public List<TProcRec> process(InputDto inputDto) throws Exception {
		intitAll(inputDto);
		//log.info("En el process(inputDto: {})", inputDto);
		List<TProcRec> lista = new ArrayList<>();
		TProcRec tProcRec = null;
		int colNum = 1;
		if(inputDto != null && inputDto.getRenglon() != null) {
			for (ColumnaDto columna : inputDto.getRenglon()) {
				if (columna == null) {
					continue;
				}
				tProcRec = getTProcRec(columna, inputDto, recNum, rowNum, colNum);
				//log.info("-->" + tProcRec + "<--");
				if (tProcRec == null) { //si algo está mal, no se agrega
					continue;
				}
				lista.add(tProcRec);
				recNum++;
				colNum++;
			}
			rowNum++;
		}
		return lista;
	}
	
	private TProcRec getTProcRec(ColumnaDto columna, InputDto inputDto, Long recNum, Integer rowNum, Integer colNum) {
		//log.info("ColumnaDto: {}, InputDto {}", columna, inputDto);
		TProcRec tProcRec = new TProcRec();
		TLayoutFld campoEntrada = getCampo(columna.getId(), true);
		Assert.notNull(campoEntrada, "No es posible que el campo sea null");
		TLayoutFldAtrb atributoCampoEntrada = getTLayoutFldAtrb(campoEntrada);
		String textoOriginal = columna.getTexto();
		
		tProcRec.setDstnctCtrlNum(inputDto.getDcn());
		tProcRec.setRecNum(recNum);
		tProcRec.setXcelSheetNm(inputDto.getNombreHoja());
		tProcRec.setRowNum(rowNum);
		tProcRec.setColNum(colNum);
		tProcRec.setFileNm(inputDto.getFileNm());
		tProcRec.setLayoutFldId(columna.getId());//el id de la columna de entrada
		tProcRec.setOrigVal(!isNull(textoOriginal)?textoOriginal:Constantes.NULL);
		tProcRec.setBadRsltInd(false);
		tProcRec.setNewVal(Constantes.NULL);
		if (!validaConcepto(campoEntrada.getLayoutFldId(), textoOriginal)) {
			return null;
		}
		//1ro vemos si es null
		if (isNull(textoOriginal)) {
			//si es null, pero es mandatory, mensaje de error
			if(campoEntrada.getMndtLayoutFldInd()) {
				tProcRec.setBadRsltInd(true);
				tProcRec.setMsgTxt(Constantes.TIPO_DATO_ERROR);
			}
			tProcRec.setNewVal(Constantes.NULL);
		} else {
			String message = validaByParametros(campoEntrada.getLayoutFldId(), textoOriginal);
			if (message != null && !message.isEmpty()) {
				tProcRec.setBadRsltInd(true);
				tProcRec.setMsgTxt(message);
			} else {
				//no es null, quitamos caracteres raros y demas
				textoOriginal = OperationUtility.getValueByDatatypId(textoOriginal, campoEntrada.getDatatypId());
				textoOriginal = OperationUtility.removeCarateresExcluir(textoOriginal, listaCaracteresOmitir);
				//valiamos que sea de acuerdo al tipo de dato esperado
				//log.info("OperationUtility.isDataTypeCorrectByDatatypId(textoOriginal, campoEntrada.getDatatypId())): " +OperationUtility.isDataTypeCorrectByDatatypId(textoOriginal, campoEntrada.getDatatypId()));
				if(!OperationUtility.isDataTypeCorrectByDatatypId(textoOriginal, campoEntrada.getDatatypId())) 
				{
					tProcRec.setBadRsltInd(true);
					tProcRec.setMsgTxt(Constantes.TIPO_DATO_ERROR);
				}
				//habria que ver si esto va
				if (campoEntrada.getDatatypId().equals(TDatatyp.TIPO_DATO.FECHA.getId()) 
						&& atributoCampoEntrada != null && atributoCampoEntrada.getRegXprsnTxt() != null
						&& !OperationUtility.validaFormatoFecha(atributoCampoEntrada.getRegXprsnTxt(), textoOriginal)) 
				{
					tProcRec.setBadRsltInd(true);
					tProcRec.setMsgTxt(Constantes.FORMATO_FECHA_DESCONOCIDO);
				}
				if (!campoEntrada.getDatatypId().equals(TDatatyp.TIPO_DATO.NUMERICO.getId()) &&
						(atributoCampoEntrada != null && atributoCampoEntrada.getFixLnthNum() != null  && atributoCampoEntrada.getFixLnthNum() > 0 
							&& !atributoCampoEntrada.getFixLnthNum().equals(textoOriginal.length())) ||
						(atributoCampoEntrada != null && atributoCampoEntrada.getMaxLnthNum() != null 
							&& atributoCampoEntrada.getMinLnthNum() > 0 && atributoCampoEntrada.getMaxLnthNum()  > 0 
							&& (textoOriginal.length() > atributoCampoEntrada.getMaxLnthNum() || textoOriginal.length() < atributoCampoEntrada.getMinLnthNum()))) 
				{
					// el texto es más grande o pequeño de lo permitido
					tProcRec.setBadRsltInd(true);
					tProcRec.setMsgTxt(Constantes.LENGTH_ERROR);
				}
			}
			//finalmente, va en mayusculas. Al parecer
			textoOriginal = textoOriginal.toUpperCase();
			tProcRec.setNewVal(textoOriginal);
		}
		return tProcRec;
	}
	
	private Boolean validaConcepto(Long campoEntradaId, String valor) {
		List<TFldTform> validaciones = getValidacionesPorCampo(campoEntradaId);
		for(TFldTform validacion: validaciones) {
			if (validacion.getFldOperId() == null) {
				continue;
			}
			//preguntamos si tiene la operacion de conceptofone
			if (OperationUtility.OPERATION_IDS.VALIDACION_CONCEPTO_FONE.getName().equals(getNameOperacionById(validacion.getFldOperId()))){
				//ahora hay que ver que sea 77, 77a o algo mas
				if (!valor.equals(Constantes.CONCEPTO_77) || !valor.equals(Constantes.CONCEPTO_77A) || !valor.equals(Constantes.CONCEPTO_37) ) {
					return false;
				}
			}
		}
		return true;
	}
	
	private String validaByParametros(Long campoEntradaId, String valor) {
		if (parametros == null || parametros.isEmpty()) {
			return null;
		}
		List<TFldTform> validaciones = getValidacionesPorCampo(campoEntradaId);
		if (validaciones == null || validaciones.isEmpty()) {
			return null;
		}
		for(TFldTform validacion: validaciones) {
			if (validacion.getFldOperId() == null) {
				continue;
			}
			//preguntamos si tiene las operaciones de validaciones que se tengan registrado
			if (OPERATION_IDS.VALIDA_ANIO_QUINCENA_FONE_RETENCION.getName().equals(getNameOperacionById(validacion.getFldOperId()))){
				String anio = getByParametro(Constantes.PARAM_NAME_ANIO);
				String mes = getByParametro(Constantes.PARAM_NAME_MES);
				if (anio == null || anio.isEmpty() || mes == null || mes.isEmpty()) {
					return null;
				}
				Boolean b = Boolean.parseBoolean(OperationUtility.validacionAnioQuincenaFoneRetencion(valor, anio, mes));
				if (!b) {
					return "No concide la quincena, con el ingresado";
				}
			}
		}
		return null;
	}
	
	private List<TFldTform> getValidacionesPorCampo(Long campoEntradaId) {
		return mapValidacionesPorCampo.get(campoEntradaId);
	}

	private String getByParametro(String paramName) {
		for (TUloadExt parametro:parametros) {
			if (parametro.getKey().equalsIgnoreCase(paramName)) {
				return parametro.getValue();
			}
		}
		return null;
	}
	
	private String getNameOperacionById(Long id) {
		if (operaciones != null && !operaciones.isEmpty()) {
			for (TFldOper oper: operaciones) {
				if (oper.getFldOperId().equals(id)) {
					return oper.getFldOperNm();
				}
			}
		}
		return null;
	}
	
	private TLayoutFld getCampo(Long id, Boolean isEntrada) {
		if (isEntrada) {
			for(TLayoutFld campo:camposEntrada) {
				if (campo.getLayoutFldId().equals(id)) {
					return campo;
				}
			}
		} else {
			for(TLayoutFld campo:camposSalida) {
				if (campo.getLayoutFldId().equals(id)) {
					return campo;
				}
			}
		}
		return null;
	}
	
	private TLayoutFldAtrb getTLayoutFldAtrb(TLayoutFld campo) {
		if (campo.getListTLayoutFldAtrb() != null && !campo.getListTLayoutFldAtrb().isEmpty()) {
			return campo.getListTLayoutFldAtrb().iterator().next();
		}
		return null;
	}

	protected synchronized void intitAll(InputDto inputDto) {
		if (layoutEntrada ==null || layoutSalida == null) {
			layoutEntrada = tLayoutRepository.findById(inputDto.getEntradaLayoutId());
			camposEntrada = tLayoutFldRepository.findByLayoutId(inputDto.getEntradaLayoutId());
			layoutSalida = tLayoutRepository.findById(inputDto.getSalidaLayoutId());
			camposSalida = tLayoutFldRepository.findByLayoutId(inputDto.getSalidaLayoutId());
			parametros = tUloadExtRepository.findAllByDstnctCtrlNum(inputDto.getDcn());
			recNum = 0L;
			rowNum = layoutEntrada.getOmitInitRecCnt();
			rowNum = rowNum==null?1:rowNum+1;
			mapValidacionesPorCampo = new HashedMap<>();
			List<TFldTform> validaciones = null;
			for(TLayoutFld campoEntrada : camposEntrada) {
				validaciones = tFldTformRepository.findAllByLayoutId(campoEntrada.getLayoutFldId());
				mapValidacionesPorCampo.put(campoEntrada.getLayoutFldId(), validaciones);
			}
			operaciones = tFldOperRepository.findAll();
			listaCaracteresOmitir = tSkpCharRepository.findAllByLayoutId(layoutSalida.getLayoutId()); 
			log.info("=================================");
			log.info("Iniciando el proceso de validacion");
			log.info("El layout de entrada: {}" , layoutEntrada);
			log.info("los campos del layout de entrada: {}" , camposEntrada);
			log.info("El layout de salida: {}" , layoutSalida);
			log.info("los campos del layout de salida: {}" , camposSalida);
			log.info("los parametros externos: {}", parametros);
			log.info("El mapa de las validaciones: {}", mapValidacionesPorCampo);
			log.info("las operaciones: {}", operaciones);
			log.info("los caracteres a omitir: {}" , listaCaracteresOmitir);
			log.info("=================================");
		}
	}
}
