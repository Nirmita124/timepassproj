package mx.com.metlife.tom.fitrava.engine.items.readers;

import java.io.File;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.mapping.DefaultLineMapper;
import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.DelimitedLineTokenizer;
import org.springframework.batch.item.file.transform.FieldSet;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.core.io.FileSystemResource;
import org.springframework.stereotype.Component;
import org.springframework.validation.BindException;

import mx.com.metlife.tom.fitrava.services.dto.CatalogoFitravaDTO;
import mx.com.metlife.tom.fitrava.services.dto.CatalogoFoneDTO;
import mx.com.metlife.tom.fitrava.services.dto.CatalogoIsssteDTO;
import mx.com.metlife.tom.fitrava.services.dto.CatalogoRamo74DTO;
import mx.com.metlife.tom.fitrava.services.dto.CatalogoRicsiDTO;
import mx.com.metlife.tom.fitrava.services.utility.Constantes;
import mx.com.metlife.tom.fitrava.services.utility.UtilCommon;

@Scope(value = "step", proxyMode = ScopedProxyMode.INTERFACES)
@Component
public class FitravaCatalogoReader implements ItemReader<CatalogoFitravaDTO> {

	static final Logger log = LoggerFactory.getLogger(FitravaCatalogoReader.class);

	private FlatFileItemReader<CatalogoFitravaDTO> reader = null;

	private String filePath = null;
	private Integer tipoCatalgo = null;
	private int linea = 1;

	public FitravaCatalogoReader(String filePath) {
		this.filePath = filePath;
	}

	@Override
	public CatalogoFitravaDTO read() throws Exception {
		initAll();
    	initReader();
    	if (reader != null ) {
    		linea++;
    		CatalogoFitravaDTO catalogoFitravaDTO = null;
    		try {
    			catalogoFitravaDTO = reader.read();
	    		if (catalogoFitravaDTO instanceof CatalogoRicsiDTO) {
	    			//log.info("Ricsi: --->{}<--", (CatalogoRicsiDTO) catalogoFitravaDTO);
	    			return (CatalogoRicsiDTO)catalogoFitravaDTO;
	    		} else if (catalogoFitravaDTO instanceof CatalogoFoneDTO) {
	    			//log.info("Fone: --->{}<--", (CatalogoFoneDTO) catalogoFitravaDTO);
	    			return (CatalogoFoneDTO)catalogoFitravaDTO;
	    		} else if (catalogoFitravaDTO instanceof CatalogoIsssteDTO) {
	    			//log.info("Issste: --->{}<--", (CatalogoIsssteDTO) catalogoFitravaDTO);
	    			return (CatalogoIsssteDTO)catalogoFitravaDTO;
	    		} else if (catalogoFitravaDTO instanceof CatalogoRamo74DTO) {
	    			//log.info("Ramo72: --->{}<--", (CatalogoRamo74DTO) catalogoFitravaDTO);
	    			return (CatalogoRamo74DTO)catalogoFitravaDTO;
	    		} 
    		} catch (Exception e) {
    			log.error("Excepcion al leer", e);
				return new CatalogoFitravaDTO(linea, e.getMessage());
			}
    	}
    	return null;
	}
	
	// con base en el nombre del archivo puedo saber a qué catalogo se refiere
	private void initAll() {
		if (tipoCatalgo == null && filePath != null) {
			log.info("========================");
			log.info("iniciando la lectura del archivo: {}", filePath);
			linea = 0;
			tipoCatalgo = UtilCommon.getTipoCatalgoByFileName((new File(filePath)).getName());
			log.info("Es un tipo de catalogo {}, {} ", tipoCatalgo, 
					tipoCatalgo.equals(Constantes.ID_CATALOGO_RICSI)?"RICSI":
						tipoCatalgo.equals(Constantes.ID_CATALOGO_FONE)?"FONE":
							tipoCatalgo.equals(Constantes.ID_CATALOGO_ISSSTE)?"ISSSTE":
								"RAMO74");
		}
	}

	private void initReader() {
    	if (reader == null && filePath != null && tipoCatalgo != null && tipoCatalgo > 0) {
    		File f = new File(filePath);
    		if (f.exists()) {
    			log.info("Iniciando el Reader");
				final FileSystemResource fileResource = new FileSystemResource(filePath);
				reader = new FlatFileItemReader<>();
				reader.setResource(fileResource);
				reader.setEncoding(Constantes.ENCODE_UTF_8);
				reader.setLinesToSkip(1);
				reader.setStrict(false);
	
				DelimitedLineTokenizer tokenizer = new DelimitedLineTokenizer(tipoCatalgo.equals(Constantes.ID_CATALOGO_RICSI)?"\t":"|");
				tokenizer.setNames(getTokens());
				DefaultLineMapper<CatalogoFitravaDTO> lineMapper = new DefaultLineMapper<>();
				lineMapper.setLineTokenizer(tokenizer);
				lineMapper.setFieldSetMapper(getCatalogoDTOFieldSetMapper());
				
				reader.setLineMapper(lineMapper);
				reader.open(new ExecutionContext());
	    	}
    	}
	}
	
	private String[] getTokens() {
		switch(tipoCatalgo) {
			case Constantes.ID_CATALOGO_RICSI: return Constantes.CATALOGO_RICSI_CAMPOS;
			case Constantes.ID_CATALOGO_FONE: return Constantes.CATALOGO_FONE_CAMPOS;
			case Constantes.ID_CATALOGO_ISSSTE: return Constantes.CATALOGO_ISSSTE_CAMPOS;
			case Constantes.ID_CATALOGO_RAMO74: return Constantes.CATALOGO_RAMO74_CAMPOS;
			default: return null;
		}
	}
	
	private FieldSetMapper<CatalogoFitravaDTO> getCatalogoDTOFieldSetMapper(){
		return new FieldSetMapper<CatalogoFitravaDTO>() {
			@Override
			public CatalogoFitravaDTO mapFieldSet(FieldSet fieldSet) throws BindException {
				switch (tipoCatalgo) {
					case Constantes.ID_CATALOGO_RICSI: 
						CatalogoRicsiDTO catalogoRicsi = new CatalogoRicsiDTO();
						catalogoRicsi.setPoliza(fieldSet.readString("poliza")); 
						catalogoRicsi.setRfc(UtilCommon.getValidRfc(fieldSet.readString("rfc"))); 
						catalogoRicsi.setNombre(fieldSet.readString("nombre")); 
						catalogoRicsi.setNumRecibo(fieldSet.readString("numRecibo")); 
						catalogoRicsi.setEstatus(fieldSet.readString("estatus")); 
						catalogoRicsi.setFechaEmision(UtilCommon.parseDate(fieldSet.readString("fechaEmision"))); 
						catalogoRicsi.setFechaRecibo(UtilCommon.parseDate(fieldSet.readString("fechaRecibo"))); 
						catalogoRicsi.setFechaEfectoPoliza(UtilCommon.parseDate(fieldSet.readString("fechaEfectoPoliza"))); 
						catalogoRicsi.setFormaPago(fieldSet.readString("formaPago")); 
						catalogoRicsi.setConductoCobro(fieldSet.readString("conductoCobro")); 
						catalogoRicsi.setNumPensionado(fieldSet.readString("numPensionado")); 
						catalogoRicsi.setPrimaAnual(UtilCommon.getDouble(fieldSet.readString("primaAnual"))); 
						catalogoRicsi.setStatusRecibo(fieldSet.readString("statusRecibo")); 
						catalogoRicsi.setPrimaCobro(UtilCommon.getDouble(fieldSet.readString("primaCobro")));
						return catalogoRicsi;
					
					case Constantes.ID_CATALOGO_FONE: 
						CatalogoFoneDTO catalogoFone = new CatalogoFoneDTO();
						catalogoFone.setId(fieldSet.readString("id"));
						catalogoFone.setPolizaOriginal(fieldSet.readString("polizaOriginal"));
						catalogoFone.setContratante(fieldSet.readString("contratante"));
						catalogoFone.setRamoSubramo(UtilCommon.getInteger(fieldSet.readString("ramoSubramo")));
						catalogoFone.setProducto(fieldSet.readString("producto"));
						catalogoFone.setSubgrupoAplicacion(UtilCommon.getInteger(fieldSet.readString("subgrupoAplicacion")));
						catalogoFone.setDescripcionSubgrupo(fieldSet.readString("descripcionSubgrupo"));
						catalogoFone.setReciboFiscalCartaRecibo(fieldSet.readString("reciboFiscalCartaRecibo"));
						catalogoFone.setPrimaSueldoMet(UtilCommon.getDouble(fieldSet.readString("primaSueldoMet")));
						catalogoFone.setNumAsegurados(UtilCommon.getInteger(fieldSet.readString("numAsegurados")));
						catalogoFone.setNominaMensual(UtilCommon.getDouble(fieldSet.readString("nominaMensual")));
						catalogoFone.setSumaAsegurada(UtilCommon.getDouble(fieldSet.readString("sumaAsegurada")));
						catalogoFone.setSumaAseguradaPromedio(UtilCommon.getDouble(fieldSet.readString("sumaAseguradaPromedio")));
						catalogoFone.setPrimaAnual(UtilCommon.getDouble(fieldSet.readString("primaAnual")));
						catalogoFone.setPrimaMensual(UtilCommon.getDouble(fieldSet.readString("primaMensual")));
						return catalogoFone;
					
					case Constantes.ID_CATALOGO_ISSSTE: 
						CatalogoIsssteDTO catalogoIssste = new CatalogoIsssteDTO();
						catalogoIssste.setConcepto(fieldSet.readString("concepto"));
						catalogoIssste.setRamoIssste(fieldSet.readString("ramoIssste"));
						catalogoIssste.setNombreOrganismo(fieldSet.readString("nombreOrganismo"));
						catalogoIssste.setPoliza(fieldSet.readString("poliza"));
						catalogoIssste.setRamoSubramo(fieldSet.readString("ramoSubramo"));
						catalogoIssste.setSubgrupo(fieldSet.readString("subgrupo"));
						catalogoIssste.setClasificacion(fieldSet.readString("clasificacion"));
						catalogoIssste.setAseguradoUnico(fieldSet.readString("aseguradoUnico"));
						return catalogoIssste;
					
					case Constantes.ID_CATALOGO_RAMO74: 
						CatalogoRamo74DTO catalogoRamo74 = new CatalogoRamo74DTO();
						catalogoRamo74.setNumeroPension(fieldSet.readString("numeroPension"));
						catalogoRamo74.setRfc(UtilCommon.getValidRfc(fieldSet.readString("rfc")));
						catalogoRamo74.setNombreCompleto(fieldSet.readString("nombreCompleto"));
						catalogoRamo74.setPoliza(fieldSet.readString("poliza"));
						return catalogoRamo74;
						
					default: return null;
				}
			}
		};
	}
}
