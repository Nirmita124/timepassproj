package mx.com.metlife.tom.fitrava.engine.items.writers;

import static mx.com.metlife.tom.fitrava.services.utility.Constantes.BLANK;
import static mx.com.metlife.tom.fitrava.services.utility.Constantes.ENCODE_UTF_8;
import static mx.com.metlife.tom.fitrava.services.utility.OperationUtility.fillLeft;
import static mx.com.metlife.tom.fitrava.services.utility.OperationUtility.fillRigt;
import static mx.com.metlife.tom.fitrava.services.utility.OperationUtility.ltrim;
import static mx.com.metlife.tom.fitrava.services.utility.OperationUtility.rtrim;
import static mx.com.metlife.tom.fitrava.services.utility.UtilCommon.isNull;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.file.FlatFileItemWriter;
import org.springframework.batch.item.file.transform.LineAggregator;
import org.springframework.core.io.FileSystemResource;

import mx.com.metlife.tom.fitrava.services.dto.InputDto;
import mx.com.metlife.tom.fitrava.services.error.FitravaException;
import mx.com.metlife.tom.fitrava.services.error.FitravaPersistenceException;
import mx.com.metlife.tom.fitrava.services.error.ValidationException;
import mx.com.metlife.tom.fitrava.services.model.entity.TClctStts;
import mx.com.metlife.tom.fitrava.services.model.entity.TDatatyp;
import mx.com.metlife.tom.fitrava.services.model.entity.TExtCncpt74;
import mx.com.metlife.tom.fitrava.services.model.entity.TExtFone;
import mx.com.metlife.tom.fitrava.services.model.entity.TExtIssste;
import mx.com.metlife.tom.fitrava.services.model.entity.TExtRicsi;
import mx.com.metlife.tom.fitrava.services.model.entity.TFldOper;
import mx.com.metlife.tom.fitrava.services.model.entity.TFldTform;
import mx.com.metlife.tom.fitrava.services.model.entity.TFldTformParm;
import mx.com.metlife.tom.fitrava.services.model.entity.TFlowMapping;
import mx.com.metlife.tom.fitrava.services.model.entity.TFlowMappingDtl;
import mx.com.metlife.tom.fitrava.services.model.entity.TLayoutFld;
import mx.com.metlife.tom.fitrava.services.model.entity.TLayoutFldAtrb;
import mx.com.metlife.tom.fitrava.services.model.entity.TProcRec;
import mx.com.metlife.tom.fitrava.services.model.entity.TProcRecSum;
import mx.com.metlife.tom.fitrava.services.model.entity.TProcRecSumDtl;
import mx.com.metlife.tom.fitrava.services.model.entity.TUloadExt;
import mx.com.metlife.tom.fitrava.services.utility.Constantes;
import mx.com.metlife.tom.fitrava.services.utility.OperationUtility;
import mx.com.metlife.tom.fitrava.services.utility.OperationUtility.OPERATION_IDS;
import mx.com.metlife.tom.fitrava.services.utility.UtilCommon;

public class FitravaItemWriterFile extends FitravaItemWriter {

	private InputDto inicial;
	private List<TLayoutFld> camposSalida;
	private List<TFlowMappingDtl> mapeos;
	private List<TFldTform> transformacionesEntrada;
	private List<TFldTform> transformacionesSalida;
	private Map<Long, Double> cifrasControl;
	private List<TUloadExt> parametros;
	private List<TFldOper> operaciones;
	
	
	private FlatFileItemWriter<List<TProcRec>> writer = null;

	@Override
	public void write(List<? extends List<TProcRec>> items) throws Exception {
		initAll(items);
		initWriter();
		List<List<TProcRec>> sinErrores = getListaFinalSinErrores(items);
		List<List<TProcRec>> errores = getListaFinalSoloErrores(items);
		
		try {
			writer.write(sinErrores);
		} finally {
			writer.close();
		}
		try {
			guardaCifrasControl(sinErrores!=null?sinErrores.size():0, errores!=null?errores.size():0);
		} catch (Exception e) {
			log.error("No se pudo guardar las cifras de control en la BD", e);
		}
	}

	private void initWriter() {
		//if (writer == null) {
			final FileSystemResource fileResource = new FileSystemResource(archivoSalida);
			writer = new FlatFileItemWriter<>();
			writer.setResource(fileResource);
			writer.setAppendAllowed(true);
			writer.setEncoding(ENCODE_UTF_8);
			//writer.setSaveState(true);//investigar un poco mas
			writer.setShouldDeleteIfEmpty(true);
			writer.open(new ExecutionContext());
			writer.setLineAggregator(new MiLineaAca());
		//}
	}
	private void initAll(List<? extends List<TProcRec>> items) throws ValidationException, FitravaException {
		if (archivoSalida == null) {
			if (items == null || items.get(0) == null || items.get(0).get(0) == null) {
				throw new FitravaException("No pueden ser null la lista de tProcRec");
			}
			
			TProcRec uno = items.get(0).get(0);
			
			String nombreArchivo = uno.getFileNm();
			nombreArchivo = nombreArchivo.substring(0, nombreArchivo.lastIndexOf(Constantes.DOT));
			nombreArchivo = nombreArchivo.concat(Constantes.DOT).concat(Constantes.TXT);
			
			this.archivoSalida = new File(Constantes.TEMP_ROOT_DIRECTORY_DESTINO_TEMP, nombreArchivo);
	
			if (!archivoSalida.exists()) {
				Boolean isCreate = null;
				try {
					isCreate = archivoSalida.createNewFile();
					if (!isCreate) {
						throw new FitravaException("No se pudo crear el archivo: " + archivoSalida.getName());
					}
				} catch (IOException e) {
					throw new FitravaException("No existe el archivo y no se puede crear");
				}
			}
			log.info("========================");
			log.info("inicialdo la escritura del archivo: {}", archivoSalida);
			initAll(uno.getDstnctCtrlNum(), uno.getFileNm());
			log.info("========================");
		}	
	}
	
	protected synchronized void initAll(String dcn, String fileName) throws ValidationException, FitravaException {
		if (inicial == null ) {
			if (isNull(fileName)|| isNull(dcn)) {
				throw new ValidationException("Nombre de archivo no valido");
			}
			try {
				inicial = auxCustomerRepository.createByDcnAndFileName(dcn, fileName);
				log.info("El inicio del proceso es: {}", inicial);
			} catch (Exception e) {
				log.error("Exception!!... ", e);
				throw new FitravaException("No se pudo inicializar el InputDto de inicio");
			}
			if (inicial == null) {
				throw new FitravaException("No se encuentra registrado el archivo en la BD");
			}
			camposSalida = tLayoutFldRepository.findByLayoutId(inicial.getSalidaLayoutId());
			List<TFlowMapping> mapping = tFlowMappingRepository.findByFlowIdAndLayoutEntradaId(inicial.getFlowId(), inicial.getEntradaLayoutId());
			//aqui hay una premisa, que hay que verificar que no sea falsa: solo hay un mapeo por cada flujo de entrada con un layout de entrada, y tiene sentido, ni modo que vaya a mas de uno de salida
			if (mapping == null || mapping.isEmpty() || mapping.get(0) == null || mapping.get(0).getListTFlowMappingDtl() == null || mapping.get(0).getListTFlowMappingDtl().isEmpty()) {
				throw new FitravaException("No es posible que el mapeo sea nulo, está mal hecho el layout");
			}
			mapeos =  mapping.get(0).getListTFlowMappingDtl();
			transformacionesEntrada = tFldTformRepository.findAllByLayoutId(inicial.getEntradaLayoutId());
			transformacionesSalida = tFldTformRepository.findAllByLayoutId(inicial.getSalidaLayoutId());
			parametros = tUloadExtRepository.findAllByDstnctCtrlNum(inicial.getDcn());
			operaciones = tFldOperRepository.findAll();
			log.info("Los campos de salida del layout son: {}", camposSalida);
			log.info("los mapeos son: {}", mapeos);
			log.info("las transformaciones del layout de entrada son: {}", transformacionesEntrada);
			log.info("las transformaciones del layout de salida son: {}", transformacionesSalida);
			log.info("los parametros por el dcn son: {}", parametros);
			log.info("las operaciones son: {}", operaciones);
		}
	}
	
	//vamos a guardar en t_proc_rec_sum y en t_proc_rec_sum_dtl
	private void guardaCifrasControl(int sinErrores, int errores) {
		//log.info("en el guardaCifrasControl(sinErrores: {}, errores: {})", sinErrores, errores);
		int total = sinErrores + errores;
		TProcRecSum tProcRecSum = tProcRecSumRepository.findByDcnAndArchivo(inicial.getDcn(), inicial.getFileNm());
		if (tProcRecSum == null) {
			tProcRecSum = new TProcRecSum(inicial.getDcn(), inicial.getFileNm(), UtilCommon.getExtension(inicial.getFileNm()), TClctStts.Estatus.EN_PROCESO.getId(), total, errores);
		} else {
			Long totalRegistros = tProcRecSum.getTotRecCnt();
			Long totalErrores = tProcRecSum.getTotErrRecCnt();
			
			totalErrores += errores;
			totalRegistros += total;
			
			tProcRecSum.setTotErrRecCnt(totalErrores);
			tProcRecSum.setTotRecCnt(totalRegistros);
		}
		tProcRecSum = tProcRecSumRepository.save(tProcRecSum);
		if (cifrasControl != null) {
			Set<Long> keys = cifrasControl.keySet();
			Double valor = null;
			TProcRecSumDtl tProcRecSumDtl = null;
			for (Long campoSalidaControlId: keys) {
				valor = cifrasControl.get(campoSalidaControlId);
				tProcRecSumDtl = new TProcRecSumDtl();
				tProcRecSumDtl.setDstnctCtrlNum(tProcRecSum.getDstnctCtrlNum());
				tProcRecSumDtl.setFileNm(tProcRecSum.getFileNm());
				tProcRecSumDtl.setLayoutFldId(campoSalidaControlId);
				tProcRecSumDtl.setRecSumVal(valor+"");
				tProcRecSumDtl.setRsltMsgTxt("");
				tProcRecSumDtlRepository.save(tProcRecSumDtl);
			}
		}
	}
	
	private class MiLineaAca implements LineAggregator<List<TProcRec>> {
		private Map<Long, String>  mapCamposSalidaValor = new HashMap<>();
		//aqui veriamos los del mapeo
		private String getNewVal(List<TProcRec> items) {
			StringBuilder builder = new StringBuilder(); 
			mapCamposSalidaValor = new HashMap<>();
			//hay que ver si algun campo de la linea tiene error, de ser así no se pinta
			//Por todos los la campos de salida, debemos encontrar el de entrada (por el mapeo), el texto, y aplicar la transformacion correspondiente
			List<Long> idsEntrada = null;
			for (TLayoutFld campoSalida: camposSalida) {
				String temp = BLANK;
				//obtenemos todos los que correspondan
				idsEntrada = getIdsCamposLayoutEntradaByMapeo(campoSalida.getLayoutFldId());
				//si no tiene IDs de entrada, quiere decir que tiene una operacion relacionada
				if (idsEntrada == null || idsEntrada.isEmpty()) {
					//temp = getDataExternal(items, campoSalida); //si fuera a los campos de entrada, pero ya no. Es, SIEMPRE, a los de salida
					temp = getDataExternal(campoSalida);
				} else {
					//iteramos y obtenemos el texto de cada uno por el tProcRec
					for (Long idEntrada:idsEntrada) {
						//obtenemos el tprocRec
						temp += getTextoByTProcRec(items, idEntrada);
						//le aplicamos las operaciones, le enviamos el id de entrada, para ver si tiene operaciones
						temp = getTextoConOperaciones(temp, campoSalida.getLayoutFldId());
					}
				}
				//lo guardamos, para futuras operaciones
				mapCamposSalidaValor.put(campoSalida.getLayoutFldId(), temp);//aun sin transformar
				if (campoSalida.getCifraCtrlInd()) {
					addCifraControl(campoSalida.getLayoutFldId(), temp);
				}
				//aqui veriamos si el T_LAYOUT_FLD si el campo se va pintar o es de los ocultos
				if(campoSalida.getHdnInd() != null && campoSalida.getHdnInd().equals(Constantes.HIDDEN)) {
					continue;
				}
				//lo transformamos
				temp = getTextoTransformado(temp, campoSalida);
				//lo agregamos a la linea
				builder.append(temp);
			}
			return builder.toString();
		}
		
		private String getDataExternal(TLayoutFld campoSalida) {
			//log.info(Constantes.LOGGER_DOUBLE_BRACET, renglon, campoSalida);
			//tengo que ver cual operacion es
			TFldTform tFldTform = getTransformacionByIdCampoSalida(campoSalida.getLayoutFldId());
			//log.info("{}", tFldTform);
			String operacionName = null;
			Object[] parametrosValue = null;
			if (tFldTform != null) {
				operacionName = getNameOperacionById(tFldTform.getFldOperId());
				parametrosValue = getObjectsByParametros(tFldTform.getListTFldTformParm());
				if (operacionName != null && operacionName.equals(OPERATION_IDS.CONCAT.getName())) {
					return OperationUtility.concat(tFldTform.getCnstVal(), parametrosValue);
				} else if (OperationUtility.isFoneOperation(operacionName) && parametrosValue != null && parametrosValue[0] != null) {
					//Es lo de FONE, obtenemos el registro, de acuerdo al 1er campo
					String id = (String)parametrosValue[0];//solo debe venir uno
					//log.info("id: {}", id);
					id = id.substring(0, 3);//R01
					//log.info("id: {}", id);
					//Ahora obtenemos el campo
					TExtFone tExtFone = null;
					try {
						tExtFone = auxCustomerRepository.findFoneBy(id, operacionName);
						//log.info("tExtFone: {}", tExtFone);
						return cadenaByFone(tExtFone, operacionName);
					} catch (FitravaPersistenceException e) {
						log.error("no se pudo obtener el FONE: {}",id);
						return BLANK;
					}
				} else if (OperationUtility.OPERATION_IDS.ARCHIVO_ORIGINARIO.getName().equals(operacionName)){
					//obtener el nombre del archivo
					return inicial.getFileNm();
				} else if (OperationUtility.OPERATION_IDS.OBTEN_PARAMETER_VALUE.getName().equals(operacionName) && tFldTform.getCnstVal() != null){
					//obtener el valor del parametro, que venga en CNST_VAL
					return getByParametro(tFldTform.getCnstVal());
				} else if (OperationUtility.isIsssteOperation(operacionName)) {
					return isssteOperation(tFldTform.getListTFldTformParm() , operacionName);
				}
			}
			return BLANK;
		}
		
		private String isssteOperation(List<TFldTformParm> params, String operacionName) {
			if (OperationUtility.OPERATION_IDS.OBTENER_POLIZA_ISSSTE.getName().equals(operacionName)) {
				return getPolizaIssste(params);
			} else if (OperationUtility.OPERATION_IDS.OBTENER_NOMBRE_CLIENTE_ISSSTE.getName().equals(operacionName)) {
				return getNombreClienteIssste(params);
			} else if (OperationUtility.OPERATION_IDS.OBTENER_SUBGRUPO_ISSSTE.getName().equals(operacionName)) {
				return getSubGrupoIssste(params);
			}
			return null;
		}
		
		/**
		 * 1-Si el concepto está en rango 75-79 o 101-105 entonces buscar póliza en catalogo RICSI con dato de “NUM_PENSION”.
		 * 2-Si el concepto 74 y el ramo es 1 buscar la póliza en catálogo de” Concepto 74”, los campos: “RFC”,” NUMERO DE PENSION”,”NOMBRE COMPLETO”
		 * 		2.1-Con el dato de concepto (74), ramo (1) y la póliza consultada en el punto 2 localizar Ramo/SubRamo.
		 * 3-Si no buscar en polizario ISSSTE los valores que trae Concepto y Ramo para localizar la póliza
		 * 4- Si no encuentra la póliza en ninguno de los catálogos poner la leyenda "NO ENCONTRADO"
		 * 
		 * @param params
		 * @return
		 */
		private String getPolizaIssste(List<TFldTformParm> params) {
			Integer concepto = null;
			Integer ramo = null;
			String numPension = null;
			List<TExtRicsi> listTExtRicsi = null;
			List<TExtCncpt74> listTExtCncpt74 = null;
			List<TExtIssste> listTExtIssste = null;
			try {
				concepto = Integer.parseInt(getValueByParametros(params, Constantes.CONCEPTO));
				numPension = getValueByParametros(params, Constantes.NUM_PENSION);
				ramo = Integer.parseInt(getValueByParametros(params, Constantes.RAMO));
				log.info("concepto: {}, numPension: {}, ramo: {}", concepto, numPension, ramo);
				//1-Si el concepto está en rango 75-79 o 101-105 
				if (concepto >= 75 && concepto <= 79 || concepto >= 101 && concepto <= 105) {
					//entonces buscar póliza en catalogo RICSI con dato de “NUM_PENSION”.
					listTExtRicsi = tExtRicsiRepository.findByNumeroPension(numPension);
					log.info("{}", listTExtRicsi);
					if (listTExtRicsi != null && !listTExtRicsi.isEmpty() && listTExtRicsi.get(0) != null) {
						return listTExtRicsi.get(0).getPolNum();
					}
				} else if (concepto.equals(74) && ramo.equals(1)) { //2-Si el concepto 74 y el ramo es 1 buscar la póliza en catálogo de” Concepto 74”, los campos: “RFC”,” NUMERO DE PENSION”,”NOMBRE COMPLETO”
					listTExtCncpt74 = tExtCncpt74Repository.findByNumeroPension(numPension);
					log.info("{}", listTExtCncpt74);
					if (listTExtCncpt74 != null && !listTExtCncpt74.isEmpty() && listTExtCncpt74.get(0) != null) {
						return listTExtCncpt74.get(0).getPolNum();
					}
				} else { //3-Si no buscar en polizario ISSSTE los valores que trae Concepto y Ramo para localizar la póliza
					listTExtIssste = tExtIsssteRepository.findByConceptoAndRamo(concepto, ramo);
					log.info("{}", listTExtIssste);
					if (listTExtIssste != null && !listTExtIssste.isEmpty() && listTExtIssste.get(0) != null) {
						return listTExtIssste.get(0).getOrigPolNum();
					}
				}
			} catch (Exception e) {
				log.error("Error al obtener la poliza del Issste", e);
			}
			//4- Si no encuentra la póliza en ninguno de los catálogos poner la leyenda "NO ENCONTRADO"
			return Constantes.NO_ENCONTRADO;
		}
		
		/**
		 * 1-Si el concepto está en rango 75-79 o 101-105 entonces colocar leyenda “POTENCIACION”, para los siguientes IDs.
		 * •	101-11
		 * •	102-11
		 * •	103-11
		 * •	104-11
		 * •	105-11
		 * •	75-11
		 * •	76-11
		 * •	77-11
		 * •	78-11
		 * •	79-11
		 * 
		 * 2-Si el concepto 74 y el ramo es 1 buscar la póliza en catálogo de” Concepto 74”, los campos: “RFC” ,”NUMERO DE PENSION”,”NOMBRE COMPLETO”
		 * 2.1-Con el dato de concepto (74), ramo (1) , la póliza consultada en el punto 2 y ”SubGrupo” localizar en polizario ISSSTE ” NOMBRE DEL ORGANISMO”.
		 * 3-Si no buscar en polizario ISSSTE los valores que trae Concepto y Ramo para localizar “NOMBRE DEL ORGANISMO”.
		 * 4- Si no encuentra la póliza en ninguno de los catálogos poner la leyenda "NO ENCONTRADO"
		 * 
		 * @param params
		 * @return
		 */
		private String getNombreClienteIssste(List<TFldTformParm> params) {
			Integer concepto = null;
			Integer ramo = null;
			String polNum = null;
			String numPension = null;
			List<TExtCncpt74> listTExtCncpt74 = null;
			List<TExtIssste> listTExtIssste = null;
			try {
				concepto = Integer.parseInt(getValueByParametros(params, Constantes.CONCEPTO));
				numPension = getValueByParametros(params, Constantes.NUM_PENSION);
				ramo = Integer.parseInt(getValueByParametros(params, Constantes.RAMO));
				log.info("concepto: {}, numPension: {}, ramo: {}", concepto, numPension, ramo);
				//1-Si el concepto está en rango 75-79 o 101-105 entonces colocar leyenda “POTENCIACION”, para los siguientes IDs.
				if (concepto >= 75 && concepto <= 79 || concepto >= 101 && concepto <= 105) {
					if (UtilCommon.isPotenciacion(concepto, ramo)) {
						return Constantes.POTENCIACION;
					}
				} else if (concepto.equals(74) && ramo.equals(1)) { //2-Si el concepto 74 y el ramo es 1 buscar la póliza en catálogo de” Concepto 74”, los campos: “RFC” ,”NUMERO DE PENSION”,”NOMBRE COMPLETO”
					listTExtCncpt74 = tExtCncpt74Repository.findByNumeroPension(numPension);
					log.info("{}", listTExtCncpt74);
					if (listTExtCncpt74 != null && !listTExtCncpt74.isEmpty() && listTExtCncpt74.get(0) != null) {
						//2.1-Con el dato de concepto (74), ramo (1) , la póliza consultada en el punto 2 y ”SubGrupo” localizar en polizario ISSSTE ” NOMBRE DEL ORGANISMO”.
						polNum = listTExtCncpt74.get(0).getPolNum();
						listTExtIssste = tExtIsssteRepository.findByConceptoAndRamoAndNumeroPoliza(concepto, ramo, polNum);
						log.info("{}", listTExtIssste);
						if (listTExtIssste != null && !listTExtIssste.isEmpty() && listTExtIssste.get(0) != null) {
							return listTExtIssste.get(0).getCustNm();
						}
					}
				}
			} catch (Exception e) {
				log.error("Error al obtener la poliza del Issste", e);
			}
			//4- Si no encuentra la póliza en ninguno de los catálogos poner la leyenda "NO ENCONTRADO"
			return Constantes.NO_ENCONTRADO;
		}
		
		/**
		 * 1-Si el concepto está en rango 75-79 o 101-105 entonces colocar leyenda “POTENCIACION”.
		 * 2-Si el concepto 74 y el ramo es 1 buscar la póliza en catálogo de ”Concepto 74”, los campos: “RFC” ,”NUMERO DE PENSION”,”NOMBRE COMPLETO”
		 * 2.1-Con el dato de concepto (74), ramo(1) y la póliza consultada en el punto 2 localizar ”SubGrupo” del polzario ISSTE
		 * 3-Si no buscar en polizario ISSSTE los valores que trae Concepto y Ramo para localizar la póliza
		 * 4- Si no encuentra la póliza en ninguno de los catálogos poner la leyenda "NO ENCONTRADO"
		 * 
		 * @param params
		 * @return
		 */
		private String getSubGrupoIssste(List<TFldTformParm> params) {
			Integer concepto = null;
			Integer ramo = null;
			String polNum = null;
			String numPension = null;
			List<TExtCncpt74> listTExtCncpt74 = null;
			List<TExtIssste> listTExtIssste = null;
			try {
				concepto = Integer.parseInt(getValueByParametros(params, Constantes.CONCEPTO));
				numPension = getValueByParametros(params, Constantes.NUM_PENSION);
				ramo = Integer.parseInt(getValueByParametros(params, Constantes.RAMO));
				log.info("concepto: {}, numPension: {}, ramo: {}", concepto, numPension, ramo);
				//1-Si el concepto está en rango 75-79 o 101-105 entonces colocar leyenda “POTENCIACION”.
				if (concepto >= 75 && concepto <= 79 || concepto >= 101 && concepto <= 105) {
					return Constantes.POTENCIACION;
				} else if (concepto == 74 && ramo.equals(1)) { //2-Si el concepto 74 y el ramo es 1 buscar la póliza en catálogo de ”Concepto 74”, los campos: “RFC” ,”NUMERO DE PENSION”,”NOMBRE COMPLETO”
					listTExtCncpt74 = tExtCncpt74Repository.findByNumeroPension(numPension);
					log.info("{}", listTExtCncpt74);
					if (listTExtCncpt74 != null && !listTExtCncpt74.isEmpty() && listTExtCncpt74.get(0) != null) {
						//2.1-Con el dato de concepto (74), ramo(1) y la póliza consultada en el punto 2 localizar ”SubGrupo” del polzario ISSTE
						polNum = listTExtCncpt74.get(0).getPolNum();
						listTExtIssste = tExtIsssteRepository.findByConceptoAndRamoAndNumeroPoliza(concepto, ramo, polNum);
						log.info("{}", listTExtIssste);
						if (listTExtIssste != null && !listTExtIssste.isEmpty() && listTExtIssste.get(0) != null) {
							return listTExtIssste.get(0).getSbGrpNm();
						}
					}
				} else {//3-Si no buscar en polizario ISSSTE los valores que trae Concepto y Ramo para localizar la póliza
					listTExtIssste = tExtIsssteRepository.findByConceptoAndRamo(concepto, ramo);
					log.info("{}", listTExtIssste);
					if (listTExtIssste != null && !listTExtIssste.isEmpty() && listTExtIssste.get(0) != null)  {
						return listTExtIssste.get(0).getSbGrpNm();
					}
				}
			} catch (Exception e) {
				log.error("Error al obtener la poliza del Issste", e);
			}
			//4- Si no encuentra la póliza en ninguno de los catálogos poner la leyenda "NO ENCONTRADO"
			return Constantes.NO_ENCONTRADO;
		}
		
		private String cadenaByFone(TExtFone tExtFone, String operacionName) {
			if (OperationUtility.isFonePolizaOriginal(operacionName)) {
				return tExtFone.getOrigPolNum();
			} else if (OperationUtility.isFoneRamoSubRamo(operacionName)) {
				return tExtFone.getSbCtgyCd()!=null?tExtFone.getSbCtgyCd():BLANK;
			} else if (OperationUtility.isFoneSubGrupo(operacionName)) {
				return tExtFone.getSbGrpNum()!=null?tExtFone.getSbGrpNum().toString():BLANK;
			}			
			return BLANK;
		}

		private String getTextoByTProcRec(List<TProcRec> items, Long idEntrada) {
			for (TProcRec item: items) {
				//log.info("item: {}", item);
				if (item.getLayoutFldId().equals(idEntrada)) {
					return item.getNewVal();
				}
			}
			return BLANK;
		}
		
		private void addCifraControl(Long campoSalidaId, String valor) {
			if (cifrasControl == null) {
				cifrasControl = new HashMap<>();
			}
			valor = OperationUtility.remove(valor);
			Double valorCifraControl = cifrasControl.get(campoSalidaId);
			if (valorCifraControl == null) {
				valorCifraControl = 0.0;
			}
			valorCifraControl += Double.parseDouble(valor);
			//log.info("valor: {} - valorCifraControl: {}", valor, valorCifraControl);
			cifrasControl.put(campoSalidaId, valorCifraControl);
		}
		
		private String getTextoTransformado(String temp, TLayoutFld campoSalida) {
			//log.info("getTextoTransformado(temp: {}, campoSalida: {}", temp, campoSalida);
			//empezamos con la transformacion por el campo
			if (campoSalida.getDatatypId().equals(TDatatyp.TIPO_DATO.NUMERICO.getId())) {
			 	try {
					temp = OperationUtility.formatNumber(temp, campoSalida.getSeprtrDecVal(), campoSalida.getDecPstnCnt());
				} catch (ValidationException e) {
					temp = BLANK;
				}
			}
			//log.info("temp: {}", temp);
			if (campoSalida.getListTLayoutFldAtrb() != null && !campoSalida.getListTLayoutFldAtrb().isEmpty()) {
				TLayoutFldAtrb atributos = campoSalida.getListTLayoutFldAtrb().iterator().next();//solo debe haber uno, segun el bubu
				//log.info("atributos--->{}<---", atributos);
				Integer longitudAjustar = atributos.getFixLnthNum();
				//log.info("longitudAjustar--->{}", longitudAjustar);
				if (longitudAjustar != null && longitudAjustar > 0) {//dice el bubu que si es de longitud fija, entro, en caso que no, else
					if (atributos.getLeftAlgnInd()) {// se alinea a la izquierda
						Character caracter = atributos.getRghtFillCharVal().charAt(0);//E = espacio y 0 = 0
						if (caracter.equals('E')) {
							caracter = Constantes.CHAR_SPCAE;
						} else {
							caracter = Constantes.CHAR_ZERO;
						}
						temp = fillRigt(temp, caracter, longitudAjustar);
					} 
					if (atributos.getRghtAlgnInd()) { // se alinea a la derecha
						Character caracter = atributos.getLeftFillCharVal().charAt(0);
						if (caracter.equals('E')) {
							caracter = Constantes.CHAR_SPCAE;
						} else {
							caracter = Constantes.CHAR_ZERO;
						}
						temp = fillLeft(temp, caracter, longitudAjustar);
					}
				} else {
					if (atributos.getLeftTrimInd()) {// se hace un trim a la izquierda
						temp = ltrim(temp);
					} 
					if (atributos.getRghtTrimInd()) { // se hace un trim a la derecha
						temp = rtrim(temp);
					}
				}
			}
			//log.info("---->{}<----", temp);
			return temp;
		}
		
		//si es producto de una operacion: ¿no hacemos caso del texto de entrada?, y generamos el nuevo texto a partir de las operaciones
		private String getTextoConOperaciones(String temp, Long idCampoSalida) {
			//log.info("en el getTextoConOperaciones(temp {}, idCampoEntrada: {}, items: {}", temp, idCampoEntrada, items);
			//obtenemos las formas por el id de entrada
			TFldTform tFldTform = getTransformacionByIdCampoEntrada(idCampoSalida);
			String operationName = null;
			if (tFldTform != null) {
				//log.info("tFldTform: {} ", tFldTform);
				operationName = getNameOperacionById(tFldTform.getFldOperId());
				List<TFldTformParm> parametros = tFldTform.getListTFldTformParm();
				//log.info("Operacion: {}, parametros: {} ", operacionId, parametros);
				try {
					if (parametros == null || parametros.isEmpty()) {
						//la operacion se realiza sobre el texto que entra
						temp = OperationUtility.transformAndFormat(operationName, temp);
						//log.info("Con parametros null, se aplica la operacion sobre la misma cadena, regresando de la operacion {}, y el resultado fue: {}", operacionId, temp);
					} else if (!operationName.equals(OPERATION_IDS.CONCAT.getName())) {
						//de la operacion 
						temp = OperationUtility.transformAndFormat(operationName, getObjectsByParametros(parametros));
						//log.info("Regresando de la operacion {}, y el resultado fue: {}", operacionId, temp);
					}
				}catch (ValidationException e) {
					log.error("error al aplicar la transformacion y formato", e);
				}
			}
			return temp;
		}
		
		private Object[] getObjectsByParametros(List<TFldTformParm> params) {
			if (params == null) {
				return null;
			}
			Object[] parametros = new Object[params.size()];
			int i = 0;
			Long campoSalidaId = null;
			for (TFldTformParm param: params) {
				campoSalidaId = param.getLayoutFldId(); //los parametros siempre van a venir con respecto al ID de salida
				log.info("{}", campoSalidaId);
				parametros[i++] = mapCamposSalidaValor.get(campoSalidaId);
			}
			log.info("Los parametros: --->{}<---", UtilCommon.getArrayToString(parametros));
			return parametros;
		}
		
		private String getValueByParametros(List<TFldTformParm> params, String paramName) {
			if (params == null) {
				return null;
			}
			for (TFldTformParm param: params) {
				if (param.getParmNm().equalsIgnoreCase(paramName)) {
					return mapCamposSalidaValor.get(param.getLayoutFldId()); //los parametros siempre van a venir con respecto al ID de salida
				}
			}
			return null;
		}
		
		
		private TFldTform getTransformacionByIdCampoEntrada(Long idCampoEntrada) {
			if (transformacionesEntrada != null) {
				for (TFldTform form: transformacionesEntrada) {
					if (form.getLayoutFldId().equals(idCampoEntrada)) {
						return form;
					}
				}
			}
			return null;
		}

		private TFldTform getTransformacionByIdCampoSalida(Long idCampoSalida) {
			if (transformacionesSalida != null) {
				for (TFldTform form: transformacionesSalida) {
					if (form.getLayoutFldId().equals(idCampoSalida)) {
						return form;
					}
				}
			}
			return null;
		}

		private List<Long> getIdsCamposLayoutEntradaByMapeo(Long idCampoSalida) {
			List<Long> ids = new ArrayList<>();
			for (TFlowMappingDtl mapeoDtl: mapeos) {
				if (mapeoDtl.getOutLayoutFldId().equals(idCampoSalida)) {
					ids.add(mapeoDtl.getEntrncLayoutFldId());
				}
			}
			return ids;
		}
		

		private String getByParametro(String paramName) {
			if (parametros == null || parametros.isEmpty()) {
				return null;
			}
			for (TUloadExt parametro:parametros) {
				if (parametro.getKey().equalsIgnoreCase(paramName)) {
					return parametro.getValue();
				}
			}
			return null;
		}
		
		private String getNameOperacionById(Long id) {
			if (operaciones != null && !operaciones.isEmpty()) {
				for (TFldOper oper: operaciones) {
					if (oper.getFldOperId().equals(id)) {
						return oper.getFldOperNm();
					}
				}
			}
			return null;
		}
		

		@Override
		public String aggregate(List<TProcRec> items) {
			String temp = getNewVal(items);
			return temp!=null?temp:BLANK;
		}
		
	}

}
