package mx.com.metlife.tom.fitrava.engine.items.readers;

import java.util.Arrays;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.excel.RowMapper;
import org.springframework.batch.item.excel.support.rowset.RowSet;

import mx.com.metlife.tom.fitrava.services.utility.excel.ExcelUtility;

public class RowMapperImpl implements RowMapper<String[]> {

	static final Logger log = LoggerFactory.getLogger(RowMapperImpl.class);

	private ExcelUtility excelUtility = null;
	
	public RowMapperImpl() {}

	public RowMapperImpl(ExcelUtility excelUtility) {
		this.excelUtility = excelUtility;
	}
	
    @Override
    public String[] mapRow(RowSet rs) throws Exception {
        if (rs == null || rs.getCurrentRow() == null) {
            return null;
        }
        String[] temp = rs.getCurrentRow();
        if (excelUtility != null && temp != null) { 
        	return Arrays.copyOfRange(temp, excelUtility.getColumnaInicial(), excelUtility.getColumnaFinal()+1);
        }
        return temp;
    }
 
}
 