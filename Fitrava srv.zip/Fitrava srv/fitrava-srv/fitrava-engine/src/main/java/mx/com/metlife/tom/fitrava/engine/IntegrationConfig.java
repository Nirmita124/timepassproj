package mx.com.metlife.tom.fitrava.engine;

import java.io.File;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.integration.launch.JobLaunchingMessageHandler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.integration.channel.DirectChannel;
import org.springframework.integration.core.MessageSource;
import org.springframework.integration.dsl.IntegrationFlow;
import org.springframework.integration.dsl.IntegrationFlows;
import org.springframework.integration.dsl.Pollers;
import org.springframework.integration.file.FileReadingMessageSource;
import org.springframework.integration.file.FileReadingMessageSource.WatchEventType;
import org.springframework.integration.file.filters.AcceptAllFileListFilter;

import mx.com.metlife.tom.fitrava.services.utility.Constantes;

@Configuration
public class IntegrationConfig {

	private static final Logger log = LoggerFactory.getLogger(IntegrationConfig.class);

	
	@Autowired
	private JobLauncher jobLauncher;

	@Autowired
	private Job fitravaJob;

	@Autowired
	private Job catalogosJob;

	protected DirectChannel inputChannel() {
		return new DirectChannel();
	}
	
	@Bean
	public IntegrationFlow integrationFlow() {
		log.info("en el integrationFlow");
		return IntegrationFlows 
				.from(fileReadingMessageSourceFitrava(), c -> c.poller(Pollers.fixedDelay(30000)))
				.channel(inputChannel()) 
				.transform(fileMessageToJobRequestFitrava()) 
				.handle(jobLaunchingMessageHandler()) 
				.handle(jobExecution -> jobExecution.getPayload())
				.get();
	}

	@Bean
	public IntegrationFlow cargaIntegrationFlow() {
		log.info("en el cargaIntegrationFlow");
		return IntegrationFlows 
				.from(fileReadingMessageSourceCatalogo(), c -> c.poller(Pollers.fixedDelay(5000)))
				.channel(inputChannel()) 
				.transform(fileMessageToJobRequestCatalogo()) 
				.handle(jobLaunchingMessageHandler()) 
				.handle(jobExecution -> jobExecution.getPayload())
				.get();
	}
	
	@Bean
	public MessageSource<File> fileReadingMessageSourceFitrava() {
		log.info("en el fileReadingMessageSourceFitrava");
		FileReadingMessageSource source = new FileReadingMessageSource();
		source.setDirectory(new File(Constantes.TEMP_ROOT_DIRECTORY_ORIGEN));
		source.setFilter(onlyInput());
		source.setUseWatchService(true);
		source.setWatchEvents(WatchEventType.CREATE);
		return source;
	}

	@Bean
	public MessageSource<File> fileReadingMessageSourceCatalogo() {
		log.info("en el fileReadingMessageSourceCatalogo");
		FileReadingMessageSource source = new FileReadingMessageSource();
		source.setDirectory(new File(Constantes.TEMP_ROOT_DIRECTORY_CATALOGOS));
		source.setFilter(onlyCatalogos());
		source.setUseWatchService(true);
		source.setWatchEvents(WatchEventType.CREATE);
		return source;
	}

	@Bean
	public FileMessageToJobRequest fileMessageToJobRequestFitrava() {
		log.info("en el fileMessageToJobRequestFitrava");
		return new FileMessageToJobRequest(fitravaJob, Constantes.FILE_PATH_RECIBE_ARCHIVOS);
	}

	@Bean
	public FileMessageToJobRequest fileMessageToJobRequestCatalogo() {
		log.info("en el fileMessageToJobRequestCatalogo");
		return new FileMessageToJobRequest(catalogosJob, Constantes.FILE_CATALOGO_PATH_RECIBE_CATALOGOS);
	}

	@Bean
	public JobLaunchingMessageHandler jobLaunchingMessageHandler() {
		log.info("en el jobLaunchingMessageHandler");
		return new JobLaunchingMessageHandler(jobLauncher);
	}
	
	public AcceptAllFileListFilter<File> onlyInput() {
	    return new AcceptAllFileListFilter<File>() {
	        @Override
	        public boolean accept(File source) {
	          return source.getName().startsWith(Constantes.INICIO_NOMBRE_ARCHIVO_ENTRADA);
	        }
	    };
	}

	public AcceptAllFileListFilter<File> onlyCatalogos() {
	    return new AcceptAllFileListFilter<File>() {
	        @Override
	        public boolean accept(File source) {
	          return source.getName().endsWith(".txt") &&
	        		  (source.getName().startsWith(Constantes.PREF_NOMBRE_CATALOGO_FONE) || 
	        				  source.getName().startsWith(Constantes.PREF_NOMBRE_CATALOGO_ISSSTE) || 
	        				  source.getName().startsWith(Constantes.PREF_NOMBRE_CATALOGO_RICSI) ||
	        				  source.getName().startsWith(Constantes.PREF_NOMBRE_CATALOGO_RAMO74));
	        }
	    };
	}
}