package mx.com.metlife.tom.fitrava.engine.listener;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import mx.com.metlife.tom.fitrava.engine.utils.RestTemplateConsumer;
import mx.com.metlife.tom.fitrava.services.error.FitravaPersistenceException;
import mx.com.metlife.tom.fitrava.services.model.customer.AuxCustomerRepository;
import mx.com.metlife.tom.fitrava.services.model.entity.TClctStts;
import mx.com.metlife.tom.fitrava.services.utility.Constantes;
import mx.com.metlife.tom.fitrava.services.utility.UtilCommon;

@Component
public class JobFilesFitravaListener extends JobFitravaListener {

	private static final Logger log = LoggerFactory.getLogger(JobFilesFitravaListener.class);

	@Autowired
	private AuxCustomerRepository auxCustomerRepository;
	
	@Autowired
	private RestTemplateConsumer restTemplateConsumer;

	
	@Override
	public void afterJob(JobExecution jobExecution) {
		if (jobExecution.getStatus().equals(BatchStatus.COMPLETED)) {
			String filePath = jobExecution.getJobParameters().getString(Constantes.FILE_PATH_RECIBE_ARCHIVOS);
			if (filePath != null) {
				File file = new File(filePath);
				if (file.exists()) {
					addTiempoEspera(filePath, false);
					logTiempos(filePath);
					String nombreArchivo = UtilCommon.getFileOriginalNameByFileName(file.getName());
					String dcn = UtilCommon.getDcnByFileName(file.getName());
					deleteFile(file);
					try {
						auxCustomerRepository.mergeTProcFileStatus(TClctStts.Estatus.FINALIZADO.getId(), nombreArchivo);
						auxCustomerRepository.mergeTProcRecSumStatus(TClctStts.Estatus.FINALIZADO.getId(), nombreArchivo);
					} catch (FitravaPersistenceException e) {
						log.error(String.format("No fue posible actualizar el estatus del archivo: %1$s a FINALIZADO", filePath), e);
					}
					//ahora, hay que ver si hay más archivos del mismo DCN, si es así se queda en el temporal, si ya no hay más se pasa al definitivo
					Boolean hasMoreFiles = null;
					String nombreArchivoSalida = null;
					List<String> archivosSalidas = null;
					File archivoSalida = null;
					try {
						hasMoreFiles = auxCustomerRepository.hasMoreFiles(dcn);
						if (!hasMoreFiles) {
							//si ya no hay más archivos por DCN, hay que pasar todos al directorio definitivo
							archivosSalidas = auxCustomerRepository.findFileNamesByDcn(dcn);
							for (String archivo: archivosSalidas) {
								nombreArchivoSalida = archivo.substring(0, archivo.lastIndexOf(Constantes.DOT));
								nombreArchivoSalida = nombreArchivoSalida.concat(Constantes.DOT).concat(Constantes.TXT);
								archivoSalida = new File(Constantes.TEMP_ROOT_DIRECTORY_DESTINO_TEMP, nombreArchivoSalida);
								if (archivoSalida.length() == 0) {
									Files.delete(archivoSalida.toPath());
									continue;
								}
								Files.move(archivoSalida.toPath(), (new File (Constantes.TEMP_ROOT_DIRECTORY_DESTINO, nombreArchivoSalida)).toPath(), StandardCopyOption.REPLACE_EXISTING);
							}
							//hay que actualizar el t_proc
							auxCustomerRepository.mergeTProcStatus(TClctStts.Estatus.FINALIZADO.getId(), dcn);
							//llamada metodo bubus.
							//{{Pieda Solorzano}}
							restTemplateConsumer.uploadFiles(dcn);//Mandando archivos de salida a SFG
						}
					} catch (FitravaPersistenceException e) {
						log.error(String.format("No fue posible mandar consultar si existen mas archivos por la DCN : %1$s", dcn), e);
					} catch (IOException e) {
						log.error(String.format("No fue posible mover los archivos a destino : %1$s", dcn), e);
					}
				}
			}
		}
		super.afterJob(jobExecution);
	}

	@Override
	public void beforeJob(JobExecution jobExecution) {
		log.info("Antes de que se ejecute el Job: {}" + jobExecution.getJobParameters());
		if (jobExecution.getStatus().equals(BatchStatus.STARTING) || jobExecution.getStatus().equals(BatchStatus.STARTED) ) {
			String filePath = jobExecution.getJobParameters().getString(Constantes.FILE_PATH_RECIBE_ARCHIVOS);
			if (filePath != null) {
				addTiempoEspera(filePath, true);
				File file = new File(filePath);
				if (file.exists()) {
					String nombreArchivo = UtilCommon.getFileOriginalNameByFileName(file.getName());
					try {
						auxCustomerRepository.mergeTProcFileStatus(TClctStts.Estatus.EN_PROCESO.getId(), nombreArchivo);
					} catch (FitravaPersistenceException e) {
						log.error(String.format("No fue posible actualizar el estatus del archivo: %1$s a EN_PROCESO", filePath), e);
					}
				}
			}
		}
		super.beforeJob(jobExecution);
	}
	
}






