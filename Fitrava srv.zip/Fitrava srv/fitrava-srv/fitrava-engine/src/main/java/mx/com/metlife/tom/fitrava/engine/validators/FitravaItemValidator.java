package mx.com.metlife.tom.fitrava.engine.validators;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.validator.Validator;

import mx.com.metlife.tom.fitrava.services.utility.UtilCommon;

public class FitravaItemValidator implements Validator<String[]> {

	private static final Logger log = LoggerFactory.getLogger(FitravaItemValidator.class);

	@Override
	public void validate(String[] value) {
		log.info("Aqui se hace la validacion, antes de escribir: {} ", UtilCommon.getArrayToString(value));
	}

}
