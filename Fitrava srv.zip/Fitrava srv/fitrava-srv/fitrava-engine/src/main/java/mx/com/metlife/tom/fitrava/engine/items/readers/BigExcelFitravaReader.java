package mx.com.metlife.tom.fitrava.engine.items.readers;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.batch.item.support.AbstractItemCountingItemStreamItemReader;

import com.monitorjbl.xlsx.StreamingReader;

import mx.com.metlife.tom.fitrava.services.error.FitravaException;
import mx.com.metlife.tom.fitrava.services.utility.UtilCommon;

public class BigExcelFitravaReader extends AbstractItemCountingItemStreamItemReader<String[]> {

	private int renglonesOmitir = 0;
	private String[] hojasOmitir = null;
	private String nombreHoja = null;
	private Integer numHojas = null;
	protected List<CellType> columnTypes = null;

	private Workbook book = null;
	private List<Sheet> allSheet = null;
	
	protected Integer numColumnas = null;
	protected Integer columnaInicial;
	protected Integer columnaFinal;
	protected Boolean isForNumber = null;

	private String excel = null;
	protected InputStream is = null;
	
	private int hojaActual = 0;
	private int saltarRenglones = 0;
	private int intentos = 0;
	
	private int endAfterBlankLines = 3;

    
	public void setEndAfterBlankLines(int endAfterBlankLines) {
		this.endAfterBlankLines = endAfterBlankLines;
	}


	public BigExcelFitravaReader(String excel, Integer renglonesOmitir, String...hojasOmitir) throws FitravaException{
		super();
		this.excel = excel;
		this.renglonesOmitir = renglonesOmitir==null?0:renglonesOmitir.intValue();
		this.hojasOmitir = hojasOmitir;
	}


    private void init() throws FitravaException {
    	//System.out.println("iniciando");
    	File excelFile = null;
    	try {
    		excelFile = new File(excel);
			is = new FileInputStream(excelFile);
			this.book = StreamingReader.builder()
				.rowCacheSize(100)
		        .bufferSize(2096)   
		        .open(is);     
    	} catch (Exception e) {
    		throw new FitravaException("no se pudo crear el ExcelFitravaReader", e);
    	}
    	//System.out.println("terminamos");
    }
    
    public void initAllHojas() {
		//System.out.println("iniciando las hojas");
		this.allSheet = new ArrayList<>();
		initIsForNumber();
		//System.out.println("book.getNumberOfSheets(): " + book.getNumberOfSheets());
		for (int i = 0; i < book.getNumberOfSheets(); i++) {
			//System.out.println("i: " + i);
			if (isForNumber != null) {
				if (isForNumber) {
					if (validateHojaNumero(i)) {
						continue;
					}
				} else {
					if(validateHojaNombre(book.getSheetAt(i).getSheetName())) {
						continue;
					}
				}
			}
			//System.out.println("----->>>" + i);
			allSheet.add(book.getSheetAt(i));
		}
		this.numHojas = allSheet.size();
		this.nombreHoja = allSheet.get(0).getSheetName();
	}
    
    protected void initIsForNumber() {
		if (hojasOmitir != null && hojasOmitir.length > 0) {
			isForNumber = UtilCommon.hasOnlyIntegers(hojasOmitir);
		}
	}
	
	protected Boolean validateHojaNumero(int i) {
		Integer h = null;
		for (String hoja:hojasOmitir) {
			h = Integer.parseInt(hoja);
			if (h.equals(i)) {
				return true;
			}
		}
		return false;
	}
	
	protected Boolean validateHojaNombre(String nombre) {
		for (String hoja:hojasOmitir) {
			if (nombre.equals(hoja)) {
				return true;
			}
		}
		return false;
	}
    
    
    public String getNombreHoja() {
		return nombreHoja;
	}

	@Override
	protected String[] doRead() throws Exception {
		//System.out.println(String.format("en el doRead(), hojaActual:%1$s < numHojas: %2$s", hojaActual,numHojas));
		String[] arr = null;
		uno: while(hojaActual < numHojas) {
			//System.out.println("1");
			dos: for (Row row :getHoja(hojaActual)) {
					//System.out.println("row: " + row);
					if (saltarRenglones < renglonesOmitir) {
						saltarRenglones++;
						continue dos;
					}
					if (intentos == endAfterBlankLines) {
						if (hojaActual < numHojas) {
							intentos = 0;
							saltarRenglones = 0;
							hojaActual++;
							continue uno;
						} 
						return null;
					}
					if (getColumnTypes() == null) {
						initColumnTypes(row);
					}
					arr = getRowAsStringArray(row);
					if (UtilCommon.isNull(arr)) {
						intentos++;
						continue dos;
					}
					//System.out.println("->" + UtilCommon.getArrayToString(arr) + "<-");
					return arr;
				}
				hojaActual++;
		}
		return null;
	}

	private String[] getRowAsStringArray(Row row) {
		List<String> array = new ArrayList<>();
		int i = 0;
		for(Cell cell: row) {
			if (i < columnaInicial) {
				i++;
				continue;
			}
			if (i > columnaFinal) {
				break;
			}
			array.add(cell.getStringCellValue());
			i++;
		}
		return array.toArray(new String[array.size()]);
	}

	public Sheet getHoja(int sheet) {
		if (sheet >=0 && sheet<allSheet.size()) {
			Sheet s = allSheet.get(sheet);
			this.nombreHoja = s.getSheetName();
			return s;
		}
		return null;
	}

	public List<CellType> getColumnTypes() {
		return columnTypes;
	}
	
	private void initColumnTypes(Row row) {
		//System.out.println("row: " + row);
		columnTypes = new ArrayList<>();
		for (Cell cell: row) {
			if (cell.getCellType().equals(CellType._NONE) 
					|| cell.getCellType().equals(CellType.BLANK)
					|| cell.getCellType().equals(CellType.ERROR)) 
			{
				continue;
			}
			if (columnaInicial == null) {
				columnaInicial = cell.getColumnIndex();
			}
			columnTypes.add(cell.getCellType());
			columnaFinal = cell.getColumnIndex();
		}
		numColumnas = columnTypes.size();
		//System.out.println(String.format("numColumnas: %1$s, columnaInicial: %2$s, columnaFinal: %3$s", numColumnas, columnaInicial, columnaFinal));
	}

	@Override
	protected void doOpen() throws Exception {
		init();
		initAllHojas();		
	}


	@Override
	protected void doClose() throws Exception {
		if (book != null) {
			try {
				book.close();
			} catch (Exception e) {}
		}
		if (is != null) {
			try {
				is.close();
			} catch (Exception e) {}
		}
	}


}
