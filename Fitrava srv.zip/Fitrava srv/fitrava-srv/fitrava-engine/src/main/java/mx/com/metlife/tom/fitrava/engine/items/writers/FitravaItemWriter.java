package mx.com.metlife.tom.fitrava.engine.items.writers;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;

import mx.com.metlife.tom.fitrava.services.model.customer.AuxCustomerRepository;
import mx.com.metlife.tom.fitrava.services.model.entity.TProcRec;
import mx.com.metlife.tom.fitrava.services.model.repository.TExtCncpt74Repository;
import mx.com.metlife.tom.fitrava.services.model.repository.TExtFoneRepository;
import mx.com.metlife.tom.fitrava.services.model.repository.TExtIsssteRepository;
import mx.com.metlife.tom.fitrava.services.model.repository.TExtRicsiRepository;
import mx.com.metlife.tom.fitrava.services.model.repository.TFldOperRepository;
import mx.com.metlife.tom.fitrava.services.model.repository.TFldTformRepository;
import mx.com.metlife.tom.fitrava.services.model.repository.TFlowMappingRepository;
import mx.com.metlife.tom.fitrava.services.model.repository.TLayoutFldRepository;
import mx.com.metlife.tom.fitrava.services.model.repository.TProcRecRepository;
import mx.com.metlife.tom.fitrava.services.model.repository.TProcRecSumDtlRepository;
import mx.com.metlife.tom.fitrava.services.model.repository.TProcRecSumRepository;
import mx.com.metlife.tom.fitrava.services.model.repository.TUloadExtRepository;

@Scope(value = "step", proxyMode = ScopedProxyMode.INTERFACES)
@Component
public abstract class FitravaItemWriter implements ItemWriter<List<TProcRec>> {

	protected static final Logger log = LoggerFactory.getLogger(FitravaItemWriter.class);
	
	@Autowired
	protected AuxCustomerRepository auxCustomerRepository; 

	@Autowired
	protected TLayoutFldRepository tLayoutFldRepository;

	@Autowired
	protected TFlowMappingRepository tFlowMappingRepository;

	@Autowired
	protected TFldTformRepository tFldTformRepository;

	@Autowired
	protected TProcRecRepository tProcRecRepository;
	
	@Autowired
	protected TProcRecSumRepository tProcRecSumRepository;

	@Autowired
	protected TProcRecSumDtlRepository tProcRecSumDtlRepository;
	
	@Autowired
	protected TUloadExtRepository tUloadExtRepository;

	@Autowired
	protected TFldOperRepository tFldOperRepository;

	@Autowired
	protected TExtFoneRepository tExtFoneRepository;
	
	@Autowired
	protected TExtIsssteRepository tExtIsssteRepository;
	
	@Autowired
	protected TExtCncpt74Repository tExtCncpt74Repository;
	
	@Autowired
	protected TExtRicsiRepository tExtRicsiRepository;
	
	
	protected File archivoSalida;
	
	private static String[] TEXTO_COMUN_FOOTER = {"TOTAL", "SUBTOTAL"};

	protected List<List<TProcRec>> getListaFinalSinErrores(List<? extends List<TProcRec>> items) {
		List<List<TProcRec>> listaTotal = null;
		if (items != null && !items.isEmpty()) {
			listaTotal = new ArrayList<>();
			uno: for (List<TProcRec> renglones: items) {
				//quita los vacios
					if (validaRenglonNull(renglones) || validaFooter(renglones)) {
						continue uno;
					}
					for (TProcRec celda: renglones) {
						if (celda.getBadRsltInd().equals(Boolean.TRUE)) {
							continue uno;
						}
					}
					listaTotal.add(renglones);	
				}
		}
		return listaTotal;
	}
	
	protected List<List<TProcRec>> getListaFinalConErrores(List<? extends List<TProcRec>> items) {
		List<List<TProcRec>> listaTotal = null;
		if (items != null && !items.isEmpty()) {
			listaTotal = new ArrayList<>();
			for (List<TProcRec> renglones: items) {
				//quita los vacios
				if (validaRenglonNull(renglones) || validaFooter(renglones)) {
					continue;
				}
				listaTotal.add(renglones);
			}
		}
		return listaTotal;
	}
	
	protected List<List<TProcRec>> getListaFinalSoloErrores(List<? extends List<TProcRec>> items) {
		List<List<TProcRec>> listaTotal = null;
		if (items != null && !items.isEmpty()) {
			listaTotal = new ArrayList<>();
			uno: for (List<TProcRec> renglones: items) {
				//quita los vacios
				if (validaRenglonNull(renglones) || validaFooter(renglones)) {
					continue uno;
				}
				//revisa si por cada celda su indicador dice que es error, consideramos que el renglon tiene error
				for (TProcRec celda: renglones) {
					if (celda.getBadRsltInd().equals(Boolean.TRUE)) {
						listaTotal.add(renglones);
						continue uno;
					}
				}
			}
		}
		return listaTotal;
	}
	
	protected Boolean validaRenglonNull(List<TProcRec> renglones) {
		for (TProcRec columna: renglones) {
			//si alguna celda contiene un valor, no es null
			if (columna.getNewVal() != null && columna.getNewVal().trim().length() > 0) {
				return false;
			}
		}
		//si el renglon está vacio...
		return true;
	}
	
	//pues habria que validar si es el footer del archivo, podria ser por textos fijos, de TOTAL, o subtotal o por ser los últimos del archivo
	protected Boolean validaFooter(List<TProcRec> renglones) {
		for (TProcRec columna: renglones) {
			//si alguna celda contiene un valor, no es null
			for (String textoComunFooter:TEXTO_COMUN_FOOTER) {
				if (columna.getNewVal() != null && columna.getNewVal().trim().toUpperCase().contains(textoComunFooter)) {
					//log.info("columna.getNewVal(): {}", columna.getNewVal());
					//si alguna de las columns del renglon contiene el texto comun de footer, es footer
					return true;
				}
			}
		}
		//si en el renglon no aparece, no es footer
		return false;
	}

	
}
