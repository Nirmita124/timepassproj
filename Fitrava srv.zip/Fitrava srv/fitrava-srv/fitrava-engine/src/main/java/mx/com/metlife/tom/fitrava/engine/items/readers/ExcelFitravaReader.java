package mx.com.metlife.tom.fitrava.engine.items.readers;

import java.io.File;
import java.io.InputStream;

import org.springframework.batch.item.excel.AbstractExcelItemReader;
import org.springframework.batch.item.excel.Sheet;
import org.springframework.core.io.FileSystemResource;

import mx.com.metlife.tom.fitrava.services.error.FitravaException;
import mx.com.metlife.tom.fitrava.services.utility.Constantes;
import mx.com.metlife.tom.fitrava.services.utility.excel.ExcelUtility;
import mx.com.metlife.tom.fitrava.services.utility.excel.ExcelXlsxBigFilesUtility;
import mx.com.metlife.tom.fitrava.services.utility.excel.ExcelXlsxUtility;
import mx.com.metlife.tom.fitrava.services.utility.excel.ExcelXmlUtility;

public class ExcelFitravaReader extends AbstractExcelItemReader<String[]> {

	private ExcelUtility excelUtility = null;
	private File excel = null;
	private int renglonesOmitir = 0;
	private String[] hojasOmitir = null;
	private boolean isXML = false;
	private String nombreHoja = null;
    
	public ExcelFitravaReader(File excel, Integer renglonesOmitir, String...hojasOmitir) throws FitravaException{
		super();
		this.excel = excel;
		this.renglonesOmitir = renglonesOmitir==null?0:renglonesOmitir.intValue();
		this.hojasOmitir = hojasOmitir;
		init();
	}

    public ExcelFitravaReader(String excelPath, Integer renglonesOmitir, String...hojasOmitir) throws FitravaException{
		super();
		this.excel = new File(excelPath);
		this.renglonesOmitir = renglonesOmitir==null?0:renglonesOmitir.intValue();
		this.hojasOmitir = hojasOmitir;
		init();
	}

    private void init() throws FitravaException {
    	FileSystemResource fileResource = null;
    	RowMapperImpl rowMapperImpl = null;
    	try {
    		if (excel.getName().toLowerCase().endsWith(Constantes.XLSX)) {
    			excelUtility = new ExcelXlsxUtility(excel, renglonesOmitir, hojasOmitir);
    		} else {
    			try {
    				excelUtility = new ExcelXlsxBigFilesUtility(excel, renglonesOmitir, hojasOmitir);
    			} catch (FitravaException e) {
    				excelUtility = new ExcelXmlUtility(excel, renglonesOmitir, hojasOmitir);
    				isXML = true;
    			}
    		}
    		fileResource = new FileSystemResource(excel);
    		rowMapperImpl = new RowMapperImpl(excelUtility);
    		setResource(fileResource);
    		setStrict(true);
    		setRowMapper(rowMapperImpl);
    	} catch (Exception e) {
    		throw new FitravaException("no se pudo crear el ExcelFitravaReader", e);
    	}
    }
    
    
    @Override
    protected Sheet getSheet(final int sheet) {
    	Sheet mySheet = isXML?
    			new MyXmlSheet((ExcelXmlUtility)excelUtility): 
    				new MySheet(excelUtility, sheet);
    	nombreHoja = mySheet.getName();
    	return mySheet;
    }
    
    public String getNombreHoja() {
		return nombreHoja;
	}

    @Override
    protected int getNumberOfSheets() {
    	return excelUtility.getNumeroHojas();
    }

    @Override
    protected void doClose() throws Exception {
        excelUtility.close();
        super.doClose();
    }

    @Override
    protected void openExcelFile(final InputStream inputStream) throws Exception {
    	
    }
    
    private class MySheet implements Sheet {
    	
    	private int sheetNum;
    	private ExcelUtility excelUtility = null;
    	
    	public MySheet(ExcelUtility excelUtility, int sheetNum) {
    		this.sheetNum = sheetNum;
    		this.excelUtility = excelUtility;
		}
    	
		@Override
		public int getNumberOfRows() {
			return excelUtility.getLastRowNum(sheetNum);
		}

		@Override
		public String getName() {
			return excelUtility.getHoja(sheetNum).getSheetName();
		}

		@Override
		public String[] getRow(int rowNumber) {
			return excelUtility.getRow(sheetNum, rowNumber);
		}
		
    }

    private class MyXmlSheet implements Sheet{
    	
    	private ExcelXmlUtility excelXmlUtility = null;
    	
    	public MyXmlSheet(ExcelXmlUtility excelXmlUtility) {
    		this.excelXmlUtility = excelXmlUtility;
		}
    	
		@Override
		public int getNumberOfRows() {
			return excelXmlUtility.getNumeroRows();
		}

		@Override
		public String getName() {
			return "Hoja 1";
		}

		@Override
		public String[] getRow(int rowNumber) {
			return excelXmlUtility.getRow(rowNumber);
		}
		
    }

}
