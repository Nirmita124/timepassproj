package mx.com.metlife.tom.fitrava.engine.validators;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.validator.ValidatingItemProcessor;
import org.springframework.batch.item.validator.ValidationException;

import mx.com.metlife.tom.fitrava.services.model.entity.TProcRec;


public class FitravaItemValidator2 extends ValidatingItemProcessor<List<TProcRec>> {
	private static final Logger log = LoggerFactory.getLogger(FitravaItemValidator2.class);

	public FitravaItemValidator2(int[] notNullIds) {
        super(
            item -> {
                log.info("Aqui se haría la validacion de los items, antes de la escritura: {} ", item.get(0));
                StringBuilder builder = new StringBuilder();
                for (int id: notNullIds) {
	                if (item.get(id)== null) {
	                	builder.append(String.format("El campo[%1$s] no puede ser null", id));
	                }
                }
                if (builder.length()>0) {
                	throw new ValidationException("NO PUEDE SER NULL, por ejemplo");
                }
            }
        );
        setFilter(true);
    }
}