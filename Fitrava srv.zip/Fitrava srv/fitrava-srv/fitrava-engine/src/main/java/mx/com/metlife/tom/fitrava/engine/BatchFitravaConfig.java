package mx.com.metlife.tom.fitrava.engine;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.dozer.DozerBeanMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.support.CompositeItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

import mx.com.metlife.tom.fitrava.engine.items.processors.FitravaItemProcessor;
import mx.com.metlife.tom.fitrava.engine.items.readers.FitravaCatalogoReader;
import mx.com.metlife.tom.fitrava.engine.items.readers.FitravaExcelItemReader;
import mx.com.metlife.tom.fitrava.engine.items.readers.FitravaItemReader;
import mx.com.metlife.tom.fitrava.engine.items.readers.FitravaTextItemReader;
import mx.com.metlife.tom.fitrava.engine.items.writers.FitravaCatalogoWriter;
import mx.com.metlife.tom.fitrava.engine.items.writers.FitravaItemWriterDataBase;
import mx.com.metlife.tom.fitrava.engine.items.writers.FitravaItemWriterFile;
import mx.com.metlife.tom.fitrava.engine.listener.JobCatalogoFitravaListener;
import mx.com.metlife.tom.fitrava.engine.listener.JobFilesFitravaListener;
import mx.com.metlife.tom.fitrava.engine.tasklets.RemoveSpringBatchHistoryTasklet;
import mx.com.metlife.tom.fitrava.services.dto.CatalogoFitravaDTO;
import mx.com.metlife.tom.fitrava.services.dto.InputDto;
import mx.com.metlife.tom.fitrava.services.model.entity.TProcRec;
import mx.com.metlife.tom.fitrava.services.utility.Constantes;
import mx.com.metlife.tom.fitrava.services.utility.UtilCommon;

@Component
@Configuration
@EnableBatchProcessing
public class BatchFitravaConfig {

	public static final Logger log = LoggerFactory.getLogger(BatchFitravaConfig.class);

	static final String FITRAVA_JOB = "fitravaJob";

	static final String CATALOGOS_JOB = "catalogosJob";
	
	static final String FITRAVA_CHUNK_STEP = "stepPrincipal";

	static final String CATALOGOS_CHUNK_STEP = "stepCargaCatalogos";
	
	static final String DELETE_TABLES_SPRING_BATCH = "deleteTablesSpringBatch";
	
	static final int CHUNK_FITRAVA_PARSER_SIZE = 1000;

	static final int CHUNK_FITRAVA_CATALOGOS_SIZE = 10000;
	
	@Autowired
	public JobBuilderFactory jobBuilderFactory;

	@Autowired
	public StepBuilderFactory stepBuilderFactory;

	@Bean
	public Job fitravaJob() {
		log.info("En el fitravaJob");		
		try {
			return jobBuilderFactory
					.get(FITRAVA_JOB) 
					.incrementer(new RunIdIncrementer()) 
					.start(stepPrincipal())
					.build();
		} catch (Exception e) {
			log.error("No se ha podido iniciar el JOB", e);
			return null;
		}
	}
	
	@Bean
	public Job catalogosJob() {
		log.info("En el catalogosJob");
		try {
			return jobBuilderFactory
					.get(CATALOGOS_JOB) 
					.incrementer(new RunIdIncrementer()) 
					.start(stepCargaCatalogos())
					.next(deleteTablesSpringBatch())
					.build();
		} catch (Exception e) {
			log.error("No se ha podido iniciar el JOB", e);
			return null;
		}
	}
	
	@SuppressWarnings("unchecked")
	@Bean
	public Step stepPrincipal() {
		log.info("En el stepPrincipal");
		return stepBuilderFactory
				.get(FITRAVA_CHUNK_STEP)
				.<InputDto, List<TProcRec>>chunk(CHUNK_FITRAVA_PARSER_SIZE)
				.reader(reader(null))
				.processor(processor())
				.writer(writer())
				.build();
	}

	@Bean
	public Step stepCargaCatalogos() {
		log.info("En el stepCargaCatalogos");
		return stepBuilderFactory
				.get(CATALOGOS_CHUNK_STEP)
				.<CatalogoFitravaDTO, CatalogoFitravaDTO>chunk(CHUNK_FITRAVA_CATALOGOS_SIZE)
				.reader(readerCatalogos(null))
				.writer(writerCatalogos())
				.build();
	}


	@StepScope
	@Bean
	public FitravaItemReader reader(@Value("#{jobParameters[file_path]}") String filePath) {
		log.info("En el reader de archivos regulares: {}", filePath);
		if (filePath != null && filePath.trim().length() > 0) { 
			File f = new File(filePath);
			if (f.exists()) {
				String ext = UtilCommon.getExtension(filePath);
				if (ext != null) {
					if (ext.equalsIgnoreCase(Constantes.XLS) || ext.equalsIgnoreCase(Constantes.XLSX)) {
						log.info("es EXCEL");
						return new FitravaExcelItemReader(filePath);
					}
					log.info("es TXT");
					return new FitravaTextItemReader(filePath);
				}
			}
		}
		return new FitravaItemReader(null);
	}

	@StepScope
	@Bean
	public FitravaCatalogoReader readerCatalogos(@Value("#{jobParameters[catalog_file_path]}") String filePath) {
		log.info("En el readerCatalogos: {}", filePath);
		if (filePath != null && filePath.trim().length() > 0) { 
			File f = new File(filePath);
			if (f.exists()) {
				return new FitravaCatalogoReader(filePath);
			}
		}
		return new FitravaCatalogoReader(null);
	}

	@StepScope
	@Bean
	public FitravaItemProcessor processor() {
		return new FitravaItemProcessor();
	}

	@StepScope
	@Bean
	public FitravaItemWriterFile writerToFile() {
		return new FitravaItemWriterFile();
	}

	@StepScope
	@Bean
	public FitravaItemWriterDataBase writerToDataBase() {
		return new FitravaItemWriterDataBase();
	}
	
	@StepScope
	@Bean
	public FitravaCatalogoWriter writerCatalogos() {
		return new FitravaCatalogoWriter();
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@StepScope
	@Bean
	public CompositeItemWriter writer() {
		List<ItemWriter<List<TProcRec>>> writers = new ArrayList<>();
		writers.add(writerToFile());
		writers.add(writerToDataBase());

		CompositeItemWriter itemWriter = new CompositeItemWriter();

		itemWriter.setDelegates(writers);
		
		return itemWriter;
	}

	@Bean
	public Job fitravaJob(JobFilesFitravaListener jobListener, Step stepPrincipal) {
		log.info("En el fitravaJob con listener: {}, and step {}", jobListener, stepPrincipal);
		return jobBuilderFactory.get(FITRAVA_JOB)
				.incrementer(new RunIdIncrementer())
				.listener(jobListener)
				.flow(stepPrincipal)
				.end()
				.build();
	}
	
	@Bean
	public Job catalogosJob(JobCatalogoFitravaListener jobListener, Step stepCargaCatalogos) {
		log.info("En el catalogosJob con listener {} and step {}", jobListener, stepCargaCatalogos);
		return jobBuilderFactory.get(CATALOGOS_JOB)
				.incrementer(new RunIdIncrementer())
				.listener(jobListener)
				.flow(stepCargaCatalogos)
				.end()
				.build();
	}
	
	@Bean
	public Step deleteTablesSpringBatch() {
		return stepBuilderFactory.get(DELETE_TABLES_SPRING_BATCH ).
				tasklet(getRemoveSpringBatchHistoryTasklet()).
				build();
	}
	
	@Bean
	public RemoveSpringBatchHistoryTasklet getRemoveSpringBatchHistoryTasklet() {
		return new RemoveSpringBatchHistoryTasklet();
	}
	 
	@Bean
	public DozerBeanMapper getMapper() {
		return new DozerBeanMapper();
	}

}
