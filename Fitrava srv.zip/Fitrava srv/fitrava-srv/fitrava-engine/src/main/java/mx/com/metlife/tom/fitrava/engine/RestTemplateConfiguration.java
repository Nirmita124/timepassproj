package mx.com.metlife.tom.fitrava.engine;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.util.CollectionUtils;
import org.springframework.web.client.RestTemplate;

@Configuration
public class RestTemplateConfiguration {
	
	@Primary
	@Bean(name = "restTemplateFitravaSrv")
	public RestTemplate getRestTemplateFitravaSrv() {
		RestTemplate template = new RestTemplate();
		List<ClientHttpRequestInterceptor> interceptors = template.getInterceptors();
		if(CollectionUtils.isEmpty(interceptors)) {
			interceptors = new ArrayList<>();
		}
		interceptors.add(new RestTemplateModifierInterceptor());
		template.setInterceptors(interceptors);
		template.setErrorHandler(new RestTemplateResponseErrorHandler());
		return template;
	}
}
