package mx.com.metlife.tom.fitrava.engine.items.writers;

import java.util.List;

import mx.com.metlife.tom.fitrava.services.model.entity.TProcRec;

public class FitravaItemWriterDataBase extends FitravaItemWriter {

	
	@Override
	public void write(List<? extends List<TProcRec>> items) throws Exception {
		log.info("En el write de base de datos");
		List<List<TProcRec>> sinErroresSinEspacios = getListaFinalSoloErrores(items);
		if (sinErroresSinEspacios != null) {
			for (List<TProcRec> item:sinErroresSinEspacios) {
				//log.info("--->{}<---" , item);
				auxCustomerRepository.saveAllTProcRecBatch(item);
				//tProcRecRepository.saveAll(item);
			}
		}
	}
}




