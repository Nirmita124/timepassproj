package mx.com.metlife.tom.fitrava.engine.items.writers;

import java.io.File;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.dozer.DozerBeanMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;

import mx.com.metlife.tom.fitrava.services.dto.CatalogoFitravaDTO;
import mx.com.metlife.tom.fitrava.services.dto.CatalogoFoneDTO;
import mx.com.metlife.tom.fitrava.services.dto.CatalogoIsssteDTO;
import mx.com.metlife.tom.fitrava.services.dto.CatalogoRamo74DTO;
import mx.com.metlife.tom.fitrava.services.dto.CatalogoRicsiDTO;
import mx.com.metlife.tom.fitrava.services.model.customer.AuxCustomerRepository;
import mx.com.metlife.tom.fitrava.services.model.entity.TExtCncpt74;
import mx.com.metlife.tom.fitrava.services.model.entity.TExtFone;
import mx.com.metlife.tom.fitrava.services.model.entity.TExtIssste;
import mx.com.metlife.tom.fitrava.services.model.entity.TExtRicsi;
import mx.com.metlife.tom.fitrava.services.utility.Constantes;
import mx.com.metlife.tom.fitrava.services.utility.UtilCommon;

@Scope(value = "step", proxyMode = ScopedProxyMode.INTERFACES)
@Component
public class FitravaCatalogoWriter implements ItemWriter<CatalogoFitravaDTO> {
	
	@Autowired
	private AuxCustomerRepository auxCustomerRepository;
	
	@Autowired
	private DozerBeanMapper mapper;
	
	static final Logger log = LoggerFactory.getLogger(FitravaCatalogoWriter.class);
	
	private List<String> excepciones = new ArrayList<>();
	private int linea = 0;
	private PrintWriter out = null;
	private File fileErrores = null;
	private int tipo = 0;
	
	@Override
	public void write(List<? extends CatalogoFitravaDTO> items) throws Exception {
		//write1(items);
		//write2(items);
		write3(items);
	}
	
	void write1(List<? extends CatalogoFitravaDTO> items) throws Exception {
		for (CatalogoFitravaDTO catalogoFitravaDTO: items) {
			linea++;
			try {
				if (catalogoFitravaDTO instanceof CatalogoRicsiDTO) {
					//Ricsi
					tipo = Constantes.ID_CATALOGO_RICSI;
					CatalogoRicsiDTO catalogoRicsiDTO = (CatalogoRicsiDTO) catalogoFitravaDTO;
	    			TExtRicsi tExtRicsi = mapper.map(catalogoRicsiDTO, TExtRicsi.class);
			    	auxCustomerRepository.saveCatalogoRicsi(tExtRicsi);		
	    			//log.info("tExtRicsi: --->{}<--", tExtRicsi);
	    		} else if (catalogoFitravaDTO instanceof CatalogoFoneDTO) {
	    			//Fone
	    			tipo = Constantes.ID_CATALOGO_FONE;
					CatalogoFoneDTO catalogoFoneDTO = (CatalogoFoneDTO) catalogoFitravaDTO;
	    			TExtFone tExtFone = mapper.map(catalogoFoneDTO, TExtFone.class);
	    			auxCustomerRepository.saveCatalogoFone(tExtFone);
	    			//log.info("tExtFone: --->{}<--", tExtFone);
	    		} else if (catalogoFitravaDTO instanceof CatalogoIsssteDTO) {
	    			//Issste
	    			tipo = Constantes.ID_CATALOGO_ISSSTE;
					CatalogoIsssteDTO catalogoIsssteDTO = (CatalogoIsssteDTO) catalogoFitravaDTO;
	    			TExtIssste tExtIssste = mapper.map(catalogoIsssteDTO, TExtIssste.class);
	    			auxCustomerRepository.saveCatalogoIssste(tExtIssste);
	    			//log.info("Issste: --->{}<--", tExtIssste);
	    		} else if (catalogoFitravaDTO instanceof CatalogoRamo74DTO) {
	    			//Ramo74
	    			tipo = Constantes.ID_CATALOGO_RAMO74;
					CatalogoRamo74DTO catalogoRamo74DTO = (CatalogoRamo74DTO) catalogoFitravaDTO;
	    			TExtCncpt74 tExtCncpt74 = mapper.map(catalogoRamo74DTO, TExtCncpt74.class);
	    			auxCustomerRepository.saveCatalogoConcepto74(tExtCncpt74);
	    			//log.info("Cncpt74: --->{}<--", tExtCncpt74);
	    		} else {
	    			addExcepcion(catalogoFitravaDTO.getError(), catalogoFitravaDTO.getLinea());
	    		}
			} catch (Exception e) {
				addExcepcion(e.toString(), linea);
			}
		}
		saveErrores();
	}

	void write2(List<? extends CatalogoFitravaDTO> items) throws Exception {
		if (items !=null && !items.isEmpty()) {
			List<String> errores = null;
			CatalogoFitravaDTO catalogoFitravaDTO  = null;
			for (int i = 0; i < items.size(); i++) { 
				catalogoFitravaDTO = items.get(i);
				if (catalogoFitravaDTO instanceof CatalogoRicsiDTO) {
					//Ricsi
					tipo = Constantes.ID_CATALOGO_RICSI;
					errores = auxCustomerRepository.saveAllRicsi(getListTExtRicsi(items));
					break;
				} else if (catalogoFitravaDTO instanceof CatalogoFoneDTO) {
					//Fone
					tipo = Constantes.ID_CATALOGO_FONE;
					errores = auxCustomerRepository.saveAllFone(getListTExtFone(items));
					break;
				} else if (catalogoFitravaDTO instanceof CatalogoIsssteDTO) {
					//Issste
					tipo = Constantes.ID_CATALOGO_ISSSTE;
					errores = auxCustomerRepository.saveAllIssste(getListTExtIssste(items));
					break;
				} else if (catalogoFitravaDTO instanceof CatalogoRamo74DTO) {
					//Ramo74
					tipo = Constantes.ID_CATALOGO_RAMO74;
					errores = auxCustomerRepository.saveAllConcepto74(getListTExtCncpt74(items));
					break;
				} else {
	    			addExcepcion(catalogoFitravaDTO.getError(), catalogoFitravaDTO.getLinea());
	    		}
			}
			if (errores != null && !errores.isEmpty()) {
				excepciones.addAll(errores);
			}
			saveErrores();
		}
	}
	
	void write3(List<? extends CatalogoFitravaDTO> items) throws Exception {
		if (items !=null && !items.isEmpty()) {
			CatalogoFitravaDTO catalogoFitravaDTO  = null;
			for (int i = 0; i < items.size(); i++) { 
				catalogoFitravaDTO = items.get(i);
				if (catalogoFitravaDTO instanceof CatalogoRicsiDTO) {
					//Ricsi
					tipo = Constantes.ID_CATALOGO_RICSI;
					auxCustomerRepository.saveAllRicsiBatch(getListTExtRicsi(items));
					break;
				} else if (catalogoFitravaDTO instanceof CatalogoFoneDTO) {
					//Fone
					tipo = Constantes.ID_CATALOGO_FONE;
					auxCustomerRepository.saveAllFoneBatch(getListTExtFone(items));
					break;
				} else if (catalogoFitravaDTO instanceof CatalogoIsssteDTO) {
					//Issste
					tipo = Constantes.ID_CATALOGO_ISSSTE;
					auxCustomerRepository.saveAllIsssteBatch(getListTExtIssste(items));
					break;
				} else if (catalogoFitravaDTO instanceof CatalogoRamo74DTO) {
					//Ramo74
					tipo = Constantes.ID_CATALOGO_RAMO74;
					auxCustomerRepository.saveAllConcepto74Batch(getListTExtCncpt74(items));
					break;
				} else {
	    			addExcepcion(catalogoFitravaDTO.getError(), catalogoFitravaDTO.getLinea());
	    		}
			}
			saveErrores();
		}
	}
	
	
	private void addExcepcion(String e, int i) {
		excepciones.add(String.format("No se pudo insertar el registro: %1$s, a causa de: %2$s", i, e));
	}
	
	private void saveErrores () {
		if (excepciones != null && !excepciones.isEmpty()) {
			if (fileErrores == null) {
				fileErrores = new File(Constantes.TEMP_ROOT_DIRECTORY_CATALOGOS, UtilCommon.getNameFileErrors(tipo));
			}
			try {
				out = new PrintWriter(fileErrores);
				for (String line: excepciones) {
					out.append(line);
					out.append("\n");
				}
			} catch  (Exception e) {
				log.error("no se pudo crear el archivo de errores", e);
			} finally {
				out.flush();
				out.close();
			}
		}
	}
	
	private List<TExtFone> getListTExtFone(List<? extends CatalogoFitravaDTO> items) {
		List<TExtFone> lista = new ArrayList<>();
		if (items != null && !items.isEmpty()) {
			for (CatalogoFitravaDTO catalogoFitravaDTO: items) {
				if (catalogoFitravaDTO instanceof CatalogoFoneDTO) {
					lista.add(mapper.map((CatalogoFoneDTO)catalogoFitravaDTO, TExtFone.class));
				} else {
					addExcepcion(catalogoFitravaDTO.getError(), catalogoFitravaDTO.getLinea());
				}
			}
		}
		return lista.stream().distinct().collect(Collectors.toList());
	}

	private List<TExtIssste> getListTExtIssste(List<? extends CatalogoFitravaDTO> items) {
		List<TExtIssste> lista = new ArrayList<>();
		if (items != null && !items.isEmpty()) {
			for (CatalogoFitravaDTO catalogoFitravaDTO: items) {
				if (catalogoFitravaDTO instanceof CatalogoIsssteDTO) {
					lista.add(mapper.map((CatalogoIsssteDTO)catalogoFitravaDTO, TExtIssste.class));
				} else {
					addExcepcion(catalogoFitravaDTO.getError(), catalogoFitravaDTO.getLinea());
				}
			}
		}
		return lista.stream().distinct().collect(Collectors.toList());
	}

	private List<TExtRicsi> getListTExtRicsi(List<? extends CatalogoFitravaDTO> items) {
		List<TExtRicsi> lista = new ArrayList<>();
		if (items != null && !items.isEmpty()) {
			for (CatalogoFitravaDTO catalogoFitravaDTO: items) {
				if (catalogoFitravaDTO instanceof CatalogoRicsiDTO) {
					lista.add(mapper.map((CatalogoRicsiDTO)catalogoFitravaDTO, TExtRicsi.class));
				} else {
					addExcepcion(catalogoFitravaDTO.getError(), catalogoFitravaDTO.getLinea());
				}
			}
		}
		return lista.stream().distinct().collect(Collectors.toList());
	}
	
	private List<TExtCncpt74> getListTExtCncpt74(List<? extends CatalogoFitravaDTO> items) {
		List<TExtCncpt74> lista = new ArrayList<>();
		if (items != null && !items.isEmpty()) {
			for (CatalogoFitravaDTO catalogoFitravaDTO: items) {
				if (catalogoFitravaDTO instanceof CatalogoRamo74DTO) {
					lista.add(mapper.map(catalogoFitravaDTO, TExtCncpt74.class));
				} else {
					addExcepcion(catalogoFitravaDTO.getError(), catalogoFitravaDTO.getLinea());
				}
			}
		}
		return lista.stream().distinct().collect(Collectors.toList());
	}

}
