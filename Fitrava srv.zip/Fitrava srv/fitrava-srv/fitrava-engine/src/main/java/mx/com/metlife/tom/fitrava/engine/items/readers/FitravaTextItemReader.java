package mx.com.metlife.tom.fitrava.engine.items.readers;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.mapping.PassThroughLineMapper;
import org.springframework.core.io.FileSystemResource;

import mx.com.metlife.tom.fitrava.services.dto.ColumnaDto;
import mx.com.metlife.tom.fitrava.services.dto.InputDto;
import mx.com.metlife.tom.fitrava.services.model.entity.TLayoutFld;
import mx.com.metlife.tom.fitrava.services.utility.UtilCommon;

public class FitravaTextItemReader extends FitravaItemReader {
	static final Logger log = LoggerFactory.getLogger(FitravaItemReader.class);

	private FlatFileItemReader<String> reader = null;

	public FitravaTextItemReader(String filePath) {
		super(filePath);
	}
	
    @Override
	public InputDto read() throws Exception {
    	initAll();
    	initReader();
    	if (reader != null ) {
			String line = reader.read();
			//log.info("-->{}<--", line);
			if (UtilCommon.isNull(line)) {
				return null;
			}
			return getInputDto(line);
		}
    	return null;
    }
    
    private InputDto getInputDto(String line) {
    	InputDto inputDto = getNewInputDto();
    	String[] renglon = null;
    	ColumnaDto[] columnasDTO = null;
    	if (getLayoutEntrada().getDlmtInd() != null && getLayoutEntrada().getDlmtInd() && getLayoutEntrada().getDlmtChar() != null) {
    		// es por parser
    		String parser = getLayoutEntrada().getDlmtChar();
    		renglon = StringUtils.splitPreserveAllTokens(line,parser);
    		columnasDTO = new ColumnaDto[renglon.length];
    		//log.info("renglon.length:{}, getLayoutEntrada().getNumColumns(){}", renglon.length, getLayoutEntrada().getNumColumns());
    		for(int i = 0; i < renglon.length; i++) {
    			//log.info("renglon[{}]: {}", i, renglon[i]);
    			columnasDTO[i] = new ColumnaDto(getCampos().get(i).getLayoutFldId(), renglon[i]);
    		}
    		inputDto.setRenglon(columnasDTO);
    		//System.out.println("---->" + inputDto );
    		return inputDto;
    	}
		//es por tamanio
		renglon = new String[getLayoutEntrada().getNumColumns()];
		columnasDTO = new ColumnaDto[renglon.length];
    	int i = 0;
		int cuenta = 0;
		for (TLayoutFld campo: getCampos()) {
			//log.info("campo: " + campo);
			renglon[i] = line.substring(cuenta, cuenta+=campo.getLayoutFldLnthNum());
			columnasDTO[i] = new ColumnaDto(getCampos().get(i).getLayoutFldId(), renglon[i]);
    		i++;
		}
		//log.info("columnasDTO-->" + UtilCommon.getArrayToString(columnasDTO));
		inputDto.setRenglon(columnasDTO);
		return inputDto;
    }
    
    
    private void initReader() {
    	if (reader == null && filePath != null) {
			final FileSystemResource fileResource = new FileSystemResource(filePath);
			reader = new FlatFileItemReader<>();
			reader.setResource(fileResource);
			if (getLayoutEntrada().getOmitInitRecCnt() != null && getLayoutEntrada().getOmitInitRecCnt() > 0) {
				reader.setLinesToSkip(getLayoutEntrada().getOmitInitRecCnt());
			}
			reader.setStrict(false);
			reader.setLineMapper(new PassThroughLineMapper());
			reader.setRecordSeparatorPolicy(new LineNullRecordSeparatorPolicy());
			reader.open(new ExecutionContext());
		}
    }
    
    
    

}
