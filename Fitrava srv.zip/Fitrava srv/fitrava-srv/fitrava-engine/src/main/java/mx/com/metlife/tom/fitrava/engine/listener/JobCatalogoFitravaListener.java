package mx.com.metlife.tom.fitrava.engine.listener;

import java.io.File;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import mx.com.metlife.tom.fitrava.services.error.FitravaPersistenceException;
import mx.com.metlife.tom.fitrava.services.model.customer.AuxCustomerRepository;
import mx.com.metlife.tom.fitrava.services.utility.Constantes;
import mx.com.metlife.tom.fitrava.services.utility.UtilCommon;

@Component
public class JobCatalogoFitravaListener extends JobFitravaListener {

	private static final Logger log = LoggerFactory.getLogger(JobCatalogoFitravaListener.class);

	@Autowired
	private AuxCustomerRepository auxCustomerRepository;
	
	@Override
	public void afterJob(JobExecution jobExecution) {
		if (jobExecution.getStatus().equals(BatchStatus.COMPLETED)) {
			String catalgoFilePath = jobExecution.getJobParameters().getString(Constantes.FILE_CATALOGO_PATH_RECIBE_CATALOGOS);
			if (catalgoFilePath != null && (new File(catalgoFilePath).exists())) {
				addTiempoEspera(catalgoFilePath, false);
				logTiempos(catalgoFilePath);
				File file = new File(catalgoFilePath);
				if (file.exists()) {
					//String nombreArchivo = file.getName();
					//Integer tipoCatalgo = UtilCommon.getTipoCatalgoByFileName(nombreArchivo);
					deleteFile(file);
					//posiblemente haya que actualizar algun estatus en algun lado para que ya se puedan utilizar
				}
			}
		}
		super.afterJob(jobExecution);
	}

	@Override
	public void beforeJob(JobExecution jobExecution) {
		log.info("Antes de que se ejecute el Job de carga de catalogos: {}", jobExecution);
		if (jobExecution.getStatus().equals(BatchStatus.STARTING) || jobExecution.getStatus().equals(BatchStatus.STARTED) ) {
			String catalgoFilePath = jobExecution.getJobParameters().getString(Constantes.FILE_CATALOGO_PATH_RECIBE_CATALOGOS);
			if (catalgoFilePath != null && (new File(catalgoFilePath).exists())) {
				addTiempoEspera(catalgoFilePath, true);
				File file = new File(catalgoFilePath);
				if (file.exists()) {
					Integer tipoCatalgo = UtilCommon.getTipoCatalgoByFileName(file.getName());
					try {
						auxCustomerRepository.deleteAllCatalogoByTipo(tipoCatalgo);
					} catch (FitravaPersistenceException e) {
						log.error(String.format("No fue posible actualizar el estatus del archivo: %1$s a EN_PROCESO", catalgoFilePath), e);
					}
				}
			}
			
		}
		super.beforeJob(jobExecution);
	}
}
