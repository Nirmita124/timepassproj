package mx.com.metlife.tom.fitrava.engine.items.readers;

import java.io.File;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemReader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

import mx.com.metlife.tom.fitrava.services.dto.InputDto;
import mx.com.metlife.tom.fitrava.services.error.FitravaException;
import mx.com.metlife.tom.fitrava.services.error.FitravaPersistenceException;
import mx.com.metlife.tom.fitrava.services.error.ValidationException;
import mx.com.metlife.tom.fitrava.services.model.customer.AuxCustomerRepository;
import mx.com.metlife.tom.fitrava.services.model.entity.TDatatyp;
import mx.com.metlife.tom.fitrava.services.model.entity.TLayout;
import mx.com.metlife.tom.fitrava.services.model.entity.TLayoutFld;
import mx.com.metlife.tom.fitrava.services.model.entity.TProcFileErr;
import mx.com.metlife.tom.fitrava.services.model.repository.TDatatypRepository;
import mx.com.metlife.tom.fitrava.services.model.repository.TLayoutFldRepository;
import mx.com.metlife.tom.fitrava.services.model.repository.TLayoutRepository;
import mx.com.metlife.tom.fitrava.services.model.repository.TProcFileErrRepository;
import mx.com.metlife.tom.fitrava.services.utility.Constantes;
import mx.com.metlife.tom.fitrava.services.utility.TextUtility;
import mx.com.metlife.tom.fitrava.services.utility.UtilCommon;
import mx.com.metlife.tom.fitrava.services.utility.excel.ValidatorExcel;

@Scope(value = "step", proxyMode = ScopedProxyMode.INTERFACES)
@Component
public class FitravaItemReader implements ItemReader<InputDto> {

	protected static final Logger log = LoggerFactory.getLogger(FitravaItemReader.class);
	
	@Autowired
	private AuxCustomerRepository auxCustomerRepository; 

	@Autowired
	private TLayoutRepository tLayoutRepository;
	
	@Autowired
	private TLayoutFldRepository tLayoutFldRepository;

	@Autowired
	private TDatatypRepository tDatatypRepository;

	@Autowired
	private TProcFileErrRepository tProcFileErrRepository; 
	
	
	protected File file;
	private InputDto inicial;
	private TLayout layoutEntrada;
	private List<TLayoutFld> campos;
	
	protected String filePath;

	public FitravaItemReader(String filePath) {
		this.filePath = filePath;
	}
	
	@Override
	public InputDto read() throws Exception {
		return null;
	}
	
	protected synchronized void initAll() throws ValidationException, FitravaException {
		if (inicial == null && filePath != null && !filePath.isEmpty() ) {
			file = new File(filePath);
			if (file.exists()) {
				log.info("==============================");
				log.info("Iniciando el proceso de lectura del archivo: {}", filePath);
				TProcFileErr tProcFileErr = null;
				String fileName = UtilCommon.getFileByPath(filePath);
				String dcn = UtilCommon.getDcnByFileName(fileName);
				if (UtilCommon.isNull(fileName)|| UtilCommon.isNull(dcn)) {
					throw new ValidationException("Nombre de archivo no valido");
				}
				try {
					fileName = fileName.substring(fileName.indexOf(dcn) + dcn.length()+1);
					inicial = auxCustomerRepository.createByDcnAndFileName(dcn, UtilCommon.getFileNameOriginal(fileName));
					log.info("El inicio de los datos son: {}", inicial);
				} catch (Exception e) {
					throw new FitravaException("No se pudo inicializar el InputDto de inicio");
				}
				if (inicial == null) {
					tProcFileErr = new TProcFileErr(dcn, fileName, 101, new Date(), "No se encuentra registrado el archivo en la BD");
					tProcFileErrRepository.save(tProcFileErr);
					throw new FitravaException("No se encuentra registrado el archivo en la BD");
				}
				layoutEntrada = getLayoutEntrada(inicial);
				campos = tLayoutFldRepository.findByLayoutId(layoutEntrada.getLayoutId());
				inicial.setEntradaLayoutId(layoutEntrada.getLayoutId());
				log.info("Obteniendo los datos de entrada, Layout de entrada: {}", layoutEntrada);
				log.info("Los campos del layout de entrada: {}", campos);
				try {
					log.info("Actualizando el TProcFile");
					boolean b = auxCustomerRepository.mergeTProcFileLayout(dcn, UtilCommon.getFileNameOriginal(fileName), layoutEntrada.getLayoutId());
					log.info("actualiza?: {}", b?"Sí":"No");
				} catch (FitravaPersistenceException e) {
					log.error("No se pudo actualizar el layot de entrada", e);
				}
				log.info("==============================");
			}
		}
	}
	

	public TLayout getLayoutEntrada() {
		return layoutEntrada;
	}

	public List<TLayoutFld> getCampos() {
		return campos;
	}

	protected InputDto getNewInputDto() {
		 Assert.notNull(inicial, "No debe ser null el inicial!");
 		 return new InputDto(inicial.getDcn(), inicial.getFlowId(), inicial.getFileNm(), inicial.getEntradaLayoutId(), inicial.getSalidaLayoutId());
    }
	   
	private TLayout getLayoutEntrada(InputDto inicial) throws FitravaException {
		List<TLayout> layoutsEntrada = null;
		TLayout layout = null;
		TProcFileErr tProcFileErr = null; 
		try {
			layoutsEntrada = tLayoutRepository.findByFlowId(inicial.getFlowId());
		} catch (Exception e) {
			log.error("Error al obtener el Layout de entrada", e);
			tProcFileErr = new TProcFileErr(inicial.getDcn(), inicial.getFileNm(), 104, new Date(), "Error al obtener el layout de entrada: " + e );
			tProcFileErrRepository.save(tProcFileErr);
			UtilCommon.deleteFile(file);
			throw new FitravaException(String.format("Error al obtener el layout de entrada, Error: %1$s", e.getCause()));
		}
		if (layoutsEntrada == null || layoutsEntrada.isEmpty()) {
			tProcFileErr = new TProcFileErr(inicial.getDcn(), inicial.getFileNm(), 105, new Date(), "No existe un layout que corresponda con el archivo de entrada");
			tProcFileErrRepository.save(tProcFileErr);
			UtilCommon.deleteFile(file);
			throw new FitravaException("No esta dado de alta ningun Layout de entrada que coincida con flujo registrado");
		}
		layout = getLayoutEntradaByFiles(layoutsEntrada);
		if (layout == null) { 
			tProcFileErr = new TProcFileErr(inicial.getDcn(), inicial.getFileNm(), 105, new Date(), "No existe un layout que corresponda con el archivo de entrada");
			tProcFileErrRepository.save(tProcFileErr);
			UtilCommon.deleteFile(file);
			throw new FitravaException("No coincide los layouts de entrada , con el archivo ingresado");
		}
		return layout;
	}
	
	private TLayout getLayoutEntradaByFiles(List<TLayout> layoutsEntrada) throws FitravaException {
		if (layoutsEntrada == null || layoutsEntrada.isEmpty() || file == null || file.length() == 0) {
			return null;
		}
		if (layoutsEntrada.size() == 1) {
			return layoutsEntrada.get(0);
		}
		String nombreArchivo = file.getName();
		String ext = nombreArchivo.toLowerCase().substring(nombreArchivo.lastIndexOf(Constantes.DOT)+1);
		Integer numeroColumnas = 0;
		List<TLayout> list = null;
		List<TDatatyp> tipos = null;
		if (ext.equalsIgnoreCase(Constantes.XLS) || ext.equalsIgnoreCase(Constantes.XLSX)) {
			log.info("Es un Excel: {}", file);
			list = new ArrayList<>();
			for (TLayout tl : layoutsEntrada) {
				numeroColumnas = ValidatorExcel.getNumeroColumnas(file, tl.getExtCd(), tl.getOmitInitRecCnt(), UtilCommon.getHojas(tl.getLstTLayoutXcel()));
				if (numeroColumnas == null || numeroColumnas == 0) {
					continue;
				}
				if (tl.getNumColumns().equals(numeroColumnas)) {
					list.add(tl);
				}
			}
			if (list.isEmpty()) {
				return null;
			}
			if (list.size() == 1) {
				return list.get(0);
			}
			for (TLayout tl: list) {
				tipos = tDatatypRepository.findAllByLayoutEntradaId(tl.getLayoutId());
				if(ValidatorExcel.validaTipos(tipos, file, tl.getOmitInitRecCnt(), UtilCommon.getHojas(tl.getLstTLayoutXcel()))) {
					return tl;
				}
			}
		} else { 
			log.info("Es un archivo de Texto: {}", file);
			TextUtility textUtility = new TextUtility(file);
			Integer longitudRenglon = textUtility.getLongitudRenglon();
			list = new ArrayList<>();
			for (TLayout tl : layoutsEntrada) {
				numeroColumnas = textUtility.getNumColumnas(tl.getDlmtChar());
				//log.info(Constantes.LOGGER_DOUBLE_BRACET, numeroColumnas, tl.getNumColumns());
				if (tl.getNumColumns().equals(numeroColumnas)) {
					list.add(tl);
				}
			}
			if (list.isEmpty()) {
				return null;
			}
			if (list.size() == 1) {
				return list.get(0);
			}
			layoutsEntrada = new ArrayList<>();
			layoutsEntrada.addAll(list);
			list = new ArrayList<>();
			for (TLayout tl : layoutsEntrada) {
				//log.info(Constantes.LOGGER_DOUBLE_BRACET, longitudRenglon, tl.getXpctRecLnthNum());
				if (tl.getXpctRecLnthNum().equals(longitudRenglon)) {
					list.add(tl);
				}
			}
			if (list.isEmpty()) {
				return null;
			}
			if (list.size() == 1) {
				return list.get(0);
			}
			//seguiria por tipo...
			/*for (TLayout tl: list) {
				tipos = tDatatypRepository.findAllByLayoutEntradaId(tl.getLayoutId());
				if(textUtility.validaTipos(tipos) {
					return tl;
				}
			}*/
		}
		return null;
	}

}
