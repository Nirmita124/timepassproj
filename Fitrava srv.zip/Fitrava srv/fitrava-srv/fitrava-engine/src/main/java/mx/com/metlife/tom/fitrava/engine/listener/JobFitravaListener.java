package mx.com.metlife.tom.fitrava.engine.listener;

import java.io.File;
import java.nio.file.Files;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.listener.JobExecutionListenerSupport;

import mx.com.metlife.tom.fitrava.services.utility.Constantes;
import mx.com.metlife.tom.fitrava.services.utility.UtilCommon;

public class JobFitravaListener extends JobExecutionListenerSupport {

	static final Logger log = LoggerFactory.getLogger(JobFitravaListener.class);

	private Map<String, Date> tiemposEsperaMap = new HashMap<>();


	protected void deleteFile(File file ) {
		log.info("Intentandoo borrar el archivo: {}", file);
		try {
			Thread.sleep(30000);//(1000*60)/2 = 30 segs
		} catch (InterruptedException e) {
			log.warn("No se completo el tiempo de espera: {} ", e);
			 Thread.currentThread().interrupt();
		} 
		File nuevo = null;
		if (file.exists()) {
			try {
				nuevo = new File(Constantes.TEMP_ROOT_DIRECTORY_DELETE, file.getName());
				Files.move(file.toPath(), nuevo.toPath());
			} catch (Exception e) {
				log.error(String.format("No fue posible mandar el archivo: %1$s a borrar", file), e);
			}
			if (nuevo != null && nuevo.exists()) {
				//log.info("1er intento");
				try {
					Files.delete(nuevo.toPath());
				} catch (Exception e) {
					log.error(String.format("No fue posible mandar el archivo: %1$s a borrar", nuevo), e);
				}
			}
//			if (nuevo.exists()) {
//				log.info("2do intento");
//				try {
//					Files.delete(nuevo.toPath());
//				} catch (Exception e) {
//					log.error(String.format("No fue posible mandar el archivo: %1$s a borrar", nuevo), e);
//				}
//			}
//			if (nuevo.exists()) {
//				log.info("3er intento");
//				try {
//					nuevo.delete();
//				} catch (Exception e) {
//					log.error(String.format("No fue posible mandar el archivo: %1$s a borrar", nuevo), e);
//				}
//			}
		}
	}
	
	protected void addTiempoEspera(String filePath, Boolean isInicio) {
		Date fecha = new Date();
		tiemposEsperaMap.put(filePath + (isInicio?"init":"fin"), fecha);
		log.info("==============================================");
		log.info("Ha {} el proceso carga del archivo: {}, Fecha: {}", isInicio?"Iniciado":"Terminado", filePath, UtilCommon.dateToString(fecha));
		log.info("==============================================");
		
	}
	
	protected void logTiempos(String filePath) {
		Date tiempoInicial = tiemposEsperaMap.get(filePath+"init");
		Date tiempoFinal = tiemposEsperaMap.get(filePath+"fin");
		long minutos = UtilCommon.getDiferencesMinutes(tiempoInicial, tiempoFinal);
		log.info("==============================================");
		log.info("El proceso carga del archivo: {}, temino", filePath);
		log.info("El proceso ha durado Horas: {}, Minutos: {}" , (int)minutos/60, (int)minutos%60);
		log.info("==============================================");
		tiemposEsperaMap.remove(filePath+"init");
		tiemposEsperaMap.remove(filePath+"fin");
	}
}
