package mx.com.metlife.tom.fitrava.engine.tasklets;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import mx.com.metlife.tom.fitrava.services.error.FitravaPersistenceException;
import mx.com.metlife.tom.fitrava.services.model.customer.AuxCustomerRepository;

@Component
public class RemoveSpringBatchHistoryTasklet implements Tasklet, InitializingBean {

	private static final Logger log = LoggerFactory.getLogger(RemoveSpringBatchHistoryTasklet.class);


	@Autowired
	private AuxCustomerRepository auxCustomerRepository;
	
	@Override
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) {
		log.info("Borrando el historico de las tablas BATCH");
		try {
			auxCustomerRepository.deleteSpringBatchHistory();
		} catch (FitravaPersistenceException e) {
			log.error("No se pudo borrar el historico del BATCH", e);
		}
        return RepeatStatus.FINISHED;
    }

	@Override
	public void afterPropertiesSet() throws Exception {
		log.info("NADA!");
	}

}