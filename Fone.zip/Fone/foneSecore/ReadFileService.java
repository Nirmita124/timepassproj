package mx.com.metlife.da.tom.services.service.foneSecore;

import static org.slf4j.LoggerFactory.getLogger;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.concurrent.atomic.AtomicInteger;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

@Service
public class ReadFileService{
	
	private static final Logger logger = getLogger(ReadFileService.class);

	static String[] data = { "ENTIDAD", "PROCESO_DE_NOMINA", "NOMBRE", "PRIMER_APELLIDO", "SEGUNDO_APELLIDO", "CURP",
			"RFC", "CLC", "CVE_CONCEPTO", "DESCRIPCION", "SUMADEIMPORTE"};
	
	@Autowired
	private ValidateDataText validateDataText;
		
		public File convertToFile(CommonsMultipartFile file) throws Exception {
			File convFile = new File(file.getOriginalFilename());
			logger.info("Started Executing readExcelFile Method");
			try {
				convFile.createNewFile();
				FileOutputStream fos = new FileOutputStream(convFile);
				BufferedOutputStream bout = new BufferedOutputStream(fos);
				bout.write(file.getBytes());
				bout.flush();
				bout.close();
				file = null;
			} catch (Exception e) {
				throw e;
			}

			return convFile;
		}

		@SuppressWarnings("resource")
		public ArrayList<String> readExcelFileData(File file, String fileName)	throws Exception {

			logger.info("Started Executing readExcelFile Method");
			HashMap<Integer, HashMap<EnumForInput, String>> arrayListOfSTringsBR1 = new HashMap();
			AtomicInteger lineNumber = new AtomicInteger();
			try {

				Workbook workbook = new XSSFWorkbook(file);
				/* Execution */
				Instant fileProcessStartBR = Instant.now();
				/*if (MethodUtility.getFileExtension(fileName).equalsIgnoreCase("xls")) {
					workbook = new HSSFWorkbook(new FileInputStream(file));	
				} else if (MethodUtility.getFileExtension(fileName).equalsIgnoreCase("xlsx")) {
					workbook = new XSSFWorkbook(file);
				}*/
				
				DataFormatter dataFormatter = new DataFormatter();
			
			for (Sheet sheetIterate : workbook) {
				int count = 0;
				for (Row row : sheetIterate) {
					count++;
					if (count != 1) {
						HashMap<EnumForInput, String> rowObject = new HashMap();
						short length = row.getLastCellNum();
						for (int i = 0; i < length; i++) {
							rowObject.put(EnumForInput.values()[i], dataFormatter.formatCellValue(row.getCell(i)));
						}
						System.out.println(rowObject);
						arrayListOfSTringsBR1.put(lineNumber.incrementAndGet(), rowObject);
						rowObject = null;
					}
				}
			}
				System.out.println(lineNumber+" "+arrayListOfSTringsBR1);
				System.out.println("read processing time Bufferedreader: "
						+ String.valueOf(Duration.between(fileProcessStartBR, Instant.now()).toMillis()));

			} catch (Exception e) {
				e.printStackTrace();
				System.out.println(e);
			}
			validateDataText = new ValidateDataText();
			return validateDataText.validateDataTexts(arrayListOfSTringsBR1, fileName, fileName);
			 
		}
		
	
public static void main(String[] args) throws Exception {
	ReadFileService readFileService = new ReadFileService();
	File file = new File("C:\\Users\\nirmde\\Desktop\\New Microsoft Excel Worksheet (2).xlsx");
	System.out.println(file.getName());
	ArrayList<String> returnMap = readFileService.readExcelFileData(file, file.getName());
}

}