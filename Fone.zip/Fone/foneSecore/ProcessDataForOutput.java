package mx.com.metlife.da.tom.services.service.foneSecore;


import static mx.com.metlife.da.tom.services.service.foneSecore.EnumForInput.ENTIDAD;
import static mx.com.metlife.da.tom.services.service.foneSecore.EnumForInput.NOMBRE;
import static mx.com.metlife.da.tom.services.service.foneSecore.EnumForInput.PROCESO_DE_NOMINA;
import static mx.com.metlife.da.tom.services.service.foneSecore.EnumForInput.PRIMER_APELLIDO;
import static mx.com.metlife.da.tom.services.service.foneSecore.EnumForInput.SEGUNDO_APELLIDO;
import static mx.com.metlife.da.tom.services.service.foneSecore.EnumForInput.CURP;
import static mx.com.metlife.da.tom.services.service.foneSecore.EnumForInput.RFC;
//import static mx.com.metlife.da.tom.services.service.foneSecore.EnumForInput.CTA_INTERBANCARIA;
import static mx.com.metlife.da.tom.services.service.foneSecore.EnumForInput.CLC;
import static mx.com.metlife.da.tom.services.service.foneSecore.EnumForInput.CVE_CONCEPTO;
import static mx.com.metlife.da.tom.services.service.foneSecore.EnumForInput.DESCRIPCION;
import static mx.com.metlife.da.tom.services.service.foneSecore.EnumForInput.SUMADEIMPORTE;

import java.util.ArrayList;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Locale;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Service;

import mx.com.metlife.da.tom.services.utility.writeUtils.WriteUtils;

/**
 * @author Capgemini
 * @since 08-07-2019
 */
@Service

@PropertySource({ "classpath:application.properties", "classpath:issteReadWrite.properties" })

public class ProcessDataForOutput {

	@Value("#{${outputLengthConstraint}}")
	private HashMap<String, String> outputLengthConstraint;

	@Autowired
	private FileWriteService fileWriteService;

	public Object processTextOutPut(HashMap<Integer, HashMap<EnumForInput, String>> hashMapOfRows, String parentFileName, String fileName) {

		fileWriteService = new FileWriteService();
		hashMapOfRows.forEach((lineNumber,row) -> {

			row.put(ENTIDAD, StringUtils.leftPad(row.get(ENTIDAD), 20)) ;
			row.put(PROCESO_DE_NOMINA, StringUtils.leftPad(row.get(PROCESO_DE_NOMINA), 7)) ;
			row.put(NOMBRE, StringUtils.leftPad(row.get(NOMBRE), 20)) ;
			row.put(PRIMER_APELLIDO, StringUtils.leftPad(row.get(PRIMER_APELLIDO), 20)) ;
			row.put(SEGUNDO_APELLIDO, StringUtils.leftPad(row.get(SEGUNDO_APELLIDO), 20)) ;
			row.put(CURP, StringUtils.leftPad(row.get(CURP), 18)) ;
			row.put(RFC, StringUtils.leftPad(row.get(RFC), 13)) ;
			//row.put(CTA_INTERBANCARIA, StringUtils.leftPad(row.get(CTA_INTERBANCARIA), 18)) ;
			row.put(CLC, StringUtils.leftPad(row.get(CLC), 5)) ;
			row.put(CVE_CONCEPTO, StringUtils.leftPad(row.get(CVE_CONCEPTO), 3)) ;
			row.put(DESCRIPCION, StringUtils.leftPad(row.get(DESCRIPCION), 80)) ;
			row.put(SUMADEIMPORTE, StringUtils.leftPad(row.get(SUMADEIMPORTE), 10)) ;
			
		});
		fileWriteService.writeToTextFile(hashMapOfRows,parentFileName,fileName);
		return hashMapOfRows;
	}
}