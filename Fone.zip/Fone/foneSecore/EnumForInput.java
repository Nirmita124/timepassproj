package mx.com.metlife.da.tom.services.service.foneSecore;

public enum EnumForInput {

	ENTIDAD, 
	PROCESO_DE_NOMINA, 
	NOMBRE, 
	PRIMER_APELLIDO, 
	SEGUNDO_APELLIDO, 
	CURP, 
	RFC,
	CLC,
	CVE_CONCEPTO, 
	DESCRIPCION,
	SUMADEIMPORTE
	
	

}
