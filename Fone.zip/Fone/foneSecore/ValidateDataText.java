/**
 * 
 */
package mx.com.metlife.da.tom.services.service.foneSecore;

import java.time.Duration;

import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import static mx.com.metlife.da.tom.services.service.foneSecore.EnumForInput.ENTIDAD;
import static mx.com.metlife.da.tom.services.service.foneSecore.EnumForInput.NOMBRE;
import static mx.com.metlife.da.tom.services.service.foneSecore.EnumForInput.PROCESO_DE_NOMINA;
import static mx.com.metlife.da.tom.services.service.foneSecore.EnumForInput.PRIMER_APELLIDO;
import static mx.com.metlife.da.tom.services.service.foneSecore.EnumForInput.SEGUNDO_APELLIDO;
import static mx.com.metlife.da.tom.services.service.foneSecore.EnumForInput.CURP;
import static mx.com.metlife.da.tom.services.service.foneSecore.EnumForInput.RFC;
/*import static mx.com.metlife.da.tom.services.service.foneSecore.EnumForInput.CTA_INTERBANCARIA;*/
import static mx.com.metlife.da.tom.services.service.foneSecore.EnumForInput.CLC;
import static mx.com.metlife.da.tom.services.service.foneSecore.EnumForInput.CVE_CONCEPTO;
import static mx.com.metlife.da.tom.services.service.foneSecore.EnumForInput.DESCRIPCION;
import static mx.com.metlife.da.tom.services.service.foneSecore.EnumForInput.SUMADEIMPORTE;


/**
 * @author Capgemini
 * @since 08-07-2019
 */

@Service
public class ValidateDataText {
	
	@Autowired
	private ProcessDataForOutput processOutput;
	
	@Autowired
	private FileWriteService fileWrite;
	
	public ArrayList<String> validateDataTexts(HashMap<Integer, HashMap<EnumForInput, String>> hashMapOfAllRows, String parentFileName, String fileName) throws Exception {

		processOutput = new ProcessDataForOutput();
		Instant validationStart = Instant.now();

//		ArrayList<HashMap<String, Object>> arrayListOfSTringsBR2 = new ArrayList<>();
		ExecutorService executor = Executors.newFixedThreadPool(12);
					
		List<Callable<Map<Integer, HashMap<EnumForInput, String>>>> callables = Arrays.asList(
				() -> {
					//ENTIDAD

					Stream<Entry<Integer, HashMap<EnumForInput, String>>> stream = hashMapOfAllRows.entrySet().stream();
					
					Map<Integer, HashMap<EnumForInput, String>> collect2 = stream.filter(row -> {
						return !StringUtils.isAlphanumericSpace(row.getValue().get(ENTIDAD));
					}).collect(Collectors.toMap(entry -> entry.getKey(), entry -> entry.getValue() ) );
					
					return collect2;
					},
				() -> {
					
					//PROCESO_DE_NOMINA
					Stream<Entry<Integer, HashMap<EnumForInput, String>>> stream = hashMapOfAllRows.entrySet().stream();
					
					Map<Integer, HashMap<EnumForInput, String>> collect2 = stream.filter(row -> {
						return !StringUtils.isAlphanumericSpace(row.getValue().get(PROCESO_DE_NOMINA));
					}).collect(Collectors.toMap(entry -> entry.getKey(), entry -> entry.getValue() ) );
					
					return collect2;
				}, 
				() -> {
					
					//NOMBRE
					Stream<Entry<Integer, HashMap<EnumForInput, String>>> stream = hashMapOfAllRows.entrySet().stream();
					
					Map<Integer, HashMap<EnumForInput, String>> collect2 = stream.filter(row -> {
						return !StringUtils.isAlphaSpace(row.getValue().get(NOMBRE));
					}).collect(Collectors.toMap(entry -> entry.getKey(), entry -> entry.getValue() ) );
					
					return collect2;
				}, 
				() -> {
					
					//PRIMER_APELLIDO
					Stream<Entry<Integer, HashMap<EnumForInput, String>>> stream = hashMapOfAllRows.entrySet().stream();
					
					Map<Integer, HashMap<EnumForInput, String>> collect2 = stream.filter(row -> {
						return !StringUtils.isAlphaSpace(row.getValue().get(PRIMER_APELLIDO));
					}).collect(Collectors.toMap(entry -> entry.getKey(), entry -> entry.getValue() ) );
					
					return collect2;
				}, 
				() -> {
					
					//SEGUNDO_APELLIDO
					// Overrided the StringUtils,isAlphaSpace to support the dot character in names
					Stream<Entry<Integer, HashMap<EnumForInput, String>>> stream = hashMapOfAllRows.entrySet().stream();
					
					Map<Integer, HashMap<EnumForInput, String>> collect2 = stream.filter(row -> {
						return !StringUtils.isAlphaSpace(row.getValue().get(SEGUNDO_APELLIDO));
					}).collect(Collectors.toMap(entry -> entry.getKey(), entry -> entry.getValue() ) );
					
					return collect2;
				}, 
				() -> {
					
					//CURP
					Stream<Entry<Integer, HashMap<EnumForInput, String>>> stream = hashMapOfAllRows.entrySet().stream();
					
					Map<Integer, HashMap<EnumForInput, String>> collect2 = stream.filter(row -> {
						return !StringUtils.isAlphanumericSpace(row.getValue().get(CURP));
					}).collect(Collectors.toMap(entry -> entry.getKey(), entry -> entry.getValue() ) );
					
					return collect2;
				}, 
				() -> {
					
					//RFC
					Stream<Entry<Integer, HashMap<EnumForInput, String>>> stream = hashMapOfAllRows.entrySet().stream();
					
					Map<Integer, HashMap<EnumForInput, String>> collect2 = stream.filter(row -> {
						return !StringUtils.isAlphanumericSpace(row.getValue().get(RFC));
					}).collect(Collectors.toMap(entry -> entry.getKey(), entry -> entry.getValue() ) );
					
					return collect2;
				}, 
				/*() -> {
					
					//CTA_INTERBANCARIA
					Stream<Entry<Integer, HashMap<EnumForInput, String>>> stream = hashMapOfAllRows.entrySet().stream();
					
					Map<Integer, HashMap<EnumForInput, String>> collect2 = stream.filter(row -> {
						return !StringUtils.isAlphanumericSpace(row.getValue().get(CTA_INTERBANCARIA));
					}).collect(Collectors.toMap(entry -> entry.getKey(), entry -> entry.getValue() ) );
					
					return collect2;
				},*/
				() -> {
					
					//CLC
					Stream<Entry<Integer, HashMap<EnumForInput, String>>> stream = hashMapOfAllRows.entrySet().stream();
					
					Map<Integer, HashMap<EnumForInput, String>> collect2 = stream.filter(row -> {
						return !StringUtils.isNumericSpace(row.getValue().get(CLC));
					}).collect(Collectors.toMap(entry -> entry.getKey(), entry -> entry.getValue() ) );
					
					return collect2;
				},
				() -> {
					
					//CVE_CONCEPTO
					Stream<Entry<Integer, HashMap<EnumForInput, String>>> stream = hashMapOfAllRows.entrySet().stream();
					
					Map<Integer, HashMap<EnumForInput, String>> collect2 = stream.filter(row -> {
						return !StringUtils.isNumericSpace(row.getValue().get(CVE_CONCEPTO));
					}).collect(Collectors.toMap(entry -> entry.getKey(), entry -> entry.getValue() ) );
					
					return collect2;
				},
				() -> {
					
					//DESCRIPCION
					Stream<Entry<Integer, HashMap<EnumForInput, String>>> stream = hashMapOfAllRows.entrySet().stream();
					
					Map<Integer, HashMap<EnumForInput, String>> collect2 = stream.filter(row -> {
						return !StringUtils.isAlphanumericSpace(row.getValue().get(DESCRIPCION));
					}).collect(Collectors.toMap(entry -> entry.getKey(), entry -> entry.getValue() ) );
					
					return collect2;
				},
				() -> {
					
					//IMPORTE
					Stream<Entry<Integer, HashMap<EnumForInput, String>>> stream = hashMapOfAllRows.entrySet().stream();
					
					Map<Integer, HashMap<EnumForInput, String>> collect2 = stream.filter(row -> {
						return !StringUtils.isNumericSpace(row.getValue().get(SUMADEIMPORTE));
					}).collect(Collectors.toMap(entry -> entry.getKey(), entry -> entry.getValue() ) );
					
					return collect2;
				});

		List<Future<Map<Integer, HashMap<EnumForInput, String>>>> futures = null;
		try {
			futures = executor.invokeAll(callables);
		} catch (InterruptedException e1) {
			e1.printStackTrace();
			throw new Exception("Error executing Executer service...");
		}
		ArrayList<String> listOfAllError = new ArrayList<>();
		HashMap<Integer, ArrayList<String>> errorInLine = new HashMap<>();
		

		for (int i = 0; i < futures.size(); i++) {
			switch (i) {
			case 0:
				try {
					Map<Integer, HashMap<EnumForInput, String>> list = futures.get(i).get();
					list.forEach((lineNumber, row) -> {
						ArrayList<String> errorLineandVal = new ArrayList<>();
						errorLineandVal.addAll(Arrays.asList("ENTIDAD is not numeric value", row.get(ENTIDAD)));
						errorInLine.put(lineNumber, errorLineandVal);
					});
				} catch (InterruptedException | ExecutionException e) {
					throw new Exception(e);
				}
				break;
			case 1:
				try {
					Map<Integer, HashMap<EnumForInput, String>> list = futures.get(i).get();
					list.forEach((lineNumber, row) -> {
						ArrayList<String> errorLineandVal = new ArrayList<>();
						errorLineandVal.addAll(Arrays.asList("PROCESO_DE_NOMINA is not numeric value", row.get(PROCESO_DE_NOMINA)));
						errorInLine.put(lineNumber, errorLineandVal);
					});
				} catch (InterruptedException | ExecutionException e) {
					throw new Exception(e);
				}
				break;
			case 2:
				try {
					Map<Integer, HashMap<EnumForInput, String>> list = futures.get(i).get();
					list.forEach((lineNumber, row) -> {
						ArrayList<String> errorLineandVal = new ArrayList<>();
						errorLineandVal.addAll(Arrays.asList("NOMBRE is not numeric value", row.get(NOMBRE)));
						errorInLine.put(lineNumber, errorLineandVal);
					});
				} catch (InterruptedException | ExecutionException e) {
					throw new Exception(e);
				}
				break;
			case 3:
				try {
					Map<Integer, HashMap<EnumForInput, String>> list = futures.get(i).get();
					list.forEach((lineNumber, row) -> {
						ArrayList<String> errorLineandVal = new ArrayList<>();
						errorLineandVal.addAll(Arrays.asList("PRIMER_APELLIDO is not numeric value", row.get(PRIMER_APELLIDO)));
						errorInLine.put(lineNumber, errorLineandVal);
					});
				} catch (InterruptedException | ExecutionException e) {
					throw new Exception(e);
				}
				break;
			case 4:
				try {
					Map<Integer, HashMap<EnumForInput, String>> list = futures.get(i).get();
					list.forEach((lineNumber, row) -> {
						ArrayList<String> errorLineandVal = new ArrayList<>();
						errorLineandVal.addAll(Arrays.asList("SEGUNDO_APELLIDO is not numeric value", row.get(SEGUNDO_APELLIDO)));
						errorInLine.put(lineNumber, errorLineandVal);
					});
				} catch (InterruptedException | ExecutionException e) {
					throw new Exception(e);
				}
				break;
			case 5:
				try {
					Map<Integer, HashMap<EnumForInput, String>> list = futures.get(i).get();
					list.forEach((lineNumber, row) -> {
						ArrayList<String> errorLineandVal = new ArrayList<>();
						errorLineandVal.addAll(Arrays.asList("CURP is not numeric value", row.get(CURP)));
						errorInLine.put(lineNumber, errorLineandVal);
					});
				} catch (InterruptedException | ExecutionException e) {
					throw new Exception(e);
				}
				break;
			case 6:
				try {
					Map<Integer, HashMap<EnumForInput, String>> list = futures.get(i).get();
					list.forEach((lineNumber, row) -> {
						ArrayList<String> errorLineandVal = new ArrayList<>();
						errorLineandVal.addAll(Arrays.asList("RFC is not numeric value", row.get(RFC)));
						errorInLine.put(lineNumber, errorLineandVal);
					});
				} catch (InterruptedException | ExecutionException e) {
					throw new Exception(e);
				}
				break;
			/*case 7:
				try {
					Map<Integer, HashMap<EnumForInput, String>> list = futures.get(i).get();
					list.forEach((lineNumber, row) -> {
						ArrayList<String> errorLineandVal = new ArrayList<>();
						errorLineandVal.addAll(Arrays.asList("Concepto is not numeric value", row.get(CTA_INTERBANCARIA)));
						errorInLine.put(lineNumber, errorLineandVal);
					});
				} catch (InterruptedException | ExecutionException e) {
					throw new Exception(e);
				}
				break;*/
			case 7:
				try {
					Map<Integer, HashMap<EnumForInput, String>> list = futures.get(i).get();
					list.forEach((lineNumber, row) -> {
						ArrayList<String> errorLineandVal = new ArrayList<>();
						errorLineandVal.addAll(Arrays.asList("RFC is not numeric value", row.get(CLC)));
						errorInLine.put(lineNumber, errorLineandVal);
					});
				} catch (InterruptedException | ExecutionException e) {
					throw new Exception(e);
				}
				break;
			case 8:
				try {
					Map<Integer, HashMap<EnumForInput, String>> list = futures.get(i).get();
					list.forEach((lineNumber, row) -> {
						ArrayList<String> errorLineandVal = new ArrayList<>();
						errorLineandVal.addAll(Arrays.asList("CVE_CONCEPTO is not numeric value", row.get(CVE_CONCEPTO)));
						errorInLine.put(lineNumber, errorLineandVal);
					});
				} catch (InterruptedException | ExecutionException e) {
					throw new Exception(e);
				}
				break;
			case 9:
				try {
					Map<Integer, HashMap<EnumForInput, String>> list = futures.get(i).get();
					list.forEach((lineNumber, row) -> {
						ArrayList<String> errorLineandVal = new ArrayList<>();
						errorLineandVal.addAll(Arrays.asList("DESCRIPCION is not numeric value", row.get(DESCRIPCION)));
						errorInLine.put(lineNumber, errorLineandVal);
					});
				} catch (InterruptedException | ExecutionException e) {
					throw new Exception(e);
				}
				break;
			case 10:
				try {
					Map<Integer, HashMap<EnumForInput, String>> list = futures.get(i).get();
					list.forEach((lineNumber, row) -> {
						ArrayList<String> errorLineandVal = new ArrayList<>();
						errorLineandVal.addAll(Arrays.asList("SUMADEIMPORTE is not numeric value", row.get(SUMADEIMPORTE)));
						errorInLine.put(lineNumber, errorLineandVal);
					});
				} catch (InterruptedException | ExecutionException e) {
					throw new Exception(e);
				}
				break;
			}
		}

		try {
			executor.shutdown();
			executor.awaitTermination(20, TimeUnit.MILLISECONDS);
		} catch (InterruptedException e) {
			e.printStackTrace();
		} finally {
			if (!executor.isTerminated()) {
				System.out.println("NOt terminated");
			}
			executor.shutdownNow();
		}

		System.out.println(
				"Validation time : " + String.valueOf(Duration.between(validationStart, Instant.now()).toMillis()));
		
		/*if ( errorInLine.isEmpty() ) {
			processOutput.processTextOutPut(hashMapOfAllRows, fileName);
		}*/
		if (errorInLine.isEmpty()) {
			System.out.println("Validation complete for file: {}"+ fileName);
			processOutput.processTextOutPut(hashMapOfAllRows, parentFileName, fileName);
		} //else {
			fileWrite = new FileWriteService();
			System.out.println("Error in file {}"+fileName);
			fileWrite.processAndWriteErrorCSV(errorInLine, fileName);
			listOfAllError.add("Error File Generated");
		//}
		return listOfAllError;
	}

}


